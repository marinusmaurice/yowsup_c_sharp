namespace yowsup.env
{

    public static class @__init__ {
    }
}
