namespace yowsup.env
{

    using YowsupEnv = env.YowsupEnv;

    using System.Linq;

    public static class env_android {
        
        public class AndroidYowsupEnv
            : YowsupEnv {
            
            //public bool _AXOLOTL;
            
            //public string _BUILD_VERSION;
            
            //public string _DEVICE_NAME;
            
            //public string _KEY;
            
            //public string _MANUFACTURER;
            
            //public string _MD5_CLASSES;
            
            //public string _OS_NAME;
            
            //public string _OS_VERSION;
            
            //public string _SIGNATURE;
            
            //public string _VERSION;
            
            public string _SIGNATURE = "MIIDMjCCAvCgAwIBAgIETCU2pDALBgcqhkjOOAQDBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCkNhbGlmb3JuaWExFDASBgNVBAcTC1NhbnRhIENsYXJhMRYwFAYDVQQKEw1XaGF0c0FwcCBJbmMuMRQwEgYDVQQLEwtFbmdpbmVlcmluZzEUMBIGA1UEAxMLQnJpYW4gQWN0b24wHhcNMTAwNjI1MjMwNzE2WhcNNDQwMjE1MjMwNzE2WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTEUMBIGA1UEBxMLU2FudGEgQ2xhcmExFjAUBgNVBAoTDVdoYXRzQXBwIEluYy4xFDASBgNVBAsTC0VuZ2luZWVyaW5nMRQwEgYDVQQDEwtCcmlhbiBBY3RvbjCCAbgwggEsBgcqhkjOOAQBMIIBHwKBgQD9f1OBHXUSKVLfSpwu7OTn9hG3UjzvRADDHj+AtlEmaUVdQCJR+1k9jVj6v8X1ujD2y5tVbNeBO4AdNG/yZmC3a5lQpaSfn+gEexAiwk+7qdf+t8Yb+DtX58aophUPBPuD9tPFHsMCNVQTWhaRMvZ1864rYdcq7/IiAxmd0UgBxwIVAJdgUI8VIwvMspK5gqLrhAvwWBz1AoGBAPfhoIXWmz3ey7yrXDa4V7l5lK+7+jrqgvlXTAs9B4JnUVlXjrrUWU/mcQcQgYC0SRZxI+hMKBYTt88JMozIpuE8FnqLVHyNKOCjrh4rs6Z1kW6jfwv6ITVi8ftiegEkO8yk8b6oUZCJqIPf4VrlnwaSi2ZegHtVJWQBTDv+z0kqA4GFAAKBgQDRGYtLgWh7zyRtQainJfCpiaUbzjJuhMgo4fVWZIvXHaSHBU1t5w//S0lDK2hiqkj8KpMWGywVov9eZxZy37V26dEqr/c2m5qZ0E+ynSu7sqUD7kGx/zeIcGT0H+KAVgkGNQCo5Uc0koLRWYHNtYoIvt5R3X6YZylbPftF/8ayWTALBgcqhkjOOAQDBQADLwAwLAIUAKYCp0d6z4QQdyN74JDfQ2WCyi8CFDUM4CaNB+ceVXdKtOrNTQcc0e+t";
            
            public string _MD5_CLASSES = "/QhoCBMppKpKQumhTC8kcQ==";
            
            public string _KEY = "eQV5aq/Cg63Gsq1sshN9T3gh+UUp0wIw0xgHYT1bnCjEqOJQKCRrWxdAe2yvsDeCJL+Y4G3PRD2HUF7oUgiGo8vGlNJOaux26k+A2F3hj8A=";
            
            public string _VERSION = "2.19.244";
            
            public string _OS_NAME = "Android";
            
            public string _OS_VERSION = "8.0.0";
            
            public string _DEVICE_NAME = "star2lte";
            
            public string _MANUFACTURER = "samsung";
            
            public string _BUILD_VERSION = "star2ltexx-user 8.0.0 R16NW G965FXXU1ARCC release-keys";
            
            public bool _AXOLOTL = true;
            
            public virtual object getVersion() {
                return this.@__class__._VERSION;
            }
            
            public virtual object getOSName() {
                return this.@__class__._OS_NAME;
            }
            
            public virtual object getOSVersion() {
                return this.@__class__._OS_VERSION;
            }
            
            public virtual object getDeviceName() {
                return this.@__class__._DEVICE_NAME;
            }
            
            public virtual object getBuildVersion() {
                return this.@__class__._BUILD_VERSION;
            }
            
            public virtual object getManufacturer() {
                return this.@__class__._MANUFACTURER;
            }
            
            public virtual object isAxolotlEnabled() {
                return this.@__class__._AXOLOTL;
            }
            
            public virtual object getToken(object phoneNumber) {
                var keyDecoded = bytearray(base64.b64decode(this.@__class__._KEY));
                var sigDecoded = base64.b64decode(this.@__class__._SIGNATURE);
                var clsDecoded = base64.b64decode(this.@__class__._MD5_CLASSES);
                var data = sigDecoded + clsDecoded + phoneNumber.encode();
                var opad = bytearray();
                var ipad = bytearray();
                foreach (var i in Enumerable.Range(0, 64 - 0)) {
                    opad.append(0x5C ^ keyDecoded[i]);
                    ipad.append(0x36 ^ keyDecoded[i]);
                }
                var hash = hashlib.sha1();
                var subHash = hashlib.sha1();
                try {
                    subHash.update(ipad + data);
                    hash.update(opad + subHash.digest());
                } catch (TypeError) {
                    subHash.update(bytes(ipad + data));
                    hash.update(bytes(opad + subHash.digest()));
                }
                var result = base64.b64encode(hash.digest());
                return result;
            }
        }
    }
}
