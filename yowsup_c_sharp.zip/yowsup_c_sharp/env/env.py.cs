

namespace yowsup.env
{

    using with_metaclass = six.with_metaclass;

    using System.Collections.Generic;

    using System;

    using System.Linq;

    public static class env {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public static string DEFAULT = "android";
        
        public class YowsupEnvType
            : abc.ABCMeta {
            
            public string @__name__;
            
            public static object @__init__(object cls, object name, object bases, object dct) {
                if (name != "YowsupEnv") {
                    YowsupEnv.registerEnv(cls);
                }
                super(YowsupEnvType, cls).@__init__(name, bases, dct);
            }
        }
        
        public class YowsupEnv
            : with_metaclass(YowsupEnvType,object) {
            
            public object @__CURR;
            
            public Dictionary<object, object> @__ENVS;
            
            public YowsupEnvType @__metaclass__;
            
            public string _USERAGENT_STRING;
            
            public YowsupEnvType @__metaclass__ = YowsupEnvType;
            
            public Dictionary<object, object> @__ENVS = new Dictionary<object, object> {
            };
            
            public None @__CURR = null;
            
            public string _USERAGENT_STRING = "WhatsApp/{WHATSAPP_VERSION} {OS_NAME}/{OS_VERSION} Device/{MANUFACTURER}-{DEVICE_NAME}";
            
            [classmethod]
            public static object registerEnv(object cls, object envCls) {
                var envName = envCls.@__name__.lower().replace("yowsupenv", "");
                cls.@__ENVS[envName] = envCls;
                logger.debug(String.Format("registered env %s => %s", envName, envCls));
            }
            
            [classmethod]
            public static object setEnv(object cls, object envName) {
                if (!cls.@__ENVS.Contains(envName)) {
                    throw new ValueError(String.Format("%s env does not exist", envName));
                }
                logger.debug(String.Format("Current env changed to %s ", envName));
                cls.@__CURR = cls.@__ENVS[envName]();
            }
            
            [classmethod]
            public static object getEnv(object cls, object envName) {
                if (!cls.@__ENVS.Contains(envName)) {
                    throw new ValueError(String.Format("%s env does not exist", envName));
                }
                return cls.@__ENVS[envName]();
            }
            
            [classmethod]
            public static object getRegisteredEnvs(object cls) {
                return cls.@__ENVS.keys().ToList();
            }
            
            // 
            //         :rtype: YowsupEnv
            //         
            [classmethod]
            public static object getCurrent(object cls) {
                if (cls.@__CURR == null) {
                    var env = DEFAULT;
                    var envs = cls.getRegisteredEnvs();
                    if (!envs.Contains(env)) {
                        env = envs[0];
                    }
                    logger.debug(String.Format("Env not set, setting it to %s", env));
                    cls.setEnv(env);
                }
                return cls.@__CURR;
            }
            
            [abc.abstractmethod]
            public virtual object getToken(object phoneNumber) {
            }
            
            [abc.abstractmethod]
            public virtual object getVersion() {
            }
            
            [abc.abstractmethod]
            public virtual object getOSVersion() {
            }
            
            [abc.abstractmethod]
            public virtual object getOSName() {
            }
            
            [abc.abstractmethod]
            public virtual object getDeviceName() {
            }
            
            [abc.abstractmethod]
            public virtual object getManufacturer() {
            }
            
            public virtual object getBuildVersion() {
            }
            
            public virtual object getUserAgent() {
                return this.@__class__._USERAGENT_STRING.format(WHATSAPP_VERSION: this.getVersion(), OS_NAME: this.getOSName(), OS_VERSION: this.getOSVersion(), MANUFACTURER: this.getManufacturer(), DEVICE_NAME: this.getDeviceName());
            }
        }
    }
}
