namespace yowsup.demos.cli
{

    using YowStackBuilder = yowsup.stacks.YowStackBuilder;

    using YowsupCliLayer = layer.YowsupCliLayer;

    using PROP_IDENTITY_AUTOTRUST = yowsup.layers.axolotl.props.PROP_IDENTITY_AUTOTRUST;

    public static class stack {
        
        public class YowsupCliStack
            : object {
            
            public object _stack;
            
            public YowsupCliStack(object profile) {
                var stackBuilder = YowStackBuilder();
                this._stack = stackBuilder.pushDefaultLayers().push(YowsupCliLayer).build();
                this._stack.setProfile(profile);
                this._stack.setProp(PROP_IDENTITY_AUTOTRUST, true);
            }
            
            public virtual object set_prop(object prop, object val) {
                this._stack.setProp(prop, val);
            }
            
            public virtual object start() {
                Console.WriteLine("Yowsup Cli client\n==================\nType /help for available commands\n");
                this._stack.boadcastEvent(YowLayerEvent(YowsupCliLayer.EVENT_START));
                try {
                    this._stack.loop();
                } catch (KeyboardInterrupt) {
                    Console.WriteLine("\nYowsdown");
                    sys.exit(0);
                }
            }
        }
    }
}
