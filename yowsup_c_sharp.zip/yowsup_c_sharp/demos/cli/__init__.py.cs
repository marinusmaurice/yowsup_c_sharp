namespace yowsup.demos.cli
{

    public static class @__init__ {
    }
}
