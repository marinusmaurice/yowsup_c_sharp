namespace yowsup.demos.cli {
    
    using Cli = cli.Cli;
    
    using clicmd = cli.clicmd;
    
    using YowInterfaceLayer = yowsup.layers.interface.YowInterfaceLayer;
    
    using ProtocolEntityCallback = yowsup.layers.interface.ProtocolEntityCallback;
    
    using YowLayerEvent = yowsup.layers.YowLayerEvent;
    
    using EventCallback = yowsup.layers.EventCallback;
    
    using YowNetworkLayer = yowsup.layers.network.YowNetworkLayer;
    
    using sys;
    
    using YowConstants = yowsup.common.YowConstants;
    
    using datetime;
    
    using time;
    
    using os;
    
    using logging;
    
    using threading;
    
    using base64;
    
    using MediaUploader = yowsup.layers.protocol_media.mediauploader.MediaUploader;
    
    using Jid = yowsup.common.tools.Jid;
    
    using PILOptionalModule = yowsup.common.optionalmodules.PILOptionalModule;
    
    using GetKeysIqProtocolEntity = yowsup.layers.axolotl.protocolentities.iq_key_get.GetKeysIqProtocolEntity;
    
    using System.Collections.Generic;
    
    using System;
    
    using System.Linq;
    
    public static class layer {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class YowsupCliLayer
            : Cli, YowInterfaceLayer {
            
            public int ACCOUNT_DEL_WARNINGS;
            
            public int accountDelWarnings;
            
            public bool connected;
            
            public int DISCONNECT_ACTION_EXIT;
            
            public int DISCONNECT_ACTION_PROMPT;
            
            public object disconnectAction;
            
            public string EVENT_LOGIN;
            
            public string EVENT_SENDANDEXIT;
            
            public string EVENT_START;
            
            public string FAIL_OPT_AXOLOTL;
            
            public string FAIL_OPT_PILLOW;
            
            public Dictionary<object, object> jidAliases;
            
            public string MESSAGE_FORMAT;
            
            public string PROP_CONTACT_JID;
            
            public string PROP_RECEIPT_AUTO;
            
            public string PROP_RECEIPT_KEEPALIVE;
            
            public bool sendRead;
            
            public bool sendReceipts;
            
            public None username;
            
            public string PROP_RECEIPT_AUTO = "org.openwhatsapp.yowsup.prop.cli.autoreceipt";
            
            public string PROP_RECEIPT_KEEPALIVE = "org.openwhatsapp.yowsup.prop.cli.keepalive";
            
            public string PROP_CONTACT_JID = "org.openwhatsapp.yowsup.prop.cli.contact.jid";
            
            public string EVENT_LOGIN = "org.openwhatsapp.yowsup.event.cli.login";
            
            public string EVENT_START = "org.openwhatsapp.yowsup.event.cli.start";
            
            public string EVENT_SENDANDEXIT = "org.openwhatsapp.yowsup.event.cli.sendandexit";
            
            public string MESSAGE_FORMAT = "[%s(%s)]:[%s]\t %s";
            
            public string FAIL_OPT_PILLOW = "No PIL library installed, try install pillow";
            
            public string FAIL_OPT_AXOLOTL = "axolotl is not installed, try install python-axolotl";
            
            public int DISCONNECT_ACTION_PROMPT = 0;
            
            public int DISCONNECT_ACTION_EXIT = 1;
            
            public int ACCOUNT_DEL_WARNINGS = 4;
            
            public YowsupCliLayer() {
                YowInterfaceLayer.@__init__(this);
                this.accountDelWarnings = 0;
                this.connected = false;
                this.username = null;
                this.sendReceipts = true;
                this.sendRead = true;
                this.disconnectAction = this.@__class__.DISCONNECT_ACTION_PROMPT;
                //add aliases to make it user to use commands. for example you can then do:
                // /message send foobar "HI"
                // and then it will get automaticlaly mapped to foobar's jid
                this.jidAliases = new Dictionary<object, object> {
                };
            }
            
            public virtual object aliasToJid(object calias) {
                foreach (var _tup_1 in this.jidAliases.items()) {
                    var alias = _tup_1.Item1;
                    var ajid = _tup_1.Item2;
                    if (calias.lower() == alias.lower()) {
                        return Jid.normalize(ajid);
                    }
                }
                return Jid.normalize(calias);
            }
            
            public virtual object jidToAlias(object jid) {
                foreach (var _tup_1 in this.jidAliases.items()) {
                    var alias = _tup_1.Item1;
                    var ajid = _tup_1.Item2;
                    if (ajid == jid) {
                        return alias;
                    }
                }
                return jid;
            }
            
            [EventCallback(EVENT_START)]
            public virtual object onStart(object layerEvent) {
                this.startInput();
                return true;
            }
            
            [EventCallback(YowNetworkLayer.EVENT_STATE_DISCONNECTED)]
            public virtual object onStateDisconnected(object layerEvent) {
                this.output(String.Format("Disconnected: %s", layerEvent.getArg("reason")));
                if (this.disconnectAction == this.@__class__.DISCONNECT_ACTION_PROMPT) {
                    this.connected = false;
                    this.notifyInputThread();
                } else {
                    os._exit(os.EX_OK);
                }
            }
            
            public virtual object assertConnected() {
                if (this.connected) {
                    return true;
                } else {
                    this.output("Not connected", tag: "Error", prompt: false);
                    return false;
                }
            }
            
            //######### PRESENCE ###############
            [clicmd("Set presence name")]
            public virtual object presence_name(object name) {
                if (this.assertConnected()) {
                    var entity = PresenceProtocolEntity(name: name);
                    this.toLower(entity);
                }
            }
            
            [clicmd("Set presence as available")]
            public virtual object presence_available() {
                if (this.assertConnected()) {
                    var entity = AvailablePresenceProtocolEntity();
                    this.toLower(entity);
                }
            }
            
            [clicmd("Set presence as unavailable")]
            public virtual object presence_unavailable() {
                if (this.assertConnected()) {
                    var entity = UnavailablePresenceProtocolEntity();
                    this.toLower(entity);
                }
            }
            
            [clicmd("Unsubscribe from contact's presence updates")]
            public virtual object presence_unsubscribe(object contact) {
                if (this.assertConnected()) {
                    var entity = UnsubscribePresenceProtocolEntity(this.aliasToJid(contact));
                    this.toLower(entity);
                }
            }
            
            [clicmd("Subscribe to contact's presence updates")]
            public virtual object presence_subscribe(object contact) {
                if (this.assertConnected()) {
                    var entity = SubscribePresenceProtocolEntity(this.aliasToJid(contact));
                    this.toLower(entity);
                }
            }
            
            //########## END PRESENCE #############
            //########## ib #######################
            [clicmd("Send clean dirty")]
            public virtual object ib_clean(object dirtyType) {
                if (this.assertConnected()) {
                    var entity = CleanIqProtocolEntity("groups", YowConstants.DOMAIN);
                    this.toLower(entity);
                }
            }
            
            [clicmd("Ping server")]
            public virtual object ping() {
                if (this.assertConnected()) {
                    var entity = PingIqProtocolEntity(to: YowConstants.DOMAIN);
                    this.toLower(entity);
                }
            }
            
            //#####################################
            //###### contacts/ profiles ####################
            [clicmd("Set status text")]
            public virtual object profile_setStatus(object text) {
                if (this.assertConnected()) {
                    var entity = SetStatusIqProtocolEntity(text);
                    this._sendIq(entity, onSuccess, onError);
                }
                Func<object, object, object> onSuccess = (resultIqEntity,originalIqEntity) => {
                    this.output("Status updated successfully");
                };
                Func<object, object, object> onError = (errorIqEntity,originalIqEntity) => {
                    logger.error("Error updating status");
                };
            }
            
            [clicmd("Get profile picture for contact")]
            public virtual object contact_picture(object jid) {
                if (this.assertConnected()) {
                    var entity = GetPictureIqProtocolEntity(this.aliasToJid(jid), preview: false);
                    this._sendIq(entity, this.onGetContactPictureResult);
                }
            }
            
            [clicmd("Get profile picture preview for contact")]
            public virtual object contact_picturePreview(object jid) {
                if (this.assertConnected()) {
                    var entity = GetPictureIqProtocolEntity(this.aliasToJid(jid), preview: true);
                    this._sendIq(entity, this.onGetContactPictureResult);
                }
            }
            
            [clicmd("Get lastseen for contact")]
            public virtual object contact_lastseen(object jid) {
                if (this.assertConnected()) {
                    var entity = LastseenIqProtocolEntity(this.aliasToJid(jid));
                    this._sendIq(entity, onSuccess, onError);
                }
                Func<object, object, object> onSuccess = (resultIqEntity,originalIqEntity) => {
                    this.output(String.Format("%s lastseen %s seconds ago", resultIqEntity.getFrom(), resultIqEntity.getSeconds()));
                };
                Func<object, object, object> onError = (errorIqEntity,originalIqEntity) => {
                    logger.error(String.Format("Error getting lastseen information for %s", originalIqEntity.getTo()));
                };
            }
            
            [clicmd("Set profile picture")]
            public virtual object profile_setPicture(object path) {
                if (this.assertConnected()) {
                    using (var imp = PILOptionalModule(failMessage: "No PIL library installed, try install pillow")) {
                        Image = imp("Image");
                        //example by @aesedepece in https://github.com/tgalal/yowsup/pull/781
                        //modified to support python3
                        src = Image.open(path);
                        pictureData = src.resize((640, 640)).tobytes("jpeg", "RGB");
                        picturePreview = src.resize((96, 96)).tobytes("jpeg", "RGB");
                        iq = SetPictureIqProtocolEntity(this.getOwnJid(), picturePreview, pictureData);
                        this._sendIq(iq, onSuccess, onError);
                    }
                }
                Func<object, object, object> onSuccess = (resultIqEntity,originalIqEntity) => {
                    this.output("Profile picture updated successfully");
                };
                Func<object, object, object> onError = (errorIqEntity,originalIqEntity) => {
                    logger.error("Error updating profile picture");
                };
            }
            
            [clicmd("Get profile privacy")]
            public virtual object profile_getPrivacy() {
                if (this.assertConnected()) {
                    var iq = GetPrivacyIqProtocolEntity();
                    this._sendIq(iq, onSuccess, onError);
                }
                Func<object, object, object> onSuccess = (resultIqEntity,originalIqEntity) => {
                    this.output(String.Format("Profile privacy is: %s", resultIqEntity));
                };
                Func<object, object, object> onError = (errorIqEntity,originalIqEntity) => {
                    logger.error("Error getting profile privacy");
                };
            }
            
            [clicmd("Profile privacy. value=all|contacts|none names=profile|status|last. Names are comma separated, defaults to all.")]
            public virtual object profile_setPrivacy(object value = "all", object names = null) {
                if (this.assertConnected()) {
                    try {
                        names = names ? (from name in names.split(",")
                            select name).ToList() : null;
                        var iq = SetPrivacyIqProtocolEntity(value, names);
                        this._sendIq(iq, onSuccess, onError);
                    } catch (Exception) {
                        this.output(inst.message);
                        return this.print_usage();
                    }
                }
                Func<object, object, object> onSuccess = (resultIqEntity,originalIqEntity) => {
                    this.output(String.Format("Profile privacy set to: %s", resultIqEntity));
                };
                Func<object, object, object> onError = (errorIqEntity,originalIqEntity) => {
                    logger.error("Error setting profile privacy");
                };
            }
            
            //########## groups
            [clicmd("List all groups you belong to",5)]
            public virtual object groups_list() {
                if (this.assertConnected()) {
                    var entity = ListGroupsIqProtocolEntity();
                    this.toLower(entity);
                }
            }
            
            [clicmd("Leave a group you belong to",4)]
            public virtual object group_leave(object group_jid) {
                if (this.assertConnected()) {
                    var entity = LeaveGroupsIqProtocolEntity(new List<object> {
                        this.aliasToJid(group_jid)
                    });
                    this.toLower(entity);
                }
            }
            
            [clicmd("Create a new group with the specified subject and participants. Jids are a comma separated list but optional.",3)]
            public virtual object groups_create(object subject, object jids = null) {
                if (this.assertConnected()) {
                    jids = jids ? (from jid in jids.split(",")
                        select this.aliasToJid(jid)).ToList() : new List<object>();
                    var entity = CreateGroupsIqProtocolEntity(subject, participants: jids);
                    this.toLower(entity);
                }
            }
            
            [clicmd("Invite to group. Jids are a comma separated list")]
            public virtual object group_invite(object group_jid, object jids) {
                if (this.assertConnected()) {
                    jids = (from jid in jids.split(",")
                        select this.aliasToJid(jid)).ToList();
                    var entity = AddParticipantsIqProtocolEntity(this.aliasToJid(group_jid), jids);
                    this.toLower(entity);
                }
            }
            
            [clicmd("Promote admin of a group. Jids are a comma separated list")]
            public virtual object group_promote(object group_jid, object jids) {
                if (this.assertConnected()) {
                    jids = (from jid in jids.split(",")
                        select this.aliasToJid(jid)).ToList();
                    var entity = PromoteParticipantsIqProtocolEntity(this.aliasToJid(group_jid), jids);
                    this.toLower(entity);
                }
            }
            
            [clicmd("Remove admin of a group. Jids are a comma separated list")]
            public virtual object group_demote(object group_jid, object jids) {
                if (this.assertConnected()) {
                    jids = (from jid in jids.split(",")
                        select this.aliasToJid(jid)).ToList();
                    var entity = DemoteParticipantsIqProtocolEntity(this.aliasToJid(group_jid), jids);
                    this.toLower(entity);
                }
            }
            
            [clicmd("Kick from group. Jids are a comma separated list")]
            public virtual object group_kick(object group_jid, object jids) {
                if (this.assertConnected()) {
                    jids = (from jid in jids.split(",")
                        select this.aliasToJid(jid)).ToList();
                    var entity = RemoveParticipantsIqProtocolEntity(this.aliasToJid(group_jid), jids);
                    this.toLower(entity);
                }
            }
            
            [clicmd("Change group subject")]
            public virtual object group_setSubject(object group_jid, object subject) {
                if (this.assertConnected()) {
                    var entity = SubjectGroupsIqProtocolEntity(this.aliasToJid(group_jid), subject);
                    this.toLower(entity);
                }
            }
            
            [clicmd("Set group picture")]
            public virtual object group_picture(object group_jid, object path) {
                if (this.assertConnected()) {
                    using (var imp = PILOptionalModule(failMessage: this.@__class__.FAIL_OPT_PILLOW)) {
                        Image = imp("Image");
                        //example by @aesedepece in https://github.com/tgalal/yowsup/pull/781
                        //modified to support python3
                        src = Image.open(path);
                        pictureData = src.resize((640, 640)).tobytes("jpeg", "RGB");
                        picturePreview = src.resize((96, 96)).tobytes("jpeg", "RGB");
                        iq = SetPictureIqProtocolEntity(this.aliasToJid(group_jid), picturePreview, pictureData);
                        this._sendIq(iq, onSuccess, onError);
                    }
                }
                Func<object, object, object> onSuccess = (resultIqEntity,originalIqEntity) => {
                    this.output("Group picture updated successfully");
                };
                Func<object, object, object> onError = (errorIqEntity,originalIqEntity) => {
                    logger.error("Error updating Group picture");
                };
            }
            
            [clicmd("Get group info")]
            public virtual object group_info(object group_jid) {
                if (this.assertConnected()) {
                    var entity = InfoGroupsIqProtocolEntity(this.aliasToJid(group_jid));
                    this.toLower(entity);
                }
            }
            
            [clicmd("Get shared keys")]
            public virtual object keys_get(object jids) {
                if (this.assertConnected()) {
                    jids = (from jid in jids.split(",")
                        select this.aliasToJid(jid)).ToList();
                    var entity = GetKeysIqProtocolEntity(jids);
                    this.toLower(entity);
                }
            }
            
            [clicmd("Send init seq")]
            public virtual object seq() {
                var priv = PrivacyListIqProtocolEntity();
                this.toLower(priv);
                var push = PushIqProtocolEntity();
                this.toLower(push);
                var props = PropsIqProtocolEntity();
                this.toLower(props);
                var crypto = CryptoIqProtocolEntity();
                this.toLower(crypto);
            }
            
            [clicmd("Delete your account")]
            public virtual object account_delete() {
                if (this.assertConnected()) {
                    if (this.accountDelWarnings < this.@__class__.ACCOUNT_DEL_WARNINGS) {
                        this.accountDelWarnings += 1;
                        var remaining = this.@__class__.ACCOUNT_DEL_WARNINGS - this.accountDelWarnings;
                        this.output(String.Format("Repeat delete command another %s times to send the delete request", remaining), tag: "Account delete Warning !!", prompt: false);
                    } else {
                        var entity = UnregisterIqProtocolEntity();
                        this.toLower(entity);
                    }
                }
            }
            
            [clicmd("Send message to a friend")]
            public virtual object message_send(object number, object content) {
                if (this.assertConnected()) {
                    var outgoingMessage = TextMessageProtocolEntity(content, to: this.aliasToJid(number));
                    this.toLower(outgoingMessage);
                }
            }
            
            [clicmd("Broadcast message. numbers should comma separated phone numbers")]
            public virtual object message_broadcast(object numbers, object content) {
                if (this.assertConnected()) {
                    var jids = (from number in numbers.split(",")
                        select this.aliasToJid(number)).ToList();
                    var outgoingMessage = BoadcastTextMessage(jids, content);
                    this.toLower(outgoingMessage);
                }
            }
            
            //@clicmd("Send read receipt")
            public virtual object message_read(object message_id) {
            }
            
            //@clicmd("Send delivered receipt")
            public virtual object message_delivered(object message_id) {
            }
            
            [clicmd("Send a video with optional caption")]
            public virtual object video_send(object number, object path, object caption = null) {
                this.media_send(number, path, RequestUploadIqProtocolEntity.MEDIA_TYPE_VIDEO);
            }
            
            [clicmd("Send an image with optional caption")]
            public virtual object image_send(object number, object path, object caption = null) {
                this.media_send(number, path, RequestUploadIqProtocolEntity.MEDIA_TYPE_IMAGE);
            }
            
            [clicmd("Send audio file")]
            public virtual object audio_send(object number, object path) {
                this.media_send(number, path, RequestUploadIqProtocolEntity.MEDIA_TYPE_AUDIO);
            }
            
            public virtual object media_send(object number, object path, object mediaType, object caption = null) {
                if (this.assertConnected()) {
                    var jid = this.aliasToJid(number);
                    var entity = RequestUploadIqProtocolEntity(mediaType, filePath: path);
                    var successFn = (successEntity,originalEntity) => this.onRequestUploadResult(jid, mediaType, path, successEntity, originalEntity, caption);
                    var errorFn = (errorEntity,originalEntity) => this.onRequestUploadError(jid, path, errorEntity, originalEntity);
                    this._sendIq(entity, successFn, errorFn);
                }
            }
            
            [clicmd("Send typing state")]
            public virtual object state_typing(object jid) {
                if (this.assertConnected()) {
                    var entity = OutgoingChatstateProtocolEntity(ChatstateProtocolEntity.STATE_TYPING, this.aliasToJid(jid));
                    this.toLower(entity);
                }
            }
            
            [clicmd("Request contacts statuses")]
            public virtual object statuses_get(object contacts) {
                Func<object, object, object> on_success = (entity,original_iq_entity) => {
                    // type: (ResultStatusesIqProtocolEntity, GetStatusesIqProtocolEntity) -> None
                    var status_outs = new List<object>();
                    foreach (var _tup_1 in entity.statuses.items()) {
                        var jid = _tup_1.Item1;
                        var status_info = _tup_1.Item2;
                        status_outs.append(String.Format("[user=%s status=%s last_updated=%s]", jid, status_info[0], status_info[1]));
                    }
                    this.output("\n".join(status_outs), tag: "statuses_get result");
                };
                Func<object, object, object> on_error = (entity,original_iq) => {
                    // type: (ResultStatusesIqProtocolEntity, GetStatusesIqProtocolEntity) -> None
                    logger.error("Failed to get statuses");
                };
                if (this.assertConnected()) {
                    var entity = GetStatusesIqProtocolEntity((from c in contacts.split(",")
                        select this.aliasToJid(c)).ToList());
                    this._sendIq(entity, on_success, on_error);
                }
            }
            
            [clicmd("Send paused state")]
            public virtual object state_paused(object jid) {
                if (this.assertConnected()) {
                    var entity = OutgoingChatstateProtocolEntity(ChatstateProtocolEntity.STATE_PAUSED, this.aliasToJid(jid));
                    this.toLower(entity);
                }
            }
            
            [clicmd("Sync contacts, contacts should be comma separated phone numbers, with no spaces")]
            public virtual object contacts_sync(object contacts) {
                if (this.assertConnected()) {
                    var entity = GetSyncIqProtocolEntity(contacts.split(","));
                    this.toLower(entity);
                }
            }
            
            [clicmd("Disconnect")]
            public virtual object disconnect() {
                if (this.assertConnected()) {
                    this.boadcastEvent(YowLayerEvent(YowNetworkLayer.EVENT_STATE_DISCONNECT));
                }
            }
            
            [clicmd("Quick login")]
            public virtual object L() {
                if (this.connected) {
                    return this.output("Already connected, disconnect first");
                }
                threading.Thread(target: () => this.getLayerInterface(YowNetworkLayer).connect()).start();
                return true;
            }
            
            //####### receive #########
            [ProtocolEntityCallback("presence")]
            public virtual object onPresenceChange(object entity) {
                var status = "offline";
                if (entity.getType() == null) {
                    status = "online";
                }
                //#raw fix for iphone lastseen deny output
                var lastseen = entity.getLast();
                if (object.ReferenceEquals(status, "offline") && object.ReferenceEquals(lastseen, "deny")) {
                    lastseen = time.time();
                }
                //#
                this.output(String.Format("%s %s %s lastseen at: %s", entity.getFrom(), entity.getTag(), status, lastseen));
            }
            
            [ProtocolEntityCallback("chatstate")]
            public virtual object onChatstate(object entity) {
                Console.WriteLine(entity);
            }
            
            [ProtocolEntityCallback("iq")]
            public virtual object onIq(object entity) {
                if (!(entity is ResultStatusesIqProtocolEntity)) {
                    // already printed somewhere else
                    Console.WriteLine(entity);
                }
            }
            
            [ProtocolEntityCallback("receipt")]
            public virtual object onReceipt(object entity) {
                this.toLower(entity.ack());
            }
            
            [ProtocolEntityCallback("ack")]
            public virtual object onAck(object entity) {
                //formattedDate = datetime.datetime.fromtimestamp(self.sentCache[entity.getId()][0]).strftime('%d-%m-%Y %H:%M')
                //print("%s [%s]:%s"%(self.username, formattedDate, self.sentCache[entity.getId()][1]))
                if (entity.getClass() == "message") {
                    this.output(entity.getId(), tag: "Sent");
                    //self.notifyInputThread()
                }
            }
            
            [ProtocolEntityCallback("success")]
            public virtual object onSuccess(object entity) {
                this.connected = true;
                this.output("Logged in!", "Auth", prompt: false);
                this.notifyInputThread();
            }
            
            [ProtocolEntityCallback("failure")]
            public virtual object onFailure(object entity) {
                this.connected = false;
                this.output(String.Format("Login Failed, reason: %s", entity.getReason()), prompt: false);
            }
            
            [ProtocolEntityCallback("notification")]
            public virtual object onNotification(object notification) {
                var notificationData = notification.@__str__();
                if (notificationData) {
                    this.output(notificationData, tag: "Notification");
                } else {
                    this.output(String.Format("From :%s, Type: %s", this.jidToAlias(notification.getFrom()), notification.getType()), tag: "Notification");
                }
            }
            
            [ProtocolEntityCallback("message")]
            public virtual object onMessage(object message) {
                var messageOut = "";
                if (message.getType() == "text") {
                    //self.output(message.getBody(), tag = "%s [%s]"%(message.getFrom(), formattedDate))
                    messageOut = this.getTextMessageBody(message);
                } else if (message.getType() == "media") {
                    messageOut = this.getMediaMessageBody(message);
                } else {
                    messageOut = String.Format("Unknown message type %s ", message.getType());
                    Console.WriteLine(messageOut.toProtocolTreeNode());
                }
                var formattedDate = datetime.datetime.fromtimestamp(message.getTimestamp()).strftime("%d-%m-%Y %H:%M");
                var sender = !message.isGroupMessage() ? message.getFrom() : String.Format("%s/%s", message.getParticipant(false), message.getFrom());
                var output = String.Format(this.@__class__.MESSAGE_FORMAT, sender, formattedDate, message.getId(), messageOut);
                this.output(output, tag: null, prompt: !this.sendReceipts);
                if (this.sendReceipts) {
                    this.toLower(message.ack(this.sendRead));
                    this.output(this.sendRead ? "Sent delivered receipt" + " and Read" : "", tag: String.Format("Message %s", message.getId()));
                }
            }
            
            public virtual object getTextMessageBody(object message) {
                if (message is TextMessageProtocolEntity) {
                    return message.conversation;
                } else if (message is ExtendedTextMessageProtocolEntity) {
                    return message.message_attributes.extended_text.ToString();
                } else {
                    throw new NotImplementedException();
                }
            }
            
            public virtual object getMediaMessageBody(object message) {
                // type: (DownloadableMediaMessageProtocolEntity) -> str
                return message.message_attributes.ToString();
            }
            
            public virtual object getDownloadableMediaMessageBody(object message) {
                return "[media_type={media_type}, length={media_size}, url={media_url}, key={media_key}]".format(media_type: message.media_type, media_size: message.file_length, media_url: message.url, media_key: base64.b64encode(message.media_key));
            }
            
            public virtual object doSendMedia(
                object mediaType,
                object filePath,
                object url,
                object to,
                object ip = null,
                object caption = null) {
                if (mediaType == RequestUploadIqProtocolEntity.MEDIA_TYPE_IMAGE) {
                    var entity = ImageDownloadableMediaMessageProtocolEntity.fromFilePath(filePath, url, ip, to, caption: caption);
                } else if (mediaType == RequestUploadIqProtocolEntity.MEDIA_TYPE_AUDIO) {
                    entity = AudioDownloadableMediaMessageProtocolEntity.fromFilePath(filePath, url, ip, to);
                } else if (mediaType == RequestUploadIqProtocolEntity.MEDIA_TYPE_VIDEO) {
                    entity = VideoDownloadableMediaMessageProtocolEntity.fromFilePath(filePath, url, ip, to, caption: caption);
                }
                this.toLower(entity);
            }
            
            public override object ToString() {
                return "CLI Interface Layer";
            }
            
            //########## callbacks ############
            public virtual object onRequestUploadResult(
                object jid,
                object mediaType,
                object filePath,
                object resultRequestUploadIqProtocolEntity,
                object requestUploadIqProtocolEntity,
                object caption = null) {
                if (resultRequestUploadIqProtocolEntity.isDuplicate()) {
                    this.doSendMedia(mediaType, filePath, resultRequestUploadIqProtocolEntity.getUrl(), jid, resultRequestUploadIqProtocolEntity.getIp(), caption);
                } else {
                    var successFn = (filePath,jid,url) => this.doSendMedia(mediaType, filePath, url, jid, resultRequestUploadIqProtocolEntity.getIp(), caption);
                    var mediaUploader = MediaUploader(jid, this.getOwnJid(), filePath, resultRequestUploadIqProtocolEntity.getUrl(), resultRequestUploadIqProtocolEntity.getResumeOffset(), successFn, this.onUploadError, this.onUploadProgress, asynchronous: false);
                    mediaUploader.start();
                }
            }
            
            public virtual object onRequestUploadError(object jid, object path, object errorRequestUploadIqProtocolEntity, object requestUploadIqProtocolEntity) {
                logger.error(String.Format("Request upload for file %s for %s failed", path, jid));
            }
            
            public virtual object onUploadError(object filePath, object jid, object url) {
                logger.error(String.Format("Upload file %s to %s for %s failed!", filePath, url, jid));
            }
            
            public virtual object onUploadProgress(object filePath, object jid, object url, object progress) {
                sys.stdout.write(String.Format("%s => %s, %d%% \r", os.path.basename(filePath), jid, progress));
                sys.stdout.flush();
            }
            
            public virtual object onGetContactPictureResult(object resultGetPictureIqProtocolEntiy, object getPictureIqProtocolEntity) {
                // do here whatever you want
                // write to a file
                // or open
                // or do nothing
                // write to file example:
                //resultGetPictureIqProtocolEntiy.writeToFile("/tmp/yowpics/%s_%s.jpg" % (getPictureIqProtocolEntity.getTo(), "preview" if resultGetPictureIqProtocolEntiy.isPreview() else "full"))
            }
            
            [clicmd("Print this message")]
            public virtual object help() {
                this.print_usage();
            }
        }
    }
}
