namespace yowsup.demos.cli
{

    using Queue = queue;

    using readline = pyreadline;

    using System.Collections.Generic;

    using System;

    using System.Linq;

    public static class cli {
        
        public class clicmd
            : object {
            
            public object desc;
            
            public object order;
            
            public clicmd(object desc, object order = 0) {
                this.desc = desc;
                this.order = order;
            }
            
            public virtual object @__call__(object fn) {
                fn.clidesc = this.desc;
                fn.cliorder = this.order;
                return fn;
            }
        }
        
        public class Cli
            : object {
            
            public List<object> _queuedCmds;
            
            public bool acceptingInput;
            
            public object blockingQueue;
            
            public Dictionary<object, object> commands;
            
            public object inputThread;
            
            public object lastPrompt;
            
            public Dictionary<object, object> sentCache;
            
            public Cli() {
                object subcommand;
                object cmd;
                this.sentCache = new Dictionary<object, object> {
                };
                this.commands = new Dictionary<object, object> {
                };
                this.acceptingInput = false;
                this.lastPrompt = true;
                this.blockingQueue = Queue.Queue();
                this._queuedCmds = new List<object>();
                readline.set_completer(this.complete);
                readline.parse_and_bind("tab: complete");
                var members = inspect.getmembers(this, predicate: inspect.ismethod);
                foreach (var m in members) {
                    if (hasattr(m[1], "clidesc")) {
                        var fname = m[0];
                        var fn = m[1];
                        try {
                            var _tup_1 = fname.split("_");
                            cmd = _tup_1.Item1;
                            subcommand = _tup_1.Item2;
                        } catch (ValueError) {
                            cmd = fname;
                            subcommand = "_";
                        }
                        if (!this.commands.Contains(cmd)) {
                            this.commands[cmd] = new Dictionary<object, object> {
                            };
                        }
                        this.commands[cmd][subcommand] = new Dictionary<object, object> {
                            {
                                "args",
                                inspect.getargspec(fn)[0][1]},
                            {
                                "optional",
                                inspect.getargspec(fn)[3] ? inspect.getargspec(fn)[3].Count : 0},
                            {
                                "desc",
                                fn.clidesc},
                            {
                                "fn",
                                fn},
                            {
                                "order",
                                fn.cliorder}};
                    }
                }
                //self.cv = threading.Condition()
                this.inputThread = threading.Thread(target: this.startInputThread);
                this.inputThread.daemon = true;
            }
            
            public virtual object queueCmd(object cmd) {
                this._queuedCmds.append(cmd);
            }
            
            public virtual object startInput() {
                this.inputThread.start();
            }
            
            //################## cmd input parsing ####################
            public virtual object print_usage() {
                var line_width = 100;
                var outArr = new List<List<object>>();
                Func<object, object, object> addToOut = (ind,cmd) => {
                    if (ind >= outArr.Count) {
                        outArr.extend(new List<None> {
                            null
                        } * (ind - outArr.Count + 1));
                    }
                    if (outArr[ind] != null) {
                        foreach (var i in Enumerable.Range(0, Convert.ToInt32(Math.Ceiling(Convert.ToDouble(0 - (outArr.Count - 1)) / -1))).Select(_x_1 => outArr.Count - 1 + _x_1 * -1)) {
                            if (outArr[i] == null) {
                                outArr[i] = outArr[ind];
                                outArr[ind] = cmd;
                                return;
                            }
                        }
                        outArr.append(cmd);
                    } else {
                        outArr[ind] = cmd;
                    }
                };
                foreach (var _tup_1 in this.commands.items()) {
                    var cmd = _tup_1.Item1;
                    var subcommands = _tup_1.Item2;
                    foreach (var _tup_2 in subcommands.items()) {
                        var subcmd = _tup_2.Item1;
                        var subcmdDetails = _tup_2.Item2;
                        var @out = "";
                        @out += String.Format("/%s ", cmd).ljust(15);
                        @out += subcmd != "_" ? String.Format("%s ", subcmd) : "".ljust(15);
                        var args = String.Format("%s ", " ".join((from c in subcmdDetails["args"][0::(len(subcmdDetails["args"])  -  subcmdDetails["optional"])]
                            select String.Format("<%s>", c)).ToList()));
                        args += String.Format("%s ", " ".join((from c in subcmdDetails["args"][subcmdDetails["args"].Count - subcmdDetails["optional"]]
                            select String.Format("[%s]", c)).ToList()));
                        @out += args.ljust(30);
                        @out += subcmdDetails["desc"].ljust(20);
                        addToOut(subcmdDetails["order"], @out);
                    }
                }
                Console.WriteLine("----------------------------------------------");
                Console.WriteLine("\n".join(outArr));
                Console.WriteLine("----------------------------------------------");
            }
            
            public virtual object execCmd(object cmdInput) {
                object args;
                object subcmdData;
                cmdInput = cmdInput.rstrip();
                if (!(cmdInput.Count > 1)) {
                    return;
                }
                if (cmdInput.startswith("/")) {
                    cmdInput = cmdInput[1];
                } else {
                    this.print_usage();
                    return;
                }
                var cmdInputDissect = (from c in shlex.split(cmdInput)
                    where c
                    select c).ToList();
                var cmd = cmdInputDissect[0];
                if (!this.commands.Contains(cmd)) {
                    return this.print_usage();
                }
                var cmdData = this.commands[cmd];
                if (cmdData.Count == 1 && cmdData.Contains("_")) {
                    subcmdData = cmdData["_"];
                    args = cmdInputDissect.Count > 1 ? cmdInputDissect[1] : new List<object>();
                } else {
                    args = cmdInputDissect.Count > 2 ? cmdInputDissect[2] : new List<object>();
                    var subcmd = cmdInputDissect.Count > 1 ? cmdInputDissect[1] : "";
                    if (!cmdData.Contains(subcmd)) {
                        return this.print_usage();
                    }
                    subcmdData = cmdData[subcmd];
                }
                var targetFn = subcmdData["fn"];
                if (subcmdData["args"].Count < args.Count || subcmdData["args"].Count - subcmdData["optional"] > args.Count) {
                    return this.print_usage();
                }
                return this.doExecCmd(() => targetFn(args));
            }
            
            public virtual object doExecCmd(object fn) {
                return fn();
            }
            
            public virtual object startInputThread() {
                //cv.acquire()
                // Fix Python 2.x.
                try {
                    input = raw_input;
                } catch (NameError) {
                }
                while (true) {
                    var cmd = this._queuedCmds.Count ? this._queuedCmds.pop(0) : input(this.getPrompt()).strip();
                    var wait = this.execCmd(cmd);
                    if (wait) {
                        this.acceptingInput = false;
                        this.blockingQueue.get(true);
                        //cv.wait()
                        //self.inputThread.wait()
                    }
                    this.acceptingInput = true;
                    //cv.release()
                }
            }
            
            public virtual object getPrompt() {
                return String.Format("[%s]:", this.connected ? "connected" : "offline");
            }
            
            public virtual object printPrompt() {
                //return "Enter Message or command: (/%s)" % ", /".join(self.commandMappings)
                Console.WriteLine(this.getPrompt());
            }
            
            public virtual object output(object message, object tag = "general", object prompt = true) {
                if (this.acceptingInput == true && object.ReferenceEquals(this.lastPrompt, true)) {
                    Console.WriteLine("");
                }
                this.lastPrompt = prompt;
                if (tag != null) {
                    Console.WriteLine(String.Format("%s: %s", tag, message));
                } else {
                    Console.WriteLine(message);
                }
                if (prompt) {
                    this.printPrompt();
                }
            }
            
            public virtual object complete(object text, object state) {
                if (state == 0) {
                    foreach (var cmd in this.commands) {
                        if (cmd.startswith(text) && cmd != text) {
                            return cmd;
                        }
                    }
                }
            }
            
            public virtual object notifyInputThread() {
                this.blockingQueue.put(1);
            }
        }
        
        public static Cli c = new Cli();
        
        static cli() {
            c.print_usage();
        }
    }
}
