namespace yowsup.demos.echoclient {
    
    using YowInterfaceLayer = yowsup.layers.interface.YowInterfaceLayer;
    
    using ProtocolEntityCallback = yowsup.layers.interface.ProtocolEntityCallback;
    
    using System;
    
    public static class layer {
        
        public class EchoLayer
            : YowInterfaceLayer {
            
            [ProtocolEntityCallback("message")]
            public virtual object onMessage(object messageProtocolEntity) {
                if (messageProtocolEntity.getType() == "text") {
                    this.onTextMessage(messageProtocolEntity);
                } else if (messageProtocolEntity.getType() == "media") {
                    this.onMediaMessage(messageProtocolEntity);
                }
                this.toLower(messageProtocolEntity.forward(messageProtocolEntity.getFrom()));
                this.toLower(messageProtocolEntity.ack());
                this.toLower(messageProtocolEntity.ack(true));
            }
            
            [ProtocolEntityCallback("receipt")]
            public virtual object onReceipt(object entity) {
                this.toLower(entity.ack());
            }
            
            public virtual object onTextMessage(object messageProtocolEntity) {
                // just print info
                Console.WriteLine(String.Format("Echoing %s to %s", messageProtocolEntity.getBody(), messageProtocolEntity.getFrom(false)));
            }
            
            public virtual object onMediaMessage(object messageProtocolEntity) {
                // just print info
                if (messageProtocolEntity.media_type == "image") {
                    Console.WriteLine(String.Format("Echoing image %s to %s", messageProtocolEntity.url, messageProtocolEntity.getFrom(false)));
                } else if (messageProtocolEntity.media_type == "location") {
                    Console.WriteLine(String.Format("Echoing location (%s, %s) to %s", messageProtocolEntity.getLatitude(), messageProtocolEntity.getLongitude(), messageProtocolEntity.getFrom(false)));
                } else if (messageProtocolEntity.media_type == "contact") {
                    Console.WriteLine(String.Format("Echoing contact (%s, %s) to %s", messageProtocolEntity.getName(), messageProtocolEntity.getCardData(), messageProtocolEntity.getFrom(false)));
                }
            }
        }
    }
}
