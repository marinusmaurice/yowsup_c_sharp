namespace yowsup.demos.echoclient
{

    using YowStackBuilder = yowsup.stacks.YowStackBuilder;

    using EchoLayer = layer.EchoLayer;

    using YowNetworkLayer = yowsup.layers.network.YowNetworkLayer;

    public static class stack {
        
        public class YowsupEchoStack
            : object {
            
            public object _stack;
            
            public YowsupEchoStack(object profile) {
                var stackBuilder = YowStackBuilder();
                this._stack = stackBuilder.pushDefaultLayers().push(EchoLayer).build();
                this._stack.setProfile(profile);
            }
            
            public virtual object set_prop(object key, object val) {
                this._stack.setProp(key, val);
            }
            
            public virtual object start() {
                this._stack.boadcastEvent(YowLayerEvent(YowNetworkLayer.EVENT_STATE_CONNECT));
                this._stack.loop();
            }
        }
    }
}
