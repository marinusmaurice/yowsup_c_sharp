namespace yowsup.demos.echoclient
{

    public static class @__init__ {
    }
}
