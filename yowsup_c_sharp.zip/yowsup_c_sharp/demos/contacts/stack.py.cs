namespace yowsup.demos.contacts
{

    using SyncLayer = layer.SyncLayer;

    using YowStackBuilder = yowsup.stacks.YowStackBuilder;

    using YowAuthenticationProtocolLayer = yowsup.layers.auth.YowAuthenticationProtocolLayer;

    using YowNetworkLayer = yowsup.layers.network.YowNetworkLayer;

    public static class stack {
        
        public class YowsupSyncStack
            : object {
            
            public object _stack;
            
            public YowsupSyncStack(object profile, object contacts) {
                var stackBuilder = YowStackBuilder();
                this._stack = stackBuilder.pushDefaultLayers().push(SyncLayer).build();
                this._stack.setProp(SyncLayer.PROP_CONTACTS, contacts);
                this._stack.setProp(YowAuthenticationProtocolLayer.PROP_PASSIVE, true);
                this._stack.setProfile(profile);
            }
            
            public virtual object set_prop(object key, object val) {
                this._stack.setProp(key, val);
            }
            
            public virtual object start() {
                this._stack.boadcastEvent(YowLayerEvent(YowNetworkLayer.EVENT_STATE_CONNECT));
                this._stack.loop();
            }
        }
    }
}
