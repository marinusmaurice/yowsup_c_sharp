namespace yowsup.demos.contacts {
    
    using YowInterfaceLayer = yowsup.layers.interface.YowInterfaceLayer;
    
    using ProtocolEntityCallback = yowsup.layers.interface.ProtocolEntityCallback;
    
    using GetSyncIqProtocolEntity = yowsup.layers.protocol_contacts.protocolentities.GetSyncIqProtocolEntity;
    
    using ResultSyncIqProtocolEntity = yowsup.layers.protocol_contacts.protocolentities.ResultSyncIqProtocolEntity;
    
    using ErrorIqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.ErrorIqProtocolEntity;
    
    using threading;
    
    using logging;
    
    using System.Collections.Generic;
    
    public static class layer {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class SyncLayer
            : YowInterfaceLayer {
            
            public string PROP_CONTACTS;
            
            public string PROP_CONTACTS = "org.openwhatsapp.yowsup.prop.syncdemo.contacts";
            
            public SyncLayer() {
            }
            
            //call back function when there is a successful connection to whatsapp server
            [ProtocolEntityCallback("success")]
            public virtual object onSuccess(object successProtocolEntity) {
                var contacts = this.getProp(this.@__class__.PROP_CONTACTS, new List<object>());
                var contactEntity = GetSyncIqProtocolEntity(contacts);
                this._sendIq(contactEntity, this.onGetSyncResult, this.onGetSyncError);
            }
            
            public virtual object onGetSyncResult(object resultSyncIqProtocolEntity, object originalIqProtocolEntity) {
                Console.WriteLine(resultSyncIqProtocolEntity);
                throw new KeyboardInterrupt();
            }
            
            public virtual object onGetSyncError(object errorSyncIqProtocolEntity, object originalIqProtocolEntity) {
                Console.WriteLine(errorSyncIqProtocolEntity);
                throw new KeyboardInterrupt();
            }
        }
    }
}
