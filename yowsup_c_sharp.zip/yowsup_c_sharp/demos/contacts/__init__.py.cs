namespace yowsup.demos.contacts
{

    public static class @__init__ {
    }
}
