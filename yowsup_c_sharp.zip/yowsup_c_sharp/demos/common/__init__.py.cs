namespace yowsup.demos.common {
    
    public static class @__init__ {
    }
}
