namespace yowsup.demos.common
{

    using MediaCipher = yowsup.layers.protocol_media.mediacipher.MediaCipher;

    using ImageDownloadableMediaMessageProtocolEntity = yowsup.layers.protocol_media.protocolentities.ImageDownloadableMediaMessageProtocolEntity;

    using AudioDownloadableMediaMessageProtocolEntity = yowsup.layers.protocol_media.protocolentities.AudioDownloadableMediaMessageProtocolEntity;

    using VideoDownloadableMediaMessageProtocolEntity = yowsup.layers.protocol_media.protocolentities.VideoDownloadableMediaMessageProtocolEntity;

    using DocumentDownloadableMediaMessageProtocolEntity = yowsup.layers.protocol_media.protocolentities.DocumentDownloadableMediaMessageProtocolEntity;

    using ContactMediaMessageProtocolEntity = yowsup.layers.protocol_media.protocolentities.ContactMediaMessageProtocolEntity;

    using DownloadableMediaMessageProtocolEntity = yowsup.layers.protocol_media.protocolentities.DownloadableMediaMessageProtocolEntity;

    using StickerDownloadableMediaMessageProtocolEntity = yowsup.layers.protocol_media.protocolentities.StickerDownloadableMediaMessageProtocolEntity;

    using tqdm = tqdm.tqdm;

    using Queue = queue.Queue;

    using System;

    using System.Linq;

    public static class sink_worker {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class SinkWorker
            : threading.Thread {
            
            public object _jobs;
            
            public object _media_cipher;
            
            public object _storage_dir;
            
            public bool daemon;
            
            public SinkWorker(object storage_dir) {
                this.daemon = true;
                this._storage_dir = storage_dir;
                this._jobs = Queue();
                this._media_cipher = MediaCipher();
            }
            
            public virtual object enqueue(object media_message_protocolentity) {
                this._jobs.put(media_message_protocolentity);
            }
            
            public virtual object _create_progress_iterator(object iterable, object niterations, object desc) {
                return tqdm(iterable, total: niterations, unit: "KB", dynamic_ncols: true, unit_scale: true, leave: true, desc: desc, ascii: true);
            }
            
            public virtual object _download(object url) {
                var response = requests.get(url, stream: true);
                var total_size = Convert.ToInt32(response.headers.get("content-length", 0));
                logger.debug(String.Format("%s total size is %s, downloading", url, total_size));
                var block_size = 1024;
                var wrote = 0;
                var enc_data = "";
                foreach (var data in this._create_progress_iterator(response.iter_content(block_size), math.ceil(total_size / block_size) + 1, new byte[] { (byte)'D', (byte)'o', (byte)'w', (byte)'n', (byte)'l', (byte)'o', (byte)'a', (byte)'d', (byte)' ', (byte)' ', (byte)' ', (byte)' ', (byte)' ', (byte)' ', (byte)' ' })) {
                    wrote = wrote + data.Count;
                    enc_data = enc_data + data;
                }
                if (total_size != 0 && wrote != total_size) {
                    logger.error("Something went wrong");
                    return null;
                }
                return enc_data;
            }
            
            public virtual object _decrypt(object ciphertext, object ref_key, object media_info) {
                var length_kb = Convert.ToInt32(math.ceil(ciphertext.Count / 1024));
                var progress = this._create_progress_iterator(Enumerable.Range(0, length_kb), length_kb, "Decrypt        ");
                try {
                    var plaintext = this._media_cipher.decrypt(ciphertext, ref_key, media_info);
                    progress.update(length_kb);
                    return plaintext;
                } catch (Exception) {
                    progress.set_description("Decrypt Error  ");
                    logger.error(e);
                }
                return null;
            }
            
            public virtual object _write(object data, object filename) {
                var length_kb = Convert.ToInt32(math.ceil(data.Count / 1024));
                var progress = this._create_progress_iterator(Enumerable.Range(0, length_kb), length_kb, "Write          ");
                try {
                    using (var f = open(filename, "wb")) {
                        f.write(data);
                    }
                    progress.update(length_kb);
                    return filename;
                } catch (Exception) {
                    progress.set_description("Write error    ");
                    logger.error(e);
                }
                return null;
            }
            
            public virtual object _create_unique_filepath(object filepath) {
                var file_dir = os.path.dirname(filepath);
                var filename = os.path.basename(filepath);
                var result_filename = filename;
                var dissected = os.path.splitext(filename);
                var count = 0;
                while (os.path.exists(os.path.join(file_dir, result_filename))) {
                    count += 1;
                    result_filename = String.Format("%s_%d%s", dissected[0], count, dissected[1]);
                }
                return os.path.join(file_dir, result_filename);
            }
            
            public virtual object run() {
                object filename_full;
                object filename;
                logger.debug(String.Format("SinkWorker started, storage_dir=%s", this._storage_dir));
                while (true) {
                    var media_message_protocolentity = this._jobs.get();
                    if (media_message_protocolentity == null) {
                        sys.exit(0);
                    }
                    if (media_message_protocolentity is DownloadableMediaMessageProtocolEntity) {
                        logger.info(String.Format("Processing [url=%s, media_key=%s]", media_message_protocolentity.url, base64.b64encode(media_message_protocolentity.media_key)));
                    } else {
                        logger.info(String.Format("Processing %s", media_message_protocolentity.media_type));
                    }
                    object filedata = null;
                    object fileext = null;
                    if (media_message_protocolentity is ImageDownloadableMediaMessageProtocolEntity) {
                        var media_info = MediaCipher.INFO_IMAGE;
                        filename = "image";
                    } else if (media_message_protocolentity is AudioDownloadableMediaMessageProtocolEntity) {
                        media_info = MediaCipher.INFO_AUDIO;
                        filename = media_message_protocolentity.ptt ? "ptt" : "audio";
                    } else if (media_message_protocolentity is VideoDownloadableMediaMessageProtocolEntity) {
                        media_info = MediaCipher.INFO_VIDEO;
                        filename = "video";
                    } else if (media_message_protocolentity is DocumentDownloadableMediaMessageProtocolEntity) {
                        media_info = MediaCipher.INFO_DOCUM;
                        filename = media_message_protocolentity.file_name;
                    } else if (media_message_protocolentity is ContactMediaMessageProtocolEntity) {
                        filename = media_message_protocolentity.display_name;
                        filedata = media_message_protocolentity.vcard;
                        fileext = "vcard";
                    } else if (media_message_protocolentity is StickerDownloadableMediaMessageProtocolEntity) {
                        media_info = MediaCipher.INFO_IMAGE;
                        filename = "sticker";
                    } else {
                        logger.error(String.Format("Unsupported Media type: %s", media_message_protocolentity.@__class__));
                        sys.exit(1);
                    }
                    if (filedata == null) {
                        var enc_data = this._download(media_message_protocolentity.url);
                        if (enc_data == null) {
                            logger.error("Download failed");
                            sys.exit(1);
                        }
                        filedata = this._decrypt(enc_data, media_message_protocolentity.media_key, media_info);
                        if (filedata == null) {
                            logger.error("Decrypt failed");
                            sys.exit(1);
                        }
                    }
                    if (!(media_message_protocolentity is DocumentDownloadableMediaMessageProtocolEntity)) {
                        if (fileext == null) {
                            fileext = media_message_protocolentity.mimetype.split("/")[1].split(";")[0];
                        }
                        filename_full = String.Format("%s.%s", filename, fileext);
                    } else {
                        filename_full = filename;
                    }
                    var filepath = this._create_unique_filepath(os.path.join(this._storage_dir, filename_full));
                    if (this._write(filedata, filepath)) {
                        logger.info(String.Format("Wrote %s", filepath));
                    } else {
                        sys.exit(1);
                    }
                }
            }
        }
    }
}
