namespace yowsup.demos {
    
    public static class @__init__ {
    }
}
