namespace yowsup.demos.sendclient {
    
    using YowInterfaceLayer = yowsup.layers.interface.YowInterfaceLayer;
    
    using ProtocolEntityCallback = yowsup.layers.interface.ProtocolEntityCallback;
    
    using TextMessageProtocolEntity = yowsup.layers.protocol_messages.protocolentities.TextMessageProtocolEntity;
    
    using Jid = yowsup.common.tools.Jid;
    
    using threading;
    
    using logging;
    
    using System.Collections.Generic;
    
    public static class layer {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class SendLayer
            : YowInterfaceLayer {
            
            public List<object> ackQueue;
            
            public object @lock;
            
            public string PROP_MESSAGES;
            
            public string PROP_MESSAGES = "org.openwhatsapp.yowsup.prop.sendclient.queue";
            
            public SendLayer() {
                this.ackQueue = new List<object>();
                this.@lock = threading.Condition();
            }
            
            //call back function when there is a successful connection to whatsapp server
            [ProtocolEntityCallback("success")]
            public virtual object onSuccess(object successProtocolEntity) {
                this.@lock.acquire();
                foreach (var target in this.getProp(this.@__class__.PROP_MESSAGES, new List<object>())) {
                    //getProp() is trying to retreive the list of (jid, message) tuples, if none exist, use the default []
                    var _tup_1 = target;
                    var phone = _tup_1.Item1;
                    var message = _tup_1.Item2;
                    var messageEntity = TextMessageProtocolEntity(message, to: Jid.normalize(phone));
                    //append the id of message to ackQueue list
                    //which the id of message will be deleted when ack is received.
                    this.ackQueue.append(messageEntity.getId());
                    this.toLower(messageEntity);
                }
                this.@lock.release();
            }
            
            //after receiving the message from the target number, target number will send a ack to sender(us)
            [ProtocolEntityCallback("ack")]
            public virtual object onAck(object entity) {
                this.@lock.acquire();
                //if the id match the id in ackQueue, then pop the id of the message out
                if (this.ackQueue.Contains(entity.getId())) {
                    this.ackQueue.pop(this.ackQueue.index(entity.getId()));
                }
                if (!this.ackQueue.Count) {
                    this.@lock.release();
                    logger.info("Message sent");
                    throw new KeyboardInterrupt();
                }
                this.@lock.release();
            }
        }
    }
}
