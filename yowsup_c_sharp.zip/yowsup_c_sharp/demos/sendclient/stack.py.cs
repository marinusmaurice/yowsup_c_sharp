namespace yowsup.demos.sendclient
{

    using YowStackBuilder = yowsup.stacks.YowStackBuilder;

    using SendLayer = layer.SendLayer;

    using YowAuthenticationProtocolLayer = yowsup.layers.auth.YowAuthenticationProtocolLayer;

    using YowNetworkLayer = yowsup.layers.network.YowNetworkLayer;

    public static class stack {
        
        public class YowsupSendStack
            : object {
            
            public object _stack;
            
            public YowsupSendStack(object profile, object messages) {
                var stackBuilder = YowStackBuilder();
                this._stack = stackBuilder.pushDefaultLayers().push(SendLayer).build();
                this._stack.setProp(SendLayer.PROP_MESSAGES, messages);
                this._stack.setProp(YowAuthenticationProtocolLayer.PROP_PASSIVE, true);
                this._stack.setProfile(profile);
            }
            
            public virtual object set_prop(object key, object val) {
                this._stack.setProp(key, val);
            }
            
            public virtual object start() {
                this._stack.boadcastEvent(YowLayerEvent(YowNetworkLayer.EVENT_STATE_CONNECT));
                this._stack.loop();
            }
        }
    }
}
