namespace yowsup.demos.sendclient
{

    public static class @__init__ {
    }
}
