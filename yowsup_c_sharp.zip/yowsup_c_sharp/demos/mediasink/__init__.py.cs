namespace yowsup.demos.mediasink
{

    public static class @__init__ {
    }
}
