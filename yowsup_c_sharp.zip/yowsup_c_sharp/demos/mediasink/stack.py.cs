namespace yowsup.demos.mediasink
{

    using YowStackBuilder = yowsup.stacks.YowStackBuilder;

    using MediaSinkLayer = layer.MediaSinkLayer;

    using YowNetworkLayer = yowsup.layers.network.YowNetworkLayer;

    public static class stack {
        
        public class MediaSinkStack
            : object {
            
            public object _stack;
            
            public MediaSinkStack(object profile, object storage_dir = null) {
                var stackBuilder = YowStackBuilder();
                this._stack = stackBuilder.pushDefaultLayers().push(MediaSinkLayer).build();
                this._stack.setProp(MediaSinkLayer.PROP_STORAGE_DIR, storage_dir);
                this._stack.setProfile(profile);
            }
            
            public virtual object set_prop(object key, object val) {
                this._stack.setProp(key, val);
            }
            
            public virtual object start() {
                this._stack.boadcastEvent(YowLayerEvent(YowNetworkLayer.EVENT_STATE_CONNECT));
                this._stack.loop();
            }
        }
    }
}
