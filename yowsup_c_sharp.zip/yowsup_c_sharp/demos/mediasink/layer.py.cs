namespace yowsup.demos.mediasink {
    
    using YowInterfaceLayer = yowsup.layers.interface.YowInterfaceLayer;
    
    using ProtocolEntityCallback = yowsup.layers.interface.ProtocolEntityCallback;
    
    using YowNetworkLayer = yowsup.layers.network.layer.YowNetworkLayer;
    
    using EventCallback = yowsup.layers.EventCallback;
    
    using sys;
    
    using tqdm = tqdm.tqdm;
    
    using requests;
    
    using SinkWorker = common.sink_worker.SinkWorker;
    
    using tempfile;
    
    using logging;
    
    using os;
    
    using System;
    
    public static class layer {
        
        static layer() {
            sys.exit(1);
        }
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class MediaSinkLayer
            : YowInterfaceLayer {
            
            public object _sink_worker;
            
            public string PROP_STORAGE_DIR;
            
            public string PROP_STORAGE_DIR = "org.openwhatsapp.yowsup.prop.demos.mediasink.storage_dir";
            
            public MediaSinkLayer() {
                this._sink_worker = null;
            }
            
            [EventCallback(YowNetworkLayer.EVENT_STATE_CONNECTED)]
            public virtual object on_connected(object @event) {
                logger.info("Connected, starting SinkWorker");
                var storage_dir = this.getProp(this.PROP_STORAGE_DIR);
                if (storage_dir == null) {
                    logger.debug("No storage dir specified, creating tempdir");
                    storage_dir = tempfile.mkdtemp("yowsup_mediasink");
                }
                if (!os.path.exists(storage_dir)) {
                    logger.debug(String.Format("%s does not exist, creating", storage_dir));
                    os.makedirs(storage_dir);
                }
                logger.info(String.Format("Storing incoming media to %s", storage_dir));
                this._sink_worker = SinkWorker(storage_dir);
                this._sink_worker.start();
            }
            
            [ProtocolEntityCallback("message")]
            public virtual object on_message(object message_protocolentity) {
                this.toLower(message_protocolentity.ack());
                this.toLower(message_protocolentity.ack(true));
                if (message_protocolentity is MediaMessageProtocolEntity) {
                    this.on_media_message(message_protocolentity);
                }
            }
            
            [ProtocolEntityCallback("receipt")]
            public virtual object on_receipt(object entity) {
                this.toLower(entity.ack());
            }
            
            public virtual object on_media_message(object media_message_protocolentity) {
                this._sink_worker.enqueue(media_message_protocolentity);
            }
        }
    }
}
