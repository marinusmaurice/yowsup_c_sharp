namespace yowsup.layers.protocol_receipts
{

    using YowProtocolLayer = yowsup.layers.YowProtocolLayer;

    using System.Collections.Generic;

    public static class layer {
        
        public class YowReceiptProtocolLayer
            : YowProtocolLayer {
            
            public YowReceiptProtocolLayer() {
                var handleMap = new Dictionary<object, object> {
                    {
                        "receipt",
                        (this.recvReceiptNode, this.sendReceiptEntity)}};
                super(YowReceiptProtocolLayer, this).@__init__(handleMap);
            }
            
            public override object ToString() {
                return "Receipt Layer";
            }
            
            public virtual object sendReceiptEntity(object entity) {
                this.entityToLower(entity);
            }
            
            public virtual object recvReceiptNode(object node) {
                this.toUpper(IncomingReceiptProtocolEntity.fromProtocolTreeNode(node));
            }
        }
    }
}
