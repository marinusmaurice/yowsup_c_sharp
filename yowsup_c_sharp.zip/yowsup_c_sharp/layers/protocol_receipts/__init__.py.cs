namespace yowsup.layers.protocol_receipts
{

    public static class @__init__ {
    }
}
