namespace yowsup.layers.protocol_receipts.protocolentities
{

    using IncomingReceiptProtocolEntity = yowsup.layers.protocol_receipts.protocolentities.IncomingReceiptProtocolEntity;

    using ProtocolEntityTest = yowsup.structs.protocolentity.ProtocolEntityTest;

    using System;

    public static class test_receipt_incoming {
        
        public class IncomingReceiptProtocolEntityTest
            : ProtocolEntityTest, unittest.TestCase {
            
            public object node;
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                this.ProtocolEntity = IncomingReceiptProtocolEntity;
                this.node = IncomingReceiptProtocolEntity("123", "sender", Convert.ToInt32(time.time())).toProtocolTreeNode();
            }
        }
    }
}
