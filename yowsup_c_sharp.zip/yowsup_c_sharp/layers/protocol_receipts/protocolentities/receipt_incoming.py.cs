namespace yowsup.layers.protocol_receipts.protocolentities
{

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using ReceiptProtocolEntity = receipt.ReceiptProtocolEntity;

    using OutgoingAckProtocolEntity = yowsup.layers.protocol_acks.protocolentities.OutgoingAckProtocolEntity;

    using System;

    using System.Collections.Generic;

    public static class receipt_incoming {
        
        // 
        //     delivered:
        //     <receipt to="xxxxxxxxxxx@s.whatsapp.net" id="1415389947-15"></receipt>
        // 
        //     read
        //     <receipt to="xxxxxxxxxxx@s.whatsapp.net" id="1415389947-15" type="read"></receipt>
        // 
        //     delivered to participant in group:
        //     <receipt participant="xxxxxxxxxx@s.whatsapp.net" from="yyyyyyyyyyyyy@g.us" id="1431204051-9" t="1431204094"></receipt>
        // 
        //     read by participant in group:
        //     <receipt participant="xxxxxxxxxx@s.whatsapp.net" t="1431204235" from="yyyyyyyyyyyyy@g.us" id="1431204051-9" type="read"></receipt>
        // 
        //     multiple items:
        //     <receipt type="read" from="xxxxxxxxxxxx@s.whatsapp.net" id="1431364583-191" t="1431365553">
        //         <list>
        //             <item id="1431364572-189"></item>
        //             <item id="1431364575-190"></item>
        //         </list>
        //     </receipt>
        // 
        //     multiple items to group:
        //     <receipt participant="xxxxxxxxxxxx@s.whatsapp.net" t="1431330533" from="yyyyyyyyyyyyyy@g.us" id="1431330385-323" type="read">
        //         <list>
        //             <item id="1431330096-317"></item>
        //             <item id="1431330373-320"></item>
        //             <item id="1431330373-321"></item>
        //             <item id="1431330385-322"></item>
        //         </list>
        //     </receipt>
        // 
        //     INCOMING
        //     <receipt offline="0" from="xxxxxxxxxx@s.whatsapp.net" id="1415577964-1" t="1415578027"></receipt>
        //     
        public class IncomingReceiptProtocolEntity
            : ReceiptProtocolEntity {
            
            public object _from;
            
            public object items;
            
            public None offline;
            
            public object participant;
            
            public object timestamp;
            
            public Func<object> type;
            
            public IncomingReceiptProtocolEntity(
                object _id,
                object _from,
                object timestamp,
                object offline = null,
                object type = null,
                object participant = null,
                object items = null) {
                this.setIncomingData(_from, timestamp, offline, type, participant, items);
            }
            
            public virtual object getType() {
                return this.type;
            }
            
            public virtual object getParticipant(object full = true) {
                if (this.participant) {
                    return full ? this.participant : this.participant.split("@")[0];
                }
            }
            
            public virtual object getFrom(object full = true) {
                return full ? this._from : this._from.split("@")[0];
            }
            
            public virtual object setIncomingData(
                object _from,
                object timestamp,
                object offline,
                object type = null,
                object participant = null,
                object items = null) {
                this._from = _from;
                this.timestamp = timestamp;
                this.type = type;
                this.participant = participant;
                if (offline != null) {
                    this.offline = offline == "1" ? true : false;
                } else {
                    this.offline = null;
                }
                this.items = items;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(IncomingReceiptProtocolEntity, this).toProtocolTreeNode();
                node.setAttribute("from", this._from);
                node.setAttribute("t", this.timestamp.ToString());
                if (this.offline != null) {
                    node.setAttribute("offline", this.offline ? "1" : "0");
                }
                if (this.type != null) {
                    node.setAttribute("type", this.type);
                }
                if (this.participant != null) {
                    node.setAttribute("participant", this.participant);
                }
                if (this.items != null) {
                    var inodes = new List<object>();
                    foreach (var item in this.items) {
                        var inode = ProtocolTreeNode("item", new Dictionary<object, object> {
                            {
                                "id",
                                item}});
                        inodes.append(inode);
                    }
                    var lnode = ProtocolTreeNode("list");
                    lnode.addChildren(inodes);
                    node.addChild(lnode);
                }
                return node;
            }
            
            public override object ToString() {
                var @out = super(IncomingReceiptProtocolEntity, this).@__str__();
                @out += String.Format("From: %s\n", this._from);
                @out += String.Format("Timestamp: %s\n", this.timestamp);
                if (this.offline != null) {
                    @out += String.Format("Offline: %s\n", this.offline ? "1" : "0");
                }
                if (this.type != null) {
                    @out += String.Format("Type: %s\n", this.type);
                }
                if (this.participant != null) {
                    @out += String.Format("Participant: %s\n", this.participant);
                }
                if (this.items != null) {
                    @out += String.Format("Items: %s\n", " ".join(this.items));
                }
                return @out;
            }
            
            public virtual object ack() {
                return OutgoingAckProtocolEntity(this.getId(), "receipt", this.getType(), this.getFrom(), participant: this.participant);
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                object items = null;
                var listNode = node.getChild("list");
                if (listNode != null) {
                    items = new List<object>();
                    foreach (var inode in listNode.getAllChildren("item")) {
                        items.append(inode["id"]);
                    }
                }
                return new IncomingReceiptProtocolEntity(node.getAttributeValue("id"), node.getAttributeValue("from"), node.getAttributeValue("t"), node.getAttributeValue("offline"), node.getAttributeValue("type"), node.getAttributeValue("participant"), items);
            }
        }
    }
}
