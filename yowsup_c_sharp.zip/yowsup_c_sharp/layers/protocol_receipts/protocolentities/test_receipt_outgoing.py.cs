namespace yowsup.layers.protocol_receipts.protocolentities
{

    using OutgoingReceiptProtocolEntity = yowsup.layers.protocol_receipts.protocolentities.OutgoingReceiptProtocolEntity;

    using ProtocolEntityTest = yowsup.structs.protocolentity.ProtocolEntityTest;

    public static class test_receipt_outgoing {
        
        public class OutgoingReceiptProtocolEntityTest
            : ProtocolEntityTest, unittest.TestCase {
            
            public object node;
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                this.ProtocolEntity = OutgoingReceiptProtocolEntity;
                this.node = OutgoingReceiptProtocolEntity("123", "target", "read").toProtocolTreeNode();
            }
        }
    }
}
