namespace yowsup.layers.protocol_receipts.protocolentities
{

    public static class @__init__ {
    }
}
