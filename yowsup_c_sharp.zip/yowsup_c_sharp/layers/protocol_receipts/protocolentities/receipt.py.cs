namespace yowsup.layers.protocol_receipts.protocolentities
{

    using ProtocolEntity = yowsup.structs.ProtocolEntity;

    using System.Collections.Generic;

    using System;

    public static class receipt {
        
        // 
        //     delivered:
        //     <receipt to="xxxxxxxxxxx@s.whatsapp.net" id="1415389947-15"></receipt>
        // 
        //     read
        //     <receipt to="xxxxxxxxxxx@s.whatsapp.net" id="1415389947-15" type="read || played"></receipt>
        // 
        //     INCOMING
        //     <receipt offline="0" from="4915225256022@s.whatsapp.net" id="1415577964-1" t="1415578027" type="played?"></receipt>
        //     
        public class ReceiptProtocolEntity
            : ProtocolEntity {
            
            public object _id;
            
            public ReceiptProtocolEntity(object _id) {
                this._id = _id;
            }
            
            public virtual object getId() {
                return this._id;
            }
            
            public virtual object toProtocolTreeNode() {
                var attribs = new Dictionary<object, object> {
                    {
                        "id",
                        this._id}};
                return this._createProtocolTreeNode(attribs, null, data: null);
            }
            
            public override object ToString() {
                var @out = "Receipt:\n";
                @out += String.Format("ID: %s\n", this._id);
                return @out;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                return new ReceiptProtocolEntity(node.getAttributeValue("id"));
            }
        }
    }
}
