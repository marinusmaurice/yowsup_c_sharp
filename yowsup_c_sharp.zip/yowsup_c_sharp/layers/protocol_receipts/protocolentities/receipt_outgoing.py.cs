namespace yowsup.layers.protocol_receipts.protocolentities
{

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using ReceiptProtocolEntity = receipt.ReceiptProtocolEntity;

    using System.Collections.Generic;

    using System.Linq;

    using System;

    public static class receipt_outgoing {
        
        // 
        //     delivered:
        //     If we send the following without "to" specified, whatsapp will consider the message delivered,
        //     but will not notify the sender.
        //     <receipt to="xxxxxxxxxxx@s.whatsapp.net" id="1415389947-15"></receipt>
        // 
        //     read
        //     <receipt to="xxxxxxxxxxx@s.whatsapp.net" id="1415389947-15" type="read"></receipt>
        // 
        //     multiple items:
        //     <receipt type="read" to="xxxxxxxxxxxx@s.whatsapp.net" id="1431364583-191">
        //         <list>
        //             <item id="1431364572-189"></item>
        //             <item id="1431364575-190"></item>
        //         </list>
        //     </receipt>
        //     
        public class OutgoingReceiptProtocolEntity
            : ReceiptProtocolEntity {
            
            public object callId;
            
            public object messageIds;
            
            public object participant;
            
            public object read;
            
            public object to;
            
            public OutgoingReceiptProtocolEntity(
                object messageIds,
                object to,
                object read = false,
                object participant = null,
                object callId = null) {
                object receiptId;
                if ((list, tuple).Contains(type(messageIds))) {
                    if (messageIds.Count > 1) {
                        receiptId = this._generateId();
                    } else {
                        receiptId = messageIds[0];
                    }
                } else {
                    receiptId = messageIds;
                    messageIds = new List<List<object>> {
                        messageIds
                    };
                }
                super(OutgoingReceiptProtocolEntity, this).@__init__(receiptId);
                this.setOutgoingData(messageIds, to, read, participant, callId);
            }
            
            public virtual object setOutgoingData(
                object messageIds,
                object to,
                object read,
                object participant,
                object callId) {
                this.messageIds = messageIds;
                this.to = to;
                this.read = read;
                this.participant = participant;
                this.callId = callId;
            }
            
            public virtual object getMessageIds() {
                return this.messageIds;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(OutgoingReceiptProtocolEntity, this).toProtocolTreeNode();
                if (this.read) {
                    node.setAttribute("type", "read");
                }
                if (this.participant) {
                    node.setAttribute("participant", this.participant);
                }
                if (this.callId) {
                    var offer = ProtocolTreeNode("offer", new Dictionary<object, object> {
                        {
                            "call-id",
                            this.callId}});
                    node.addChild(offer);
                }
                node.setAttribute("to", this.to);
                if (this.messageIds.Count > 1) {
                    var listNode = ProtocolTreeNode("list");
                    listNode.addChildren((from mId in this.messageIds
                        select ProtocolTreeNode("item", new Dictionary<object, object> {
                            {
                                "id",
                                mId}})).ToList());
                    node.addChild(listNode);
                }
                return node;
            }
            
            public override object ToString() {
                var @out = super(OutgoingReceiptProtocolEntity, this).@__str__();
                @out += String.Format("To: \n%s", this.to);
                if (this.read) {
                    @out += String.Format("Type: \n%s", "read");
                }
                @out += String.Format("For: \n%s", this.messageIds);
                return @out;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var listNode = node.getChild("list");
                var messageIds = new List<object>();
                if (listNode) {
                    messageIds = (from child in listNode.getChildren()
                        select child["id"]).ToList();
                } else {
                    messageIds = new List<object> {
                        node["id"]
                    };
                }
                return new OutgoingReceiptProtocolEntity(messageIds, node["to"], node["type"] == "read", node["participant"]);
            }
        }
    }
}
