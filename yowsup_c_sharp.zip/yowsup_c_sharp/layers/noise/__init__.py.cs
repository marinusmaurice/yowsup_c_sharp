namespace yowsup.layers.noise {
    
    public static class @__init__ {
    }
}
