namespace yowsup.layers.noise.workers
{

    using HandshakeFailedException = consonance.exceptions.handshake_failed_exception.HandshakeFailedException;

    public static class handshake {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class WANoiseProtocolHandshakeWorker
            : threading.Thread {
            
            public object _client_config;
            
            public object _finish_callback;
            
            public object _protocol;
            
            public object _rs;
            
            public object _s;
            
            public object _stream;
            
            public bool daemon;
            
            public WANoiseProtocolHandshakeWorker(
                object wanoiseprotocol,
                object stream,
                object client_config,
                object s,
                object rs = null,
                object finish_callback = null) {
                this.daemon = true;
                this._protocol = wanoiseprotocol;
                this._stream = stream;
                this._client_config = client_config;
                this._s = s;
                this._rs = rs;
                this._finish_callback = finish_callback;
            }
            
            public virtual object run() {
                this._protocol.reset();
                object error = null;
                try {
                    this._protocol.start(this._stream, this._client_config, this._s, this._rs);
                } catch (HandshakeFailedException) {
                    error = e;
                }
                if (this._finish_callback != null) {
                    this._finish_callback(error);
                }
            }
        }
    }
}
