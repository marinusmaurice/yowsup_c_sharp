namespace yowsup.layers.noise.workers {
    
    public static class @__init__ {
    }
}
