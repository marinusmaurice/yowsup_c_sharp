namespace yowsup.layers.noise
{

    using YowLayer = yowsup.layers.YowLayer;

    using System;

    public static class layer_noise_segments {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class YowNoiseSegmentsLayer
            : YowLayer {
            
            public object _read_buffer;
            
            public string PROP_ENABLED;
            
            public string PROP_ENABLED = "org.openwhatsapp.yowsup.prop.noise.segmented_enabled";
            
            public YowNoiseSegmentsLayer() {
                this._read_buffer = bytearray();
            }
            
            public override object ToString() {
                return "Noise Segments Layer";
            }
            
            public virtual object send(object data) {
                if (data.Count >= 16777216) {
                    throw new ValueError(String.Format("data too large to write; length=%d", data.Count));
                }
                if (this.getProp(this.PROP_ENABLED, false)) {
                    this.toLower(@struct.pack(">I", data.Count)[1]);
                }
                this.toLower(data);
            }
            
            public virtual object receive(object data) {
                if (this.getProp(this.PROP_ENABLED, false)) {
                    this._read_buffer.extend(data);
                    while (this._read_buffer.Count > 3) {
                        var read_size = @struct.unpack(">I", new byte[] { 0x00 } + this._read_buffer[::3])[0];
                        if (this._read_buffer.Count >= 3 + read_size) {
                            data = this._read_buffer[3::(read_size  +  3)];
                            this._read_buffer = this._read_buffer[3 + read_size];
                            this.toUpper(bytes(data));
                        } else {
                            beak;
                        }
                    }
                } else {
                    this.toUpper(data);
                }
            }
        }
    }
}
