namespace yowsup.layers.noise
{

    using YowLayer = yowsup.layers.YowLayer;

    using EventCallback = yowsup.layers.EventCallback;

    using YowAuthenticationProtocolLayer = yowsup.layers.auth.layer_authentication.YowAuthenticationProtocolLayer;

    using YowNetworkLayer = yowsup.layers.network.layer.YowNetworkLayer;

    using YowNoiseSegmentsLayer = yowsup.layers.noise.layer_noise_segments.YowNoiseSegmentsLayer;

    using YowsupEnv = yowsup.env.env.YowsupEnv;

    using WANoiseProtocol = consonance.protocol.WANoiseProtocol;

    using ClientConfig = consonance.config.client.ClientConfig;

    using UserAgentConfig = consonance.config.useragent.UserAgentConfig;

    using BlockingQueueSegmentedStream = consonance.streams.segmented.blockingqueue.BlockingQueueSegmentedStream;

    using KeyPair = consonance.structs.keypair.KeyPair;

    using Queue = queue;

    using System;

    using System.Diagnostics;

    using System.Collections.Generic;

    public static class layer {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class YowNoiseLayer
            : YowLayer {
            
            public object _flush_lock;
            
            public object _handshake_worker;
            
            public object _incoming_segments_queue;
            
            public object _profile;
            
            public object _read_buffer;
            
            public object _rs;
            
            public object _stream;
            
            public object _wa_noiseprotocol;
            
            public string DEFAULT_PUSHNAME;
            
            public string EDGE_HEADER;
            
            public string EVENT_HANDSHAKE_FAILED;
            
            public string HEADER;
            
            public string DEFAULT_PUSHNAME = "yowsup";
            
            public string HEADER = new byte[] { (byte)'W', (byte)'A', 0x02, 0x01 };
            
            public string EDGE_HEADER = new byte[] { (byte)'E', (byte)'D', 0x00, 0x01 };
            
            public string EVENT_HANDSHAKE_FAILED = "org.whatsapp.yowsup.layer.noise.event.handshake_failed";
            
            public YowNoiseLayer() {
                this._wa_noiseprotocol = WANoiseProtocol(2, 1, protocol_state_callbacks: this._on_protocol_state_changed);
                this._handshake_worker = null;
                this._stream = BlockingQueueSegmentedStream();
                this._read_buffer = bytearray();
                this._flush_lock = threading.Lock();
                this._incoming_segments_queue = Queue.Queue();
                this._profile = null;
                this._rs = null;
            }
            
            public override object ToString() {
                return "Noise Layer";
            }
            
            [EventCallback(YowNetworkLayer.EVENT_STATE_DISCONNECTED)]
            public virtual object on_disconnected(object @event) {
                this._wa_noiseprotocol.reset();
            }
            
            [EventCallback(YowAuthenticationProtocolLayer.EVENT_AUTH)]
            public virtual object on_auth(object @event) {
                logger.debug("Received auth event");
                this._profile = this.getProp("profile");
                var config = this._profile.config;
                // event's keypair will override config's keypair
                var local_static = config.client_static_keypair;
                var username = Convert.ToInt32(this._profile.username);
                if (local_static == null) {
                    logger.error("client_static_keypair is not defined in specified config, disconnecting");
                    this.boadcastEvent(YowLayerEvent(YowNetworkLayer.EVENT_STATE_DISCONNECT, reason: "client_static_keypair is not defined in specified config"));
                } else {
                    if (object.ReferenceEquals(type(local_static), bytes)) {
                        local_static = KeyPair.from_bytes(local_static);
                    }
                    Debug.Assert(object.ReferenceEquals(type(local_static), KeyPair));
                    Debug.Assert(type(local_static));
                    var passive = @event.getArg("passive");
                    this.setProp(YowNoiseSegmentsLayer.PROP_ENABLED, false);
                    if (config.edge_routing_info) {
                        this.toLower(this.EDGE_HEADER);
                        this.setProp(YowNoiseSegmentsLayer.PROP_ENABLED, true);
                        this.toLower(config.edge_routing_info);
                        this.setProp(YowNoiseSegmentsLayer.PROP_ENABLED, false);
                    }
                    this.toLower(this.HEADER);
                    this.setProp(YowNoiseSegmentsLayer.PROP_ENABLED, true);
                    var remote_static = config.server_static_public;
                    this._rs = remote_static;
                    var yowsupenv = YowsupEnv.getCurrent();
                    var client_config = ClientConfig(username: username, passive: passive, useragent: UserAgentConfig(platform: 0, app_version: yowsupenv.getVersion(), mcc: config.mcc || "000", mnc: config.mnc || "000", os_version: yowsupenv.getOSVersion(), manufacturer: yowsupenv.getManufacturer(), device: yowsupenv.getDeviceName(), os_build_number: yowsupenv.getOSVersion(), phone_id: config.fdid || "", locale_lang: "en", locale_country: "US"), pushname: config.pushname || this.DEFAULT_PUSHNAME, short_connect: true);
                    if (!this._in_handshake()) {
                        logger.debug(String.Format("Performing handshake [username= %d, passive=%s]", username, passive));
                        this._handshake_worker = WANoiseProtocolHandshakeWorker(this._wa_noiseprotocol, this._stream, client_config, local_static, remote_static, this.on_handshake_finished);
                        logger.debug("Starting handshake worker");
                        this._stream.set_events_callback(this._handle_stream_event);
                        this._handshake_worker.start();
                    }
                }
            }
            
            public virtual object on_handshake_finished(object e = null) {
                // type: (Exception) -> None
                if (e != null) {
                    this.emitEvent(YowLayerEvent(this.EVENT_HANDSHAKE_FAILED, reason: e));
                    var data = WriteEncoder(TokenDictionary()).protocolTreeNodeToBytes(ProtocolTreeNode("failure", new Dictionary<object, object> {
                        {
                            "reason",
                            e.ToString()}}));
                    this.toUpper(data);
                    logger.error("An error occurred during handshake, try login again.");
                }
            }
            
            // 
            //         :return:
            //         :rtype: bool
            //         
            public virtual object _in_handshake() {
                return this._wa_noiseprotocol.state == WANoiseProtocol.STATE_HANDSHAKE;
            }
            
            public virtual object _on_protocol_state_changed(object state) {
                if (state == WANoiseProtocol.STATE_TRANSPORT) {
                    if (this._rs != this._wa_noiseprotocol.rs) {
                        var config = this._profile.config;
                        config.server_static_public = this._wa_noiseprotocol.rs;
                        this._profile.write_config(config);
                        this._rs = this._wa_noiseprotocol.rs;
                    }
                    this._flush_incoming_buffer();
                }
            }
            
            public virtual object _handle_stream_event(object @event) {
                if (@event == BlockingQueueSegmentedStream.EVENT_WRITE) {
                    this.toLower(this._stream.get_write_segment());
                } else if (@event == BlockingQueueSegmentedStream.EVENT_READ) {
                    this._stream.put_read_segment(this._incoming_segments_queue.get(block: true));
                }
            }
            
            // 
            //         :param data:
            //         :type data: bytearray | bytes
            //         :return:
            //         :rtype:
            //         
            public virtual object send(object data) {
                data = type(data) != bytes ? bytes(data) : data;
                this._wa_noiseprotocol.send(data);
            }
            
            public virtual object _flush_incoming_buffer() {
                this._flush_lock.acquire();
                while (this._incoming_segments_queue.qsize()) {
                    this.toUpper(this._wa_noiseprotocol.receive());
                }
                this._flush_lock.release();
            }
            
            // 
            //         :param data:
            //         :type data: bytes
            //         :return:
            //         :rtype:
            //         
            public virtual object receive(object data) {
                this._incoming_segments_queue.put(data);
                if (!this._in_handshake()) {
                    this._flush_incoming_buffer();
                }
            }
        }
    }
}
