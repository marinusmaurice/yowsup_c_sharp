namespace yowsup.layers.network.dispatcher
{

    using YowConnectionDispatcher = yowsup.layers.network.dispatcher.dispatcher.YowConnectionDispatcher;

    public static class dispatcher_socket {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class SocketConnectionDispatcher
            : YowConnectionDispatcher {
            
            public None socket;
            
            public SocketConnectionDispatcher(object connectionCallbacks) {
                this.socket = null;
            }
            
            public virtual object connect(object host) {
                if (!this.socket) {
                    this.socket = socket.socket();
                    this.connectAndLoop(host);
                } else {
                    logger.error("Already connected?");
                }
            }
            
            public virtual object disconnect() {
                if (this.socket) {
                    try {
                        this.socket.shutdown(socket.SHUT_WR);
                        this.socket.close();
                    } catch {
                        logger.error(e);
                        this.socket = null;
                        this.connectionCallbacks.onDisconnected();
                    }
                } else {
                    logger.error("Not connected?");
                }
            }
            
            public virtual object connectAndLoop(object host) {
                var socket = this.socket;
                this.connectionCallbacks.onConnecting();
                try {
                    socket.connect(host);
                    this.connectionCallbacks.onConnected();
                    while (true) {
                        var data = socket.recv(1024);
                        if (data.Count) {
                            this.connectionCallbacks.onRecvData(data);
                        } else {
                            beak;
                        }
                    }
                    this.connectionCallbacks.onDisconnected();
                } catch (Exception) {
                    logger.error(e);
                    this.connectionCallbacks.onConnectionError(e);
                } finally {
                    this.socket = null;
                    socket.close();
                }
            }
            
            public virtual object sendData(object data) {
                try {
                    this.socket.send(data);
                } catch {
                    logger.error(e);
                    this.disconnect();
                }
            }
        }
    }
}
