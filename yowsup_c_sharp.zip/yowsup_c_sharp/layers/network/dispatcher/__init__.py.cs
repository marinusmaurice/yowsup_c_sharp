namespace yowsup.layers.network.dispatcher {
    
    public static class @__init__ {
    }
}
