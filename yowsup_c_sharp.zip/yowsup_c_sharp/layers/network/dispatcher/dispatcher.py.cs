namespace yowsup.layers.network.dispatcher {
    
    using System.Diagnostics;
    
    public static class dispatcher {
        
        public class ConnectionCallbacks
            : object {
            
            public virtual object onConnected() {
            }
            
            public virtual object onDisconnected() {
            }
            
            public virtual object onRecvData(object data) {
            }
            
            public virtual object onConnecting() {
            }
            
            public virtual object onConnectionError(object error) {
            }
        }
        
        public class YowConnectionDispatcher
            : object {
            
            public object connectionCallbacks;
            
            public YowConnectionDispatcher(object connectionCallbacks) {
                Debug.Assert(connectionCallbacks is ConnectionCallbacks);
                this.connectionCallbacks = connectionCallbacks;
            }
            
            public virtual object connect(object host) {
            }
            
            public virtual object disconnect() {
            }
            
            public virtual object sendData(object data) {
            }
        }
    }
}
