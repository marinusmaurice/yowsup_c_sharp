namespace yowsup.layers.network.dispatcher
{

    using YowConnectionDispatcher = yowsup.layers.network.dispatcher.dispatcher.YowConnectionDispatcher;

    using System;

    public static class dispatcher_asyncore {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class AsyncoreConnectionDispatcher
            : YowConnectionDispatcher, asyncore.dispatcher_with_send {
            
            public bool _connected;
            
            public object out_buffer;
            
            public AsyncoreConnectionDispatcher(object connectionCallbacks) {
                asyncore.dispatcher_with_send.@__init__(this);
                this._connected = false;
            }
            
            public virtual object sendData(object data) {
                if (this._connected) {
                    this.out_buffer = this.out_buffer + data;
                    this.initiate_send();
                } else {
                    logger.warn(String.Format("Attempted to send %d bytes while still not connected", data.Count));
                }
            }
            
            public virtual object connect(object host) {
                logger.debug(String.Format("connect(%s)", host.ToString()));
                this.connectionCallbacks.onConnecting();
                this.create_socket(socket.AF_INET, socket.SOCK_STREAM);
                asyncore.dispatcher_with_send.connect(this, host);
                asyncore.loop(timeout: 1);
            }
            
            public virtual object handle_connect() {
                logger.debug("handle_connect");
                if (!this._connected) {
                    this._connected = true;
                    this.connectionCallbacks.onConnected();
                }
            }
            
            public virtual object handle_close() {
                logger.debug("handle_close");
                this.close();
                this._connected = false;
                this.connectionCallbacks.onDisconnected();
            }
            
            public virtual object handle_error() {
                logger.error(traceback.format_exc());
                this.handle_close();
            }
            
            public virtual object handle_read() {
                var data = this.recv(1024);
                this.connectionCallbacks.onRecvData(data);
            }
            
            public virtual object disconnect() {
                logger.debug("disconnect");
                this.handle_close();
            }
        }
    }
}
