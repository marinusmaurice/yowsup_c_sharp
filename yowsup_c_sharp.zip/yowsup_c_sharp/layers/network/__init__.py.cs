namespace yowsup.layers.network
{

    public static class @__init__ {
    }
}
