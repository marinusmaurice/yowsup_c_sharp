namespace yowsup.layers.network
{

    using YowLayer = yowsup.layers.YowLayer;

    using EventCallback = yowsup.layers.EventCallback;

    using ConnectionCallbacks = yowsup.layers.network.dispatcher.dispatcher.ConnectionCallbacks;

    using System;

    public static class layer {
        
        public static logger logger = logging.getLogger(@__name__);
        
        // This layer wraps a connection dispatcher that provides connection and a communication channel
        //     to remote endpoints. Unless explicitly configured, applications should not make assumption about
        //     the dispatcher being used as the default dispatcher could be changed across versions
        public class YowNetworkLayer
            : YowLayer, ConnectionCallbacks {
            
            public object _disconnect_reason;
            
            public None _dispatcher;
            
            public bool connected;
            
            public int DISPATCHER_ASYNCORE;
            
            public int DISPATCHER_DEFAULT;
            
            public int DISPATCHER_SOCKET;
            
            public string EVENT_STATE_CONNECT;
            
            public string EVENT_STATE_CONNECTED;
            
            public string EVENT_STATE_DISCONNECT;
            
            public string EVENT_STATE_DISCONNECTED;
            
            public object interface;
            
            public string PROP_DISPATCHER;
            
            public string PROP_ENDPOINT;
            
            public string PROP_NET_READSIZE;
            
            public object state;
            
            public int STATE_CONNECTED;
            
            public int STATE_CONNECTING;
            
            public int STATE_DISCONNECTED;
            
            public int STATE_DISCONNECTING;
            
            public string EVENT_STATE_CONNECT = "org.openwhatsapp.yowsup.event.network.connect";
            
            public string EVENT_STATE_DISCONNECT = "org.openwhatsapp.yowsup.event.network.disconnect";
            
            public string EVENT_STATE_CONNECTED = "org.openwhatsapp.yowsup.event.network.connected";
            
            public string EVENT_STATE_DISCONNECTED = "org.openwhatsapp.yowsup.event.network.disconnected";
            
            public string PROP_ENDPOINT = "org.openwhatsapp.yowsup.prop.endpoint";
            
            public string PROP_NET_READSIZE = "org.openwhatsapp.yowsup.prop.net.readSize";
            
            public string PROP_DISPATCHER = "org.openwhatsapp.yowsup.prop.net.dispatcher";
            
            public int STATE_DISCONNECTED = 0;
            
            public int STATE_CONNECTING = 1;
            
            public int STATE_CONNECTED = 2;
            
            public int STATE_DISCONNECTING = 3;
            
            public int DISPATCHER_SOCKET = 0;
            
            public int DISPATCHER_ASYNCORE = 1;
            
            public int DISPATCHER_DEFAULT = DISPATCHER_ASYNCORE;
            
            public YowNetworkLayer() {
                this.state = this.@__class__.STATE_DISCONNECTED;
                YowLayer.@__init__(this);
                ConnectionCallbacks.@__init__(this);
                this.interface = YowNetworkLayerInterface(this);
                this.connected = false;
                this._dispatcher = null;
                this._disconnect_reason = null;
            }
            
            public virtual object @__create_dispatcher(object dispatcher_type) {
                if (dispatcher_type == this.DISPATCHER_ASYNCORE) {
                    logger.debug("Created asyncore dispatcher");
                    return AsyncoreConnectionDispatcher(this);
                } else {
                    logger.debug("Created socket dispatcher");
                    return SocketConnectionDispatcher(this);
                }
            }
            
            public virtual object onConnected() {
                logger.debug("Connected");
                this.state = this.@__class__.STATE_CONNECTED;
                this.connected = true;
                this.emitEvent(YowLayerEvent(YowNetworkLayer.EVENT_STATE_CONNECTED));
            }
            
            public virtual object onDisconnected() {
                if (this.state != this.@__class__.STATE_DISCONNECTED) {
                    this.state = this.@__class__.STATE_DISCONNECTED;
                    this.connected = false;
                    logger.debug("Disconnected");
                    this.emitEvent(YowLayerEvent(this.@__class__.EVENT_STATE_DISCONNECTED, reason: this._disconnect_reason || "", detached: true));
                }
            }
            
            public virtual object onConnecting() {
            }
            
            public virtual object onConnectionError(object error) {
                this.onDisconnected();
            }
            
            [EventCallback(EVENT_STATE_CONNECT)]
            public virtual object onConnectLayerEvent(object ev) {
                if (!this.connected) {
                    this.createConnection();
                } else {
                    logger.warn("Received connect event while already connected");
                }
                return true;
            }
            
            [EventCallback(EVENT_STATE_DISCONNECT)]
            public virtual object onDisconnectLayerEvent(object ev) {
                this.destroyConnection(ev.getArg("reason"));
                return true;
            }
            
            public virtual object createConnection() {
                this._disconnect_reason = null;
                this._dispatcher = this.@__create_dispatcher(this.getProp(this.PROP_DISPATCHER, this.DISPATCHER_DEFAULT));
                this.state = this.@__class__.STATE_CONNECTING;
                var endpoint = this.getProp(this.@__class__.PROP_ENDPOINT);
                logger.info(String.Format("Connecting to %s:%s", endpoint));
                this._dispatcher.connect(endpoint);
            }
            
            public virtual object destroyConnection(object reason = null) {
                this._disconnect_reason = reason;
                this.state = this.@__class__.STATE_DISCONNECTING;
                this._dispatcher.disconnect();
            }
            
            public virtual object getStatus() {
                return this.connected;
            }
            
            public virtual object send(object data) {
                if (this.connected) {
                    this._dispatcher.sendData(data);
                }
            }
            
            public virtual object onRecvData(object data) {
                this.receive(data);
            }
            
            public virtual object receive(object data) {
                this.toUpper(data);
            }
            
            public override object ToString() {
                return "Network Layer";
            }
        }
    }
}
