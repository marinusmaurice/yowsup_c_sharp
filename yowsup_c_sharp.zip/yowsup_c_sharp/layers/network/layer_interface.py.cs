namespace yowsup.layers.network {
    
    using YowLayerInterface = yowsup.layers.YowLayerInterface;
    
    public static class layer_interface {
        
        public class YowNetworkLayerInterface
            : YowLayerInterface {
            
            public virtual object connect() {
                this._layer.createConnection();
            }
            
            public virtual object disconnect() {
                this._layer.destroyConnection();
            }
            
            public virtual object getStatus() {
                return this._layer.getStatus();
            }
        }
    }
}
