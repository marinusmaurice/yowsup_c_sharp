namespace yowsup.layers.coder
{

    using YowLayer = yowsup.layers.YowLayer;

    using System.Collections.Generic;

    public static class layer {
        
        public class YowCoderLayer
            : YowLayer {
            
            public object reader;
            
            public object writer;
            
            public YowCoderLayer() {
                var tokenDictionary = TokenDictionary();
                this.writer = WriteEncoder(tokenDictionary);
                this.reader = ReadDecoder(tokenDictionary);
            }
            
            public virtual object send(object data) {
                this.write(this.writer.protocolTreeNodeToBytes(data));
            }
            
            public virtual object receive(object data) {
                var node = this.reader.getProtocolTreeNode(bytearray(data));
                if (node) {
                    this.toUpper(node);
                }
            }
            
            public virtual object write(object i) {
                if ((list, tuple).Contains(type(i))) {
                    this.toLower(bytearray(i));
                } else {
                    this.toLower(bytearray(new List<object> {
                        i
                    }));
                }
            }
            
            public override object ToString() {
                return "Coder Layer";
            }
        }
    }
}
