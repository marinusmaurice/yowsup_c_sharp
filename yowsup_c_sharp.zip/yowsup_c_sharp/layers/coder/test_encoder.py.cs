namespace yowsup.layers.coder
{

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using System.Collections.Generic;

    public static class test_encoder {
        
        public class EncoderTest
            : unittest.TestCase {
            
            public object encoder;
            
            public List<object> res;
            
            public virtual object setUp() {
                this.res = new List<object>();
                this.encoder = WriteEncoder(TokenDictionary());
            }
            
            public virtual object test_encode() {
                var node = ProtocolTreeNode("message", new Dictionary<object, object> {
                    {
                        "form",
                        "abc"},
                    {
                        "to",
                        "xyz"}}, new List<object> {
                    ProtocolTreeNode("media", new Dictionary<object, object> {
                        {
                            "width",
                            "123"}}, data: new byte[] { (byte)'1', (byte)'2', (byte)'3', (byte)'4', (byte)'5', (byte)'6' })
                });
                var result = this.encoder.protocolTreeNodeToBytes(node);
                this.assertTrue((new List<int> {
                    0,
                    248,
                    6,
                    95,
                    179,
                    252,
                    3,
                    120,
                    121,
                    122,
                    252,
                    4,
                    102,
                    111,
                    114,
                    109,
                    252,
                    3,
                    97,
                    98,
                    99,
                    248,
                    1,
                    248,
                    4,
                    93,
                    236,
                    104,
                    255,
                    130,
                    18,
                    63,
                    252,
                    6,
                    49,
                    50,
                    51,
                    52,
                    53,
                    54
                }, new List<int> {
                    0,
                    248,
                    6,
                    95,
                    252,
                    4,
                    102,
                    111,
                    114,
                    109,
                    252,
                    3,
                    97,
                    98,
                    99,
                    179,
                    252,
                    3,
                    120,
                    121,
                    122,
                    248,
                    1,
                    248,
                    4,
                    93,
                    236,
                    104,
                    255,
                    130,
                    18,
                    63,
                    252,
                    6,
                    49,
                    50,
                    51,
                    52,
                    53,
                    54
                }).Contains(result));
            }
        }
    }
}
