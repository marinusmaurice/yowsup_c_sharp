namespace yowsup.layers.coder
{

    public static class @__init__ {
    }
}
