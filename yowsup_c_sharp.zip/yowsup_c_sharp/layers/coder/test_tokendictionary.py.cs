namespace yowsup.layers.coder
{

    public static class test_tokendictionary {
        
        public class TokenDictionaryTest
            : unittest.TestCase {
            
            public object tokenDictionary;
            
            public virtual object setUp() {
                this.tokenDictionary = TokenDictionary();
            }
            
            public virtual object test_getToken() {
                this.assertEqual(this.tokenDictionary.getToken(80), "iq");
            }
            
            public virtual object test_getIndex() {
                this.assertEqual(this.tokenDictionary.getIndex("iq"), (80, false));
            }
            
            public virtual object test_getSecondaryToken() {
                this.assertEqual(this.tokenDictionary.getToken(238), "amrnb");
            }
            
            public virtual object test_getSecondaryTokenExplicit() {
                this.assertEqual(this.tokenDictionary.getToken(11, true), "wmv");
            }
            
            public virtual object test_getSecondaryIndex() {
                this.assertEqual(this.tokenDictionary.getIndex("wmv"), (11, true));
            }
        }
    }
}
