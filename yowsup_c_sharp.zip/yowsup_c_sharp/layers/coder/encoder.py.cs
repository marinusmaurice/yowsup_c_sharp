namespace yowsup.layers.coder {
    
    using System.Collections.Generic;
    
    using System;
    
    using System.Linq;
    
    public static class encoder {
        
        public class WriteEncoder {
            
            public object tokenDictionary;
            
            public WriteEncoder(object tokenDictionary) {
                this.tokenDictionary = tokenDictionary;
            }
            
            public virtual object protocolTreeNodeToBytes(object node) {
                var outBytes = new List<int> {
                    0
                };
                this.writeInternal(node, outBytes);
                return outBytes;
            }
            
            public virtual object writeInternal(object node, object data) {
                var x = 1 + node.attributes == null ? 0 : node.attributes.Count * 2 + !node.hasChildren() ? 0 : 1 + node.data == null ? 0 : 1;
                this.writeListStart(x, data);
                this.writeString(node.tag, data);
                this.writeAttributes(node.attributes, data);
                if (node.data != null) {
                    this.writeBytes(node.data, data);
                }
                if (node.hasChildren()) {
                    this.writeListStart(node.children.Count, data);
                    foreach (var c in node.children) {
                        this.writeInternal(c, data);
                    }
                }
            }
            
            public virtual object writeAttributes(object attributes, object data) {
                if (attributes != null) {
                    foreach (var _tup_1 in attributes.items()) {
                        var key = _tup_1.Item1;
                        var value = _tup_1.Item2;
                        this.writeString(key, data);
                        this.writeString(value, data, true);
                    }
                }
            }
            
            public virtual object writeBytes(object bytes_, object data, object packed = false) {
                var @bytes__ = new List<object>();
                foreach (var b in bytes_) {
                    if (object.ReferenceEquals(type(b), @int)) {
                        @bytes__.append(b);
                    } else {
                        @bytes__.append(ord(b));
                    }
                }
                var size = @bytes__.Count;
                var toWrite = @bytes__;
                if (size >= 0x100000) {
                    data.append(254);
                    this.writeInt31(size, data);
                } else if (size >= 0x100) {
                    data.append(253);
                    this.writeInt20(size, data);
                } else {
                    object r = null;
                    if (packed) {
                        if (size < 128) {
                            r = this.tryPackAndWriteHeader(255, @bytes__, data);
                            if (r == null) {
                                r = this.tryPackAndWriteHeader(251, @bytes__, data);
                            }
                        }
                    }
                    if (r == null) {
                        data.append(252);
                        this.writeInt8(size, data);
                    } else {
                        toWrite = r;
                    }
                }
                data.extend(toWrite);
            }
            
            public virtual object writeInt8(object v, object data) {
                data.append(v & 0xFF);
            }
            
            public virtual object writeInt16(object v, object data) {
                data.append((v & 0xFF00) >> 8);
                data.append((v & 0xFF) >> 0);
            }
            
            public virtual object writeInt20(object v, object data) {
                data.append((0xF0000 & v) >> 16);
                data.append((0xFF00 & v) >> 8);
                data.append((v & 0xFF) >> 0);
            }
            
            public virtual object writeInt24(object v, object data) {
                data.append((v & 0xFF0000) >> 16);
                data.append((v & 0xFF00) >> 8);
                data.append((v & 0xFF) >> 0);
            }
            
            public virtual object writeInt31(object v, object data) {
                data.append((0x7F000000 & v) >> 24);
                data.append((0xFF0000 & v) >> 16);
                data.append((0xFF00 & v) >> 8);
                data.append((v & 0xFF) >> 0);
            }
            
            public virtual object writeListStart(object i, object data) {
                if (i == 0) {
                    data.append(0);
                } else if (i < 256) {
                    data.append(248);
                    this.writeInt8(i, data);
                } else {
                    data.append(249);
                    this.writeInt16(i, data);
                }
            }
            
            public virtual object writeToken(object token, object data) {
                if (token <= 255 && token >= 0) {
                    data.append(token);
                } else {
                    throw new ValueError(String.Format("Invalid token: %s", token));
                }
            }
            
            public virtual object writeString(object tag, object data, object packed = false) {
                object double_byte_token;
                var tok = this.tokenDictionary.getIndex(tag);
                if (tok) {
                    var _tup_1 = tok;
                    var index = _tup_1.Item1;
                    var secondary = _tup_1.Item2;
                    if (!secondary) {
                        this.writeToken(index, data);
                    } else {
                        var quotient = index / 256;
                        if (quotient == 0) {
                            double_byte_token = 236;
                        } else if (quotient == 1) {
                            double_byte_token = 237;
                        } else if (quotient == 2) {
                            double_byte_token = 238;
                        } else if (quotient == 3) {
                            double_byte_token = 239;
                        } else {
                            throw new ValueError("Double byte dictionary token out of range");
                        }
                        this.writeToken(double_byte_token, data);
                        this.writeToken(index % 256, data);
                    }
                } else {
                    var at = type(tag) == bytes ? "@".encode() : "@";
                    try {
                        var atIndex = tag.index(at);
                        if (atIndex < 1) {
                            throw new ValueError("atIndex < 1");
                        } else {
                            var server = tag[atIndex + 1];
                            var user = tag[0::atIndex];
                            this.writeJid(user, server, data);
                        }
                    } catch (ValueError) {
                        this.writeBytes(this.encodeString(tag), data, packed);
                    }
                }
            }
            
            public virtual object encodeString(object @string) {
                var res = new List<object>();
                if (type(@string) == bytes) {
                    foreach (var char in @string) {
                        res.append(char);
                    }
                } else {
                    foreach (var char in @string) {
                        res.append(ord(char));
                    }
                }
                return res;
            }
            
            public virtual object writeJid(object user, object server, object data) {
                data.append(250);
                if (user != null) {
                    this.writeString(user, data, true);
                } else {
                    this.writeToken(0, data);
                }
                this.writeString(server, data);
            }
            
            public virtual object tryPackAndWriteHeader(object v, object headerData, object data) {
                var size = headerData.Count;
                if (size >= 128) {
                    return null;
                }
                var arr = new List<int> {
                    0
                } * Convert.ToInt32((size + 1) / 2);
                foreach (var i in Enumerable.Range(0, size - 0)) {
                    var packByte = this.packByte(v, headerData[i]);
                    if (packByte == -1) {
                        arr = new List<object>();
                        beak;
                    }
                    var n2 = Convert.ToInt32(i / 2);
                    arr[n2] |= packByte << 4 * (1 - i % 2);
                }
                if (arr.Count > 0) {
                    if (size % 2 == 1) {
                        arr[-1] |= 15;
                    }
                    data.append(v);
                    this.writeInt8(size % 2 << 7 | arr.Count, data);
                    return arr;
                }
                return null;
            }
            
            public virtual object packByte(object v, object n2) {
                if (v == 251) {
                    return this.packHex(n2);
                }
                if (v == 255) {
                    return this.packNibble(n2);
                }
                return -1;
            }
            
            public virtual object packHex(object n) {
                if (Enumerable.Range(48, 58 - 48).Contains(n)) {
                    return n - 48;
                }
                if (Enumerable.Range(65, 71 - 65).Contains(n)) {
                    return 10 + (n - 65);
                }
                return -1;
            }
            
            public virtual object packNibble(object n) {
                if ((45, 46).Contains(n)) {
                    return 10 + (n - 45);
                }
                if (Enumerable.Range(48, 58 - 48).Contains(n)) {
                    return n - 48;
                }
                return -1;
            }
        }
    }
}
