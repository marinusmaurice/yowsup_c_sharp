namespace yowsup.layers.coder
{

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using System;

    using System.Linq;

    using System.Collections.Generic;

    public static class decoder {
        
        public class ReadDecoder {
            
            public bool streamStarted;
            
            public object tokenDictionary;
            
            public ReadDecoder(object tokenDictionary) {
                this.tokenDictionary = tokenDictionary;
            }
            
            public virtual object getProtocolTreeNode(object data) {
                if (object.ReferenceEquals(type(data), list)) {
                    data = bytearray(data);
                }
                if ((data[0] & this.tokenDictionary.FLAG_DEFLATE) != 0) {
                    data = bytearray(new byte[] { 0x00 } + zlib.decompress(bytes(data[1])));
                }
                if ((data[0] & this.tokenDictionary.FLAG_SEGMENTED) != 0) {
                    throw new ValueError("server to client stanza fragmentation not supported");
                }
                return this.nextTreeInternal(data[1]);
            }
            
            public virtual object getToken(object index, object data) {
                var token = this.tokenDictionary.getToken(index);
                if (!token) {
                    index = this.readInt8(data);
                    token = this.tokenDictionary.getToken(index, true);
                    if (!token) {
                        throw new ValueError(String.Format("Invalid token %s", token));
                    }
                }
                return token;
            }
            
            public virtual object getTokenDouble(object n, object n2) {
                var pos = n2 + n * 256;
                var token = this.tokenDictionary.getToken(pos, true);
                if (!token) {
                    throw new ValueError(String.Format("Invalid token %s", pos));
                }
                return token;
            }
            
            public virtual object streamStart(object data) {
                this.streamStarted = true;
                var tag = data.pop(0);
                var size = this.readListSize(tag, data);
                tag = data.pop(0);
                if (tag != 1) {
                    if (tag == 236) {
                        tag = data.pop(0) + 237;
                    }
                    var token = this.getToken(tag, data);
                    throw new Exception(String.Format("expecting STREAM_START in streamStart, instead got token: %s", token));
                }
                var attribCount = (size - 2 + size % 2) / 2;
                this.readAttributes(attribCount, data);
            }
            
            public virtual object readNibble(object data) {
                var _byte = this.readInt8(data);
                var ignoreLastNibble = @bool(_byte & 0x80);
                var size = _byte & 0x7f;
                var nrOfNibbles = size * 2 - Convert.ToInt32(ignoreLastNibble);
                var dataArr = this.readArray(size, data);
                var @string = "";
                foreach (var i in Enumerable.Range(0, nrOfNibbles - 0)) {
                    _byte = dataArr[Convert.ToInt32(math.floor(i / 2))];
                    var _shift = 4 * (1 - i % 2);
                    var dec = (_byte & 15 << _shift) >> _shift;
                    if ((0, 1, 2, 3, 4, 5, 6, 7, 8, 9).Contains(dec)) {
                        @string += dec.ToString();
                    } else if ((10, 11).Contains(dec)) {
                        @string += chr(dec - 10 + 45);
                    } else {
                        throw new Exception(String.Format("Bad nibble %s", dec));
                    }
                }
                return @string;
            }
            
            public virtual object readPacked8(object n, object data) {
                var size = this.readInt8(data);
                var remove = 0;
                if ((size & 0x80) != 0 && n == 251) {
                    remove = 1;
                }
                size = size & 0x7F;
                var text = bytearray(this.readArray(size, data));
                var hexData = binascii.hexlify(sys.version_info < (2, 7) ? text.ToString() : text).upper();
                var dataSize = hexData.Count;
                var @out = new List<object>();
                if (remove == 0) {
                    foreach (var i in Enumerable.Range(0, dataSize - 0)) {
                        var char = object.ReferenceEquals(type(hexData[i]), @int) ? chr(hexData[i]) : hexData[i];
                        var val = ord(binascii.unhexlify(String.Format("0%s", char)));
                        if (i == dataSize - 1 && val > 11 && n != 251) {
                            continue;
                        }
                        @out.append(this.unpackByte(n, val));
                    }
                } else {
                    @out = sys.version_info < (3, 0) ? map(ord, hexData[0:: - remove].ToList()) : hexData[0:: - remove].ToList();
                }
                return @out;
            }
            
            public virtual object unpackByte(object n, object n2) {
                if (n == 251) {
                    return this.unpackHex(n2);
                }
                if (n == 255) {
                    return this.unpackNibble(n2);
                }
                throw new ValueError(String.Format("bad packed type %s", n));
            }
            
            public virtual object unpackHex(object n) {
                if (Enumerable.Range(0, 10 - 0).Contains(n)) {
                    return n + 48;
                }
                if (Enumerable.Range(10, 16 - 10).Contains(n)) {
                    return 65 + (n - 10);
                }
                throw new ValueError(String.Format("bad hex %s", n));
            }
            
            public virtual object unpackNibble(object n) {
                if (Enumerable.Range(0, 10 - 0).Contains(n)) {
                    return n + 48;
                }
                if ((10, 11).Contains(n)) {
                    return 45 + (n - 10);
                }
                throw new ValueError(String.Format("bad nibble %s", n));
            }
            
            public virtual object readHeader(object data, object offset = 0) {
                var ret = 0;
                if (data.Count >= 3 + offset) {
                    var b0 = data[offset];
                    var b1 = data[offset + 1];
                    var b2 = data[offset + 2];
                    ret = b0 + (b1 << 16) + (b2 << 8);
                }
                return ret;
            }
            
            public virtual object readInt8(object data) {
                return data.pop(0);
            }
            
            public virtual object readInt16(object data) {
                var intTop = data.pop(0);
                var intBot = data.pop(0);
                var value = (intTop << 8) + intBot;
                if (value != null) {
                    return value;
                } else {
                    return "";
                }
            }
            
            public virtual object readInt20(object data) {
                var int1 = data.pop(0);
                var int2 = data.pop(0);
                var int3 = data.pop(0);
                return (int1 & 0xF) << 16 | int2 << 8 | int3;
            }
            
            public virtual object readInt24(object data) {
                var int1 = data.pop(0);
                var int2 = data.pop(0);
                var int3 = data.pop(0);
                var value = (int1 << 16) + (int2 << 8) + (int3 << 0);
                return value;
            }
            
            public virtual object readInt31(object data) {
                data.pop(0);
                var int1 = data.pop(0);
                var int2 = data.pop(0);
                var int3 = data.pop(0);
                return int1 << 24 | int1 << 16 | int2 << 8 | int3;
            }
            
            public virtual object readListSize(object token, object data) {
                var size = 0;
                if (token == 0) {
                    size = 0;
                } else if (token == 248) {
                    size = this.readInt8(data);
                } else if (token == 249) {
                    size = this.readInt16(data);
                } else {
                    throw new Exception("invalid list size in readListSize: token " + token.ToString());
                }
                return size;
            }
            
            public virtual object readAttributes(object attribCount, object data) {
                var attribs = new Dictionary<object, object> {
                };
                foreach (var i in Enumerable.Range(0, Convert.ToInt32(attribCount) - 0)) {
                    var key = this.readString(this.readInt8(data), data);
                    var value = this.readString(this.readInt8(data), data);
                    attribs[key] = value;
                }
                return attribs;
            }
            
            public virtual object readString(object token, object data) {
                if (token == -1) {
                    throw new Exception("-1 token in readString");
                }
                if (2 < token < 236) {
                    return this.getToken(token, data);
                }
                if (token == 0) {
                    return null;
                }
                if ((236, 237, 238, 239).Contains(token)) {
                    return this.getTokenDouble(token - 236, this.readInt8(data));
                }
                if (token == 250) {
                    var user = this.readString(data.pop(0), data);
                    var server = this.readString(data.pop(0), data);
                    if (user != null && server != null) {
                        return user + "@" + server;
                    }
                    if (server != null) {
                        return server;
                    }
                    throw new Exception("readString couldn't reconstruct jid");
                }
                if ((251, 255).Contains(token)) {
                    return "".join(map(chr, this.readPacked8(token, data)));
                }
                if (token == 252) {
                    var size8 = this.readInt8(data);
                    var buf8 = this.readArray(size8, data);
                    return "".join(map(chr, buf8));
                }
                if (token == 253) {
                    var size20 = this.readInt20(data);
                    var buf20 = this.readArray(size20, data);
                    return "".join(map(chr, buf20));
                }
                if (token == 254) {
                    var size31 = this.readInt31();
                    var buf31 = this.readArray(size31, data);
                    return "".join(map(chr, buf31));
                }
                throw new Exception("readString couldn't match token " + token.ToString());
            }
            
            public virtual object readArray(object length, object data) {
                var @out = data[::length];
                data.Remove(::length);
                return @out;
            }
            
            public virtual object nextTreeInternal(object data) {
                var size = this.readListSize(this.readInt8(data), data);
                var token = this.readInt8(data);
                if (token == 1) {
                    token = this.readInt8(data);
                }
                if (token == 2) {
                    return null;
                }
                var tag = this.readString(token, data);
                if (size == 0 || tag == null) {
                    throw new ValueError("nextTree sees 0 list or null tag");
                }
                var attribCount = (size - 2 + size % 2) / 2;
                var attribs = this.readAttributes(attribCount, data);
                if (size % 2 == 1) {
                    return ProtocolTreeNode(tag, attribs);
                }
                var read2 = this.readInt8(data);
                object nodeData = null;
                object nodeChildren = null;
                if (this.isListTag(read2)) {
                    nodeChildren = this.readList(read2, data);
                } else if (read2 == 252) {
                    size = this.readInt8(data);
                    nodeData = bytes(this.readArray(size, data));
                } else if (read2 == 253) {
                    size = this.readInt20(data);
                    nodeData = bytes(this.readArray(size, data));
                } else if (read2 == 254) {
                    size = this.readInt31(data);
                    nodeData = bytes(this.readArray(size, data));
                } else if ((255, 251).Contains(read2)) {
                    nodeData = this.readPacked8(read2, data);
                } else {
                    nodeData = this.readString(read2, data);
                }
                return ProtocolTreeNode(tag, attribs, nodeChildren, nodeData);
            }
            
            public virtual object readList(object token, object data) {
                var size = this.readListSize(token, data);
                var listx = new List<object>();
                foreach (var i in Enumerable.Range(0, size - 0)) {
                    listx.append(this.nextTreeInternal(data));
                }
                return listx;
            }
            
            public virtual object isListTag(object b) {
                return (248, 0, 249).Contains(b);
            }
        }
    }
}
