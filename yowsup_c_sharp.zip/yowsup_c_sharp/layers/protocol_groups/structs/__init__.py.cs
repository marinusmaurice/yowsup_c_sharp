namespace yowsup.layers.protocol_groups.structs
{

    public static class @__init__ {
    }
}
