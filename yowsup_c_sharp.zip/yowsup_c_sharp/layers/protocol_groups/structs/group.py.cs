namespace yowsup.layers.protocol_groups.structs {
    
    using System.Collections.Generic;
    
    using System;
    
    public static class group {
        
        public class Group
            : object {
            
            public int _creationTime;
            
            public object _creatorJid;
            
            public object _groupId;
            
            public Dictionary<object, object> _participants;
            
            public object _subject;
            
            public object _subjectOwnerJid;
            
            public int _subjectTime;
            
            public Group(
                object groupId,
                object creatorJid,
                object subject,
                object subjectOwnerJid,
                object subjectTime,
                object creationTime,
                object participants = null) {
                this._groupId = groupId;
                this._creatorJid = creatorJid;
                this._subject = subject;
                this._subjectOwnerJid = subjectOwnerJid;
                this._subjectTime = Convert.ToInt32(subjectTime);
                this._creationTime = Convert.ToInt32(creationTime);
                this._participants = participants || new Dictionary<object, object> {
                };
            }
            
            public virtual object getId() {
                return this._groupId;
            }
            
            public virtual object getCreator() {
                return this._creatorJid;
            }
            
            public virtual object getOwner() {
                return this.getCreator();
            }
            
            public virtual object getSubject() {
                return this._subject;
            }
            
            public virtual object getSubjectOwner() {
                return this._subjectOwnerJid;
            }
            
            public virtual object getSubjectTime() {
                return this._subjectTime;
            }
            
            public virtual object getCreationTime() {
                return this._creationTime;
            }
            
            public override object ToString() {
                return String.Format("ID: %s, Subject: %s, Creation: %s, Creator: %s, Subject Owner: %s, Subject Time: %s\nParticipants: %s", this.getId(), this.getSubject(), this.getCreationTime(), this.getCreator(), this.getSubjectOwner(), this.getSubjectTime(), ", ".join(this._participants.keys()));
            }
            
            public virtual object getParticipants() {
                return this._participants;
            }
        }
    }
}
