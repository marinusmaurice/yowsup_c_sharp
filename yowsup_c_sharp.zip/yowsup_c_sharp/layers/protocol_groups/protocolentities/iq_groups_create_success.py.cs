namespace yowsup.layers.protocol_groups.protocolentities
{

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using ResultIqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.ResultIqProtocolEntity;

    using System.Collections.Generic;

    public static class iq_groups_create_success {
        
        // 
        //     <iq type="result" id="{{id}}" from="g.us">
        //         <group id="{group_id}"></group>
        //     </iq>
        //     
        public class SuccessCreateGroupsIqProtocolEntity
            : ResultIqProtocolEntity {
            
            public object groupId;
            
            public SuccessCreateGroupsIqProtocolEntity(object _id, object groupId)
                : base(_id: _id) {
                this.setProps(groupId);
            }
            
            public virtual object setProps(object groupId) {
                this.groupId = groupId;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(SuccessCreateGroupsIqProtocolEntity, this).toProtocolTreeNode();
                node.addChild(ProtocolTreeNode("group", new Dictionary<object, object> {
                    {
                        "id",
                        this.groupId}}));
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = super(SuccessCreateGroupsIqProtocolEntity, SuccessCreateGroupsIqProtocolEntity).fromProtocolTreeNode(node);
                entity.@__class__ = SuccessCreateGroupsIqProtocolEntity;
                entity.setProps(node.getChild("group").getAttributeValue("id"));
                return entity;
            }
        }
    }
}
