namespace yowsup.layers.protocol_groups.protocolentities {
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using ResultIqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.ResultIqProtocolEntity;
    
    using System.Diagnostics;
    
    using System;
    
    using System.Collections.Generic;
    
    public static class iq_result_groups_info {
        
        // 
        // <iq type="result" from="{{GROUP_ID}}" id="{{IQ_ID}}">
        //   <group subject="{{GROUPSUBJ}}" creation="{{GROUP_CREATION_TYIME}}"
        //       creator="{{CREATOR_JID}}" s_t="{{SUBJECT_SET_TIMESTAMP}}" id="{{GROUP_ID}}"
        //       s_o="{{SUBJECT_OWNER_JID}}">
        //     <participant jid="{{PARTICIPANT_JID}}" type="admin"></participant>
        //     <participant jid="{{PARTICIPANT_JID}}"></participant>
        //     <participant jid="{{PARTICIPANT_JID}}"></participant>
        //   </group>
        // </iq>
        //     
        public class InfoGroupsResultIqProtocolEntity
            : ResultIqProtocolEntity {
            
            public int creationTimestamp;
            
            public object creatorJid;
            
            public object groupId;
            
            public object participants;
            
            public object subject;
            
            public object subjectOwnerJid;
            
            public int subjectTime;
            
            public string TYPE_PARTICIPANT_ADMIN;
            
            public string TYPE_PARTICIPANT_ADMIN = "admin";
            
            public InfoGroupsResultIqProtocolEntity(
                object _id,
                object _from,
                object groupId,
                object creationTimestamp,
                object creatorJid,
                object subject,
                object subjectTime,
                object subjectOwnerJid,
                object participants)
                : base(_from: _from) {
                this.setGroupProps(groupId, creationTimestamp, creatorJid, subject, subjectTime, subjectOwnerJid, participants);
            }
            
            public virtual object setGroupProps(
                object groupId,
                object creationTimestamp,
                object creatorJid,
                object subject,
                object subjectTime,
                object subjectOwnerJid,
                object participants) {
                Debug.Assert(object.ReferenceEquals(type(participants), dict));
                Debug.Assert("Participants must be a dict {jid => type?}");
                this.groupId = groupId;
                this.creationTimestamp = Convert.ToInt32(creationTimestamp);
                this.creatorJid = creatorJid;
                this.subject = subject;
                this.subjectTime = Convert.ToInt32(subjectTime);
                this.subjectOwnerJid = subjectOwnerJid;
                this.participants = participants;
            }
            
            public virtual object getParticipants() {
                return this.participants;
            }
            
            public virtual object getSubject() {
                return this.subject;
            }
            
            public virtual object getGroupId() {
                return this.groupId;
            }
            
            public virtual object getCreationTimestamp() {
                return this.creationTimestamp;
            }
            
            public virtual object getCreatorJid(object full = true) {
                return full ? this.creatorJid : this.creatorJid.split("@")[0];
            }
            
            public virtual object getSubjectTimestamp() {
                return this.subjectTime;
            }
            
            public virtual object getSubjectOwnerJid(object full = true) {
                return full ? this.subjectOwnerJid : this.subjectOwnerJid.split("@")[0];
            }
            
            public virtual object getGroupAdmins(object full = true) {
                var admins = new List<object>();
                foreach (var _tup_1 in this.participants.items()) {
                    var jid = _tup_1.Item1;
                    var _type = _tup_1.Item2;
                    if (_type == this.@__class__.TYPE_PARTICIPANT_ADMIN) {
                        admins.append(full ? jid : jid.split("@")[0]);
                    }
                }
                return admins;
            }
            
            public override object ToString() {
                var @out = super(InfoGroupsResultIqProtocolEntity, this).@__str__();
                @out += String.Format("Group ID: %s\n", this.groupId);
                @out += String.Format("Created: %s\n", this.creationTimestamp);
                @out += String.Format("Creator JID: %s\n", this.creatorJid);
                @out += String.Format("Subject: %s\n", this.subject);
                @out += String.Format("Subject Timestamp: %s\n", this.subjectTime);
                @out += String.Format("Subject owner JID: %s\n", this.subjectOwnerJid);
                @out += String.Format("Participants: %s\n", this.participants);
                return @out;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(InfoGroupsResultIqProtocolEntity, this).toProtocolTreeNode();
                var groupNode = ProtocolTreeNode("group", new Dictionary<object, object> {
                    {
                        "subject",
                        this.getSubject()},
                    {
                        "creation",
                        this.getCreationTimestamp().ToString()},
                    {
                        "creator",
                        this.getCreatorJid()},
                    {
                        "s_t",
                        this.getSubjectTimestamp()},
                    {
                        "s_o",
                        this.getSubjectOwnerJid()},
                    {
                        "id",
                        this.getGroupId()}});
                var participants = new List<object>();
                foreach (var _tup_1 in this.getParticipants().items()) {
                    var jid = _tup_1.Item1;
                    var _type = _tup_1.Item2;
                    var pnode = ProtocolTreeNode("participant", new Dictionary<object, object> {
                        {
                            "jid",
                            jid}});
                    if (_type) {
                        pnode["type"] = _type;
                    }
                    participants.append(pnode);
                }
                groupNode.addChildren(participants);
                node.addChild(groupNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var groupNode = node.getChild("group");
                var participants = new Dictionary<object, object> {
                };
                foreach (var p in groupNode.getAllChildren("participant")) {
                    participants[p["jid"]] = p["type"];
                }
                return new InfoGroupsResultIqProtocolEntity(node["id"], node["from"], groupNode["id"], groupNode["creation"], groupNode["creator"], groupNode["subject"], groupNode["s_t"], groupNode["s_o"], participants);
            }
        }
    }
}
