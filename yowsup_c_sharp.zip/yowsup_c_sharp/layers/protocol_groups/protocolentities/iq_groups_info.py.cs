namespace yowsup.layers.protocol_groups.protocolentities
{

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using GroupsIqProtocolEntity = iq_groups.GroupsIqProtocolEntity;

    using System;

    using System.Collections.Generic;

    using System.Diagnostics;

    public static class iq_groups_info {
        
        // 
        //     <iq id="{{id}}"" type="get" to="{{group_jid}}" xmlns="w:g2">
        //         <query request="interactive"></query>
        //     </iq>
        // 
        // 
        //     
        public class InfoGroupsIqProtocolEntity
            : GroupsIqProtocolEntity {
            
            public object group_jid;
            
            public InfoGroupsIqProtocolEntity(object group_jid, object _id = null)
                : base(_id: _id, _type: "get") {
                this.setProps(group_jid);
            }
            
            public virtual object setProps(object group_jid) {
                this.group_jid = group_jid;
            }
            
            public override object ToString() {
                var @out = super(InfoGroupsIqProtocolEntity, this).@__str__();
                @out += String.Format("Group JID: %s\n", this.group_jid);
                return @out;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(InfoGroupsIqProtocolEntity, this).toProtocolTreeNode();
                node.addChild(ProtocolTreeNode("query", new Dictionary<object, object> {
                    {
                        "request",
                        "interactive"}}));
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                Debug.Assert(node.getChild("query") != null);
                Debug.Assert(String.Format("Not a groups info iq node %s", node));
                var entity = super(InfoGroupsIqProtocolEntity, InfoGroupsIqProtocolEntity).fromProtocolTreeNode(node);
                entity.@__class__ = InfoGroupsIqProtocolEntity;
                entity.setProps(node.getAttributeValue("to"));
                return entity;
            }
        }
    }
}
