namespace yowsup.layers.protocol_groups.protocolentities
{

    using CreateGroupsIqProtocolEntity = yowsup.layers.protocol_groups.protocolentities.iq_groups_create.CreateGroupsIqProtocolEntity;

    using ProtocolEntityTest = yowsup.structs.protocolentity.ProtocolEntityTest;

    public static class test_iq_groups_create {
        
        public static object entity = CreateGroupsIqProtocolEntity("group subject");
        
        public class CreateGroupsIqProtocolEntityTest
            : ProtocolEntityTest, unittest.TestCase {
            
            public object node;
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                this.ProtocolEntity = CreateGroupsIqProtocolEntity;
                this.node = entity.toProtocolTreeNode();
            }
        }
    }
}
