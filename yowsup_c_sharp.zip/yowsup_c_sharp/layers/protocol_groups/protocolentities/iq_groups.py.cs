namespace yowsup.layers.protocol_groups.protocolentities
{

    using IqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.IqProtocolEntity;

    public static class iq_groups {
        
        // 
        //     <iq type="{{get | set?}}" id="{{id}}" xmlns="w:g2", to="{{group_jid}}">
        //     </iq>
        //     
        public class GroupsIqProtocolEntity
            : IqProtocolEntity {
            
            public GroupsIqProtocolEntity(object to = null, object _from = null, object _id = null, object _type = null)
                : base(_id, _type, to: to, _from: _from) {
            }
        }
    }
}
