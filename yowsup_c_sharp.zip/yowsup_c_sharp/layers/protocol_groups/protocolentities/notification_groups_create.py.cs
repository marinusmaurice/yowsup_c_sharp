namespace yowsup.layers.protocol_groups.protocolentities {
    
    using GroupsNotificationProtocolEntity = notification_groups.GroupsNotificationProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using System.Diagnostics;
    
    using System;
    
    using System.Collections.Generic;
    
    public static class notification_groups_create {
        
        // 
        //     <notification from="{{owner_username}}-{{group_id}}@g.us" type="w:gp2" id="{{message_id}}" participant="{{participant_jid}}"
        //             t="{{timestamp}}" notify="{{pushname}}">
        //         <create type="new" key="{{owner_username}}-{{key}}@temp">
        //             <group id="{{group_id}}" creator="{{creator_jid}}" creation="{{creation_timestamp}}"
        //                     subject="{{group_subject}}" s_t="{{subject_timestamp}}" s_o="{{subject_owner_jid}}">
        //                 <participant jid="{{pariticpant_jid}}"/>
        //                 <participant jid="{{}}" type="superadmin"/>
        //             </group>
        //         </create>
        //     </notification>
        //     
        public class CreateGroupsNotificationProtocolEntity
            : GroupsNotificationProtocolEntity {
            
            public object _key;
            
            public object createType;
            
            public int creationTimestamp;
            
            public object creatorJid;
            
            public object groupId;
            
            public object participants;
            
            public object subject;
            
            public object subjectOwnerJid;
            
            public int subjectTime;
            
            public string TYPE_CREATE_NEW;
            
            public string TYPE_PARTICIPANT_ADMIN;
            
            public string TYPE_PARTICIPANT_SUPERADMIN;
            
            public string TYPE_CREATE_NEW = "new";
            
            public string TYPE_PARTICIPANT_ADMIN = "admin";
            
            public string TYPE_PARTICIPANT_SUPERADMIN = "superadmin";
            
            public CreateGroupsNotificationProtocolEntity(
                object _id,
                object _from,
                object timestamp,
                object notify,
                object participant,
                object offline,
                object createType,
                object key,
                object groupId,
                object creationTimestamp,
                object creatorJid,
                object subject,
                object subjectTime,
                object subjectOwnerJid,
                object participants)
                : base(_from, timestamp, notify, participant, offline) {
                this.setGroupProps(createType, key, groupId, creationTimestamp, creatorJid, subject, subjectTime, subjectOwnerJid, participants);
            }
            
            public virtual object setGroupProps(
                object createType,
                object key,
                object groupId,
                object creationTimestamp,
                object creatorJid,
                object subject,
                object subjectTime,
                object subjectOwnerJid,
                object participants) {
                Debug.Assert(object.ReferenceEquals(type(participants), dict));
                Debug.Assert("Participants must be a dict {jid => type?}");
                this.createType = createType;
                this.groupId = groupId;
                this.creationTimestamp = Convert.ToInt32(creationTimestamp);
                this.creatorJid = creatorJid;
                this.subject = subject;
                this.subjectTime = Convert.ToInt32(subjectTime);
                this.subjectOwnerJid = subjectOwnerJid;
                this.participants = participants;
                this._key = key;
            }
            
            public object key {
                get {
                    return this._key;
                }
            }
            
            public virtual object getParticipants() {
                return this.participants;
            }
            
            public virtual object getSubject() {
                return this.subject;
            }
            
            public virtual object getGroupId() {
                return this.groupId;
            }
            
            public virtual object getCreationTimestamp() {
                return this.creationTimestamp;
            }
            
            public virtual object getCreatorJid(object full = true) {
                return full ? this.creatorJid : this.creatorJid.split("@")[0];
            }
            
            public virtual object getSubjectTimestamp() {
                return this.subjectTime;
            }
            
            public virtual object getSubjectOwnerJid(object full = true) {
                return full ? this.subjectOwnerJid : this.subjectOwnerJid.split("@")[0];
            }
            
            public virtual object getCreatetype() {
                return this.createType;
            }
            
            public virtual object getGroupSuperAdmin(object full = true) {
                foreach (var _tup_1 in this.participants.items()) {
                    var jid = _tup_1.Item1;
                    var _type = _tup_1.Item2;
                    if (_type == this.@__class__.TYPE_PARTICIPANT_SUPERADMIN) {
                        return full ? jid : jid.split("@")[0];
                    }
                }
            }
            
            public virtual object getGroupAdmins(object full = true) {
                var @out = new List<object>();
                foreach (var _tup_1 in this.participants.items()) {
                    var jid = _tup_1.Item1;
                    var _type = _tup_1.Item2;
                    if (_type == this.@__class__.TYPE_PARTICIPANT_ADMIN) {
                        @out.append(full ? jid : jid.split("@")[0]);
                    }
                }
                return @out;
            }
            
            public override object ToString() {
                var @out = super(CreateGroupsNotificationProtocolEntity, this).@__str__();
                @out += String.Format("Creator: %s\n", this.getCreatorJid());
                @out += String.Format("Create type: %s\n", this.getCreatetype());
                @out += String.Format("Creation timestamp: %s\n", this.getCreationTimestamp());
                @out += String.Format("Subject: %s\n", this.getSubject());
                @out += String.Format("Subject owner: %s\n", this.getSubjectOwnerJid());
                @out += String.Format("Subject timestamp: %s\n", this.getSubjectTimestamp());
                @out += String.Format("Participants: %s\n", this.getParticipants());
                @out += String.Format("Key: %s\n", this.key);
                return @out;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(CreateGroupsNotificationProtocolEntity, this).toProtocolTreeNode();
                var createNode = ProtocolTreeNode("create", new Dictionary<object, object> {
                    {
                        "type",
                        this.getCreatetype()},
                    {
                        "key",
                        this.key}});
                var groupNode = ProtocolTreeNode("group", new Dictionary<object, object> {
                    {
                        "subject",
                        this.getSubject()},
                    {
                        "creation",
                        this.getCreationTimestamp().ToString()},
                    {
                        "creator",
                        this.getCreatorJid()},
                    {
                        "s_t",
                        this.getSubjectTimestamp()},
                    {
                        "s_o",
                        this.getSubjectOwnerJid()},
                    {
                        "id",
                        this.getGroupId()}});
                var participants = new List<object>();
                foreach (var _tup_1 in this.getParticipants().items()) {
                    var jid = _tup_1.Item1;
                    var _type = _tup_1.Item2;
                    var pnode = ProtocolTreeNode("participant", new Dictionary<object, object> {
                        {
                            "jid",
                            jid}});
                    if (_type) {
                        pnode["type"] = _type;
                    }
                    participants.append(pnode);
                }
                groupNode.addChildren(participants);
                createNode.addChild(groupNode);
                node.addChild(createNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var createNode = node.getChild("create");
                var groupNode = createNode.getChild("group");
                var participants = new Dictionary<object, object> {
                };
                foreach (var p in groupNode.getAllChildren("participant")) {
                    participants[p["jid"]] = p["type"];
                }
                return new CreateGroupsNotificationProtocolEntity(node["id"], node["from"], node["t"], node["notify"], node["participant"], node["offline"], createNode["type"], createNode["key"], groupNode["id"], groupNode["creation"], groupNode["creator"], groupNode["subject"], groupNode["s_t"], groupNode["s_o"], participants);
            }
        }
    }
}
