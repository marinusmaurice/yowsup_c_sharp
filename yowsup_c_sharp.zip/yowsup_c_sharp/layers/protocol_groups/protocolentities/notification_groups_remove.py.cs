namespace yowsup.layers.protocol_groups.protocolentities {
    
    using GroupsNotificationProtocolEntity = notification_groups.GroupsNotificationProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using System.Diagnostics;
    
    using System;
    
    using System.Collections.Generic;
    
    public static class notification_groups_remove {
        
        // 
        // <notification notify="{{NOTIFY_NAME}}" id="{{id}}" t="{{TIMESTAMP}}" participant="{{participant_jiid}}" from="{{group_jid}}" type="w:gp2" mode="none">
        // <remove subject="{{subject}}">
        // <participant jid="{{participant_jid}}">
        // </participant>
        // </remove>
        // </notification>
        //     
        public class RemoveGroupsNotificationProtocolEntity
            : GroupsNotificationProtocolEntity {
            
            public object participants;
            
            public object subject;
            
            public string TYPE_PARTICIPANT_ADMIN;
            
            public string TYPE_PARTICIPANT_ADMIN = "admin";
            
            public RemoveGroupsNotificationProtocolEntity(
                object _id,
                object _from,
                object timestamp,
                object notify,
                object participant,
                object offline,
                object subject,
                object participants)
                : base(_from, timestamp, notify, participant, offline) {
                this.setGroupProps(subject, participants);
            }
            
            public virtual object setGroupProps(object subject, object participants) {
                Debug.Assert(object.ReferenceEquals(type(participants), list));
                Debug.Assert(String.Format("Must be a list of jids, got %s instead.", type(participants)));
                this.subject = subject;
                this.participants = participants;
            }
            
            public virtual object getParticipants() {
                return this.participants;
            }
            
            public virtual object getSubject() {
                return this.subject;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(RemoveGroupsNotificationProtocolEntity, this).toProtocolTreeNode();
                var removeNode = ProtocolTreeNode("remove", new Dictionary<object, object> {
                    {
                        "subject",
                        this.subject}});
                var participants = new List<object>();
                foreach (var jid in this.getParticipants()) {
                    var pnode = ProtocolTreeNode("participant", new Dictionary<object, object> {
                        {
                            "jid",
                            jid}});
                    participants.append(pnode);
                }
                removeNode.addChildren(participants);
                node.addChild(removeNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var removeNode = node.getChild("remove");
                var participants = new List<object>();
                foreach (var p in removeNode.getAllChildren("participant")) {
                    participants.append(p["jid"]);
                }
                return new RemoveGroupsNotificationProtocolEntity(node["id"], node["from"], node["t"], node["notify"], node["participant"], node["offline"], removeNode["subject"], participants);
            }
        }
    }
}
