namespace yowsup.layers.protocol_groups.protocolentities
{

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using GroupsIqProtocolEntity = iq_groups.GroupsIqProtocolEntity;

    using System.Collections.Generic;

    using System.Diagnostics;

    using System.Linq;

    using System;

    public static class iq_groups_leave {
        
        // 
        //     <iq id="{{id}}"" type="set" to="{{group_jid}}" xmlns="w:g2">
        //         <leave action="delete">
        // 		    <group id="{{JID}}">
        //             <group id="{{JID}}">
        //         </leave>
        //     </iq>
        //     
        public class LeaveGroupsIqProtocolEntity
            : GroupsIqProtocolEntity {
            
            public object groupList;
            
            public LeaveGroupsIqProtocolEntity(object groupList)
                : base(_type: "set") {
                this.setProps(object.ReferenceEquals(type(groupList), list) ? groupList : new List<object> {
                    groupList
                });
            }
            
            public virtual object setProps(object groupList) {
                Debug.Assert(object.ReferenceEquals(type(groupList), list) && groupList.Count);
                Debug.Assert("Must specify a list of group jids to leave");
                this.groupList = groupList;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(LeaveGroupsIqProtocolEntity, this).toProtocolTreeNode();
                var groupNodes = (from groupid in this.groupList
                    select ProtocolTreeNode("group", new Dictionary<object, object> {
                        {
                            "id",
                            groupid}})).ToList();
                node.addChild(ProtocolTreeNode("leave", new Dictionary<object, object> {
                    {
                        "action",
                        "delete"}}, groupNodes));
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                Debug.Assert(node.getChild("leave") != null);
                Debug.Assert(String.Format("Not a group leave iq node %s", node));
                Debug.Assert(node.getChild("leave").getAttributeValue("action") == "delete");
                Debug.Assert(String.Format("Not a group leave action %s", node));
                var entity = super(LeaveGroupsIqProtocolEntity, LeaveGroupsIqProtocolEntity).fromProtocolTreeNode(node);
                entity.@__class__ = LeaveGroupsIqProtocolEntity;
                entity.setProps((from group in node.getChild("leave").getAllChildren()
                    select group.getAttributeValue("id")).ToList());
                return entity;
            }
        }
    }
}
