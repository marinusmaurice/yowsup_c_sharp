namespace yowsup.layers.protocol_groups.protocolentities
{

    using YowConstants = yowsup.common.YowConstants;

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using GroupsIqProtocolEntity = iq_groups.GroupsIqProtocolEntity;

    using System;

    using System.Diagnostics;

    public static class iq_groups_list {
        
        // 
        //     <iq id="{{id}}"" type="get" to="g.us" xmlns="w:g2">
        //         <"{{participating | owning}}"></"{{participating | owning}}">
        //     </iq>
        //     
        //     result (processed in iq_result_groups_list.py):
        //     <iq type="result" from="g.us" id="{{IQ_ID}}">
        //       <groups>
        //           <group s_t="{{SUBJECT_TIME}}" creation="{{CREATING_TIME}}" creator="{{OWNER_JID}}" id="{{GROUP_ID}}" s_o="{{SUBJECT_OWNER_JID}}" subject="{{SUBJECT}}">
        //             <participant jid="{{JID}}" type="admin">
        //             </participant>
        //             <participant jid="{{JID}}">
        //             </participant>
        //           </group>
        //           <group s_t="{{SUBJECT_TIME}}" creation="{{CREATING_TIME}}" creator="{{OWNER_JID}}" id="{{GROUP_ID}}" s_o="{{SUBJECT_OWNER_JID}}" subject="{{SUBJECT}}">
        //             <participant jid="{{JID}}" type="admin">
        //             </participant>
        //           </group>
        //       <groups>
        //     </iq>
        //     
        public class ListGroupsIqProtocolEntity
            : GroupsIqProtocolEntity {
            
            public string GROUP_TYPE_OWNING;
            
            public string GROUP_TYPE_PARTICIPATING;
            
            public Tuple<string, string> GROUPS_TYPES;
            
            public object groupsType;
            
            public string GROUP_TYPE_PARTICIPATING = "participating";
            
            public string GROUP_TYPE_OWNING = "owning";
            
            public Tuple<string, string> GROUPS_TYPES = (GROUP_TYPE_PARTICIPATING, GROUP_TYPE_OWNING);
            
            public ListGroupsIqProtocolEntity(object groupsType = GROUP_TYPE_PARTICIPATING, object _id = null)
                : base(to: YowConstants.WHATSAPP_GROUP_SERVER, _type: "get") {
                this.setProps(groupsType);
            }
            
            public virtual object setProps(object groupsType) {
                Debug.Assert(this.@__class__.GROUPS_TYPES.Contains(groupsType));
                Debug.Assert(String.Format("Groups type must be %s, not %s", " or ".join(this.@__class__.GROUPS_TYPES), groupsType));
                this.groupsType = groupsType;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(ListGroupsIqProtocolEntity, this).toProtocolTreeNode();
                node.addChild(ProtocolTreeNode(this.groupsType));
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = super(ListGroupsIqProtocolEntity, ListGroupsIqProtocolEntity).fromProtocolTreeNode(node);
                entity.@__class__ = ListGroupsIqProtocolEntity;
                entity.setProps(node.getChild(0).tag);
                return entity;
            }
        }
    }
}
