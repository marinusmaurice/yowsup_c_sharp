namespace yowsup.layers.protocol_groups.protocolentities {
    
    using IqProtocolEntityTest = yowsup.layers.protocol_iq.protocolentities.test_iq.IqProtocolEntityTest;
    
    public static class test_iq_groups {
        
        public class GroupsIqProtocolEntityTest
            : IqProtocolEntityTest {
        }
    }
}
