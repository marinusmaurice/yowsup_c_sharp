namespace yowsup.layers.protocol_groups.protocolentities
{

    using ParticipantsGroupsIqProtocolEntity = iq_groups_participants.ParticipantsGroupsIqProtocolEntity;

    using System.Collections.Generic;

    public static class iq_groups_participants_promote {
        
        // 
        //     <iq type="set" id="{{id}}" xmlns="w:g2", to="{{group_jid}}">
        //         <promote>
        //             <participant jid="{{jid}}"></participant>
        //             <participant jid="{{jid}}"></participant>
        //         </promote>
        //     </iq>
        //     
        public class PromoteParticipantsIqProtocolEntity
            : ParticipantsGroupsIqProtocolEntity {
            
            public PromoteParticipantsIqProtocolEntity(object group_jid, object participantList, object _id = null)
                : base(participantList, "promote", _id: _id) {
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = super(PromoteParticipantsIqProtocolEntity, PromoteParticipantsIqProtocolEntity).fromProtocolTreeNode(node);
                entity.@__class__ = PromoteParticipantsIqProtocolEntity;
                var participantList = new List<object>();
                foreach (var participantNode in node.getChild("promote").getAllChildren()) {
                    participantList.append(participantNode["jid"]);
                }
                entity.setProps(node.getAttributeValue("to"), participantList);
                return entity;
            }
        }
    }
}
