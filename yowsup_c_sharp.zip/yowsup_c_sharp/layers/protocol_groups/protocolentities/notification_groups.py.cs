namespace yowsup.layers.protocol_groups.protocolentities
{

    using NotificationProtocolEntity = yowsup.layers.protocol_notifications.protocolentities.NotificationProtocolEntity;

    using System;

    public static class notification_groups {
        
        // 
        // 
        //     <notification notify="WhatsApp" id="{{id}}" t="1420402514" participant="{{participant_jiid}}" from="{{group_jid}}" type="w:gp2">
        //     </notification>
        // 
        //     
        public class GroupsNotificationProtocolEntity
            : NotificationProtocolEntity {
            
            public object _participant;
            
            public object groupId;
            
            public GroupsNotificationProtocolEntity(
                object _id,
                object _from,
                object timestamp,
                object notify,
                object participant,
                object offline)
                : base(_id, _from, timestamp, notify, offline) {
                this.setParticipant(participant);
                this.setGroupId(_from);
            }
            
            public virtual object setParticipant(object participant) {
                this._participant = participant;
            }
            
            public virtual object getParticipant(object full = true) {
                return full ? this._participant : this._participant.split("@")[0];
            }
            
            public virtual object getGroupId() {
                return this.groupId;
            }
            
            public virtual object setGroupId(object groupId) {
                this.groupId = groupId;
            }
            
            public override object ToString() {
                var @out = super(GroupsNotificationProtocolEntity, this).@__str__();
                @out += String.Format("Participant: %s\n", this.getParticipant());
                return @out;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(GroupsNotificationProtocolEntity, this).toProtocolTreeNode();
                node.setAttribute("participant", this.getParticipant());
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = super(GroupsNotificationProtocolEntity, GroupsNotificationProtocolEntity).fromProtocolTreeNode(node);
                entity.@__class__ = GroupsNotificationProtocolEntity;
                entity.setParticipant(node.getAttributeValue("participant"));
                entity.setGroupId(node.getAttributeValue("from"));
                return entity;
            }
        }
    }
}
