namespace yowsup.layers.protocol_groups.protocolentities
{

    using ListGroupsResultIqProtocolEntity = yowsup.layers.protocol_groups.protocolentities.iq_result_groups_list.ListGroupsResultIqProtocolEntity;

    using ProtocolEntityTest = yowsup.structs.protocolentity.ProtocolEntityTest;

    using Group = yowsup.layers.protocol_groups.structs.Group;

    using System.Collections.Generic;

    using System;

    public static class test_iq_result_groups_list {
        
        public static object entity = ListGroupsResultIqProtocolEntity(new List<object> {
            Group("1234-456", "owner@s.whatsapp.net", "subject", "sOwnerJid@s.whatsapp.net", Convert.ToInt32(time.time()), Convert.ToInt32(time.time())),
            Group("4321-456", "owner@s.whatsapp.net", "subject", "sOwnerJid@s.whatsapp.net", Convert.ToInt32(time.time()), Convert.ToInt32(time.time()))
        });
        
        public class ListGroupsResultIqProtocolEntityTest
            : ProtocolEntityTest, unittest.TestCase {
            
            public object node;
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                this.ProtocolEntity = ListGroupsResultIqProtocolEntity;
                this.node = entity.toProtocolTreeNode();
            }
        }
    }
}
