namespace yowsup.layers.protocol_groups.protocolentities {
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using ResultIqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.ResultIqProtocolEntity;
    
    using System.Collections.Generic;
    
    using System.Linq;
    
    public static class iq_groups_participants_remove_success {
        
        // 
        //     <iq type="result" from="{{group_jid}}" id="{{id}}">
        //         <remove type="success" participant="{{jid}}"></remove>
        //         <remove type="success" participant="{{jid}}"></remove>
        //     </iq>
        //     
        public class SuccessRemoveParticipantsIqProtocolEntity
            : ResultIqProtocolEntity {
            
            public string action;
            
            public object groupId;
            
            public object participantList;
            
            public SuccessRemoveParticipantsIqProtocolEntity(object _id, object groupId, object participantList)
                : base(_id: _id) {
                this.setProps(groupId, participantList);
            }
            
            public virtual object setProps(object groupId, object participantList) {
                this.groupId = groupId;
                this.participantList = participantList;
                this.action = "remove";
            }
            
            public virtual object getAction() {
                return this.action;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(SuccessRemoveParticipantsIqProtocolEntity, this).toProtocolTreeNode();
                var participantNodes = (from participant in this.participantList
                    select ProtocolTreeNode("remove", new Dictionary<object, object> {
                        {
                            "type",
                            "success"},
                        {
                            "participant",
                            participant}})).ToList();
                node.addChildren(participantNodes);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = super(SuccessRemoveParticipantsIqProtocolEntity, SuccessRemoveParticipantsIqProtocolEntity).fromProtocolTreeNode(node);
                entity.@__class__ = SuccessRemoveParticipantsIqProtocolEntity;
                var participantList = new List<object>();
                foreach (var participantNode in node.getAllChildren()) {
                    if (participantNode["type"] == "success") {
                        participantList.append(participantNode["participant"]);
                    }
                }
                entity.setProps(node.getAttributeValue("from"), participantList);
                return entity;
            }
        }
    }
}
