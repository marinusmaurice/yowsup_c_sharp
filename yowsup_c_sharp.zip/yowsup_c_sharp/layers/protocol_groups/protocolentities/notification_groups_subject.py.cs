namespace yowsup.layers.protocol_groups.protocolentities
{

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using GroupsNotificationProtocolEntity = notification_groups.GroupsNotificationProtocolEntity;

    using System;

    using System.Collections.Generic;

    public static class notification_groups_subject {
        
        // 
        // 
        //     <notification notify="WhatsApp" id="{{id}}" t="{{TIMESTAMP}}" participant="{{PARTICIPANT_JID}}" from="{{GROUP_JID}}" type="w:gp2">
        //         <subject s_t="{{subject_set_timestamp}}" s_o="{{subject_owner_jid}}" subject="{{SUBJECT}}">
        //         </subject>
        //     </notification>
        // 
        //     
        public class SubjectGroupsNotificationProtocolEntity
            : GroupsNotificationProtocolEntity {
            
            public object subject;
            
            public object subjectOwner;
            
            public int subjectTimestamp;
            
            public SubjectGroupsNotificationProtocolEntity(
                object _type,
                object _id,
                object _from,
                object timestamp,
                object notify,
                object participant,
                object subject)
                : base(_from, timestamp, notify, participant) {
                this.setSubjectData(subject);
            }
            
            public virtual object setSubjectData(object subject, object subjectOwner, object subjectTimestamp) {
                this.subject = subject;
                this.subjectOwner = subjectOwner;
                this.subjectTimestamp = Convert.ToInt32(subjectTimestamp);
            }
            
            public virtual object getSubject() {
                return this.subject;
            }
            
            public virtual object getSubjectOwner(object full = true) {
                return full ? this.subjectOwner : this.subjectOwner.split("@")[0];
            }
            
            public virtual object getSubjectTimestamp() {
                return this.subjectTimestamp;
            }
            
            public override object ToString() {
                var @out = super(SubjectGroupsNotificationProtocolEntity, this).@__str__();
                @out += String.Format("New subject: %s\n", this.getSubject());
                @out += String.Format("Set by: %s\n", this.getSubjectOwner());
                return @out;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(SubjectGroupsNotificationProtocolEntity, this).toProtocolTreeNode();
                var subjectNode = ProtocolTreeNode("subject", new Dictionary<object, object> {
                    {
                        "s_t",
                        this.getSubjectTimestamp().ToString()},
                    {
                        "s_o",
                        this.getSubjectOwner()},
                    {
                        "subject",
                        this.getSubject()}});
                node.addChild(subjectNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = super(SubjectGroupsNotificationProtocolEntity, SubjectGroupsNotificationProtocolEntity).fromProtocolTreeNode(node);
                entity.@__class__ = SubjectGroupsNotificationProtocolEntity;
                var subjectNode = node.getChild("subject");
                entity.setSubjectData(subjectNode["subject"], subjectNode["s_o"], subjectNode["s_t"]);
                return entity;
            }
        }
    }
}
