namespace yowsup.layers.protocol_groups.protocolentities
{

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using GroupsIqProtocolEntity = iq_groups.GroupsIqProtocolEntity;

    using System.Collections.Generic;

    public static class iq_groups_subject {
        
        // 
        //     <iq type="set" id="{{id}}" xmlns="w:g2", to={{group_jid}}">
        //         <subject>
        //               {{NEW_VAL}}
        //         </subject>
        //     </iq>
        //     
        public class SubjectGroupsIqProtocolEntity
            : GroupsIqProtocolEntity {
            
            public object subject;
            
            public SubjectGroupsIqProtocolEntity(object jid, object subject, object _id = null)
                : base(_id: _id, _type: "set") {
                this.setProps(subject);
            }
            
            public virtual object setProps(object subject) {
                this.subject = subject;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(SubjectGroupsIqProtocolEntity, this).toProtocolTreeNode();
                node.addChild(ProtocolTreeNode("subject", new Dictionary<object, object> {
                }, null, this.subject));
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = super(SubjectGroupsIqProtocolEntity, SubjectGroupsIqProtocolEntity).fromProtocolTreeNode(node);
                entity.@__class__ = SubjectGroupsIqProtocolEntity;
                entity.setProps(node.getChild("subject").getData());
                return entity;
            }
        }
    }
}
