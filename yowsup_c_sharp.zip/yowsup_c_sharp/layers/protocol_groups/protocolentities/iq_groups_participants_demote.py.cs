namespace yowsup.layers.protocol_groups.protocolentities
{

    using ParticipantsGroupsIqProtocolEntity = iq_groups_participants.ParticipantsGroupsIqProtocolEntity;

    using System.Collections.Generic;

    public static class iq_groups_participants_demote {
        
        // 
        //     <iq type="set" id="{{id}}" xmlns="w:g2", to="{{group_jid}}">
        //         <demote>
        //             <participant jid="{{jid}}"></participant>
        //             <participant jid="{{jid}}"></participant>
        //         </demote>
        //     </iq>
        //     
        public class DemoteParticipantsIqProtocolEntity
            : ParticipantsGroupsIqProtocolEntity {
            
            public DemoteParticipantsIqProtocolEntity(object group_jid, object participantList, object _id = null)
                : base(participantList, "demote", _id: _id) {
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = super(DemoteParticipantsIqProtocolEntity, DemoteParticipantsIqProtocolEntity).fromProtocolTreeNode(node);
                entity.@__class__ = DemoteParticipantsIqProtocolEntity;
                var participantList = new List<object>();
                foreach (var participantNode in node.getChild("demote").getAllChildren()) {
                    participantList.append(participantNode["jid"]);
                }
                entity.setProps(node.getAttributeValue("to"), participantList);
                return entity;
            }
        }
    }
}
