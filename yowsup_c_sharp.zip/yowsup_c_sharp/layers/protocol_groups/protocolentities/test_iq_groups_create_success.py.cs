namespace yowsup.layers.protocol_groups.protocolentities
{

    using ProtocolEntityTest = yowsup.structs.protocolentity.ProtocolEntityTest;

    using SuccessCreateGroupsIqProtocolEntity = yowsup.layers.protocol_groups.protocolentities.SuccessCreateGroupsIqProtocolEntity;

    public static class test_iq_groups_create_success {
        
        public static object entity = SuccessCreateGroupsIqProtocolEntity("123-456", "431-123");
        
        public class SuccessCreateGroupsIqProtocolEntityTest
            : ProtocolEntityTest, unittest.TestCase {
            
            public object node;
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                this.ProtocolEntity = SuccessCreateGroupsIqProtocolEntity;
                this.node = entity.toProtocolTreeNode();
            }
        }
    }
}
