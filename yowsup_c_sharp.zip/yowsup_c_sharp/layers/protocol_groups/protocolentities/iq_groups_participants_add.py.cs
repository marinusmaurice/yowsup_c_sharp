namespace yowsup.layers.protocol_groups.protocolentities
{

    using ParticipantsGroupsIqProtocolEntity = iq_groups_participants.ParticipantsGroupsIqProtocolEntity;

    using System.Collections.Generic;

    public static class iq_groups_participants_add {
        
        // 
        //     <iq type="set" id="{{id}}" xmlns="w:g2", to="{{group_jid}}">
        //         <add>
        //             <participant jid="{{jid}}"></participant>
        //             <participant jid="{{jid}}"></participant>
        //         </add>
        //     </iq>
        //     
        public class AddParticipantsIqProtocolEntity
            : ParticipantsGroupsIqProtocolEntity {
            
            public AddParticipantsIqProtocolEntity(object group_jid, object participantList, object _id = null)
                : base(participantList, "add", _id: _id) {
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = super(AddParticipantsIqProtocolEntity, AddParticipantsIqProtocolEntity).fromProtocolTreeNode(node);
                entity.@__class__ = AddParticipantsIqProtocolEntity;
                var participantList = new List<object>();
                foreach (var participantNode in node.getChild("add").getAllChildren()) {
                    participantList.append(participantNode["jid"]);
                }
                entity.setProps(node.getAttributeValue("to"), participantList);
                return entity;
            }
        }
    }
}
