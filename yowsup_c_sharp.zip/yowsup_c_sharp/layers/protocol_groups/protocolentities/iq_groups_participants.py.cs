namespace yowsup.layers.protocol_groups.protocolentities
{

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using GroupsIqProtocolEntity = iq_groups.GroupsIqProtocolEntity;

    using System.Collections.Generic;

    using System.Diagnostics;

    using System;

    using System.Linq;

    public static class iq_groups_participants {
        
        // 
        //     <iq type="get" id="{{id}}" xmlns="w:g2", to={{group_jid}}">
        //         <list></list>
        //     </iq>
        //     
        public class ParticipantsGroupsIqProtocolEntity
            : GroupsIqProtocolEntity {
            
            public object group_jid;
            
            public object mode;
            
            public List<string> modes;
            
            public object participantList;
            
            public List<string> modes = new List<string> {
                "add",
                "promote",
                "remove",
                "demote"
            };
            
            public ParticipantsGroupsIqProtocolEntity(object jid, object participantList, object _mode, object _id = null)
                : base(_id: _id, _type: "set") {
                this.setProps(group_jid: jid, participantList: participantList, mode: _mode);
            }
            
            public virtual object setProps(object group_jid, object participantList, object mode) {
                Debug.Assert(object.ReferenceEquals(type(participantList), list));
                Debug.Assert(String.Format("Must be a list of jids, got %s instead.", type(participantList)));
                Debug.Assert(this.modes.Contains(mode));
                Debug.Assert("Mode should be in: '" + "', '".join(this.modes) + "' but is '" + mode + "'");
                this.group_jid = group_jid;
                this.participantList = participantList;
                this.mode = mode;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(ParticipantsGroupsIqProtocolEntity, this).toProtocolTreeNode();
                var participantNodes = (from participant in this.participantList
                    select ProtocolTreeNode("participant", new Dictionary<object, object> {
                        {
                            "jid",
                            participant}})).ToList();
                node.addChild(ProtocolTreeNode(this.mode, new Dictionary<object, object> {
                }, participantNodes));
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = super(ParticipantsGroupsIqProtocolEntity, ParticipantsGroupsIqProtocolEntity).fromProtocolTreeNode(node);
                entity.@__class__ = ParticipantsGroupsIqProtocolEntity;
                return entity;
            }
        }
    }
}
