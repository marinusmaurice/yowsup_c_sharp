namespace yowsup.layers.protocol_groups.protocolentities
{

    using ListGroupsIqProtocolEntity = yowsup.layers.protocol_groups.protocolentities.iq_groups_list.ListGroupsIqProtocolEntity;

    using ProtocolEntityTest = yowsup.structs.protocolentity.ProtocolEntityTest;

    public static class test_iq_groups_list {
        
        public static object entity = ListGroupsIqProtocolEntity();
        
        public class ListGroupsIqProtocolEntityTest
            : ProtocolEntityTest, unittest.TestCase {
            
            public object node;
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                this.ProtocolEntity = ListGroupsIqProtocolEntity;
                this.node = entity.toProtocolTreeNode();
            }
        }
    }
}
