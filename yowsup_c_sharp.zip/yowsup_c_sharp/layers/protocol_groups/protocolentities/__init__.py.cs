namespace yowsup.layers.protocol_groups.protocolentities
{

    public static class @__init__ {
    }
}
