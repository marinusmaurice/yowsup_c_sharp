namespace yowsup.layers.protocol_groups.protocolentities
{

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using GroupsIqProtocolEntity = iq_groups.GroupsIqProtocolEntity;

    using System.Collections.Generic;

    using System.Linq;

    public static class iq_groups_create {
        
        // 
        //     <iq type="set" id="{{id}}" xmlns="w:g2", to="g.us">
        //         <create subject="{{subject}}">
        //              <participant jid="{{jid}}"></participant>
        //         </create>
        //     </iq>
        //     
        public class CreateGroupsIqProtocolEntity
            : GroupsIqProtocolEntity {
            
            public object participantList;
            
            public object subject;
            
            public CreateGroupsIqProtocolEntity(object subject, object _id = null, object participants = null)
                : base(_id: _id, _type: "set") {
                this.setProps(subject);
                this.setParticipants(participants || new List<object>());
            }
            
            public virtual object setProps(object subject) {
                this.subject = subject;
            }
            
            public virtual object setParticipants(object participants) {
                this.participantList = participants;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(CreateGroupsIqProtocolEntity, this).toProtocolTreeNode();
                var cnode = ProtocolTreeNode("create", new Dictionary<object, object> {
                    {
                        "subject",
                        this.subject}});
                var participantNodes = (from participant in this.participantList
                    select ProtocolTreeNode("participant", new Dictionary<object, object> {
                        {
                            "jid",
                            participant}})).ToList();
                cnode.addChildren(participantNodes);
                node.addChild(cnode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = super(CreateGroupsIqProtocolEntity, CreateGroupsIqProtocolEntity).fromProtocolTreeNode(node);
                entity.@__class__ = CreateGroupsIqProtocolEntity;
                entity.setProps(node.getChild("create").getAttributeValue("subject"));
                var participantList = new List<object>();
                foreach (var participantNode in node.getChild("create").getAllChildren()) {
                    participantList.append(participantNode["jid"]);
                }
                entity.setParticipants(participantList);
                return entity;
            }
        }
    }
}
