namespace yowsup.layers.protocol_groups.protocolentities {
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using ResultIqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.ResultIqProtocolEntity;
    
    using System;
    
    using System.Collections.Generic;
    
    using System.Linq;
    
    public static class iq_result_participants_list {
        
        // 
        //     <iq type="result" from="{{GROUP_ID}}" id="{{IQ_ID}}">
        //         <participant jid="{{PARTICIPANT_JID}}">
        //         </participant>
        //     </iq>
        //     
        public class ListParticipantsResultIqProtocolEntity
            : ResultIqProtocolEntity {
            
            public object participantList;
            
            public ListParticipantsResultIqProtocolEntity(object _from, object participantList) {
                this.setParticipants(participantList);
            }
            
            public override object ToString() {
                var @out = super(ListParticipantsResultIqProtocolEntity, this).@__str__();
                @out += String.Format("Participants: %s\n", " ".join(this.participantList));
                return @out;
            }
            
            public virtual object getParticipants() {
                return this.participantList;
            }
            
            public virtual object setParticipants(object participants) {
                this.participantList = participants;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(ListParticipantsResultIqProtocolEntity, this).toProtocolTreeNode();
                var participantNodes = (from participant in this.participantList
                    select ProtocolTreeNode("participant", new Dictionary<object, object> {
                        {
                            "jid",
                            participant}})).ToList();
                node.addChildren(participantNodes);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = super(ListParticipantsResultIqProtocolEntity, ListParticipantsResultIqProtocolEntity).fromProtocolTreeNode(node);
                entity.@__class__ = ListParticipantsResultIqProtocolEntity;
                entity.setParticipants((from pNode in node.getAllChildren()
                    select pNode.getAttributeValue("jid")).ToList());
                return entity;
            }
        }
    }
}
