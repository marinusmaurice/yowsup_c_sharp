namespace yowsup.layers.protocol_groups.protocolentities
{

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using ResultIqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.ResultIqProtocolEntity;

    using System;

    using System.Collections.Generic;

    public static class iq_groups_leave_success {
        
        // 
        //     <iq type="result" from="g.us" id="{{ID}}">
        //         <leave>
        //             <group id="{{GROUP_JID}}"></group>
        //         </leave>
        //     </iq>
        //     
        public class SuccessLeaveGroupsIqProtocolEntity
            : ResultIqProtocolEntity {
            
            public object groupId;
            
            public SuccessLeaveGroupsIqProtocolEntity(object _id, object groupId)
                : base(_id: _id) {
                this.setProps(groupId);
            }
            
            public virtual object setProps(object groupId) {
                this.groupId = groupId;
            }
            
            public override object ToString() {
                var @out = super(SuccessLeaveGroupsIqProtocolEntity, this).@__str__();
                @out += String.Format("Group Id: %s\n", this.groupId);
                return @out;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(SuccessLeaveGroupsIqProtocolEntity, this).toProtocolTreeNode();
                var leaveNode = ProtocolTreeNode("leave", new Dictionary<object, object> {
                }, new List<object> {
                    ProtocolTreeNode("group", new Dictionary<object, object> {
                        {
                            "id",
                            this.groupId}})
                });
                node.addChild(leaveNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = super(SuccessLeaveGroupsIqProtocolEntity, SuccessLeaveGroupsIqProtocolEntity).fromProtocolTreeNode(node);
                entity.@__class__ = SuccessLeaveGroupsIqProtocolEntity;
                entity.setProps(node.getChild("leave").getChild("group").getAttributeValue("id"));
                return entity;
            }
        }
    }
}
