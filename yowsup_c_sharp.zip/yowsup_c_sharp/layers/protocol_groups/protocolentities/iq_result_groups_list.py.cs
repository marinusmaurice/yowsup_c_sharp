namespace yowsup.layers.protocol_groups.protocolentities
{

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using ResultIqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.ResultIqProtocolEntity;

    using Group = structs.Group;

    using System;

    using System.Diagnostics;

    using System.Collections.Generic;

    public static class iq_result_groups_list {
        
        // 
        //     <iq type="result" from="g.us" id="{{IQ_ID}}">
        //       <groups>
        //           <group s_t="{{SUBJECT_TIME}}" creation="{{CREATING_TIME}}" creator="{{OWNER_JID}}" id="{{GROUP_ID}}" s_o="{{SUBJECT_OWNER_JID}}" subject="{{SUBJECT}}">
        //             <participant jid="{{JID}}" type="admin">
        //             </participant>
        //             <participant jid="{{JID}}">
        //             </participant>
        //           </group>
        //           <group s_t="{{SUBJECT_TIME}}" creation="{{CREATING_TIME}}" creator="{{OWNER_JID}}" id="{{GROUP_ID}}" s_o="{{SUBJECT_OWNER_JID}}" subject="{{SUBJECT}}">
        //             <participant jid="{{JID}}" type="admin">
        //             </participant>
        //           </group>
        //       <groups>
        //     </iq>
        //     
        public class ListGroupsResultIqProtocolEntity
            : ResultIqProtocolEntity {
            
            public object groupsList;
            
            public ListGroupsResultIqProtocolEntity(object groupsList) {
                this.setProps(groupsList);
            }
            
            public override object ToString() {
                var @out = super(ListGroupsResultIqProtocolEntity, this).@__str__();
                @out += "Groups:\n";
                foreach (var g in this.groupsList) {
                    @out += String.Format("%s\n", g);
                }
                return @out;
            }
            
            public virtual object getGroups() {
                return this.groupsList;
            }
            
            public virtual object setProps(object groupsList) {
                Debug.Assert(object.ReferenceEquals(type(groupsList), list) && (groupsList.Count == 0 || object.ReferenceEquals(groupsList[0].@__class__, Group)));
                Debug.Assert("groupList must be a list of Group instances");
                this.groupsList = groupsList;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(ListGroupsResultIqProtocolEntity, this).toProtocolTreeNode();
                var groupsNodes = new List<object>();
                foreach (var group in this.groupsList) {
                    var groupNode = ProtocolTreeNode("group", new Dictionary<object, object> {
                        {
                            "id",
                            group.getId()},
                        {
                            "creator",
                            group.getCreator()},
                        {
                            "subject",
                            group.getSubject()},
                        {
                            "s_o",
                            group.getSubjectOwner()},
                        {
                            "s_t",
                            group.getSubjectTime().ToString()},
                        {
                            "creation",
                            group.getCreationTime().ToString()}});
                    var participants = new List<object>();
                    foreach (var _tup_1 in group.getParticipants().items()) {
                        var jid = _tup_1.Item1;
                        var _type = _tup_1.Item2;
                        var pnode = ProtocolTreeNode("participant", new Dictionary<object, object> {
                            {
                                "jid",
                                jid}});
                        if (_type) {
                            pnode["type"] = _type;
                        }
                        participants.append(pnode);
                    }
                    groupNode.addChildren(participants);
                    groupsNodes.append(groupNode);
                }
                node.addChild(ProtocolTreeNode("groups", children: groupsNodes));
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = super(ListGroupsResultIqProtocolEntity, ListGroupsResultIqProtocolEntity).fromProtocolTreeNode(node);
                entity.@__class__ = ListGroupsResultIqProtocolEntity;
                var groups = new List<object>();
                foreach (var groupNode in node.getChild("groups").getAllChildren()) {
                    var participants = new Dictionary<object, object> {
                    };
                    foreach (var p in groupNode.getAllChildren("participant")) {
                        participants[p["jid"]] = p["type"];
                    }
                    groups.append(Group(groupNode["id"], groupNode["creator"], groupNode["subject"], groupNode["s_o"], groupNode["s_t"], groupNode["creation"], participants));
                }
                entity.setProps(groups);
                return entity;
            }
        }
    }
}
