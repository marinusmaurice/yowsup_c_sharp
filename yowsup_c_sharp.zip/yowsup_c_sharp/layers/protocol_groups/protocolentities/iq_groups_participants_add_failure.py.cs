namespace yowsup.layers.protocol_groups.protocolentities {
    
    using ErrorIqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.ErrorIqProtocolEntity;
    
    public static class iq_groups_participants_add_failure {
        
        // 
        //     <iq type="error" from="{{group_jid}}" id="{{id}}">
        //         <error text="item-not-found" code="404">
        //         </error>
        //     </iq>
        //     
        public class FailureAddParticipantsIqProtocolEntity
            : ErrorIqProtocolEntity {
            
            public FailureAddParticipantsIqProtocolEntity(
                object _id,
                object _from,
                object _code,
                object _text,
                object _backoff = 0)
                : base(_id: _id, code: _code, text: _text, backoff: _backoff) {
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = ErrorIqProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = FailureAddParticipantsIqProtocolEntity;
                return entity;
            }
        }
    }
}
