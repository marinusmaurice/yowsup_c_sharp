namespace yowsup.layers.protocol_groups.protocolentities {
    
    using ResultIqProtocolEntityTest = yowsup.layers.protocol_iq.protocolentities.test_iq_result.ResultIqProtocolEntityTest;
    
    public static class test_iq_result_groups {
        
        public class GroupsResultIqProtocolEntityTest
            : ResultIqProtocolEntityTest {
        }
    }
}
