namespace yowsup.layers.protocol_groups.protocolentities {
    
    using GroupsNotificationProtocolEntity = notification_groups.GroupsNotificationProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using System.Diagnostics;
    
    using System;
    
    using System.Collections.Generic;
    
    public static class notification_groups_add {
        
        // 
        // <notification participant="{{participant_jiid}}" t="{{TIMESTAMP}}" from="{{group_jid}}" type="w:gp2" id="{{id}}" notify="WhatsApp">
        // <add>
        // <participant jid="{{JID_1}}">
        // </participant>
        // </add>
        // </notification>
        //     
        public class AddGroupsNotificationProtocolEntity
            : GroupsNotificationProtocolEntity {
            
            public object participants;
            
            public AddGroupsNotificationProtocolEntity(
                object _id,
                object _from,
                object timestamp,
                object notify,
                object participant,
                object offline,
                object participants)
                : base(_from, timestamp, notify, participant, offline) {
                this.setParticipants(participants);
            }
            
            public virtual object setParticipants(object participants) {
                Debug.Assert(object.ReferenceEquals(type(participants), list));
                Debug.Assert(String.Format("Must be a list of jids, got %s instead.", type(participants)));
                this.participants = participants;
            }
            
            public virtual object getParticipants() {
                return this.participants;
            }
            
            public override object ToString() {
                var @out = super(AddGroupsNotificationProtocolEntity, this).@__str__();
                @out += String.Format("Participants: %s\n", " ".join(this.getParticipants()));
                return @out;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(AddGroupsNotificationProtocolEntity, this).toProtocolTreeNode();
                var addNode = ProtocolTreeNode("add");
                var participants = new List<object>();
                foreach (var jid in this.getParticipants()) {
                    var pnode = ProtocolTreeNode("participant", new Dictionary<object, object> {
                        {
                            "jid",
                            jid}});
                    participants.append(pnode);
                }
                addNode.addChildren(participants);
                node.addChild(addNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var addNode = node.getChild("add");
                var participants = new List<object>();
                foreach (var p in addNode.getAllChildren("participant")) {
                    participants.append(p["jid"]);
                }
                return new AddGroupsNotificationProtocolEntity(node["id"], node["from"], node["t"], node["notify"], node["participant"], node["offline"], participants);
            }
        }
    }
}
