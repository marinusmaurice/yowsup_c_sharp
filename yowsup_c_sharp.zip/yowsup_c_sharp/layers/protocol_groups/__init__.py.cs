namespace yowsup.layers.protocol_groups
{

    public static class @__init__ {
    }
}
