namespace yowsup.layers.protocol_groups
{

    using YowProtocolLayer = yowsup.layers.YowProtocolLayer;

    using ErrorIqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.ErrorIqProtocolEntity;

    using ResultIqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.iq_result.ResultIqProtocolEntity;

    using System.Collections.Generic;

    public static class layer {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class YowGroupsProtocolLayer
            : YowProtocolLayer {
            
            public Tuple<object, object, object, object, object, object, object, object, object, object> HANDLE;
            
            public Tuple<object, object, object, object, object, object, object, object, object, object> HANDLE = (CreateGroupsIqProtocolEntity, InfoGroupsIqProtocolEntity, LeaveGroupsIqProtocolEntity, ListGroupsIqProtocolEntity, SubjectGroupsIqProtocolEntity, ParticipantsGroupsIqProtocolEntity, AddParticipantsIqProtocolEntity, PromoteParticipantsIqProtocolEntity, DemoteParticipantsIqProtocolEntity, RemoveParticipantsIqProtocolEntity);
            
            public YowGroupsProtocolLayer() {
                var handleMap = new Dictionary<object, object> {
                    {
                        "iq",
                        (null, this.sendIq)},
                    {
                        "notification",
                        (this.recvNotification, null)}};
                super(YowGroupsProtocolLayer, this).@__init__(handleMap);
            }
            
            public override object ToString() {
                return "Groups Iq Layer";
            }
            
            public virtual object sendIq(object entity) {
                if (this.@__class__.HANDLE.Contains(entity.@__class__)) {
                    if (entity.@__class__ == SubjectGroupsIqProtocolEntity) {
                        this._sendIq(entity, this.onSetSubjectSuccess, this.onSetSubjectFailed);
                    } else if (entity.@__class__ == CreateGroupsIqProtocolEntity) {
                        this._sendIq(entity, this.onCreateGroupSuccess, this.onCreateGroupFailed);
                    } else if (entity.@__class__ == ParticipantsGroupsIqProtocolEntity) {
                        this._sendIq(entity, this.onGetParticipantsResult);
                    } else if (entity.@__class__ == AddParticipantsIqProtocolEntity) {
                        this._sendIq(entity, this.onAddParticipantsSuccess, this.onAddParticipantsFailed);
                    } else if (entity.@__class__ == PromoteParticipantsIqProtocolEntity) {
                        this._sendIq(entity, this.onPromoteParticipantsSuccess, this.onPromoteParticipantsFailed);
                    } else if (entity.@__class__ == DemoteParticipantsIqProtocolEntity) {
                        this._sendIq(entity, this.onDemoteParticipantsSuccess, this.onDemoteParticipantsFailed);
                    } else if (entity.@__class__ == RemoveParticipantsIqProtocolEntity) {
                        this._sendIq(entity, this.onRemoveParticipantsSuccess, this.onRemoveParticipantsFailed);
                    } else if (entity.@__class__ == ListGroupsIqProtocolEntity) {
                        this._sendIq(entity, this.onListGroupsResult);
                    } else if (entity.@__class__ == LeaveGroupsIqProtocolEntity) {
                        this._sendIq(entity, this.onLeaveGroupSuccess, this.onLeaveGroupFailed);
                    } else if (entity.@__class__ == InfoGroupsIqProtocolEntity) {
                        this._sendIq(entity, this.onInfoGroupSuccess, this.onInfoGroupFailed);
                    } else {
                        this.entityToLower(entity);
                    }
                }
            }
            
            public virtual object onCreateGroupSuccess(object node, object originalIqEntity) {
                logger.info("Group create success");
                this.toUpper(SuccessCreateGroupsIqProtocolEntity.fromProtocolTreeNode(node));
            }
            
            public virtual object onCreateGroupFailed(object node, object originalIqEntity) {
                logger.error("Group create failed");
                this.toUpper(ErrorIqProtocolEntity.fromProtocolTreeNode(node));
            }
            
            public virtual object onSetSubjectSuccess(object node, object originalIqEntity) {
                logger.info("Group subject change success");
                this.toUpper(ResultIqProtocolEntity.fromProtocolTreeNode(node));
            }
            
            public virtual object onSetSubjectFailed(object node, object originalIqEntity) {
                logger.error("Group subject change failed");
                this.toUpper(ErrorIqProtocolEntity.fromProtocolTreeNode(node));
            }
            
            public virtual object onGetParticipantsResult(object node, object originalIqEntity) {
                this.toUpper(ListParticipantsResultIqProtocolEntity.fromProtocolTreeNode(node));
            }
            
            public virtual object onAddParticipantsSuccess(object node, object originalIqEntity) {
                logger.info("Group add participants success");
                this.toUpper(SuccessAddParticipantsIqProtocolEntity.fromProtocolTreeNode(node));
            }
            
            public virtual object onRemoveParticipantsFailed(object node, object originalIqEntity) {
                logger.error("Group remove participants failed");
                this.toUpper(ErrorIqProtocolEntity.fromProtocolTreeNode(node));
            }
            
            public virtual object onRemoveParticipantsSuccess(object node, object originalIqEntity) {
                logger.info("Group remove participants success");
                this.toUpper(SuccessRemoveParticipantsIqProtocolEntity.fromProtocolTreeNode(node));
            }
            
            public virtual object onPromoteParticipantsFailed(object node, object originalIqEntity) {
                logger.error("Group promote participants failed");
                this.toUpper(ErrorIqProtocolEntity.fromProtocolTreeNode(node));
            }
            
            public virtual object onPromoteParticipantsSuccess(object node, object originalIqEntity) {
                logger.info("Group promote participants success");
                this.toUpper(ResultIqProtocolEntity.fromProtocolTreeNode(node));
            }
            
            public virtual object onDemoteParticipantsFailed(object node, object originalIqEntity) {
                logger.error("Group demote participants failed");
                this.toUpper(ErrorIqProtocolEntity.fromProtocolTreeNode(node));
            }
            
            public virtual object onDemoteParticipantsSuccess(object node, object originalIqEntity) {
                logger.info("Group demote participants success");
                this.toUpper(ResultIqProtocolEntity.fromProtocolTreeNode(node));
            }
            
            public virtual object onAddParticipantsFailed(object node, object originalIqEntity) {
                logger.error("Group add participants failed");
                this.toUpper(FailureAddParticipantsIqProtocolEntity.fromProtocolTreeNode(node));
            }
            
            public virtual object onListGroupsResult(object node, object originalIqEntity) {
                this.toUpper(ListGroupsResultIqProtocolEntity.fromProtocolTreeNode(node));
            }
            
            public virtual object onLeaveGroupSuccess(object node, object originalIqEntity) {
                logger.info("Group leave success");
                this.toUpper(SuccessLeaveGroupsIqProtocolEntity.fromProtocolTreeNode(node));
            }
            
            public virtual object onLeaveGroupFailed(object node, object originalIqEntity) {
                logger.error("Group leave failed");
                this.toUpper(ErrorIqProtocolEntity.fromProtocolTreeNode(node));
            }
            
            public virtual object onInfoGroupSuccess(object node, object originalIqEntity) {
                logger.info("Group info success");
                this.toUpper(InfoGroupsResultIqProtocolEntity.fromProtocolTreeNode(node));
            }
            
            public virtual object onInfoGroupFailed(object node, object originalIqEntity) {
                logger.error("Group info failed");
                this.toUpper(ErrorIqProtocolEntity.fromProtocolTreeNode(node));
            }
            
            public virtual object recvNotification(object node) {
                if (node["type"] == "w:gp2") {
                    if (node.getChild("subject")) {
                        this.toUpper(SubjectGroupsNotificationProtocolEntity.fromProtocolTreeNode(node));
                    } else if (node.getChild("create")) {
                        this.toUpper(CreateGroupsNotificationProtocolEntity.fromProtocolTreeNode(node));
                    } else if (node.getChild("remove")) {
                        this.toUpper(RemoveGroupsNotificationProtocolEntity.fromProtocolTreeNode(node));
                    } else if (node.getChild("add")) {
                        this.toUpper(AddGroupsNotificationProtocolEntity.fromProtocolTreeNode(node));
                    }
                }
            }
        }
    }
}
