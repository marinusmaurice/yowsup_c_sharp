namespace yowsup.layers.protocol_presence
{

    public static class @__init__ {
    }
}
