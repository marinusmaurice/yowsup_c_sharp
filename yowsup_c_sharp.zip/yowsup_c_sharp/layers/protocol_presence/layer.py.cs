namespace yowsup.layers.protocol_presence
{

    using YowProtocolLayer = yowsup.layers.YowProtocolLayer;

    using ErrorIqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.ErrorIqProtocolEntity;

    using System.Collections.Generic;

    public static class layer {
        
        public class YowPresenceProtocolLayer
            : YowProtocolLayer {
            
            public YowPresenceProtocolLayer() {
                var handleMap = new Dictionary<object, object> {
                    {
                        "presence",
                        (this.recvPresence, this.sendPresence)},
                    {
                        "iq",
                        (null, this.sendIq)}};
                super(YowPresenceProtocolLayer, this).@__init__(handleMap);
            }
            
            public override object ToString() {
                return "Presence Layer";
            }
            
            public virtual object sendPresence(object entity) {
                this.entityToLower(entity);
            }
            
            public virtual object recvPresence(object node) {
                this.toUpper(PresenceProtocolEntity.fromProtocolTreeNode(node));
            }
            
            public virtual object sendIq(object entity) {
                if (entity.getXmlns() == LastseenIqProtocolEntity.XMLNS) {
                    this._sendIq(entity, this.onLastSeenSuccess, this.onLastSeenError);
                }
            }
            
            public virtual object onLastSeenSuccess(object protocolTreeNode, object lastSeenEntity) {
                this.toUpper(ResultLastseenIqProtocolEntity.fromProtocolTreeNode(protocolTreeNode));
            }
            
            public virtual object onLastSeenError(object protocolTreeNode, object lastSeenEntity) {
                this.toUpper(ErrorIqProtocolEntity.fromProtocolTreeNode(protocolTreeNode));
            }
        }
    }
}
