namespace yowsup.layers.protocol_presence.protocolentities {
    
    using UnsubscribePresenceProtocolEntity = yowsup.layers.protocol_presence.protocolentities.presence_unsubscribe.UnsubscribePresenceProtocolEntity;
    
    using PresenceProtocolEntityTest = yowsup.layers.protocol_presence.protocolentities.test_presence.PresenceProtocolEntityTest;
    
    public static class test_presence_unsubscribe {
        
        public class UnsubscribePresenceProtocolEntityTest
            : PresenceProtocolEntityTest {
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(UnsubscribePresenceProtocolEntityTest, this).setUp();
                this.ProtocolEntity = UnsubscribePresenceProtocolEntity;
                this.node.setAttribute("type", "unsubscribe");
                this.node.setAttribute("to", "some_jid");
            }
        }
    }
}
