namespace yowsup.layers.protocol_presence.protocolentities {
    
    using AvailablePresenceProtocolEntity = yowsup.layers.protocol_presence.protocolentities.presence_available.AvailablePresenceProtocolEntity;
    
    using PresenceProtocolEntityTest = yowsup.layers.protocol_presence.protocolentities.test_presence.PresenceProtocolEntityTest;
    
    public static class test_presence_available {
        
        public class AvailablePresenceProtocolEntityTest
            : PresenceProtocolEntityTest {
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(AvailablePresenceProtocolEntityTest, this).setUp();
                this.ProtocolEntity = AvailablePresenceProtocolEntity;
                this.node.setAttribute("type", "available");
            }
        }
    }
}
