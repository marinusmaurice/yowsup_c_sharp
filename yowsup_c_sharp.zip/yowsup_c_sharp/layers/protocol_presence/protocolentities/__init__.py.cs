namespace yowsup.layers.protocol_presence.protocolentities
{

    public static class @__init__ {
    }
}
