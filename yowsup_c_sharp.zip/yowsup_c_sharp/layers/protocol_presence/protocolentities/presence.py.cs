namespace yowsup.layers.protocol_presence.protocolentities
{

    using ProtocolEntity = yowsup.structs.ProtocolEntity;

    using System.Collections.Generic;

    using System;

    public static class presence {
        
        // 
        //     <presence type="{{type}} name={{push_name}}"></presence>
        //     Should normally be either type or name
        // 
        //     when contact goes offline:
        //     <presence type="unavailable" from="{{contact_jid}}" last="deny | ?">
        //     </presence>
        // 
        //     when contact goes online:
        //     <presence from="contact_jid">
        //     </presence>
        // 
        //     
        public class PresenceProtocolEntity
            : ProtocolEntity {
            
            public object _from;
            
            public object _type;
            
            public object last;
            
            public object name;
            
            public PresenceProtocolEntity(object _type = null, object name = null, object _from = null, object last = null) {
                this._type = _type;
                this.name = name;
                this._from = _from;
                this.last = last;
            }
            
            public virtual object getType() {
                return this._type;
            }
            
            public virtual object getName() {
                return this.name;
            }
            
            public virtual object getFrom(object full = true) {
                return full ? this._from : this._from.split("@")[0];
            }
            
            public virtual object getLast() {
                return this.last;
            }
            
            public virtual object toProtocolTreeNode() {
                var attribs = new Dictionary<object, object> {
                };
                if (this._type) {
                    attribs["type"] = this._type;
                }
                if (this.name) {
                    attribs["name"] = this.name;
                }
                if (this._from) {
                    attribs["from"] = this._from;
                }
                if (this.last) {
                    attribs["last"] = this.last;
                }
                return this._createProtocolTreeNode(attribs, null, null);
            }
            
            public override object ToString() {
                var @out = "Presence:\n";
                if (this._type) {
                    @out += String.Format("Type: %s\n", this._type);
                }
                if (this.name) {
                    @out += String.Format("Name: %s\n", this.name);
                }
                if (this._from) {
                    @out += String.Format("From: %s\n", this._from);
                }
                if (this.last) {
                    @out += String.Format("Last seen: %s\n", this.last);
                }
                return @out;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                return new PresenceProtocolEntity(node.getAttributeValue("type"), node.getAttributeValue("name"), node.getAttributeValue("from"), node.getAttributeValue("last"));
            }
        }
    }
}
