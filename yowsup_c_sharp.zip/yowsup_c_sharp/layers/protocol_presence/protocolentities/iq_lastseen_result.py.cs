namespace yowsup.layers.protocol_presence.protocolentities
{

    using ResultIqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.iq_result.ResultIqProtocolEntity;

    using System;

    using System.Collections.Generic;

    public static class iq_lastseen_result {
        
        public class ResultLastseenIqProtocolEntity
            : ResultIqProtocolEntity {
            
            public int seconds;
            
            public ResultLastseenIqProtocolEntity(object jid, object seconds, object _id = null)
                : base(_id: _id) {
                this.setSeconds(seconds);
            }
            
            public virtual object setSeconds(object seconds) {
                this.seconds = Convert.ToInt32(seconds);
            }
            
            public virtual object getSeconds() {
                return this.seconds;
            }
            
            public override object ToString() {
                var @out = super(ResultIqProtocolEntity, this).@__str__();
                @out += String.Format("Seconds: %s\n", this.seconds);
                return @out;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(ResultLastseenIqProtocolEntity, this).toProtocolTreeNode();
                node.addChild(ProtocolTreeNode("query", new Dictionary<object, object> {
                    {
                        "seconds",
                        this.seconds.ToString()}}));
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                return new ResultLastseenIqProtocolEntity(node["from"], node.getChild("query")["seconds"], node["id"]);
            }
        }
    }
}
