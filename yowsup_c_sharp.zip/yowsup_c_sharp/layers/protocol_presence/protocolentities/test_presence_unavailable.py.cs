namespace yowsup.layers.protocol_presence.protocolentities {
    
    using UnavailablePresenceProtocolEntity = yowsup.layers.protocol_presence.protocolentities.presence_unavailable.UnavailablePresenceProtocolEntity;
    
    using PresenceProtocolEntityTest = yowsup.layers.protocol_presence.protocolentities.test_presence.PresenceProtocolEntityTest;
    
    public static class test_presence_unavailable {
        
        public class UnavailablePresenceProtocolEntityTest
            : PresenceProtocolEntityTest {
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(UnavailablePresenceProtocolEntityTest, this).setUp();
                this.ProtocolEntity = UnavailablePresenceProtocolEntity;
                this.node.setAttribute("type", "unavailable");
            }
        }
    }
}
