namespace yowsup.layers.protocol_presence.protocolentities {
    
    using SubscribePresenceProtocolEntity = yowsup.layers.protocol_presence.protocolentities.presence_subscribe.SubscribePresenceProtocolEntity;
    
    using PresenceProtocolEntityTest = yowsup.layers.protocol_presence.protocolentities.test_presence.PresenceProtocolEntityTest;
    
    public static class test_presence_subscribe {
        
        public class SubscribePresenceProtocolEntityTest
            : PresenceProtocolEntityTest {
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(SubscribePresenceProtocolEntityTest, this).setUp();
                this.ProtocolEntity = SubscribePresenceProtocolEntity;
                this.node.setAttribute("type", "subscribe");
                this.node.setAttribute("to", "subscribe_jid");
            }
        }
    }
}
