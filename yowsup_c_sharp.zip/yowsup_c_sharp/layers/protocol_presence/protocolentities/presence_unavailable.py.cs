namespace yowsup.layers.protocol_presence.protocolentities
{

    using PresenceProtocolEntity = presence.PresenceProtocolEntity;

    public static class presence_unavailable {
        
        // 
        //     <presence type="unavailable"></presence>
        //     response:
        //     <presence type="unavailable" from="self.jid">
        //     </presence>
        //     
        public class UnavailablePresenceProtocolEntity
            : PresenceProtocolEntity {
            
            public UnavailablePresenceProtocolEntity() {
            }
        }
    }
}
