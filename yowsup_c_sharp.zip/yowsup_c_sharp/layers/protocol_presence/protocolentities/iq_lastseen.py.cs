namespace yowsup.layers.protocol_presence.protocolentities
{

    using IqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.iq.IqProtocolEntity;

    public static class iq_lastseen {
        
        public class LastseenIqProtocolEntity
            : IqProtocolEntity {
            
            public string XMLNS;
            
            public string XMLNS = "jabber:iq:last";
            
            public LastseenIqProtocolEntity(object jid, object _id = null)
                : base(_type: "get", to: jid, _id: _id) {
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                return new LastseenIqProtocolEntity(node["to"]);
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(LastseenIqProtocolEntity, this).toProtocolTreeNode();
                node.setAttribute("xmlns", this.@__class__.XMLNS);
                node.addChild(ProtocolTreeNode("query"));
                return node;
            }
        }
    }
}
