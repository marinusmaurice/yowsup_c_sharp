namespace yowsup.layers.protocol_presence.protocolentities
{

    using PresenceProtocolEntity = yowsup.layers.protocol_presence.protocolentities.presence.PresenceProtocolEntity;

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using ProtocolEntityTest = yowsup.structs.protocolentity.ProtocolEntityTest;

    using System.Collections.Generic;

    public static class test_presence {
        
        public class PresenceProtocolEntityTest
            : ProtocolEntityTest, unittest.TestCase {
            
            public object node;
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                this.ProtocolEntity = PresenceProtocolEntity;
                this.node = ProtocolTreeNode("presence", new Dictionary<object, object> {
                    {
                        "type",
                        "presence_type"},
                    {
                        "name",
                        "presence_name"}}, null, null);
            }
        }
    }
}
