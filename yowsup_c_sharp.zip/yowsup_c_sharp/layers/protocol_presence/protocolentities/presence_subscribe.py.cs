namespace yowsup.layers.protocol_presence.protocolentities
{

    using PresenceProtocolEntity = presence.PresenceProtocolEntity;

    using System;

    public static class presence_subscribe {
        
        // 
        //     <presence type="subscribe" to="jid"></presence>
        //     
        public class SubscribePresenceProtocolEntity
            : PresenceProtocolEntity {
            
            public object jid;
            
            public SubscribePresenceProtocolEntity(object jid) {
                this.setProps(jid);
            }
            
            public virtual object setProps(object jid) {
                this.jid = jid;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(SubscribePresenceProtocolEntity, this).toProtocolTreeNode();
                node.setAttribute("to", this.jid);
                return node;
            }
            
            public override object ToString() {
                var @out = super(SubscribePresenceProtocolEntity, this).@__str__();
                @out += String.Format("To: %s\n", this.jid);
                return @out;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = PresenceProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = SubscribePresenceProtocolEntity;
                entity.setProps(node.getAttributeValue("to"));
                return entity;
            }
        }
    }
}
