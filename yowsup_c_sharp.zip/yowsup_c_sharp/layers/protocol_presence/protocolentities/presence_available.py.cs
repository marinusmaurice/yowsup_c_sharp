namespace yowsup.layers.protocol_presence.protocolentities
{

    using PresenceProtocolEntity = presence.PresenceProtocolEntity;

    public static class presence_available {
        
        // 
        //     <presence type="available"></presence>
        //     response:
        //     <presence from="self.jid">
        //     </presence>
        // 
        //     
        public class AvailablePresenceProtocolEntity
            : PresenceProtocolEntity {
            
            public AvailablePresenceProtocolEntity() {
            }
        }
    }
}
