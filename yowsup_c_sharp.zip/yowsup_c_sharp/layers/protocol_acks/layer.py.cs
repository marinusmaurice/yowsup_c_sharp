namespace yowsup.layers.protocol_acks {
    
    using YowProtocolLayer = yowsup.layers.YowProtocolLayer;
    
    using System.Collections.Generic;
    
    public static class layer {
        
        public class YowAckProtocolLayer
            : YowProtocolLayer {
            
            public YowAckProtocolLayer() {
                var handleMap = new Dictionary<object, object> {
                    {
                        "ack",
                        (this.recvAckNode, this.sendAckEntity)}};
                super(YowAckProtocolLayer, this).@__init__(handleMap);
            }
            
            public override object ToString() {
                return "Ack Layer";
            }
            
            public virtual object sendAckEntity(object entity) {
                this.entityToLower(entity);
            }
            
            public virtual object recvAckNode(object node) {
                this.toUpper(IncomingAckProtocolEntity.fromProtocolTreeNode(node));
            }
        }
    }
}
