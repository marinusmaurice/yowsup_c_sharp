namespace yowsup.layers.protocol_acks.protocolentities
{

    using IncomingAckProtocolEntity = yowsup.layers.protocol_acks.protocolentities.ack_incoming.IncomingAckProtocolEntity;

    using ProtocolEntityTest = yowsup.structs.protocolentity.ProtocolEntityTest;

    using System;

    public static class test_ack_incoming {
        
        public static object entity = IncomingAckProtocolEntity("12345", "message", "sender@s.whatsapp.com", Convert.ToInt32(time.time()));
        
        public class IncomingAckProtocolEntityTest
            : ProtocolEntityTest, unittest.TestCase {
            
            public object node;
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                this.ProtocolEntity = IncomingAckProtocolEntity;
                this.node = entity.toProtocolTreeNode();
            }
        }
    }
}
