namespace yowsup.layers.protocol_acks.protocolentities {
    
    using AckProtocolEntity = ack.AckProtocolEntity;
    
    using System;
    
    public static class ack_outgoing {
        
        // 
        //     <ack type="{{delivery | read}}" class="{{message | receipt | ?}}" id="{{MESSAGE_ID}} to={{TO_JID}}">
        //     </ack>
        // 
        //     <ack to="{{GROUP_JID}}" participant="{{JID}}" id="{{MESSAGE_ID}}" class="receipt" type="{{read | }}">
        //     </ack>
        // 
        //     
        public class OutgoingAckProtocolEntity
            : AckProtocolEntity {
            
            public object _participant;
            
            public object _to;
            
            public object _type;
            
            public OutgoingAckProtocolEntity(
                object _id,
                object _class,
                object _type,
                object to,
                object participant = null)
                : base(_class) {
                this.setOutgoingData(_type, to, participant);
            }
            
            public virtual object setOutgoingData(object _type, object _to, object _participant) {
                this._type = _type;
                this._to = _to;
                this._participant = _participant;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(OutgoingAckProtocolEntity, this).toProtocolTreeNode();
                if (this._type) {
                    node.setAttribute("type", this._type);
                }
                node.setAttribute("to", this._to);
                if (this._participant) {
                    node.setAttribute("participant", this._participant);
                }
                return node;
            }
            
            public override object ToString() {
                var @out = super(OutgoingAckProtocolEntity, this).@__str__();
                @out += String.Format("Type: %s\n", this._type);
                @out += String.Format("To: %s\n", this._to);
                if (this._participant) {
                    @out += String.Format("Participant: %s\n", this._participant);
                }
                return @out;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = AckProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = OutgoingAckProtocolEntity;
                entity.setOutgoingData(node.getAttributeValue("type"), node.getAttributeValue("to"), node.getAttributeValue("participant"));
                return entity;
            }
        }
    }
}
