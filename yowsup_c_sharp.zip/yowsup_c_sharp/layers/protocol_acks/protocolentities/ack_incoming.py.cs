namespace yowsup.layers.protocol_acks.protocolentities
{

    using AckProtocolEntity = ack.AckProtocolEntity;

    using System;

    public static class ack_incoming {
        
        // 
        //     <ack t="{{TIMESTAMP}}" from="{{FROM_JID}}" id="{{MESSAGE_ID}}" class="{{message | receipt | ?}}">
        //     </ack>
        //     
        public class IncomingAckProtocolEntity
            : AckProtocolEntity {
            
            public object _from;
            
            public object timestamp;
            
            public IncomingAckProtocolEntity(object _id, object _class, object _from, object timestamp)
                : base(_class) {
                this.setIncomingData(_from, timestamp);
            }
            
            public virtual object setIncomingData(object _from, object timestamp) {
                this._from = _from;
                this.timestamp = timestamp;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(IncomingAckProtocolEntity, this).toProtocolTreeNode();
                node.setAttribute("from", this._from);
                node.setAttribute("t", this.timestamp);
                return node;
            }
            
            public override object ToString() {
                var @out = super(IncomingAckProtocolEntity, this).@__str__();
                @out += String.Format("From: %s\n", this._from);
                @out += String.Format("timestamp: %s\n", this.timestamp);
                return @out;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = AckProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = IncomingAckProtocolEntity;
                entity.setIncomingData(node.getAttributeValue("from"), node.getAttributeValue("t"));
                return entity;
            }
        }
    }
}
