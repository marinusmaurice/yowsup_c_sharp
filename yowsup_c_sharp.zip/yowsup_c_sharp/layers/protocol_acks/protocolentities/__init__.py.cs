namespace yowsup.layers.protocol_acks.protocolentities
{

    public static class @__init__ {
    }
}
