namespace yowsup.layers.protocol_acks.protocolentities
{

    using ProtocolEntity = yowsup.structs.ProtocolEntity;

    using System.Collections.Generic;

    using System;

    public static class ack {
        
        // 
        //     <ack class="{{receipt | message | ?}}" id="{{message_id}}">
        //     </ack>
        //     
        public class AckProtocolEntity
            : ProtocolEntity {
            
            public object _class;
            
            public object _id;
            
            public AckProtocolEntity(object _id, object _class) {
                this._id = _id;
                this._class = _class;
            }
            
            public virtual object getId() {
                return this._id;
            }
            
            public virtual object getClass() {
                return this._class;
            }
            
            public virtual object toProtocolTreeNode() {
                var attribs = new Dictionary<object, object> {
                    {
                        "id",
                        this._id},
                    {
                        "class",
                        this._class}};
                return this._createProtocolTreeNode(attribs, null, data: null);
            }
            
            public override object ToString() {
                var @out = "ACK:\n";
                @out += String.Format("ID: %s\n", this._id);
                @out += String.Format("Class: %s\n", this._class);
                return @out;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                return new AckProtocolEntity(node.getAttributeValue("id"), node.getAttributeValue("class"));
            }
        }
    }
}
