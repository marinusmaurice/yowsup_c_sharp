namespace yowsup.layers.protocol_acks.protocolentities
{

    using OutgoingAckProtocolEntity = yowsup.layers.protocol_acks.protocolentities.ack_outgoing.OutgoingAckProtocolEntity;

    using ProtocolEntityTest = yowsup.structs.protocolentity.ProtocolEntityTest;

    public static class test_ack_outgoing {
        
        public static object entity = OutgoingAckProtocolEntity("12345", "receipt", "delivery", "to_jid");
        
        public class OutgoingAckProtocolEntityTest
            : ProtocolEntityTest, unittest.TestCase {
            
            public object node;
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                this.ProtocolEntity = OutgoingAckProtocolEntity;
                this.node = entity.toProtocolTreeNode();
            }
        }
    }
}
