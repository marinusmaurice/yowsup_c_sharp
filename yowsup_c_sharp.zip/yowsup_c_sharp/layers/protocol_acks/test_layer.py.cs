namespace yowsup.layers.protocol_acks {
    
    using YowProtocolLayerTest = yowsup.layers.YowProtocolLayerTest;
    
    using YowAckProtocolLayer = yowsup.layers.protocol_acks.YowAckProtocolLayer;
    
    using incomingAckEntity = yowsup.layers.protocol_acks.protocolentities.test_ack_incoming.entity;
    
    using outgoingAckEntity = yowsup.layers.protocol_acks.protocolentities.test_ack_outgoing.entity;
    
    public static class test_layer {
        
        public class YowAckProtocolLayerTest
            : YowProtocolLayerTest, YowAckProtocolLayer {
            
            public virtual object setUp() {
                YowAckProtocolLayer.@__init__(this);
            }
            
            public virtual object test_receive() {
                this.assertReceived(incomingAckEntity);
            }
            
            public virtual object test_send() {
                this.assertSent(outgoingAckEntity);
            }
        }
    }
}
