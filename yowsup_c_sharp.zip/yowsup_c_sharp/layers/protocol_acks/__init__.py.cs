namespace yowsup.layers.protocol_acks
{

    public static class @__init__ {
    }
}
