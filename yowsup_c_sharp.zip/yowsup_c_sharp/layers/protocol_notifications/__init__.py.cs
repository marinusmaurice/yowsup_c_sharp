namespace yowsup.layers.protocol_notifications
{

    public static class @__init__ {
    }
}
