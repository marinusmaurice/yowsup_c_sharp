namespace yowsup.layers.protocol_notifications.protocolentities
{

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using NotificationProtocolEntity = notification.NotificationProtocolEntity;

    using System.Collections.Generic;

    public static class notification_status {
        
        // 
        //     <notification offline="0" id="{{NOTIFICATION_ID}}" notify="{{NOTIFY_NAME}}" type="status" 
        //             t="{{TIMESTAMP}}" from="{{SENDER_JID}}">
        //         <set>
        //             {{STATUS}}
        //         </set>
        //     </notification>
        //     
        //     
        public class StatusNotificationProtocolEntity
            : NotificationProtocolEntity {
            
            public object status;
            
            public StatusNotificationProtocolEntity(
                object _type,
                object _id,
                object _from,
                object status,
                object timestamp,
                object notify,
                object offline = false)
                : base(_id, _from, timestamp, notify, offline) {
                this.setStatus(status);
            }
            
            public virtual object setStatus(object status) {
                this.status = status;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(StatusNotificationProtocolEntity, this).toProtocolTreeNode();
                var setNode = ProtocolTreeNode("set", new Dictionary<object, object> {
                }, null, this.status);
                node.addChild(setNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = NotificationProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = StatusNotificationProtocolEntity;
                entity.setStatus(node.getChild("set").getData());
                return entity;
            }
        }
    }
}
