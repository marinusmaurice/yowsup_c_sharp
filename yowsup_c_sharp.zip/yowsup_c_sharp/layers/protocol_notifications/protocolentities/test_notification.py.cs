namespace yowsup.layers.protocol_notifications.protocolentities
{

    using NotificationProtocolEntity = yowsup.layers.protocol_notifications.protocolentities.notification.NotificationProtocolEntity;

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using ProtocolEntityTest = yowsup.structs.protocolentity.ProtocolEntityTest;

    using System.Collections.Generic;

    public static class test_notification {
        
        public class NotificationProtocolEntityTest
            : ProtocolEntityTest, unittest.TestCase {
            
            public object node;
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                this.ProtocolEntity = NotificationProtocolEntity;
                var attribs = new Dictionary<object, object> {
                    {
                        "t",
                        "12345"},
                    {
                        "from",
                        "from_jid"},
                    {
                        "offline",
                        "0"},
                    {
                        "type",
                        "notif_type"},
                    {
                        "id",
                        "message-id"},
                    {
                        "notify",
                        "notify_name"}};
                this.node = ProtocolTreeNode("notification", attribs);
            }
        }
    }
}
