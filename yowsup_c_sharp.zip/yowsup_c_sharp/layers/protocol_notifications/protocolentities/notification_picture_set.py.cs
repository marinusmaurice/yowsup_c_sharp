namespace yowsup.layers.protocol_notifications.protocolentities
{

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using PictureNotificationProtocolEntity = notification_picture.PictureNotificationProtocolEntity;

    using System.Collections.Generic;

    public static class notification_picture_set {
        
        // 
        //     <notification offline="0" id="{{NOTIFICATION_ID}}" notify="{{NOTIFY_NAME}}" type="picture" 
        //             t="{{TIMESTAMP}}" from="{{SENDER_JID}}">
        //         <set jid="{{SET_JID}}" id="{{SET_ID}}">
        //         </set>
        //     </notification>
        //     
        public class SetPictureNotificationProtocolEntity
            : PictureNotificationProtocolEntity {
            
            public object setId;
            
            public object setJid;
            
            public SetPictureNotificationProtocolEntity(
                object _id,
                object _from,
                object status,
                object timestamp,
                object notify,
                object offline,
                object setJid,
                object setId)
                : base(_from, timestamp, notify, offline) {
                this.setData(setJid, setId);
            }
            
            public virtual object setData(object setJid, object setId) {
                this.setId = setId;
                this.setJid = setJid;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(SetPictureNotificationProtocolEntity, this).toProtocolTreeNode();
                var setNode = ProtocolTreeNode("set", new Dictionary<object, object> {
                    {
                        "jid",
                        this.setJid},
                    {
                        "id",
                        this.setId}}, null, null);
                node.addChild(setNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = PictureNotificationProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = SetPictureNotificationProtocolEntity;
                var setNode = node.getChild("set");
                entity.setData(setNode.getAttributeValue("jid"), setNode.getAttributeValue("id"));
                return entity;
            }
        }
    }
}
