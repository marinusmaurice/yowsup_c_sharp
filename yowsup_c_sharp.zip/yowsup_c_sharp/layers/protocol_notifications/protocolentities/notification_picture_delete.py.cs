namespace yowsup.layers.protocol_notifications.protocolentities
{

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using PictureNotificationProtocolEntity = notification_picture.PictureNotificationProtocolEntity;

    using System.Collections.Generic;

    public static class notification_picture_delete {
        
        // 
        //     <notification offline="0" id="{{NOTIFICATION_ID}}" notify="{{NOTIFY_NAME}}" type="picture" 
        //             t="{{TIMESTAMP}}" from="{{SENDER_JID}}">
        //         <delete jid="{{DELETE_JID}}">
        //         </delete>
        //     </notification>
        //     
        public class DeletePictureNotificationProtocolEntity
            : PictureNotificationProtocolEntity {
            
            public object deleteJid;
            
            public DeletePictureNotificationProtocolEntity(
                object _id,
                object _from,
                object status,
                object timestamp,
                object notify,
                object offline,
                object deleteJid)
                : base(_from, timestamp, notify, offline) {
                this.setData(deleteJid);
            }
            
            public virtual object setData(object deleteJid) {
                this.deleteJid = deleteJid;
            }
            
            public override object ToString() {
                var @out = super(DeletePictureNotificationProtocolEntity, this).@__str__();
                @out += "Type: Delete";
                return @out;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(DeletePictureNotificationProtocolEntity, this).toProtocolTreeNode();
                var deleteNode = ProtocolTreeNode("delete", new Dictionary<object, object> {
                    {
                        "jid",
                        this.deleteJid}}, null, null);
                node.addChild(deleteNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = PictureNotificationProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = DeletePictureNotificationProtocolEntity;
                var deleteNode = node.getChild("delete");
                entity.setData(deleteNode.getAttributeValue("jid"));
                return entity;
            }
        }
    }
}
