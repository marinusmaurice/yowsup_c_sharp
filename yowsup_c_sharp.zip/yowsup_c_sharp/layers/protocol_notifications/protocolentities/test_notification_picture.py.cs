namespace yowsup.layers.protocol_notifications.protocolentities {
    
    using PictureNotificationProtocolEntity = yowsup.layers.protocol_notifications.protocolentities.notification_picture.PictureNotificationProtocolEntity;
    
    using NotificationProtocolEntityTest = yowsup.layers.protocol_notifications.protocolentities.test_notification.NotificationProtocolEntityTest;
    
    public static class test_notification_picture {
        
        public class PictureNotificationProtocolEntityTest
            : NotificationProtocolEntityTest {
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(PictureNotificationProtocolEntityTest, this).setUp();
                this.ProtocolEntity = PictureNotificationProtocolEntity;
            }
        }
    }
}
