namespace yowsup.layers.protocol_notifications.protocolentities {
    
    using StatusNotificationProtocolEntity = yowsup.layers.protocol_notifications.protocolentities.notification_status.StatusNotificationProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using NotificationProtocolEntityTest = yowsup.layers.protocol_notifications.protocolentities.test_notification.NotificationProtocolEntityTest;
    
    using System.Collections.Generic;
    
    public static class test_notification_status {
        
        public class StatusNotificationProtocolEntityTest
            : NotificationProtocolEntityTest {
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(StatusNotificationProtocolEntityTest, this).setUp();
                this.ProtocolEntity = StatusNotificationProtocolEntity;
                var setNode = ProtocolTreeNode("set", new Dictionary<object, object> {
                }, new List<object>(), new byte[] { (byte)'s', (byte)'t', (byte)'a', (byte)'t', (byte)'u', (byte)'s', (byte)'_', (byte)'d', (byte)'a', (byte)'t', (byte)'a' });
                this.node.addChild(setNode);
            }
        }
    }
}
