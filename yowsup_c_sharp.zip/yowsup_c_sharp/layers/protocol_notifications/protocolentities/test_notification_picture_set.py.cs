namespace yowsup.layers.protocol_notifications.protocolentities {
    
    using SetPictureNotificationProtocolEntity = yowsup.layers.protocol_notifications.protocolentities.notification_picture_set.SetPictureNotificationProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using PictureNotificationProtocolEntityTest = yowsup.layers.protocol_notifications.protocolentities.test_notification_picture.PictureNotificationProtocolEntityTest;
    
    using System.Collections.Generic;
    
    public static class test_notification_picture_set {
        
        public class SetPictureNotificationProtocolEntityTest
            : PictureNotificationProtocolEntityTest {
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(SetPictureNotificationProtocolEntityTest, this).setUp();
                this.ProtocolEntity = SetPictureNotificationProtocolEntity;
                var setNode = ProtocolTreeNode("set", new Dictionary<object, object> {
                    {
                        "jid",
                        "SET_JID"},
                    {
                        "id",
                        "123"}}, null, null);
                this.node.addChild(setNode);
            }
        }
    }
}
