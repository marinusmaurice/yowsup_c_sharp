namespace yowsup.layers.protocol_notifications.protocolentities
{

    using NotificationProtocolEntity = notification.NotificationProtocolEntity;

    public static class notification_picture {
        
        // 
        //     <notification offline="0" id="{{NOTIFICATION_ID}}" notify="{{NOTIFY_NAME}}" type="picture" 
        //             t="{{TIMESTAMP}}" from="{{SENDER_JID}}">
        //     </notification>
        //     
        public class PictureNotificationProtocolEntity
            : NotificationProtocolEntity {
            
            public PictureNotificationProtocolEntity(
                object _id,
                object _from,
                object status,
                object timestamp,
                object notify,
                object offline,
                object setJid,
                object setId)
                : base(_id, _from, timestamp, notify, offline) {
                this.setData(setJid, setId);
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = NotificationProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = PictureNotificationProtocolEntity;
                return entity;
            }
        }
    }
}
