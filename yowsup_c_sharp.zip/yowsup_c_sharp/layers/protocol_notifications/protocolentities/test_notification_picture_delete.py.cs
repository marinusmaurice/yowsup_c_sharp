namespace yowsup.layers.protocol_notifications.protocolentities {
    
    using DeletePictureNotificationProtocolEntity = yowsup.layers.protocol_notifications.protocolentities.notification_picture_delete.DeletePictureNotificationProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using PictureNotificationProtocolEntityTest = yowsup.layers.protocol_notifications.protocolentities.test_notification_picture.PictureNotificationProtocolEntityTest;
    
    using System.Collections.Generic;
    
    public static class test_notification_picture_delete {
        
        public class DeletePictureNotificationProtocolEntityTest
            : PictureNotificationProtocolEntityTest {
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(DeletePictureNotificationProtocolEntityTest, this).setUp();
                this.ProtocolEntity = DeletePictureNotificationProtocolEntity;
                var deleteNode = ProtocolTreeNode("delete", new Dictionary<object, object> {
                    {
                        "jid",
                        "DELETE_JID"}}, null, null);
                this.node.addChild(deleteNode);
            }
        }
    }
}
