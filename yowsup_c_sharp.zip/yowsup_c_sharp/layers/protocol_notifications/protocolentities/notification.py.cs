namespace yowsup.layers.protocol_notifications.protocolentities
{

    using ProtocolEntity = yowsup.structs.ProtocolEntity;

    using System;

    using System.Collections.Generic;

    public static class notification {
        
        // 
        //     <notification offline="0" id="{{NOTIFICATION_ID}}" notify="{{NOTIFY_NAME}}" type="{{NOTIFICATION_TYPE}}" 
        //             t="{{TIMESTAMP}}" from="{{SENDER_JID}}">
        //     </notification>
        // 
        //     
        //     
        public class NotificationProtocolEntity
            : ProtocolEntity {
            
            public object _from;
            
            public object _id;
            
            public object _type;
            
            public object notify;
            
            public bool offline;
            
            public int timestamp;
            
            public NotificationProtocolEntity(
                object _type,
                object _id,
                object _from,
                object timestamp,
                object notify,
                object offline) {
                this._type = _type;
                this._id = _id;
                this._from = _from;
                this.timestamp = Convert.ToInt32(timestamp);
                this.notify = notify;
                this.offline = offline == "1";
            }
            
            public override object ToString() {
                var @out = "Notification\n";
                @out += String.Format("From: %s\n", this.getFrom());
                @out += String.Format("Type: %s\n", this.getType());
                return @out;
            }
            
            public virtual object getFrom(object full = true) {
                return full ? this._from : this._from.split("@")[0];
            }
            
            public virtual object getType() {
                return this._type;
            }
            
            public virtual object getId() {
                return this._id;
            }
            
            public virtual object getTimestamp() {
                return this.timestamp;
            }
            
            public virtual object toProtocolTreeNode() {
                var attribs = new Dictionary<object, object> {
                    {
                        "t",
                        this.timestamp.ToString()},
                    {
                        "from",
                        this._from},
                    {
                        "offline",
                        this.offline ? "1" : "0"},
                    {
                        "type",
                        this._type},
                    {
                        "id",
                        this._id},
                    {
                        "notify",
                        this.notify}};
                return this._createProtocolTreeNode(attribs, children: null, data: null);
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                return new NotificationProtocolEntity(node.getAttributeValue("type"), node.getAttributeValue("id"), node.getAttributeValue("from"), node.getAttributeValue("t"), node.getAttributeValue("notify"), node.getAttributeValue("offline"));
            }
        }
    }
}
