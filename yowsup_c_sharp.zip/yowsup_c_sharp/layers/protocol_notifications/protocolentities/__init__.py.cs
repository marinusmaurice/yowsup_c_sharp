namespace yowsup.layers.protocol_notifications.protocolentities
{

    public static class @__init__ {
    }
}
