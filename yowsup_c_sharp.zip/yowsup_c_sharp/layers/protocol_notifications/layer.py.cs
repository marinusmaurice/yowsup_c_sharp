namespace yowsup.layers.protocol_notifications
{

    using YowProtocolLayer = yowsup.layers.YowProtocolLayer;

    using OutgoingAckProtocolEntity = yowsup.layers.protocol_acks.protocolentities.OutgoingAckProtocolEntity;

    using System.Collections.Generic;

    using System;

    public static class layer {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class YowNotificationsProtocolLayer
            : YowProtocolLayer {
            
            public YowNotificationsProtocolLayer() {
                var handleMap = new Dictionary<object, object> {
                    {
                        "notification",
                        (this.recvNotification, this.sendNotification)}};
                super(YowNotificationsProtocolLayer, this).@__init__(handleMap);
            }
            
            public override object ToString() {
                return "notification Ib Layer";
            }
            
            public virtual object sendNotification(object entity) {
                if (entity.getTag() == "notification") {
                    this.toLower(entity.toProtocolTreeNode());
                }
            }
            
            public virtual object recvNotification(object node) {
                if (node["type"] == "picture") {
                    if (node.getChild("set")) {
                        this.toUpper(SetPictureNotificationProtocolEntity.fromProtocolTreeNode(node));
                    } else if (node.getChild("delete")) {
                        this.toUpper(DeletePictureNotificationProtocolEntity.fromProtocolTreeNode(node));
                    } else {
                        this.raiseErrorForNode(node);
                    }
                } else if (node["type"] == "status") {
                    this.toUpper(StatusNotificationProtocolEntity.fromProtocolTreeNode(node));
                } else if (new List<string> {
                    "contacts",
                    "subject",
                    "w:gp2"
                }.Contains(node["type"])) {
                    // Implemented in respectively the protocol_contacts and protocol_groups layer
                } else {
                    logger.warning(String.Format("Unsupported notification type: %s ", node["type"]));
                    logger.debug(String.Format("Unsupported notification node: %s", node));
                }
                var ack = OutgoingAckProtocolEntity(node["id"], "notification", node["type"], node["from"], participant: node["participant"]);
                this.toLower(ack.toProtocolTreeNode());
            }
        }
    }
}
