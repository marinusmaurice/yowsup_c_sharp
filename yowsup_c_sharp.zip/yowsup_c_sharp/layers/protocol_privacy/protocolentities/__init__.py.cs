namespace yowsup.layers.protocol_privacy.protocolentities
{

    public static class @__init__ {
    }
}
