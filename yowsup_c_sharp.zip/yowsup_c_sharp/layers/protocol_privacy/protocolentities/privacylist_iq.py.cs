namespace yowsup.layers.protocol_privacy.protocolentities {
    
    using IqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.IqProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using System.Collections.Generic;
    
    public static class privacylist_iq {
        
        public class PrivacyListIqProtocolEntity
            : IqProtocolEntity {
            
            public object listName;
            
            public PrivacyListIqProtocolEntity(object name = "default")
                : base(_type: "get") {
                this.setListName(name);
            }
            
            public virtual object setListName(object name) {
                this.listName = name;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(PrivacyListIqProtocolEntity, this).toProtocolTreeNode();
                var queryNode = ProtocolTreeNode("query");
                var listNode = ProtocolTreeNode("list", new Dictionary<object, object> {
                    {
                        "name",
                        this.listName}});
                queryNode.addChild(listNode);
                node.addChild(queryNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = IqProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = PrivacyListIqProtocolEntity;
                entity.setListName(node.getChild("query").getChild("list")["name"]);
                return entity;
            }
        }
    }
}
