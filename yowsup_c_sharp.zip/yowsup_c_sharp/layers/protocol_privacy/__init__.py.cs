namespace yowsup.layers.protocol_privacy
{

    public static class @__init__ {
    }
}
