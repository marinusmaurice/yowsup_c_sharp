namespace yowsup.layers.protocol_privacy
{

    using YowProtocolLayer = yowsup.layers.YowProtocolLayer;

    using System.Collections.Generic;

    public static class layer {
        
        public class YowPrivacyProtocolLayer
            : YowProtocolLayer {
            
            public YowPrivacyProtocolLayer() {
                var handleMap = new Dictionary<object, object> {
                    {
                        "iq",
                        (this.recvIq, this.sendIq)}};
                super(YowPrivacyProtocolLayer, this).@__init__(handleMap);
            }
            
            public override object ToString() {
                return "Privacy Layer";
            }
            
            public virtual object sendIq(object entity) {
                if (entity.getXmlns() == "jabber:iq:privacy") {
                    this.entityToLower(entity);
                }
            }
            
            public virtual object recvIq(object node) {
            }
        }
    }
}
