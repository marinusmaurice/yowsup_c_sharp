namespace yowsup.layers.axolotl
{

    using Message = yowsup.layers.protocol_messages.proto.e2e_pb2.Message;

    using YowAuthenticationProtocolLayer = yowsup.layers.auth.layer_authentication.YowAuthenticationProtocolLayer;

    using InfoGroupsIqProtocolEntity = yowsup.layers.protocol_groups.protocolentities.InfoGroupsIqProtocolEntity;

    using InfoGroupsResultIqProtocolEntity = yowsup.layers.protocol_groups.protocolentities.InfoGroupsResultIqProtocolEntity;

    using WhisperMessage = axolotl.protocol.whispermessage.WhisperMessage;

    using MessageMetaAttributes = yowsup.layers.protocol_messages.protocolentities.message.MessageMetaAttributes;

    using MissingParametersException = yowsup.layers.axolotl.protocolentities.iq_keys_get_result.MissingParametersException;

    using exceptions = yowsup.axolotl.exceptions;

    using AxolotlBaseLayer = layer_base.AxolotlBaseLayer;

    using System.Collections.Generic;

    using System;

    using System.Linq;

    public static class layer_send {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class AxolotlSendLayer
            : AxolotlBaseLayer {
            
            public Dictionary<object, object> groupCiphers;
            
            public int MAX_SENT_QUEUE;
            
            public List<object> sentQueue;
            
            public Dictionary<object, object> sessionCiphers;
            
            public int MAX_SENT_QUEUE = 100;
            
            public AxolotlSendLayer() {
                this.sessionCiphers = new Dictionary<object, object> {
                };
                this.groupCiphers = new Dictionary<object, object> {
                };
                @"
            Sent messages will be put in Queue until we receive a receipt for them.
            This is for handling retry receipts which requires re-encrypting and resend of the original message
            As the receipt for a sent message might arrive at a different yowsup instance,
            ideally the original message should be fetched from a persistent storage.
            Therefore, if the original message is not in sentQueue for any reason, we will
            notify the upper layers and let them handle it.
        ";
                this.sentQueue = new List<object>();
            }
            
            public override object ToString() {
                return "Axolotl Layer";
            }
            
            public virtual object send(object node) {
                if (node.tag == "message" && !this.skipEncJids.Contains(node["to"])) {
                    this.processPlaintextNodeAndSend(node);
                } else {
                    this.toLower(node);
                }
            }
            
            public virtual object receive(object protocolTreeNode) {
                Func<object, object, object, object, object> on_get_keys_success = (node,retry_entity,success_jids,errors) => {
                    if (errors.Count) {
                        this.on_get_keys_process_errors(errors);
                    } else if (success_jids.Count == 1) {
                        this.processPlaintextNodeAndSend(node, retry_entity);
                    } else {
                        throw new NotImplementedException();
                    }
                };
                if (!this.processIqRegistry(protocolTreeNode)) {
                    if (protocolTreeNode.tag == "receipt") {
                        @"
                Going to keep all group message enqueued, as we get receipts from each participant
                So can't just remove it on first receipt. Therefore, the MAX queue length mechanism should better be working
                ";
                        var messageNode = this.getEnqueuedMessageNode(protocolTreeNode["id"], protocolTreeNode["participant"] != null);
                        if (!messageNode) {
                            logger.debug("Axolotl layer does not have the message, bubbling it upwards");
                            this.toUpper(protocolTreeNode);
                        } else if (protocolTreeNode["type"] == "retry") {
                            logger.info(String.Format("Got retry to for message %s, and Axolotl layer has the message", protocolTreeNode["id"]));
                            var retryReceiptEntity = RetryIncomingReceiptProtocolEntity.fromProtocolTreeNode(protocolTreeNode);
                            this.toLower(retryReceiptEntity.ack().toProtocolTreeNode());
                            this.getKeysFor(new List<object> {
                                protocolTreeNode["participant"] || protocolTreeNode["from"]
                            }, (successJids,errors) => on_get_keys_success(messageNode, retryReceiptEntity, successJids, errors));
                        } else {
                            //not interested in any non retry receipts, bubble upwards
                            this.toUpper(protocolTreeNode);
                        }
                    }
                }
            }
            
            public virtual object on_get_keys_process_errors(object errors) {
                // type: (dict) -> None
                foreach (var _tup_1 in errors.items()) {
                    var jid = _tup_1.Item1;
                    var error = _tup_1.Item2;
                    if (error is MissingParametersException) {
                        logger.error(String.Format("Failed to create prekeybundle for %s, user had missing parameters: %s, is that a valid user?", jid, error.parameters));
                    } else if (error is exceptions.UntrustedIdentityException) {
                        logger.error(String.Format("Failed to create session for %s as user's identity is not trusted. ", jid));
                    } else {
                        logger.error(String.Format("Failed to process keys for %s, is that a valid user? Exception: %s", error));
                    }
                }
            }
            
            public virtual object processPlaintextNodeAndSend(object node, object retryReceiptEntity = null) {
                var recipient_id = node["to"].split("@")[0];
                var isGroup = recipient_id.Contains("-");
                Func<object, object, object, object> on_get_keys_error = (error_node,getkeys_entity,plaintext_node) => {
                    logger.error(String.Format("Failed to fetch keys for %s, is that a valid user? Server response: [code=%s, text=%s], aborting send.", plaintext_node["to"], error_node.children[0]["code"], error_node.children[0]["text"]));
                };
                Func<object, object, object, object> on_get_keys_success = (node,success_jids,errors) => {
                    if (errors.Count) {
                        this.on_get_keys_process_errors(errors);
                    } else if (success_jids.Count == 1) {
                        this.sendToContact(node);
                    } else {
                        throw new NotImplementedException();
                    }
                };
                if (isGroup) {
                    this.sendToGroup(node, retryReceiptEntity);
                } else if (this.manager.session_exists(recipient_id)) {
                    this.sendToContact(node);
                } else {
                    this.getKeysFor(new List<object> {
                        node["to"]
                    }, (successJids,errors) => on_get_keys_success(node, successJids, errors), (error_node,entity) => on_get_keys_error(error_node, entity, node));
                }
            }
            
            public virtual object enqueueSent(object node) {
                logger.debug("enqueueSent(node=[omitted])");
                if (this.sentQueue.Count >= this.@__class__.MAX_SENT_QUEUE) {
                    logger.warn("Discarding queued node without receipt");
                    this.sentQueue.pop(0);
                }
                this.sentQueue.append(node);
            }
            
            public virtual object getEnqueuedMessageNode(object messageId, object keepEnqueued = false) {
                foreach (var i in Enumerable.Range(0, this.sentQueue.Count - 0)) {
                    if (this.sentQueue[i]["id"] == messageId) {
                        if (keepEnqueued) {
                            return this.sentQueue[i];
                        }
                        return this.sentQueue.pop(i);
                    }
                }
            }
            
            public virtual object sendEncEntities(object node, object encEntities, object participant = null) {
                logger.debug(String.Format("sendEncEntities(node=[omitted], encEntities=[omitted], participant=%s)", participant));
                var message_attrs = MessageMetaAttributes.from_message_protocoltreenode(node);
                message_attrs.participant = participant;
                var messageEntity = EncryptedMessageProtocolEntity(encEntities, node["type"], message_attrs);
                // if participant is set, this message is directed to that specific participant as a result of a retry, therefore
                // we already have the original group message and there is no need to store it again.
                if (participant == null) {
                    this.enqueueSent(node);
                }
                this.toLower(messageEntity.toProtocolTreeNode());
            }
            
            public virtual object sendToContact(object node) {
                var recipient_id = node["to"].split("@")[0];
                var protoNode = node.getChild("proto");
                var messageData = protoNode.getData();
                var ciphertext = this.manager.encrypt(recipient_id, messageData);
                var mediaType = protoNode["mediatype"];
                return this.sendEncEntities(node, new List<object> {
                    EncProtocolEntity(ciphertext.@__class__ == WhisperMessage ? EncProtocolEntity.TYPE_MSG : EncProtocolEntity.TYPE_PKMSG, 2, ciphertext.serialize(), mediaType)
                });
            }
            
            // 
            //         For each jid in jidsNeedSenderKey will create a pkmsg enc node with the associated jid.
            //         If retryCount > 0 and we have only one jidsNeedSenderKey, this is a retry requested by a specific participant
            //         and this message is to be directed at specific at that participant indicated by jidsNeedSenderKey[0]. In this
            //         case the participant's jid would go in the parent's EncryptedMessage and not into the enc node.
            //         
            public virtual object sendToGroupWithSessions(object node, object jidsNeedSenderKey = null, object retryCount = 0) {
                object ciphertext;
                logger.debug(String.Format("sendToGroupWithSessions(node=[omitted], jidsNeedSenderKey=%s, retryCount=%d)", jidsNeedSenderKey, retryCount));
                jidsNeedSenderKey = jidsNeedSenderKey || new List<object>();
                var groupJid = node["to"];
                var protoNode = node.getChild("proto");
                var encEntities = new List<object>();
                var participant = jidsNeedSenderKey.Count == 1 && retryCount > 0 ? jidsNeedSenderKey[0] : null;
                if (jidsNeedSenderKey.Count) {
                    var senderKeyDistributionMessage = this.manager.group_create_skmsg(groupJid);
                    foreach (var jid in jidsNeedSenderKey) {
                        var message = this.serializeSenderKeyDistributionMessageToProtobuf(node["to"], senderKeyDistributionMessage);
                        if (retryCount > 0) {
                            message.MergeFromString(protoNode.getData());
                        }
                        ciphertext = this.manager.encrypt(jid.split("@")[0], message.SerializeToString());
                        encEntities.append(EncProtocolEntity(ciphertext.@__class__ == WhisperMessage ? EncProtocolEntity.TYPE_MSG : EncProtocolEntity.TYPE_PKMSG, 2, ciphertext.serialize(), protoNode["mediatype"], jid: participant ? null : jid));
                    }
                }
                if (!retryCount) {
                    var messageData = protoNode.getData();
                    ciphertext = this.manager.group_encrypt(groupJid, messageData);
                    var mediaType = protoNode["mediatype"];
                    encEntities.append(EncProtocolEntity(EncProtocolEntity.TYPE_SKMSG, 2, ciphertext, mediaType));
                }
                this.sendEncEntities(node, encEntities, participant);
            }
            
            public virtual object ensureSessionsAndSendToGroup(object node, object jids) {
                logger.debug(String.Format("ensureSessionsAndSendToGroup(node=[omitted], jids=%s)", jids));
                var jidsNoSession = new List<object>();
                foreach (var jid in jids) {
                    if (!this.manager.session_exists(jid.split("@")[0])) {
                        jidsNoSession.append(jid);
                    }
                }
                Func<object, object, object, object> on_get_keys_success = (node,success_jids,errors) => {
                    if (errors.Count) {
                        this.on_get_keys_process_errors(errors);
                    }
                    this.sendToGroupWithSessions(node, success_jids);
                };
                if (jidsNoSession.Count) {
                    this.getKeysFor(jidsNoSession, (successJids,errors) => on_get_keys_success(node, successJids, errors));
                } else {
                    this.sendToGroupWithSessions(node, jids);
                }
            }
            
            // 
            //         Group send sequence:
            //         check if senderkeyrecord exists
            //             no: - create,
            //                 - get group jids from info request
            //                 - for each jid without a session, get keys to create the session
            //                 - send message with dist key for all participants
            //             yes:
            //                 - send skmsg without any dist key
            // 
            //         received retry for a participant
            //             - request participants keys
            //             - send message with dist key only + conversation, only for this participat
            //         
            public virtual object sendToGroup(object node, object retryReceiptEntity = null) {
                logger.debug(retryReceiptEntity != null ? String.Format("sendToGroup(node=[omitted], retryReceiptEntity=[%s])", String.Format("[retry_count=%s, retry_jid=%s]", retryReceiptEntity.getRetryCount(), retryReceiptEntity.getRetryJid())) : null);
                var groupJid = node["to"];
                var ownJid = this.getLayerInterface(YowAuthenticationProtocolLayer).getUsername(true);
                var senderKeyRecord = this.manager.load_senderkey(node["to"]);
                Func<object, object, object> sendToGroup = (resultNode,requestEntity) => {
                    var groupInfo = InfoGroupsResultIqProtocolEntity.fromProtocolTreeNode(resultNode);
                    var jids = groupInfo.getParticipants().keys().ToList();
                    if (jids.Contains(ownJid)) {
                        jids.remove(ownJid);
                    }
                    return this.ensureSessionsAndSendToGroup(node, jids);
                };
                if (senderKeyRecord.isEmpty()) {
                    logger.debug("senderKeyRecord is empty, requesting group info");
                    var groupInfoIq = InfoGroupsIqProtocolEntity(groupJid);
                    this._sendIq(groupInfoIq, sendToGroup);
                } else {
                    logger.debug("We have a senderKeyRecord");
                    var retryCount = 0;
                    var jidsNeedSenderKey = new List<object>();
                    if (retryReceiptEntity != null) {
                        retryCount = retryReceiptEntity.getRetryCount();
                        jidsNeedSenderKey.append(retryReceiptEntity.getRetryJid());
                    }
                    this.sendToGroupWithSessions(node, jidsNeedSenderKey, retryCount);
                }
            }
            
            public virtual object serializeSenderKeyDistributionMessageToProtobuf(object groupId, object senderKeyDistributionMessage, object message = null) {
                var m = message || Message();
                m.sender_key_distribution_message.group_id = groupId;
                m.sender_key_distribution_message.axolotl_sender_key_distribution_message = senderKeyDistributionMessage.serialize();
                m.sender_key_distribution_message.axolotl_sender_key_distribution_message = senderKeyDistributionMessage.serialize();
                // m.conversation = text
                return m;
            }
        }
    }
}
