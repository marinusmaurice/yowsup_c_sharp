namespace yowsup.layers.axolotl
{

    using AxolotlBaseLayer = layer_base.AxolotlBaseLayer;

    using OutgoingReceiptProtocolEntity = yowsup.layers.protocol_receipts.protocolentities.OutgoingReceiptProtocolEntity;

    using PROP_IDENTITY_AUTOTRUST = yowsup.layers.axolotl.props.PROP_IDENTITY_AUTOTRUST;

    using exceptions = yowsup.axolotl.exceptions;

    using UntrustedIdentityException = axolotl.untrustedidentityexception.UntrustedIdentityException;

    using System.Collections.Generic;

    using System;

    using System.Linq;

    public static class layer_receive {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class AxolotlReceivelayer
            : AxolotlBaseLayer {
            
            public Dictionary<object, object> _retries;
            
            public Dictionary<object, object> groupCiphers;
            
            public Dictionary<object, object> pendingIncomingMessages;
            
            public Dictionary<object, object> sessionCiphers;
            
            public List<object> v2Jids;
            
            public AxolotlReceivelayer() {
                this.v2Jids = new List<object>();
                this.sessionCiphers = new Dictionary<object, object> {
                };
                this.groupCiphers = new Dictionary<object, object> {
                };
                this.pendingIncomingMessages = new Dictionary<object, object> {
                };
                this._retries = new Dictionary<object, object> {
                };
            }
            
            // 
            //         :type protocolTreeNode: ProtocolTreeNode
            //         
            public virtual object receive(object protocolTreeNode) {
                if (!this.processIqRegistry(protocolTreeNode)) {
                    if (protocolTreeNode.tag == "message") {
                        this.onMessage(protocolTreeNode);
                    } else if (!(protocolTreeNode.tag == "receipt")) {
                        //receipts will be handled by send layer
                        this.toUpper(protocolTreeNode);
                    }
                }
            }
            
            public virtual object processPendingIncomingMessages(object jid, object participantJid = null) {
                var conversationIdentifier = (jid, participantJid);
                if (this.pendingIncomingMessages.Contains(conversationIdentifier)) {
                    foreach (var messageNode in this.pendingIncomingMessages[conversationIdentifier]) {
                        this.onMessage(messageNode);
                    }
                    this.pendingIncomingMessages.Remove(conversationIdentifier);
                }
            }
            
            public virtual object onMessage(object protocolTreeNode) {
                var encNode = protocolTreeNode.getChild("enc");
                if (encNode) {
                    this.handleEncMessage(protocolTreeNode);
                } else {
                    this.toUpper(protocolTreeNode);
                }
            }
            
            public virtual object handleEncMessage(object node) {
                var encMessageProtocolEntity = EncryptedMessageProtocolEntity.fromProtocolTreeNode(node);
                var isGroup = node["participant"] != null;
                var senderJid = isGroup ? node["participant"] : node["from"];
                if (node.getChild("enc")["v"] == "2" && !this.v2Jids.Contains(node["from"])) {
                    this.v2Jids.append(node["from"]);
                }
                try {
                    if (encMessageProtocolEntity.getEnc(EncProtocolEntity.TYPE_PKMSG)) {
                        this.handlePreKeyWhisperMessage(node);
                    } else if (encMessageProtocolEntity.getEnc(EncProtocolEntity.TYPE_MSG)) {
                        this.handleWhisperMessage(node);
                    }
                    if (encMessageProtocolEntity.getEnc(EncProtocolEntity.TYPE_SKMSG)) {
                        this.handleSenderKeyMessage(node);
                    }
                    this.reset_retries(node["id"]);
                } catch {
                    logger.warning("Invalid KeyId for %s, going to send a retry", encMessageProtocolEntity.getAuthor(false));
                    this.send_retry(node, this.manager.registration_id);
                } catch {
                    logger.warning("InvalidMessage for %s, going to send a retry", encMessageProtocolEntity.getAuthor(false));
                    this.send_retry(node, this.manager.registration_id);
                } catch {
                    logger.warning("No session for %s, getting their keys now", encMessageProtocolEntity.getAuthor(false));
                    var conversationIdentifier = (node["from"], node["participant"]);
                    if (!this.pendingIncomingMessages.Contains(conversationIdentifier)) {
                        this.pendingIncomingMessages[conversationIdentifier] = new List<object>();
                    }
                    this.pendingIncomingMessages[conversationIdentifier].append(node);
                    var successFn = (successJids,b) => successJids.Count ? this.processPendingIncomingMessages(conversationIdentifier) : null;
                    this.getKeysFor(new List<object> {
                        senderJid
                    }, successFn);
                } catch {
                    logger.warning("Received a message that we've previously decrypted, going to send the delivery receipt myself");
                    this.toLower(OutgoingReceiptProtocolEntity(node["id"], node["from"], participant: node["participant"]).toProtocolTreeNode());
                } catch (UntrustedIdentityException) {
                    if (this.getProp(PROP_IDENTITY_AUTOTRUST, false)) {
                        logger.warning("Autotrusting identity for %s", e.getName());
                        this.manager.trust_identity(e.getName(), e.getIdentityKey());
                        return this.handleEncMessage(node);
                    } else {
                        logger.error("Ignoring message with untrusted identity");
                    }
                }
            }
            
            public virtual object handlePreKeyWhisperMessage(object node) {
                var pkMessageProtocolEntity = EncryptedMessageProtocolEntity.fromProtocolTreeNode(node);
                var enc = pkMessageProtocolEntity.getEnc(EncProtocolEntity.TYPE_PKMSG);
                var plaintext = this.manager.decrypt_pkmsg(pkMessageProtocolEntity.getAuthor(false), enc.getData(), enc.getVersion() == 2);
                if (enc.getVersion() == 2) {
                    this.parseAndHandleMessageProto(pkMessageProtocolEntity, plaintext);
                }
                node = pkMessageProtocolEntity.toProtocolTreeNode();
                node.addChild(ProtoProtocolEntity(plaintext, enc.getMediaType()).toProtocolTreeNode());
                this.toUpper(node);
            }
            
            public virtual object handleWhisperMessage(object node) {
                var encMessageProtocolEntity = EncryptedMessageProtocolEntity.fromProtocolTreeNode(node);
                var enc = encMessageProtocolEntity.getEnc(EncProtocolEntity.TYPE_MSG);
                var plaintext = this.manager.decrypt_msg(encMessageProtocolEntity.getAuthor(false), enc.getData(), enc.getVersion() == 2);
                if (enc.getVersion() == 2) {
                    this.parseAndHandleMessageProto(encMessageProtocolEntity, plaintext);
                }
                node = encMessageProtocolEntity.toProtocolTreeNode();
                node.addChild(ProtoProtocolEntity(plaintext, enc.getMediaType()).toProtocolTreeNode());
                this.toUpper(node);
            }
            
            public virtual object handleSenderKeyMessage(object node) {
                var encMessageProtocolEntity = EncryptedMessageProtocolEntity.fromProtocolTreeNode(node);
                var enc = encMessageProtocolEntity.getEnc(EncProtocolEntity.TYPE_SKMSG);
                try {
                    var plaintext = this.manager.group_decrypt(groupid: encMessageProtocolEntity.getFrom(true), participantid: encMessageProtocolEntity.getParticipant(false), data: enc.getData());
                    this.parseAndHandleMessageProto(encMessageProtocolEntity, plaintext);
                    node = encMessageProtocolEntity.toProtocolTreeNode();
                    node.addChild(ProtoProtocolEntity(plaintext, enc.getMediaType()).toProtocolTreeNode());
                    this.toUpper(node);
                } catch {
                    logger.warning("No session for %s, going to send a retry", encMessageProtocolEntity.getAuthor(false));
                    this.send_retry(node, this.manager.registration_id);
                }
            }
            
            public virtual object parseAndHandleMessageProto(object encMessageProtocolEntity, object serializedData) {
                var m = Message();
                try {
                    m.ParseFromString(serializedData);
                } catch {
                    Console.WriteLine("DUMP:");
                    Console.WriteLine(serializedData);
                    Console.WriteLine((from s in serializedData
                        select s).ToList());
                    throw;
                }
                if (!m || !serializedData) {
                    throw exceptions.InvalidMessageException();
                }
                if (m.HasField("sender_key_distribution_message")) {
                    this.handleSenderKeyDistributionMessage(m.sender_key_distribution_message, encMessageProtocolEntity.getParticipant(false));
                }
            }
            
            public virtual object handleSenderKeyDistributionMessage(object senderKeyDistributionMessage, object participantId) {
                var groupId = senderKeyDistributionMessage.group_id;
                this.manager.group_create_session(groupid: groupId, participantid: participantId, skmsgdata: senderKeyDistributionMessage.axolotl_sender_key_distribution_message);
            }
            
            public virtual object send_retry(object message_node, object registration_id) {
                object count;
                var message_id = message_node["id"];
                if (this._retries.Contains(message_id)) {
                    count = this._retries[message_id];
                    count += 1;
                } else {
                    count = 1;
                }
                this._retries[message_id] = count;
                var retry = RetryOutgoingReceiptProtocolEntity.fromMessageNode(message_node, registration_id);
                retry.count = count;
                this.toLower(retry.toProtocolTreeNode());
            }
            
            public virtual object reset_retries(object message_id) {
                if (this._retries.Contains(message_id)) {
                    this._retries.Remove(message_id);
                }
            }
        }
    }
}
