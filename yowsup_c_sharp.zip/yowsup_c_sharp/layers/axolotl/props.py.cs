namespace yowsup.layers.axolotl {
    
    public static class props {
        
        public static string PROP_IDENTITY_AUTOTRUST = "org.openwhatsapp.yowsup.prop.axolotl.INDENTITY_AUTOTRUST";
    }
}
