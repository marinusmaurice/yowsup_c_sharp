namespace yowsup.layers.axolotl
{

    using YowProtocolLayer = yowsup.layers.YowProtocolLayer;

    using YowNetworkLayer = yowsup.layers.network.layer.YowNetworkLayer;

    using EventCallback = yowsup.layers.EventCallback;

    using PROP_IDENTITY_AUTOTRUST = yowsup.layers.axolotl.props.PROP_IDENTITY_AUTOTRUST;

    using System.Collections.Generic;

    using System;

    public static class layer_base {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class AxolotlBaseLayer
            : YowProtocolLayer {
            
            public None _manager;
            
            public List<object> skipEncJids;
            
            public AxolotlBaseLayer() {
                this._manager = null;
                this.skipEncJids = new List<object>();
            }
            
            public virtual object send(object node) {
            }
            
            public virtual object receive(object node) {
                this.processIqRegistry(node);
            }
            
            // 
            //         :return:
            //         :rtype: AxolotlManager
            //         
            public object manager {
                get {
                    return this._manager;
                }
            }
            
            [EventCallback(YowNetworkLayer.EVENT_STATE_CONNECTED)]
            public virtual object on_connected(object yowLayerEvent) {
                var profile = this.getProp("profile");
                this._manager = profile.axolotl_manager;
            }
            
            [EventCallback(YowNetworkLayer.EVENT_STATE_DISCONNECTED)]
            public virtual object on_disconnected(object yowLayerEvent) {
                this._manager = null;
            }
            
            public virtual object getKeysFor(object jids, object resultClbk, object errorClbk = null, object reason = null) {
                logger.debug(String.Format("getKeysFor(jids=%s, resultClbk=[omitted], errorClbk=[omitted], reason=%s)", jids, reason));
                Func<object, object, object> onSuccess = (resultNode,getKeysEntity) => {
                    var entity = ResultGetKeysIqProtocolEntity.fromProtocolTreeNode(resultNode);
                    var resultJids = entity.getJids();
                    var successJids = new List<object>();
                    var errorJids = entity.getErrors();
                    foreach (var jid in getKeysEntity.jids) {
                        if (!resultJids.Contains(jid)) {
                            this.skipEncJids.append(jid);
                            continue;
                        }
                        var recipient_id = jid.split("@")[0];
                        var preKeyBundle = entity.getPreKeyBundleFor(jid);
                        try {
                            this.manager.create_session(recipient_id, preKeyBundle, autotrust: this.getProp(PROP_IDENTITY_AUTOTRUST, false));
                            successJids.append(jid);
                        } catch {
                            errorJids[jid] = e;
                            logger.error(e);
                            logger.warning("Ignoring message with untrusted identity");
                        }
                    }
                    resultClbk(successJids, errorJids);
                };
                Func<object, object, object> onError = (errorNode,getKeysEntity) => {
                    if (errorClbk) {
                        errorClbk(errorNode, getKeysEntity);
                    }
                };
                var entity = GetKeysIqProtocolEntity(jids, reason: reason);
                this._sendIq(entity, onSuccess, onError: onError);
            }
        }
    }
}
