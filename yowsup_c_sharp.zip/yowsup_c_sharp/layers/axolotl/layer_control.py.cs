namespace yowsup.layers.axolotl
{

    using AxolotlBaseLayer = layer_base.AxolotlBaseLayer;

    using EventCallback = yowsup.layers.EventCallback;

    using YowNetworkLayer = yowsup.layers.network.layer.YowNetworkLayer;

    using YowAuthenticationProtocolLayer = yowsup.layers.auth.layer_authentication.YowAuthenticationProtocolLayer;

    using OutgoingAckProtocolEntity = yowsup.layers.protocol_acks.protocolentities.OutgoingAckProtocolEntity;

    using HexUtil = axolotl.util.hexutil.HexUtil;

    using Curve = axolotl.ecc.curve.Curve;

    using System.Collections.Generic;

    using System;

    public static class layer_control {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class AxolotlControlLayer
            : AxolotlBaseLayer {
            
            public bool _reboot_connection;
            
            public List<object> _unsent_prekeys;
            
            public AxolotlControlLayer() {
                this._unsent_prekeys = new List<object>();
                this._reboot_connection = false;
            }
            
            public virtual object send(object node) {
                this.toLower(node);
            }
            
            // 
            //         :type protocolTreeNode: ProtocolTreeNode
            //         
            public virtual object receive(object protocolTreeNode) {
                if (!this.processIqRegistry(protocolTreeNode)) {
                    if (protocolTreeNode.tag == "notification" && protocolTreeNode["type"] == "encrypt") {
                        if (protocolTreeNode.getChild("count") != null) {
                            return this.onRequestKeysEncryptNotification(protocolTreeNode);
                        } else if (protocolTreeNode.getChild("identity") != null) {
                            return this.onIdentityChangeEncryptNotification(protocolTreeNode);
                        }
                    }
                    this.toUpper(protocolTreeNode);
                }
            }
            
            public virtual object onIdentityChangeEncryptNotification(object protocoltreenode) {
                var entity = IdentityChangeEncryptNotification.fromProtocolTreeNode(protocoltreenode);
                var ack = OutgoingAckProtocolEntity(protocoltreenode["id"], "notification", protocoltreenode["type"], protocoltreenode["from"]);
                this.toLower(ack.toProtocolTreeNode());
                this.getKeysFor(new List<object> {
                    entity.getFrom(true)
                }, resultClbk: (_,@__) => null, reason: "identity");
            }
            
            public virtual object onRequestKeysEncryptNotification(object protocolTreeNode) {
                var entity = RequestKeysEncryptNotification.fromProtocolTreeNode(protocolTreeNode);
                var ack = OutgoingAckProtocolEntity(protocolTreeNode["id"], "notification", protocolTreeNode["type"], protocolTreeNode["from"]);
                this.toLower(ack.toProtocolTreeNode());
                this.flush_keys(this.manager.generate_signed_prekey(), this.manager.level_prekeys(force: true));
            }
            
            [EventCallback(YowNetworkLayer.EVENT_STATE_CONNECTED)]
            public virtual object on_connected(object yowLayerEvent) {
                super(AxolotlControlLayer, this).on_connected(yowLayerEvent);
                this.manager.level_prekeys();
                this._unsent_prekeys.extend(this.manager.load_unsent_prekeys());
                if (this._unsent_prekeys.Count) {
                    this.setProp(YowAuthenticationProtocolLayer.PROP_PASSIVE, true);
                }
            }
            
            [EventCallback(YowAuthenticationProtocolLayer.EVENT_AUTHED)]
            public virtual object onAuthed(object yowLayerEvent) {
                if (yowLayerEvent.getArg("passive") && this._unsent_prekeys.Count) {
                    logger.debug(String.Format("SHOULD FLUSH KEYS %d NOW!!", this._unsent_prekeys.Count));
                    this.flush_keys(this.manager.load_latest_signed_prekey(generate: true), this._unsent_prekeys[":"], reboot_connection: true);
                    this._unsent_prekeys = new List<object>();
                }
            }
            
            [EventCallback(YowNetworkLayer.EVENT_STATE_DISCONNECTED)]
            public virtual object on_disconnected(object yowLayerEvent) {
                super(AxolotlControlLayer, this).on_disconnected(yowLayerEvent);
                logger.debug(String.Format("Disconnected, reboot_connect? = %s", this._reboot_connection));
                if (this._reboot_connection) {
                    this._reboot_connection = false;
                    //we requested this disconnect in this layer to switch off passive
                    //no need to traverse it to upper layers?
                    this.setProp(YowAuthenticationProtocolLayer.PROP_PASSIVE, false);
                    this.getLayerInterface(YowNetworkLayer).connect();
                }
            }
            
            // 
            //         sends prekeys
            //         :return:
            //         :rtype:
            //         
            public virtual object flush_keys(object signed_prekey, object prekeys, object reboot_connection = false) {
                var preKeysDict = new Dictionary<object, object> {
                };
                foreach (var prekey in prekeys) {
                    var keyPair = prekey.getKeyPair();
                    preKeysDict[this.adjustId(prekey.getId())] = this.adjustArray(keyPair.getPublicKey().serialize()[1]);
                }
                var signedKeyTuple = (this.adjustId(signed_prekey.getId()), this.adjustArray(signed_prekey.getKeyPair().getPublicKey().serialize()[1]), this.adjustArray(signed_prekey.getSignature()));
                var setKeysIq = SetKeysIqProtocolEntity(this.adjustArray(this.manager.identity.getPublicKey().serialize()[1]), signedKeyTuple, preKeysDict, Curve.DJB_TYPE, this.adjustId(this.manager.registration_id));
                var onResult = (_,@__) => this.on_keys_flushed(prekeys, reboot_connection: reboot_connection);
                this._sendIq(setKeysIq, onResult, this.onSentKeysError);
            }
            
            public virtual object on_keys_flushed(object prekeys, object reboot_connection) {
                this.manager.set_prekeys_as_sent(prekeys);
                if (reboot_connection) {
                    this._reboot_connection = true;
                    this.boadcastEvent(YowLayerEvent(YowNetworkLayer.EVENT_STATE_DISCONNECT));
                }
            }
            
            public virtual object onSentKeysError(object errorNode, object keysEntity) {
                throw new Exception("Sent keys were not accepted");
            }
            
            public virtual object adjustArray(object arr) {
                return HexUtil.decodeHex(binascii.hexlify(arr));
            }
            
            public virtual object adjustId(object _id) {
                _id = format(_id, "x");
                var zfiller = _id.Count % 2 == 0 ? _id.Count : _id.Count + 1;
                _id = _id.zfill(zfiller > 6 ? zfiller : 6);
                // if len(_id) % 2:
                //     _id = "0" + _id
                return binascii.unhexlify(_id);
            }
        }
    }
}
