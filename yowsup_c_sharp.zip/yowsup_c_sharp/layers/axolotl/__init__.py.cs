namespace yowsup.layers.axolotl
{

    public static class @__init__ {
    }
}
