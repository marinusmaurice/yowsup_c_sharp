namespace yowsup.layers.axolotl.protocolentities
{

    using YowConstants = yowsup.common.YowConstants;

    using IqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.IqProtocolEntity;

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using System.Diagnostics;

    using System;

    using System.Collections.Generic;

    public static class iq_keys_set {
        
        public class SetKeysIqProtocolEntity
            : IqProtocolEntity {
            
            public int djbType;
            
            public object identityKey;
            
            public object preKeys;
            
            public string registration;
            
            public object signedPreKey;
            
            public SetKeysIqProtocolEntity(
                object identityKey,
                object signedPreKey,
                object preKeys,
                object djbType,
                object registrationId = null)
                : base(_type: "set", to: YowConstants.WHATSAPP_SERVER) {
                this.setProps(identityKey, signedPreKey, preKeys, djbType, registrationId);
            }
            
            public virtual object setProps(
                object identityKey,
                object signedPreKey,
                object preKeys,
                object djbType,
                object registrationId = null) {
                Debug.Assert(object.ReferenceEquals(type(preKeys), dict));
                Debug.Assert("Expected keys to be a dict key_id -> public_key");
                Debug.Assert(object.ReferenceEquals(type(signedPreKey), tuple));
                Debug.Assert("Exception signed pre key to be tuple id,key,signature");
                this.preKeys = preKeys;
                this.identityKey = identityKey;
                this.registration = registrationId || os.urandom(4);
                this.djbType = Convert.ToInt32(djbType);
                this.signedPreKey = signedPreKey;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = IqProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = SetKeysIqProtocolEntity;
                var regVal = node.getChild("registration").data;
                var typeVal = node.getChild("type").data;
                var idVal = node.getChild("identity").data;
                var preKeys = new Dictionary<object, object> {
                };
                foreach (var keyNode in node.getChild("list").getAllChildren()) {
                    preKeys[keyNode.getChild("id").data] = keyNode.getChild("value").data;
                }
                var skeyNode = node.getChild("skey");
                entity.setProps(idVal, (skeyNode.getChild("id").data, skeyNode.getChild("value").data, skeyNode.getChild("signature").data), preKeys, typeVal, regVal);
                return entity;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(SetKeysIqProtocolEntity, this).toProtocolTreeNode();
                var identityNode = ProtocolTreeNode("identity", data: this.identityKey);
                var listNode = ProtocolTreeNode("list");
                var keyNodes = new List<object>();
                foreach (var _tup_1 in this.preKeys.items()) {
                    var keyId = _tup_1.Item1;
                    var pk = _tup_1.Item2;
                    var keyNode = ProtocolTreeNode("key");
                    keyNode.addChild(ProtocolTreeNode("id", data: keyId));
                    keyNode.addChild(ProtocolTreeNode("value", data: pk));
                    keyNodes.append(keyNode);
                }
                listNode.addChildren(keyNodes);
                var regNode = ProtocolTreeNode("registration", data: this.registration);
                var typeNode = ProtocolTreeNode("type", data: @struct.pack("<B", this.djbType));
                var _tup_2 = this.signedPreKey;
                var _id = _tup_2.Item1;
                var val = _tup_2.Item2;
                var signature = _tup_2.Item3;
                var skeyNode = ProtocolTreeNode("skey", children: new List<object> {
                    ProtocolTreeNode("id", data: _id),
                    ProtocolTreeNode("value", data: val),
                    ProtocolTreeNode("signature", data: signature)
                });
                node.addChildren(new List<object> {
                    listNode,
                    identityNode,
                    regNode,
                    typeNode,
                    skeyNode
                });
                return node;
            }
        }
    }
}
