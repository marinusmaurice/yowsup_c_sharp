namespace yowsup.layers.axolotl.protocolentities {
    
    using YowConstants = yowsup.common.YowConstants;
    
    using NotificationProtocolEntity = yowsup.layers.protocol_notifications.protocolentities.NotificationProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    public static class notification_encrypt_identitychange {
        
        // 
        //     <notification t="1419824928" id="2451228097" from="s.whatsapp.net" type="encrypt">
        //         <identity />
        //     </notification>
        //     
        public class IdentityChangeEncryptNotification
            : NotificationProtocolEntity {
            
            public IdentityChangeEncryptNotification(object timestamp, object _id = null, object notify = null, object offline = null)
                : base(_id, YowConstants.WHATSAPP_SERVER, timestamp, notify, offline) {
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(IdentityChangeEncryptNotification, this).toProtocolTreeNode();
                node.addChild(ProtocolTreeNode("identity"));
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = NotificationProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = IdentityChangeEncryptNotification;
                return entity;
            }
        }
    }
}
