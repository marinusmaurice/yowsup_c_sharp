namespace yowsup.layers.axolotl.protocolentities
{

    using ProtocolEntity = yowsup.structs.ProtocolEntity;

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using System;

    using System.Diagnostics;

    using System.Collections.Generic;

    public static class enc {
        
        public class EncProtocolEntity
            : ProtocolEntity {
            
            public object data;
            
            public object jid;
            
            public object mediaType;
            
            public Func<object> type;
            
            public string TYPE_MSG;
            
            public string TYPE_PKMSG;
            
            public string TYPE_SKMSG;
            
            public Tuple<string, string, string> TYPES;
            
            public int version;
            
            public string TYPE_PKMSG = "pkmsg";
            
            public string TYPE_MSG = "msg";
            
            public string TYPE_SKMSG = "skmsg";
            
            public Tuple<string, string, string> TYPES = (TYPE_PKMSG, TYPE_MSG, TYPE_SKMSG);
            
            public EncProtocolEntity(
                object type,
                object version,
                object data,
                object mediaType = null,
                object jid = null) {
                Debug.Assert(this.@__class__.TYPES.Contains(type));
                Debug.Assert(String.Format("Unknown message enc type %s", type));
                super(EncProtocolEntity, this).@__init__("enc");
                this.type = type;
                this.version = Convert.ToInt32(version);
                this.data = data;
                this.mediaType = mediaType;
                this.jid = jid;
            }
            
            public virtual object getType() {
                return this.type;
            }
            
            public virtual object getVersion() {
                return this.version;
            }
            
            public virtual object getData() {
                return this.data;
            }
            
            public virtual object getMediaType() {
                return this.mediaType;
            }
            
            public virtual object getJid() {
                return this.jid;
            }
            
            public virtual object toProtocolTreeNode() {
                var attribs = new Dictionary<object, object> {
                    {
                        "type",
                        this.type},
                    {
                        "v",
                        this.version.ToString()}};
                if (this.mediaType) {
                    attribs["mediatype"] = this.mediaType;
                }
                var encNode = ProtocolTreeNode("enc", attribs, data: this.data);
                if (this.jid) {
                    return ProtocolTreeNode("to", new Dictionary<object, object> {
                        {
                            "jid",
                            this.jid}}, new List<object> {
                        encNode
                    });
                }
                return encNode;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                return new EncProtocolEntity(node["type"], node["v"], node.data, node["mediatype"]);
            }
        }
    }
}
