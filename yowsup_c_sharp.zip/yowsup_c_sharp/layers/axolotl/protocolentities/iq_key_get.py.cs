namespace yowsup.layers.axolotl.protocolentities {
    
    using YowConstants = yowsup.common.YowConstants;
    
    using IqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.IqProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using System.Diagnostics;
    
    using System;
    
    using System.Collections.Generic;
    
    public static class iq_key_get {
        
        public class GetKeysIqProtocolEntity
            : IqProtocolEntity {
            
            public object _jids;
            
            public object _reason;
            
            public GetKeysIqProtocolEntity(object jids, object reason = null)
                : base(_type: "get", to: YowConstants.WHATSAPP_SERVER) {
                this.jids = jids;
                this.reason = reason;
            }
            
            // type: (str) -> None
            public object reason {
                get {
                    // type: () -> str
                    return this._reason;
                }
                set {
                    this._reason = value;
                }
            }
            
            // type: (list[str]) -> None
            public object jids {
                get {
                    // type: () -> list[str]
                    return this._jids;
                }
                set {
                    Debug.Assert(object.ReferenceEquals(type(value), list));
                    Debug.Assert(String.Format("expected list of jids, got %s", type(value)));
                    this._jids = value;
                }
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(GetKeysIqProtocolEntity, this).toProtocolTreeNode();
                var keyNode = ProtocolTreeNode("key");
                foreach (var jid in this.jids) {
                    var attrs = new Dictionary<object, object> {
                        {
                            "jid",
                            jid}};
                    if (this.reason != null) {
                        attrs["reason"] = this.reason;
                    }
                    var userNode = ProtocolTreeNode("user", attrs);
                    keyNode.addChild(userNode);
                }
                node.addChild(keyNode);
                return node;
            }
        }
    }
}
