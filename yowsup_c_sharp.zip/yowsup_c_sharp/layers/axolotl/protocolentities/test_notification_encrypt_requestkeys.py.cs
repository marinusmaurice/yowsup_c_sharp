namespace yowsup.layers.axolotl.protocolentities {
    
    using NotificationProtocolEntityTest = yowsup.layers.protocol_notifications.protocolentities.test_notification.NotificationProtocolEntityTest;
    
    using RequestKeysEncryptNotification = yowsup.layers.axolotl.protocolentities.RequestKeysEncryptNotification;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using System.Collections.Generic;
    
    public static class test_notification_encrypt_requestkeys {
        
        public class TestRequestKeysEncryptNotification
            : NotificationProtocolEntityTest {
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(TestRequestKeysEncryptNotification, this).setUp();
                this.ProtocolEntity = RequestKeysEncryptNotification;
                this.node.addChild(ProtocolTreeNode("count", new Dictionary<object, object> {
                    {
                        "value",
                        "9"}}));
            }
        }
    }
}
