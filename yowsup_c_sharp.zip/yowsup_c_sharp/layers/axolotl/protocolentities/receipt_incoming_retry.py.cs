namespace yowsup.layers.axolotl.protocolentities {
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using IncomingReceiptProtocolEntity = yowsup.layers.protocol_receipts.protocolentities.IncomingReceiptProtocolEntity;
    
    using ResultGetKeysIqProtocolEntity = yowsup.layers.axolotl.protocolentities.iq_keys_get_result.ResultGetKeysIqProtocolEntity;
    
    using System;
    
    using System.Collections.Generic;
    
    public static class receipt_incoming_retry {
        
        // 
        //     <receipt type="retry" from="xxxxxxxxxxx@s.whatsapp.net" participant="" id="1415389947-12" t="1432833777">
        //         <retry count="1" t="1432833266" id="1415389947-12" v="1">
        //         </retry>
        //         <registration>
        //             HEX:xxxxxxxxx
        //         </registration>
        //     </receipt>
        //     
        public class RetryIncomingReceiptProtocolEntity
            : IncomingReceiptProtocolEntity {
            
            public int count;
            
            public object remoteRegistrationId;
            
            public int retryTimestamp;
            
            public int v;
            
            public RetryIncomingReceiptProtocolEntity(
                object _id,
                object jid,
                object remoteRegistrationId,
                object receiptTimestamp,
                object retryTimestamp,
                object v = 1,
                object count = 1,
                object participant = null,
                object offline = null)
                : base(jid, receiptTimestamp, offline: offline, type: "retry", participant: participant) {
                this.setRetryData(remoteRegistrationId, v, count, retryTimestamp);
            }
            
            public virtual object setRetryData(object remoteRegistrationId, object v, object count, object retryTimestamp) {
                this.remoteRegistrationId = remoteRegistrationId;
                this.v = Convert.ToInt32(v);
                this.count = Convert.ToInt32(count);
                this.retryTimestamp = Convert.ToInt32(retryTimestamp);
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(RetryIncomingReceiptProtocolEntity, this).toProtocolTreeNode();
                var retry = ProtocolTreeNode("retry", new Dictionary<object, object> {
                    {
                        "count",
                        this.count.ToString()},
                    {
                        "id",
                        this.getId()},
                    {
                        "v",
                        this.v.ToString()},
                    {
                        "t",
                        this.retryTimestamp.ToString()}});
                node.addChild(retry);
                var registration = ProtocolTreeNode("registration", data: ResultGetKeysIqProtocolEntity._intToBytes(this.remoteRegistrationId));
                node.addChild(registration);
                return node;
            }
            
            public virtual object getRetryCount() {
                return this.count;
            }
            
            public virtual object getRetryJid() {
                return this.getParticipant() || this.getFrom();
            }
            
            public override object ToString() {
                var @out = super(RetryIncomingReceiptProtocolEntity, this).@__str__();
                return @out;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = IncomingReceiptProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = RetryIncomingReceiptProtocolEntity;
                var retryNode = node.getChild("retry");
                entity.setRetryData(ResultGetKeysIqProtocolEntity._bytesToInt(node.getChild("registration").data), retryNode["v"], retryNode["count"], retryNode["t"]);
                return entity;
            }
        }
    }
}
