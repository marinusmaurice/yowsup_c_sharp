namespace yowsup.layers.axolotl.protocolentities {
    
    using YowConstants = yowsup.common.YowConstants;
    
    using NotificationProtocolEntity = yowsup.layers.protocol_notifications.protocolentities.NotificationProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using System.Collections.Generic;
    
    public static class notification_encrypt_requestkeys {
        
        // 
        //     <notification t="1419824928" id="2451228097" from="s.whatsapp.net" type="encrypt">
        //         <count value="9">
        //         </count>
        //     </notification>
        //     
        public class RequestKeysEncryptNotification
            : NotificationProtocolEntity {
            
            public object _count;
            
            public RequestKeysEncryptNotification(
                object count,
                object timestamp,
                object _id = null,
                object notify = null,
                object offline = null)
                : base(_id, YowConstants.WHATSAPP_SERVER, timestamp, notify, offline) {
                this._count = count;
            }
            
            public object count {
                get {
                    return this._count;
                }
                set {
                    this._count = value;
                }
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(RequestKeysEncryptNotification, this).toProtocolTreeNode();
                var count_node = ProtocolTreeNode("count", new Dictionary<object, object> {
                    {
                        "value",
                        this.count.ToString()}});
                node.addChild(count_node);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = NotificationProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = RequestKeysEncryptNotification;
                entity.count = node.getChild("count")["value"];
                return entity;
            }
        }
    }
}
