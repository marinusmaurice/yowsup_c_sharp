namespace yowsup.layers.axolotl.protocolentities
{

    public static class @__init__ {
    }
}
