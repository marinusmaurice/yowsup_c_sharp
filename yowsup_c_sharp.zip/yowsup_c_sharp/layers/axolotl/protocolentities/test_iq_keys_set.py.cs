namespace yowsup.layers.axolotl.protocolentities
{

    using IqProtocolEntityTest = yowsup.layers.protocol_iq.protocolentities.test_iq.IqProtocolEntityTest;

    public static class test_iq_keys_set {
        
        public class SetKeysIqProtocolEntityTest
            : IqProtocolEntityTest {
            
            public virtual object setUp() {
                super(SetKeysIqProtocolEntityTest, this).setUp();
                // self.ProtocolEntity = SetKeysIqProtocolEntity
                //
                // regNode = ProtocolTreeNode("registration", data = "abcd")
                // idNode = ProtocolTreeNode("identity", data = "efgh")
                // typeNode = ProtocolTreeNode("type", data = "ijkl")
                // listNode = ProtocolTreeNode("list")
                // for i in range(0, 2):
                //     keyNode = ProtocolTreeNode("key", children=[
                //         ProtocolTreeNode("id", data = "id_%s" % i),
                //         ProtocolTreeNode("value", data = "val_%s" % i)
                //     ])
                //     listNode.addChild(keyNode)
                //
                // self.node.addChildren([regNode, idNode, typeNode, listNode])
            }
        }
    }
}
