namespace yowsup.layers.axolotl.protocolentities
{

    using ResultIqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.ResultIqProtocolEntity;

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using PreKeyBundle = axolotl.state.prekeybundle.PreKeyBundle;

    using IdentityKey = axolotl.identitykey.IdentityKey;

    using Curve = axolotl.ecc.curve.Curve;

    using DjbECPublicKey = axolotl.ecc.djbec.DjbECPublicKey;

    using System.Collections.Generic;

    using System;

    using System.Diagnostics;

    using System.Linq;

    public static class iq_keys_get_result {
        
        // 
        //     <iq type="result" from="s.whatsapp.net" id="3">
        //     <list>
        //     <user jid="79049347231@s.whatsapp.net">
        //     <registration>
        //         HEX:7a9cec4b</registration>
        //     <type>
        // 
        //     HEX:05</type>
        //     <identity>
        //     HEX:eeb668c8d062c99b43560c811acfe6e492798b496767eb060d99e011d3862369</identity>
        //     <skey>
        //     <id>
        // 
        //     HEX:000000</id>
        //     <value>
        //     HEX:a1b5216ce4678143fb20aaaa2711a8c2b647230164b79414f0550b4e611ccd6c</value>
        //     <signature>
        //     HEX:94c231327fcd664b34603838b5e9ba926718d71c206e92b2b400f5cf4ae7bf17d83557bf328c1be6d51efdbd731a26d000adb8f38f140b1ea2a5fd3df2688085</signature>
        //         </skey>
        //     <key>
        //         <id>
        //         HEX:36b545</id>
        //     <value>
        //     HEX:c20826f622bec24b349ced38f1854bdec89ba098ef4c06b2402800d33e9aff61</value>
        //     </key>
        //     </user>
        //     </list>
        //     </iq>
        //     
        public class ResultGetKeysIqProtocolEntity
            : ResultIqProtocolEntity {
            
            public Dictionary<object, object> _errors;
            
            public Dictionary<object, object> preKeyBundleMap;
            
            public ResultGetKeysIqProtocolEntity(object _id, object preKeyBundleMap = null)
                : base(_id: _id) {
                this.setPreKeyBundleMap(preKeyBundleMap);
                this._errors = new Dictionary<object, object> {
                };
            }
            
            public virtual object getJids() {
                return this.preKeyBundleMap.keys();
            }
            
            public virtual object getErrors() {
                return this._errors.copy();
            }
            
            public virtual object setErrorFor(object jid, object exception) {
                this._errors[jid] = exception;
            }
            
            public virtual object setPreKeyBundleMap(object preKeyBundleMap = null) {
                this.preKeyBundleMap = preKeyBundleMap || new Dictionary<object, object> {
                };
            }
            
            public virtual object setPreKeyBundleFor(object jid, object preKeyBundle) {
                this.preKeyBundleMap[jid] = preKeyBundle;
            }
            
            public virtual object getPreKeyBundleFor(object jid) {
                if (this.preKeyBundleMap.Contains(jid)) {
                    return this.preKeyBundleMap[jid];
                }
            }
            
            [staticmethod]
            public static object _intToBytes(object val) {
                return binascii.unhexlify(format(val, "x").zfill(8).encode());
            }
            
            [staticmethod]
            public static object _bytesToInt(object val) {
                object valEnc;
                if (sys.version_info >= (3, 0)) {
                    valEnc = object.ReferenceEquals(type(val), str) ? val.encode("latin-1") : val;
                } else {
                    valEnc = val;
                }
                return Convert.ToInt32(binascii.hexlify(valEnc), 16);
            }
            
            [staticmethod]
            public static object encStr(object @string) {
                if (sys.version_info >= (3, 0) && object.ReferenceEquals(type(@string), str)) {
                    return @string.encode("latin-1");
                }
                return @string;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = new ResultGetKeysIqProtocolEntity(node["id"]);
                var userNodes = node.getChild("list").getAllChildren();
                foreach (var userNode in userNodes) {
                    var missing_params = new List<object>();
                    var preKeyNode = userNode.getChild("key");
                    var signedPreKeyNode = userNode.getChild("skey");
                    var registrationNode = userNode.getChild("registration");
                    var identityNode = userNode.getChild("identity");
                    if (preKeyNode == null) {
                        missing_params.append(MissingParametersException.PARAM_KEY);
                    }
                    if (signedPreKeyNode == null) {
                        missing_params.append(MissingParametersException.PARAM_SKEY);
                    }
                    if (registrationNode == null) {
                        missing_params.append(MissingParametersException.PARAM_REGISTRATION);
                    }
                    if (identityNode == null) {
                        missing_params.append(MissingParametersException.PARAM_IDENTITY);
                    }
                    if (missing_params.Count) {
                        entity.setErrorFor(userNode["jid"], new MissingParametersException(userNode["jid"], missing_params));
                    } else {
                        var registrationId = ResultGetKeysIqProtocolEntity._bytesToInt(registrationNode.getData());
                        var identityKey = IdentityKey(DjbECPublicKey(ResultGetKeysIqProtocolEntity.encStr(identityNode.getData())));
                        var preKeyId = ResultGetKeysIqProtocolEntity._bytesToInt(preKeyNode.getChild("id").getData());
                        var preKeyPublic = DjbECPublicKey(ResultGetKeysIqProtocolEntity.encStr(preKeyNode.getChild("value").getData()));
                        var signedPreKeyId = ResultGetKeysIqProtocolEntity._bytesToInt(signedPreKeyNode.getChild("id").getData());
                        var signedPreKeySig = ResultGetKeysIqProtocolEntity.encStr(signedPreKeyNode.getChild("signature").getData());
                        var signedPreKeyPub = DjbECPublicKey(ResultGetKeysIqProtocolEntity.encStr(signedPreKeyNode.getChild("value").getData()));
                        var preKeyBundle = PreKeyBundle(registrationId, 1, preKeyId, preKeyPublic, signedPreKeyId, signedPreKeyPub, signedPreKeySig, identityKey);
                        entity.setPreKeyBundleFor(userNode["jid"], preKeyBundle);
                    }
                }
                return entity;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(ResultGetKeysIqProtocolEntity, this).toProtocolTreeNode();
                var listNode = ProtocolTreeNode("list");
                node.addChild(listNode);
                foreach (var _tup_1 in this.preKeyBundleMap.items()) {
                    var jid = _tup_1.Item1;
                    var preKeyBundle = _tup_1.Item2;
                    var userNode = ProtocolTreeNode("user", new Dictionary<object, object> {
                        {
                            "jid",
                            jid}});
                    var registrationNode = ProtocolTreeNode("registration", data: this.@__class__._intToBytes(preKeyBundle.getRegistrationId()));
                    var typeNode = ProtocolTreeNode("type", data: this.@__class__._intToBytes(Curve.DJB_TYPE));
                    var identityNode = ProtocolTreeNode("identity", data: preKeyBundle.getIdentityKey().getPublicKey().getPublicKey());
                    var skeyNode = ProtocolTreeNode("skey");
                    var skeyNode_idNode = ProtocolTreeNode("id", data: this.@__class__._intToBytes(preKeyBundle.getSignedPreKeyId()));
                    var skeyNode_valueNode = ProtocolTreeNode("value", data: preKeyBundle.getSignedPreKey().getPublicKey());
                    var skeyNode_signatureNode = ProtocolTreeNode("signature", data: preKeyBundle.getSignedPreKeySignature());
                    skeyNode.addChildren(new List<object> {
                        skeyNode_idNode,
                        skeyNode_valueNode,
                        skeyNode_signatureNode
                    });
                    var preKeyNode = ProtocolTreeNode("key");
                    var preKeyNode_idNode = ProtocolTreeNode("id", data: this.@__class__._intToBytes(preKeyBundle.getPreKeyId()));
                    var preKeyNode_valueNode = ProtocolTreeNode("value", data: preKeyBundle.getPreKey().getPublicKey());
                    preKeyNode.addChildren(new List<object> {
                        preKeyNode_idNode,
                        preKeyNode_valueNode
                    });
                    userNode.addChildren(new List<object> {
                        registrationNode,
                        typeNode,
                        identityNode,
                        skeyNode,
                        preKeyNode
                    });
                    listNode.addChild(userNode);
                }
                return node;
            }
        }
        
        public class MissingParametersException
            : Exception {
            
            public Tuple<string, string, string, string> @__PARAMS;
            
            public object _jid;
            
            public object _parameters;
            
            public string PARAM_IDENTITY;
            
            public string PARAM_KEY;
            
            public string PARAM_REGISTRATION;
            
            public string PARAM_SKEY;
            
            public string PARAM_KEY = "key";
            
            public string PARAM_IDENTITY = "identity";
            
            public string PARAM_SKEY = "skey";
            
            public string PARAM_REGISTRATION = "registration";
            
            public Tuple<string, string, string, string> @__PARAMS = (PARAM_KEY, PARAM_IDENTITY, PARAM_SKEY, PARAM_REGISTRATION);
            
            public MissingParametersException(object jid, object parameters) {
                // type: (str, list | str) -> None
                this._jid = jid;
                Debug.Assert((list, str).Contains(type(parameters)));
                if (object.ReferenceEquals(type(parameters), str)) {
                    parameters = parameters.ToList();
                }
                Debug.Assert(parameters.Count > 0);
                foreach (var p in parameters) {
                    Debug.Assert(this.@__PARAMS.Contains(p));
                    Debug.Assert(String.Format("%s is unrecognized param", p));
                }
                this._parameters = parameters;
            }
            
            public object jid {
                get {
                    return this._jid;
                }
            }
            
            public object parameters {
                get {
                    return this._parameters;
                }
            }
        }
    }
}
