namespace yowsup.layers.axolotl.protocolentities {
    
    using MessageProtocolEntity = yowsup.layers.protocol_messages.protocolentities.MessageProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using EncProtocolEntity = yowsup.layers.axolotl.protocolentities.enc.EncProtocolEntity;
    
    using System.Diagnostics;
    
    using System.Linq;
    
    public static class message_encrypted {
        
        // 
        //     <message retry="1" from="49xxxxxxxx@s.whatsapp.net" t="1418906418" offline="1" type="text" id="1418906377-1" notify="Tarek Galal">
        // <enc type="{{type}}" mediatype="image|audio|location|document|contact" v="{{1 || 2}}">
        // HEX:33089eb3c90312210510e0196be72fe65913c6a84e75a54f40a3ee290574d6a23f408df990e718da761a210521f1a3f3d5cb87fde19fadf618d3001b64941715efd3e0f36bba48c23b08c82f2242330a21059b0ce2c4720ec79719ba862ee3cda6d6332746d05689af13aabf43ea1c8d747f100018002210d31cd6ebea79e441c4935f72398c772e2ee21447eb675cfa28b99de8d2013000</enc>
        // 
        // </message>
        //     
        public class EncryptedMessageProtocolEntity
            : MessageProtocolEntity {
            
            public object encEntities;
            
            public EncryptedMessageProtocolEntity(object encEntities, object _type, object messageAttributes)
                : base(messageAttributes) {
                this.setEncEntities(encEntities);
            }
            
            public virtual object setEncEntities(object encEntities = null) {
                Debug.Assert(object.ReferenceEquals(type(encEntities), list) && encEntities.Count);
                Debug.Assert("Must have at least a list of minumum 1 enc entity");
                this.encEntities = encEntities;
            }
            
            public virtual object getEnc(object encType) {
                foreach (var enc in this.encEntities) {
                    if (enc.type == encType) {
                        return enc;
                    }
                }
            }
            
            public virtual object getEncEntities() {
                return this.encEntities;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(EncryptedMessageProtocolEntity, this).toProtocolTreeNode();
                var participantsNode = ProtocolTreeNode("participants");
                foreach (var enc in this.encEntities) {
                    var encNode = enc.toProtocolTreeNode();
                    if (encNode.tag == "to") {
                        participantsNode.addChild(encNode);
                    } else {
                        node.addChild(encNode);
                    }
                }
                if (participantsNode.getAllChildren().Count) {
                    node.addChild(participantsNode);
                }
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = MessageProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = EncryptedMessageProtocolEntity;
                entity.setEncEntities((from encNode in node.getAllChildren("enc")
                    select EncProtocolEntity.fromProtocolTreeNode(encNode)).ToList());
                return entity;
            }
        }
    }
}
