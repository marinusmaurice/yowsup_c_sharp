namespace yowsup.layers.axolotl.protocolentities {
    
    using YowConstants = yowsup.common.YowConstants;
    
    using ResultIqProtocolEntityTest = yowsup.layers.protocol_iq.protocolentities.test_iq_result.ResultIqProtocolEntityTest;
    
    using ResultGetKeysIqProtocolEntity = yowsup.layers.axolotl.protocolentities.ResultGetKeysIqProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using KeyHelper = axolotl.util.keyhelper.KeyHelper;
    
    using Curve = axolotl.ecc.curve.Curve;
    
    using System;
    
    using System.Linq;
    
    using System.Collections.Generic;
    
    public static class test_iq_keys_get_result {
        
        public class ResultGetKeysIqProtocolEntityTest
            : ResultIqProtocolEntityTest {
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(ResultGetKeysIqProtocolEntityTest, this).setUp();
                this.ProtocolEntity = ResultGetKeysIqProtocolEntity;
                var listNode = ProtocolTreeNode("list");
                this.node.addChild(listNode);
                this.node["from"] = "s.whatsapp.net";
                this.node.attributes.Remove("xmlns");
                foreach (var i in Enumerable.Range(0, 1 - 0)) {
                    var userNode = ProtocolTreeNode("user", new Dictionary<object, object> {
                        {
                            "jid",
                            String.Format("user_%s@%s", i, YowConstants.WHATSAPP_SERVER)}});
                    listNode.addChild(userNode);
                    var registrationNode = ProtocolTreeNode("registration", data: ResultGetKeysIqProtocolEntity._intToBytes(KeyHelper.generateRegistrationId()));
                    var typeNode = ProtocolTreeNode("type", data: ResultGetKeysIqProtocolEntity._intToBytes(Curve.DJB_TYPE));
                    var identityKeyPair = KeyHelper.generateIdentityKeyPair();
                    var identityNode = ProtocolTreeNode("identity", data: identityKeyPair.getPublicKey().getPublicKey().getPublicKey());
                    var signedPreKey = KeyHelper.generateSignedPreKey(identityKeyPair, i);
                    var signedPreKeyNode = ProtocolTreeNode("skey");
                    var signedPreKeyNode_idNode = ProtocolTreeNode("id", data: ResultGetKeysIqProtocolEntity._intToBytes(signedPreKey.getId()));
                    var signedPreKeyNode_valueNode = ProtocolTreeNode("value", data: signedPreKey.getKeyPair().getPublicKey().getPublicKey());
                    var signedPreKeyNode_sigNode = ProtocolTreeNode("signature", data: signedPreKey.getSignature());
                    signedPreKeyNode.addChildren(new List<object> {
                        signedPreKeyNode_idNode,
                        signedPreKeyNode_valueNode,
                        signedPreKeyNode_sigNode
                    });
                    var preKey = KeyHelper.generatePreKeys(i * 10, 1)[0];
                    var preKeyNode = ProtocolTreeNode("key");
                    var preKeyNode_idNode = ProtocolTreeNode("id", data: ResultGetKeysIqProtocolEntity._intToBytes(preKey.getId()));
                    var preKeyNode_valNode = ProtocolTreeNode("value", data: preKey.getKeyPair().getPublicKey().getPublicKey());
                    preKeyNode.addChildren(new List<object> {
                        preKeyNode_idNode,
                        preKeyNode_valNode
                    });
                    userNode.addChildren(new List<object> {
                        registrationNode,
                        typeNode,
                        identityNode,
                        signedPreKeyNode,
                        preKeyNode
                    });
                }
            }
        }
    }
}
