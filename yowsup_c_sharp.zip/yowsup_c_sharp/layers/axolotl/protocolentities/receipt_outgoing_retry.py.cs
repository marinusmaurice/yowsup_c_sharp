namespace yowsup.layers.axolotl.protocolentities {
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using OutgoingReceiptProtocolEntity = yowsup.layers.protocol_receipts.protocolentities.OutgoingReceiptProtocolEntity;
    
    using ResultGetKeysIqProtocolEntity = yowsup.layers.axolotl.protocolentities.iq_keys_get_result.ResultGetKeysIqProtocolEntity;
    
    using System.Collections.Generic;
    
    public static class receipt_outgoing_retry {
        
        // 
        //     <receipt type="retry" to="xxxxxxxxxxx@s.whatsapp.net" participant="" id="1415389947-12" t="1432833777">
        //         <retry count="1" t="1432833266" id="1415389947-12" v="1">
        //         </retry>
        //         <registration>
        //             HEX:xxxxxxxxx
        //         </registration>
        //     </receipt>
        //     
        public class RetryOutgoingReceiptProtocolEntity
            : OutgoingReceiptProtocolEntity {
            
            public object _count;
            
            public object _local_registration_id;
            
            public object _retry_timestamp;
            
            public object _v;
            
            public RetryOutgoingReceiptProtocolEntity(
                object _id,
                object jid,
                object local_registration_id,
                object retry_timestamp,
                object v = 1,
                object count = 1,
                object participant = null)
                : base(jid, participant: participant) {
                @"
            Note to self: Android clients won't retry sending if the retry node didn't contain the message timestamp
        ";
                this.local_registration_id = local_registration_id;
                this.v = v;
                this.retry_timestamp = retry_timestamp;
                this.count = count;
            }
            
            public object local_registration_id {
                get {
                    return this._local_registration_id;
                }
                set {
                    this._local_registration_id = value;
                }
            }
            
            public object v {
                get {
                    return this._v;
                }
                set {
                    this._v = value;
                }
            }
            
            public object retry_timestamp {
                get {
                    return this._retry_timestamp;
                }
                set {
                    this._retry_timestamp = value;
                }
            }
            
            public object count {
                get {
                    return this._count;
                }
                set {
                    this._count = value;
                }
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(RetryOutgoingReceiptProtocolEntity, this).toProtocolTreeNode();
                node.setAttribute("type", "retry");
                var retry_attrs = new Dictionary<object, object> {
                    {
                        "count",
                        this.count.ToString()},
                    {
                        "id",
                        this.getId()},
                    {
                        "v",
                        this.v.ToString()},
                    {
                        "t",
                        this.retry_timestamp.ToString()}};
                var retry = ProtocolTreeNode("retry", retry_attrs);
                node.addChild(retry);
                var registration = ProtocolTreeNode("registration", data: ResultGetKeysIqProtocolEntity._intToBytes(this.local_registration_id));
                node.addChild(registration);
                return node;
            }
            
            public override object ToString() {
                var @out = super(RetryOutgoingReceiptProtocolEntity, this).@__str__();
                return @out;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = OutgoingReceiptProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = RetryOutgoingReceiptProtocolEntity;
                var retry_node = node.getChild("retry");
                entity.setRetryData(ResultGetKeysIqProtocolEntity._bytesToInt(node.getChild("registration").data), retry_node["v"], retry_node["count"], retry_node["t"]);
                return entity;
            }
            
            [staticmethod]
            public static object fromMessageNode(object message_node, object local_registration_id) {
                return new RetryOutgoingReceiptProtocolEntity(message_node.getAttributeValue("id"), message_node.getAttributeValue("from"), local_registration_id, message_node.getAttributeValue("t"), participant: message_node.getAttributeValue("participant"));
            }
        }
    }
}
