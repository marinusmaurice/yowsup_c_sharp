namespace yowsup.layers.protocol_ib.protocolentities
{

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using IbProtocolEntity = ib.IbProtocolEntity;

    using System;

    using System.Collections.Generic;

    public static class offline_ib {
        
        // 
        //     <ib from="s.whatsapp.net">
        //         <offline count="{{X}}"></offline>
        //     </ib>
        //     
        public class OfflineIbProtocolEntity
            : IbProtocolEntity {
            
            public int count;
            
            public OfflineIbProtocolEntity(object count) {
                this.setProps(count);
            }
            
            public virtual object setProps(object count) {
                this.count = Convert.ToInt32(count);
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(OfflineIbProtocolEntity, this).toProtocolTreeNode();
                var offlineChild = ProtocolTreeNode("offline", new Dictionary<object, object> {
                    {
                        "count",
                        this.count.ToString()}});
                node.addChild(offlineChild);
                return node;
            }
            
            public override object ToString() {
                var @out = super(OfflineIbProtocolEntity, this).@__str__();
                @out += String.Format("Offline count: %s\n", this.count);
                return @out;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = IbProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = OfflineIbProtocolEntity;
                entity.setProps(node.getChild("offline")["count"]);
                return entity;
            }
        }
    }
}
