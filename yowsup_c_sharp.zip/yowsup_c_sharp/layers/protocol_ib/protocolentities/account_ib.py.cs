namespace yowsup.layers.protocol_ib.protocolentities
{

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using IbProtocolEntity = ib.IbProtocolEntity;

    using System;

    using System.Collections.Generic;

    public static class account_ib {
        
        // 
        //     <ib from="s.whatsapp.net">
        //         <account status="active | ?" kind="paid" creation="timestamp" expiration="timestamp"></account>
        //     </ib>
        //     
        public class AccountIbProtocolEntity
            : IbProtocolEntity {
            
            public int creation;
            
            public int expiration;
            
            public object kind;
            
            public string KIND_PAD;
            
            public object status;
            
            public string STATUS_ACTIVE;
            
            public string STATUS_ACTIVE = "active";
            
            public string KIND_PAD = "paid";
            
            public AccountIbProtocolEntity(object status, object kind, object creation, object expiration) {
                this.setProps(status, kind, creation, expiration);
            }
            
            public virtual object setProps(object status, object kind, object creation, object expiration) {
                this.status = status;
                this.creation = Convert.ToInt32(creation);
                this.kind = kind;
                this.expiration = Convert.ToInt32(expiration);
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(AccountIbProtocolEntity, this).toProtocolTreeNode();
                var accountChild = ProtocolTreeNode("account", new Dictionary<object, object> {
                    {
                        "status",
                        this.status},
                    {
                        "kind",
                        this.kind},
                    {
                        "creation",
                        Convert.ToInt32(this.creation)},
                    {
                        "expiration",
                        Convert.ToInt32(this.expiration)}});
                node.addChild(accountChild);
                return node;
            }
            
            public override object ToString() {
                var @out = super(AccountIbProtocolEntity, this).@__str__();
                @out += String.Format("Status: %s\n", this.status);
                @out += String.Format("Kind: %s\n", this.kind);
                @out += String.Format("Creation: %s\n", this.creation);
                @out += String.Format("Expiration: %s\n", this.expiration);
                return @out;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = IbProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = AccountIbProtocolEntity;
                var accountNode = node.getChild("account");
                entity.setProps(accountNode["status"], accountNode["kind"], accountNode["creation"], accountNode["expiration"]);
            }
        }
    }
}
