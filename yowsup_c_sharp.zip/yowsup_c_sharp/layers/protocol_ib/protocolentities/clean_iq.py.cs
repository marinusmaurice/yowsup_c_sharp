namespace yowsup.layers.protocol_ib.protocolentities
{

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using IqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.IqProtocolEntity;

    using System;

    using System.Collections.Generic;

    public static class clean_iq {
        
        // 
        //     <iq id="" type="set" to="self.domain" xmlns="urn:xmpp:whatsapp:dirty">
        //         <clean type="{{dirty_type}}"></clean>
        //     </iq>
        //     
        public class CleanIqProtocolEntity
            : IqProtocolEntity {
            
            public object cleanType;
            
            public CleanIqProtocolEntity(object cleanType, object to, object _id = null)
                : base(_id: _id, _type: "set", to: to) {
                this.setProps(cleanType);
            }
            
            public virtual object setProps(object cleanType) {
                this.cleanType = cleanType;
            }
            
            public override object ToString() {
                var @out = super(CleanIqProtocolEntity, this).@__str__();
                @out += String.Format("Clean Type: %s\n", this.cleanType);
                return @out;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(CleanIqProtocolEntity, this).toProtocolTreeNode();
                var cleanNode = ProtocolTreeNode("clean", new Dictionary<object, object> {
                    {
                        "type",
                        this.cleanType}});
                node.addChild(cleanNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = IqProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = CleanIqProtocolEntity;
                entity.setProps(node.getChild("clean").getAttributeValue("type"));
                return entity;
            }
        }
    }
}
