namespace yowsup.layers.protocol_ib.protocolentities
{

    using ProtocolEntity = yowsup.structs.ProtocolEntity;

    using System.Collections.Generic;

    public static class ib {
        
        // 
        //     <ib></ib>
        //     
        public class IbProtocolEntity
            : ProtocolEntity {
            
            public IbProtocolEntity() {
            }
            
            public virtual object toProtocolTreeNode() {
                return this._createProtocolTreeNode(new Dictionary<object, object> {
                }, null, null);
            }
            
            public override object ToString() {
                var @out = "Ib:\n";
                return @out;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                return new IbProtocolEntity();
            }
        }
    }
}
