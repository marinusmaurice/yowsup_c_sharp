namespace yowsup.layers.protocol_ib.protocolentities {
    
    using IbProtocolEntityTest = yowsup.layers.protocol_ib.protocolentities.test_ib.IbProtocolEntityTest;
    
    using DirtyIbProtocolEntity = yowsup.layers.protocol_ib.protocolentities.dirty_ib.DirtyIbProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    public static class test_dirty_ib {
        
        public class DirtyIbProtocolEntityTest
            : IbProtocolEntityTest {
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(DirtyIbProtocolEntityTest, this).setUp();
                this.ProtocolEntity = DirtyIbProtocolEntity;
                var dirtyNode = ProtocolTreeNode("dirty");
                dirtyNode["timestamp"] = "123456";
                dirtyNode["type"] = "groups";
                this.node.addChild(dirtyNode);
            }
        }
    }
}
