namespace yowsup.layers.protocol_ib.protocolentities
{

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using IbProtocolEntity = ib.IbProtocolEntity;

    using System;

    public static class dirty_ib {
        
        // 
        //     <ib>
        //         <dirty type="{{groups | ?}}" timestamp="{{ts}}"></dirty>
        //     </ib>
        //     
        public class DirtyIbProtocolEntity
            : IbProtocolEntity {
            
            public object _type;
            
            public int timestamp;
            
            public DirtyIbProtocolEntity(object timestamp, object _type) {
                this.setProps(timestamp, _type);
            }
            
            public virtual object setProps(object timestamp, object _type) {
                this.timestamp = Convert.ToInt32(timestamp);
                this._type = _type;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(DirtyIbProtocolEntity, this).toProtocolTreeNode();
                var dirtyNode = ProtocolTreeNode("dirty");
                dirtyNode["timestamp"] = this.timestamp.ToString();
                dirtyNode["type"] = this._type;
                node.addChild(dirtyNode);
                return node;
            }
            
            public override object ToString() {
                var @out = super(DirtyIbProtocolEntity, this).@__str__();
                @out += String.Format("Type: %s\n", this._type);
                @out += String.Format("Timestamp: %s\n", this.timestamp);
                return @out;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = IbProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = DirtyIbProtocolEntity;
                var dirtyChild = node.getChild("dirty");
                entity.setProps(dirtyChild["timestamp"], dirtyChild["type"]);
                return entity;
            }
        }
    }
}
