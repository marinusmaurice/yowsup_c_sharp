namespace yowsup.layers.protocol_ib.protocolentities {
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using CleanIqProtocolEntity = yowsup.layers.protocol_ib.protocolentities.clean_iq.CleanIqProtocolEntity;
    
    using IqProtocolEntityTest = yowsup.layers.protocol_iq.protocolentities.test_iq.IqProtocolEntityTest;
    
    using System.Collections.Generic;
    
    public static class test_clean_iq {
        
        public class CleanIqProtocolEntityTest
            : IqProtocolEntityTest {
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(CleanIqProtocolEntityTest, this).setUp();
                this.ProtocolEntity = CleanIqProtocolEntity;
                var cleanNode = ProtocolTreeNode("clean", new Dictionary<object, object> {
                    {
                        "type",
                        "groups"}});
                this.node.addChild(cleanNode);
            }
        }
    }
}
