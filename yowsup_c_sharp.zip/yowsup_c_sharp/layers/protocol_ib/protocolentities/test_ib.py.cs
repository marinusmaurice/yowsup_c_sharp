namespace yowsup.layers.protocol_ib.protocolentities
{

    using IbProtocolEntity = yowsup.layers.protocol_ib.protocolentities.ib.IbProtocolEntity;

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using ProtocolEntityTest = yowsup.structs.protocolentity.ProtocolEntityTest;

    public static class test_ib {
        
        public class IbProtocolEntityTest
            : ProtocolEntityTest, unittest.TestCase {
            
            public object node;
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                this.ProtocolEntity = IbProtocolEntity;
                this.node = ProtocolTreeNode("ib");
            }
        }
    }
}
