namespace yowsup.layers.protocol_ib.protocolentities
{

    public static class @__init__ {
    }
}
