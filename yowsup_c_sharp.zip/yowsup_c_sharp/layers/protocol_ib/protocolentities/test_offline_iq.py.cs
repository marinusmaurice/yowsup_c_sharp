namespace yowsup.layers.protocol_ib.protocolentities {
    
    using IbProtocolEntityTest = yowsup.layers.protocol_ib.protocolentities.test_ib.IbProtocolEntityTest;
    
    using OfflineIbProtocolEntity = yowsup.layers.protocol_ib.protocolentities.offline_ib.OfflineIbProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using System.Collections.Generic;
    
    public static class test_offline_iq {
        
        public class OfflineIbProtocolEntityTest
            : IbProtocolEntityTest {
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(OfflineIbProtocolEntityTest, this).setUp();
                this.ProtocolEntity = OfflineIbProtocolEntity;
                this.node.addChild(ProtocolTreeNode("offline", new Dictionary<object, object> {
                    {
                        "count",
                        "5"}}));
            }
        }
    }
}
