namespace yowsup.layers.protocol_ib
{

    using YowProtocolLayer = yowsup.layers.YowProtocolLayer;

    using System.Collections.Generic;

    using System;

    public static class layer {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class YowIbProtocolLayer
            : YowProtocolLayer {
            
            public YowIbProtocolLayer() {
                var handleMap = new Dictionary<object, object> {
                    {
                        "ib",
                        (this.recvIb, this.sendIb)},
                    {
                        "iq",
                        (null, this.sendIb)}};
                super(YowIbProtocolLayer, this).@__init__(handleMap);
            }
            
            public override object ToString() {
                return "Ib Layer";
            }
            
            public virtual object sendIb(object entity) {
                if (entity.@__class__ == CleanIqProtocolEntity) {
                    this.toLower(entity.toProtocolTreeNode());
                }
            }
            
            public virtual object recvIb(object node) {
                if (node.getChild("dirty")) {
                    this.toUpper(DirtyIbProtocolEntity.fromProtocolTreeNode(node));
                } else if (node.getChild("offline")) {
                    this.toUpper(OfflineIbProtocolEntity.fromProtocolTreeNode(node));
                } else if (node.getChild("account")) {
                    this.toUpper(AccountIbProtocolEntity.fromProtocolTreeNode(node));
                } else if (node.getChild("edge_routing")) {
                    logger.debug("ignoring edge_routing ib node for now");
                } else if (node.getChild("attestation")) {
                    logger.debug("ignoring attestation ib node for now");
                } else if (node.getChild("fbip")) {
                    logger.debug("ignoring fbip ib node for now");
                } else {
                    logger.warning(String.Format("Unsupported ib node: %s", node));
                }
            }
        }
    }
}
