namespace yowsup.layers.protocol_ib
{

    public static class @__init__ {
    }
}
