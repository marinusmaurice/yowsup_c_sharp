namespace yowsup.layers.protocol_chatstate
{

    public static class @__init__ {
    }
}
