namespace yowsup.layers.protocol_chatstate {
    
    using YowProtocolLayerTest = yowsup.layers.YowProtocolLayerTest;
    
    using YowChatstateProtocolLayer = yowsup.layers.protocol_chatstate.YowChatstateProtocolLayer;
    
    using IncomingChatstateProtocolEntity = yowsup.layers.protocol_chatstate.protocolentities.IncomingChatstateProtocolEntity;
    
    using OutgoingChatstateProtocolEntity = yowsup.layers.protocol_chatstate.protocolentities.OutgoingChatstateProtocolEntity;
    
    public static class test_layer {
        
        public class YowChatStateProtocolLayerTest
            : YowProtocolLayerTest, YowChatstateProtocolLayer {
            
            public virtual object setUp() {
                YowChatstateProtocolLayer.@__init__(this);
            }
            
            public virtual object test_send() {
                var entity = OutgoingChatstateProtocolEntity(OutgoingChatstateProtocolEntity.STATE_PAUSED, "jid@s.whatsapp.net");
                this.assertSent(entity);
            }
            
            public virtual object test_receive() {
                var entity = IncomingChatstateProtocolEntity(IncomingChatstateProtocolEntity.STATE_TYPING, "jid@s.whatsapp.net");
                this.assertReceived(entity);
            }
        }
    }
}
