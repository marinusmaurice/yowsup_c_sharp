namespace yowsup.layers.protocol_chatstate
{

    using YowProtocolLayer = yowsup.layers.YowProtocolLayer;

    using System.Collections.Generic;

    public static class layer {
        
        public class YowChatstateProtocolLayer
            : YowProtocolLayer {
            
            public YowChatstateProtocolLayer() {
                var handleMap = new Dictionary<object, object> {
                    {
                        "chatstate",
                        (this.recvChatstateNode, this.sendChatstateEntity)}};
                super(YowChatstateProtocolLayer, this).@__init__(handleMap);
            }
            
            public override object ToString() {
                return "Chatstate Layer";
            }
            
            public virtual object sendChatstateEntity(object entity) {
                this.entityToLower(entity);
            }
            
            public virtual object recvChatstateNode(object node) {
                this.toUpper(IncomingChatstateProtocolEntity.fromProtocolTreeNode(node));
            }
        }
    }
}
