namespace yowsup.layers.protocol_chatstate.protocolentities
{

    using IncomingChatstateProtocolEntity = yowsup.layers.protocol_chatstate.protocolentities.chatstate_incoming.IncomingChatstateProtocolEntity;

    using ProtocolEntityTest = yowsup.structs.protocolentity.ProtocolEntityTest;

    public static class test_chatstate_incoming {
        
        public static object entity = IncomingChatstateProtocolEntity(IncomingChatstateProtocolEntity.STATE_TYPING, "jid@s.whatsapp.net");
        
        public class IncomingChatstateProtocolEntityTest
            : ProtocolEntityTest, unittest.TestCase {
            
            public object node;
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                this.ProtocolEntity = IncomingChatstateProtocolEntity;
                this.node = entity.toProtocolTreeNode();
            }
        }
    }
}
