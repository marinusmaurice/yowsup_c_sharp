namespace yowsup.layers.protocol_chatstate.protocolentities {
    
    using ChatstateProtocolEntity = chatstate.ChatstateProtocolEntity;
    
    using System;
    
    public static class chatstate_outgoing {
        
        // 
        //     INCOMING
        // 
        //     <chatstate from="xxxxxxxxxxx@s.whatsapp.net">
        //     <{{composing|paused}}></{{composing|paused}}>
        //     </chatstate>
        // 
        //     OUTGOING
        // 
        //     <chatstate to="xxxxxxxxxxx@s.whatsapp.net">
        //     <{{composing|paused}}></{{composing|paused}}>
        //     </chatstate>
        //     
        public class OutgoingChatstateProtocolEntity
            : ChatstateProtocolEntity {
            
            public object _to;
            
            public OutgoingChatstateProtocolEntity(object _state, object _to) {
                this.setOutgoingData(_to);
            }
            
            public virtual object setOutgoingData(object _to) {
                this._to = _to;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(OutgoingChatstateProtocolEntity, this).toProtocolTreeNode();
                node.setAttribute("to", this._to);
                return node;
            }
            
            public override object ToString() {
                var @out = super(OutgoingChatstateProtocolEntity, this).@__str__();
                @out += String.Format("To: %s\n", this._to);
                return @out;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = ChatstateProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = OutgoingChatstateProtocolEntity;
                entity.setOutgoingData(node.getAttributeValue("to"));
                return entity;
            }
        }
    }
}
