namespace yowsup.layers.protocol_chatstate.protocolentities
{

    using OutgoingChatstateProtocolEntity = yowsup.layers.protocol_chatstate.protocolentities.chatstate_outgoing.OutgoingChatstateProtocolEntity;

    using ProtocolEntityTest = yowsup.structs.protocolentity.ProtocolEntityTest;

    public static class test_chatstate_outgoing {
        
        public static object entity = OutgoingChatstateProtocolEntity(OutgoingChatstateProtocolEntity.STATE_PAUSED, "jid@s.whatsapp.net");
        
        public class OutgoingChatstateProtocolEntityTest
            : ProtocolEntityTest, unittest.TestCase {
            
            public object node;
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                this.ProtocolEntity = OutgoingChatstateProtocolEntity;
                this.node = entity.toProtocolTreeNode();
            }
        }
    }
}
