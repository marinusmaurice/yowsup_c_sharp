namespace yowsup.layers.protocol_chatstate.protocolentities
{

    public static class @__init__ {
    }
}
