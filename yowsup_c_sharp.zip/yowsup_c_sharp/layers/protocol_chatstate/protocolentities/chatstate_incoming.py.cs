namespace yowsup.layers.protocol_chatstate.protocolentities {
    
    using ChatstateProtocolEntity = chatstate.ChatstateProtocolEntity;
    
    using System;
    
    public static class chatstate_incoming {
        
        // 
        //     INCOMING
        // 
        //     <chatstate from="xxxxxxxxxxx@s.whatsapp.net">
        //     <{{composing|paused}}></{{composing|paused}}>
        //     </chatstate>
        // 
        //     OUTGOING
        // 
        //     <chatstate to="xxxxxxxxxxx@s.whatsapp.net">
        //     <{{composing|paused}}></{{composing|paused}}>
        //     </chatstate>
        //     
        public class IncomingChatstateProtocolEntity
            : ChatstateProtocolEntity {
            
            public object _from;
            
            public IncomingChatstateProtocolEntity(object _state, object _from) {
                this.setIncomingData(_from);
            }
            
            public virtual object setIncomingData(object _from) {
                this._from = _from;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(IncomingChatstateProtocolEntity, this).toProtocolTreeNode();
                node.setAttribute("from", this._from);
                return node;
            }
            
            public override object ToString() {
                var @out = super(IncomingChatstateProtocolEntity, this).@__str__();
                @out += String.Format("From: %s\n", this._from);
                return @out;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = ChatstateProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = IncomingChatstateProtocolEntity;
                entity.setIncomingData(node.getAttributeValue("from"));
                return entity;
            }
        }
    }
}
