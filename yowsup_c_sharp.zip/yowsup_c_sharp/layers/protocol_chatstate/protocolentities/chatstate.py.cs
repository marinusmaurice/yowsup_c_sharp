namespace yowsup.layers.protocol_chatstate.protocolentities {
    
    using ProtocolEntity = yowsup.structs.ProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using System;
    
    using System.Diagnostics;
    
    using System.Collections.Generic;
    
    public static class chatstate {
        
        // 
        //     INCOMING
        // 
        //     <chatstate from="xxxxxxxxxxx@s.whatsapp.net">
        //     <{{composing|paused}}></{{composing|paused}}>
        //     </chatstate>
        // 
        //     OUTGOING
        // 
        //     <chatstate to="xxxxxxxxxxx@s.whatsapp.net">
        //     <{{composing|paused}}></{{composing|paused}}>
        //     </chatstate>
        //     
        public class ChatstateProtocolEntity
            : ProtocolEntity {
            
            public object _state;
            
            public string STATE_PAUSED;
            
            public string STATE_TYPING;
            
            public Tuple<string, string> STATES;
            
            public string STATE_TYPING = "composing";
            
            public string STATE_PAUSED = "paused";
            
            public Tuple<string, string> STATES = (STATE_TYPING, STATE_PAUSED);
            
            public ChatstateProtocolEntity(object _state) {
                Debug.Assert(this.@__class__.STATES.Contains(_state));
                Debug.Assert(String.Format("Expected chat state to be in %s, got %s", this.@__class__.STATES, _state));
                this._state = _state;
            }
            
            public virtual object getState() {
                return this._state;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = this._createProtocolTreeNode(new Dictionary<object, object> {
                }, null, data: null);
                node.addChild(ProtocolTreeNode(this._state));
                return node;
            }
            
            public override object ToString() {
                var @out = "CHATSTATE:\n";
                @out += String.Format("State: %s\n", this._state);
                return @out;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                return new ChatstateProtocolEntity(node.getAllChildren()[0].tag);
            }
        }
    }
}
