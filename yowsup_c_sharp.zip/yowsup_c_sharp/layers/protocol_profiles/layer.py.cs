namespace yowsup.layers.protocol_profiles {
    
    using YowProtocolLayer = yowsup.layers.YowProtocolLayer;
    
    using ErrorIqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.ErrorIqProtocolEntity;
    
    using ResultIqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.ResultIqProtocolEntity;
    
    using System.Collections.Generic;
    
    public static class layer {
        
        public class YowProfilesProtocolLayer
            : YowProtocolLayer {
            
            public YowProfilesProtocolLayer() {
                var handleMap = new Dictionary<object, object> {
                    {
                        "iq",
                        (this.recvIq, this.sendIq)}};
                super(YowProfilesProtocolLayer, this).@__init__(handleMap);
            }
            
            public override object ToString() {
                return "Profiles Layer";
            }
            
            public virtual object sendIq(object entity) {
                if (entity.getXmlns() == "w:profile:picture") {
                    if (entity.getType() == "get") {
                        this._sendIq(entity, this.onGetPictureResult, this.onGetPictureError);
                    } else if (entity.getType() == "set") {
                        this._sendIq(entity, this.onSetPictureResult, this.onSetPictureError);
                    } else if (entity.getType() == "delete") {
                        this._sendIq(entity, this.onDeletePictureResult, this.onDeletePictureError);
                    }
                } else if (entity.getXmlns() == "privacy") {
                    this._sendIq(entity, this.onPrivacyResult, this.onPrivacyError);
                } else if (entity is GetStatusesIqProtocolEntity) {
                    this._sendIq(entity, this.onGetStatusesResult, this.onGetStatusesError);
                } else if (entity is SetStatusIqProtocolEntity) {
                    this._sendIq(entity, this.onSetStatusResult, this.onSetStatusError);
                }
            }
            
            public virtual object recvIq(object node) {
            }
            
            public virtual object onPrivacyResult(object resultNode, object originIqRequestEntity) {
                this.toUpper(ResultPrivacyIqProtocolEntity.fromProtocolTreeNode(resultNode));
            }
            
            public virtual object onPrivacyError(object errorNode, object originalIqRequestEntity) {
                this.toUpper(ErrorIqProtocolEntity.fromProtocolTreeNode(errorNode));
            }
            
            public virtual object onGetStatusesResult(object resultNode, object originIqRequestEntity) {
                this.toUpper(ResultStatusesIqProtocolEntity.fromProtocolTreeNode(resultNode));
            }
            
            public virtual object onGetStatusesError(object errorNode, object originalIqRequestEntity) {
                this.toUpper(ErrorIqProtocolEntity.fromProtocolTreeNode(errorNode));
            }
            
            public virtual object onSetStatusResult(object resultNode, object originIqRequestEntity) {
                this.toUpper(ResultIqProtocolEntity.fromProtocolTreeNode(resultNode));
            }
            
            public virtual object onSetStatusError(object errorNode, object originalIqRequestEntity) {
                this.toUpper(ErrorIqProtocolEntity.fromProtocolTreeNode(errorNode));
            }
            
            public virtual object onGetPictureResult(object resultNode, object originalIqRequestEntity) {
                this.toUpper(ResultGetPictureIqProtocolEntity.fromProtocolTreeNode(resultNode));
            }
            
            public virtual object onGetPictureError(object errorNode, object originalIqRequestEntity) {
                this.toUpper(ErrorIqProtocolEntity.fromProtocolTreeNode(errorNode));
            }
            
            public virtual object onSetPictureResult(object resultNode, object originalIqRequestEntity) {
                this.toUpper(ResultGetPictureIqProtocolEntity.fromProtocolTreeNode(resultNode));
            }
            
            public virtual object onSetPictureError(object errorNode, object originalIqRequestEntity) {
                this.toUpper(ErrorIqProtocolEntity.fromProtocolTreeNode(errorNode));
            }
            
            public virtual object onDeletePictureResult(object resultNode, object originalIqRequestEntity) {
                this.toUpper(ResultIqProtocolEntity.fromProtocolTreeNode(resultNode));
            }
            
            public virtual object onDeletePictureError(object errorNode, object originalIqRequestEntity) {
                this.toUpper(ErrorIqProtocolEntity.fromProtocolTreeNode(errorNode));
            }
        }
    }
}
