namespace yowsup.layers.protocol_profiles
{

    public static class @__init__ {
    }
}
