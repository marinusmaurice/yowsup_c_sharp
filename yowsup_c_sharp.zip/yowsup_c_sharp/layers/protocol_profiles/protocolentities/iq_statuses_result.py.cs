namespace yowsup.layers.protocol_profiles.protocolentities {
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using IqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.IqProtocolEntity;
    
    using System.Diagnostics;
    
    using System;
    
    using System.Collections.Generic;
    
    using System.Linq;
    
    public static class iq_statuses_result {
        
        // 
        //     <iq type="result" from="s.whatsapp.net" id="1">
        //         <status>
        //             <user jid="{number}@s.whatsapp.net" t="1330555420">
        //                 {status message}
        //                 HEX:{status message in hex}
        //             </user>
        //             <user jid="{number}@s.whatsapp.net" t="1420813055">
        //                 {status message}
        //                 HEX:{status message in hex}
        //             </user>
        //         </status>
        //     </iq>
        //     
        public class ResultStatusesIqProtocolEntity
            : IqProtocolEntity {
            
            public object statuses;
            
            public string XMLNS;
            
            public string XMLNS = "status";
            
            public ResultStatusesIqProtocolEntity(object _id, object _from, object statuses)
                : base(_id, "result", _from: _from) {
                this.setResultStatusesProps(statuses);
            }
            
            public virtual object setResultStatusesProps(object statuses) {
                Debug.Assert(object.ReferenceEquals(type(statuses), dict));
                Debug.Assert("statuses must be dict");
                this.statuses = statuses;
            }
            
            public override object ToString() {
                var @out = super(ResultStatusesIqProtocolEntity, this).@__str__();
                @out += String.Format("Statuses: %s\n", ",".join(from _tup_2 in this.statuses.items().Chop((jid,v) => (jid, v))
                    let jid = _tup_2.Item1
                    let v = _tup_2.Item2
                    select jid + "(" + v.ToString() + ")"));
                return @out;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(ResultStatusesIqProtocolEntity, this).toProtocolTreeNode();
                var users = (from _tup_1 in this.statuses.items().Chop((jid,(status, t)) => (jid, (status, t)))
                    let jid = _tup_1.Item1
                    let (status, t) = _tup_1.Item2
                    select ProtocolTreeNode("user", new Dictionary<object, object> {
                        {
                            "jid",
                            jid},
                        {
                            "t",
                            t}}, null, status)).ToList();
                var statusNode = ProtocolTreeNode("status", null, users);
                node.addChild(statusNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var statusNode = node.getChild("status");
                var users = statusNode.getAllChildren();
                var statuses = new dict();
                foreach (var user in users) {
                    statuses[user["jid"]] = (user.getData(), user["t"]);
                }
                var entity = IqProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = ResultStatusesIqProtocolEntity;
                entity.setResultStatusesProps(statuses);
                return entity;
            }
        }
    }
}
