namespace yowsup.layers.protocol_profiles.protocolentities
{

    using YowConstants = yowsup.common.YowConstants;

    using IqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.IqProtocolEntity;

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using System.Collections.Generic;

    public static class iq_status_set {
        
        public static logger logger = logging.getLogger(@__name__);
        
        // 
        //     <iq to="s.whatsapp.net" xmlns="status" type="set" id="{{IQ_ID}}">
        //         <status>{{MSG}}</status>
        //     </notification>
        //     
        public class SetStatusIqProtocolEntity
            : IqProtocolEntity {
            
            public object text;
            
            public string XMLNS;
            
            public string XMLNS = "status";
            
            public SetStatusIqProtocolEntity(object text = null, object _id = null) {
                if (type(text) != bytes) {
                    logger.warning("Passing text as str is deprecated, pass bytes instead");
                    text = bytes(text, "latin-1");
                }
                super(SetStatusIqProtocolEntity, this).@__init__(this.@__class__.XMLNS, _id, _type: "set", to: YowConstants.WHATSAPP_SERVER);
                this.setData(text);
            }
            
            public virtual object setData(object text) {
                this.text = text;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(SetStatusIqProtocolEntity, this).toProtocolTreeNode();
                var statusNode = ProtocolTreeNode("status", new Dictionary<object, object> {
                }, new List<object>(), this.text);
                node.addChild(statusNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = IqProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = SetStatusIqProtocolEntity;
                var statusNode = node.getChild("status");
                entity.setData(statusNode.getData());
                return entity;
            }
        }
    }
}
