namespace yowsup.layers.protocol_profiles.protocolentities
{

    using IqProtocolEntityTest = yowsup.layers.protocol_iq.protocolentities.test_iq.IqProtocolEntityTest;

    using ResultPrivacyIqProtocolEntity = yowsup.layers.protocol_profiles.protocolentities.ResultPrivacyIqProtocolEntity;

    using System.Collections.Generic;

    public static class test_iq_privacy_result {
        
        public static object entity = ResultPrivacyIqProtocolEntity(new Dictionary<object, object> {
            {
                "profile",
                "all"},
            {
                "last",
                "none"},
            {
                "status",
                "contacts"}});
        
        public class ResultPrivacyIqProtocolEntityTest
            : IqProtocolEntityTest {
            
            public object node;
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(ResultPrivacyIqProtocolEntityTest, this).setUp();
                this.ProtocolEntity = ResultPrivacyIqProtocolEntity;
                this.node = entity.toProtocolTreeNode();
            }
        }
    }
}
