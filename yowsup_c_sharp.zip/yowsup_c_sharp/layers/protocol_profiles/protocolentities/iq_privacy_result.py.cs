namespace yowsup.layers.protocol_profiles.protocolentities {
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using ResultIqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.ResultIqProtocolEntity;
    
    using System.Diagnostics;
    
    using System;
    
    using System.Collections.Generic;
    
    public static class iq_privacy_result {
        
        static iq_privacy_result() {
            @"
<iq type=""result"" from=""{{JID}}@s.whatsapp.net"" id=""{{IQ:ID}}"">
<privacy>
<category name=""last"" value=""all"">
</category>
<category name=""status"" value=""all"">
</category>
<category name=""profile"" value=""all"">
</category>
</privacy>
</iq>
";
        }
        
        public class ResultPrivacyIqProtocolEntity
            : ResultIqProtocolEntity {
            
            public string NODE_PRIVACY;
            
            public object privacy;
            
            public string NODE_PRIVACY = "privacy";
            
            public ResultPrivacyIqProtocolEntity(object privacy) {
                this.setProps(privacy);
            }
            
            public virtual object setProps(object privacy) {
                Debug.Assert(object.ReferenceEquals(type(privacy), dict));
                Debug.Assert("Privacy must be a dict {name => value}");
                this.privacy = privacy;
            }
            
            public override object ToString() {
                var @out = super(ResultPrivacyIqProtocolEntity, this).@__str__();
                @out += "Privacy settings\n";
                foreach (var _tup_1 in this.privacy.items()) {
                    var name = _tup_1.Item1;
                    var value = _tup_1.Item2;
                    @out += String.Format("Category %s  --> %s\n", name, value);
                }
                return @out;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(ResultPrivacyIqProtocolEntity, this).toProtocolTreeNode();
                var queryNode = ProtocolTreeNode(this.@__class__.NODE_PRIVACY);
                node.addChild(queryNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = super(ResultPrivacyIqProtocolEntity, ResultPrivacyIqProtocolEntity).fromProtocolTreeNode(node);
                entity.@__class__ = ResultPrivacyIqProtocolEntity;
                var privacyNode = node.getChild(ResultPrivacyIqProtocolEntity.NODE_PRIVACY);
                var privacy = new Dictionary<object, object> {
                };
                foreach (var categoryNode in privacyNode.getAllChildren()) {
                    privacy[categoryNode["name"]] = categoryNode["value"];
                }
                entity.setProps(privacy);
                return entity;
            }
        }
    }
}
