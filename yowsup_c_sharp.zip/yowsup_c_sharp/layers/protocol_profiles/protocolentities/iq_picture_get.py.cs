namespace yowsup.layers.protocol_profiles.protocolentities {
    
    using PictureIqProtocolEntity = iq_picture.PictureIqProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using System.Collections.Generic;
    
    public static class iq_picture_get {
        
        // 
        //     <iq type="get" id="{{id}}" xmlns="w:profile:picture", to={{jid}}">
        //         <picture type="image | preview">
        //         </picture>
        //     </iq>
        public class GetPictureIqProtocolEntity
            : PictureIqProtocolEntity {
            
            public object preview;
            
            public GetPictureIqProtocolEntity(object jid, object preview = true, object _id = null)
                : base(_id, "get") {
                this.setGetPictureProps(preview);
            }
            
            public virtual object setGetPictureProps(object preview = true) {
                this.preview = preview;
            }
            
            public virtual object isPreview() {
                return this.preview;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(GetPictureIqProtocolEntity, this).toProtocolTreeNode();
                var pictureNode = ProtocolTreeNode("picture", new Dictionary<object, object> {
                    {
                        "type",
                        this.isPreview() ? "preview" : "image"}});
                node.addChild(pictureNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = PictureIqProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = GetPictureIqProtocolEntity;
                entity.setGetPictureProps(node.getChild("picture").getAttributeValue("type"));
                return entity;
            }
        }
    }
}
