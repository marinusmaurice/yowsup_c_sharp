namespace yowsup.layers.protocol_profiles.protocolentities
{

    using IqProtocolEntityTest = yowsup.layers.protocol_iq.protocolentities.test_iq.IqProtocolEntityTest;

    using SetPrivacyIqProtocolEntity = yowsup.layers.protocol_profiles.protocolentities.SetPrivacyIqProtocolEntity;

    using System.Collections.Generic;

    public static class test_iq_privacy_set {
        
        public static object entity = SetPrivacyIqProtocolEntity("all", new List<string> {
            "profile",
            "last",
            "status"
        });
        
        public class SetPrivacyIqProtocolEntityTest
            : IqProtocolEntityTest {
            
            public object node;
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(SetPrivacyIqProtocolEntityTest, this).setUp();
                this.ProtocolEntity = SetPrivacyIqProtocolEntity;
                this.node = entity.toProtocolTreeNode();
            }
        }
    }
}
