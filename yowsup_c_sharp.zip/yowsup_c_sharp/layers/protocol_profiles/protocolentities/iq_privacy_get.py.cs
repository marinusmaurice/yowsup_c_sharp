namespace yowsup.layers.protocol_profiles.protocolentities {
    
    using IqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.IqProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using System.Diagnostics;
    
    using System;
    
    public static class iq_privacy_get {
        
        static iq_privacy_get() {
            @"
<iq xmlns=""privacy"" type=""get"" id=""{{IQ_ID}}"">
<privacy>
</privacy>
</iq>
";
        }
        
        public class GetPrivacyIqProtocolEntity
            : IqProtocolEntity {
            
            public string XMLNS;
            
            public string XMLNS = "privacy";
            
            public GetPrivacyIqProtocolEntity()
                : base(_type: "get") {
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(GetPrivacyIqProtocolEntity, this).toProtocolTreeNode();
                var queryNode = ProtocolTreeNode(this.@__class__.XMLNS);
                node.addChild(queryNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                Debug.Assert(node.getChild(GetPrivacyIqProtocolEntity.XMLNS) != null);
                Debug.Assert(String.Format("Not a get privacy iq node %s", node));
                var entity = IqProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = GetPrivacyIqProtocolEntity;
                return entity;
            }
        }
    }
}
