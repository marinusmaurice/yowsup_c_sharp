namespace yowsup.layers.protocol_profiles.protocolentities {
    
    using IqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.IqProtocolEntity;
    
    public static class iq_picture {
        
        // 
        //     When receiving a profile picture:
        //     <iq type="result" from="{{jid}}" id="{{id}}">
        //         <picture type="image" id="{{another_id}}">
        //         {{Binary bytes of the picture.}}
        //         </picture>
        //     </iq>
        //     
        public class PictureIqProtocolEntity
            : IqProtocolEntity {
            
            public string XMLNS;
            
            public string XMLNS = "w:profile:picture";
            
            public PictureIqProtocolEntity(object jid, object _id = null, object type = "get")
                : base(_id: _id, _type: type, to: jid) {
            }
        }
    }
}
