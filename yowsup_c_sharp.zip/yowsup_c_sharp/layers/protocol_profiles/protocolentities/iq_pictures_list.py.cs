namespace yowsup.layers.protocol_profiles.protocolentities
{

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using PictureIqProtocolEntity = iq_picture.PictureIqProtocolEntity;

    using System.Diagnostics;

    using System.Collections.Generic;

    using System.Linq;

    public static class iq_pictures_list {
        
        // 
        //     <iq type="get" id="{{id}}" xmlns="w:profile:picture", to="self.jid">
        //         <list>
        //             <user jid="{{user_jid}}"></user>
        //             <user jid="{{user_jid}}"></user>
        //         </list>
        //     </iq>
        //     
        public class ListPicturesIqProtocolEntity
            : PictureIqProtocolEntity {
            
            public object jids;
            
            public ListPicturesIqProtocolEntity(object selfJid, object jids)
                : base(type: "get") {
                this.setProps(jids);
            }
            
            public virtual object setProps(object jids) {
                Debug.Assert(object.ReferenceEquals(type(jids), list) && jids.Count);
                Debug.Assert("Must specify a list of jids to get the pictures for");
                this.jids = jids;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(ListPicturesIqProtocolEntity, this).toProtocolTreeNode();
                var userNodes = (from jid in this.jids
                    select ProtocolTreeNode("user", new Dictionary<object, object> {
                        {
                            "jid",
                            jid}})).ToList();
                var listNode = ProtocolTreeNode("list", new Dictionary<object, object> {
                }, userNodes);
                node.addChild(listNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = PictureIqProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = ListPicturesIqProtocolEntity;
                var jids = (from userNode in node.getChild("list").getAllChildren()
                    select userNode.getAttributeValue("jid")).ToList();
                entity.setProps(jids);
                return entity;
            }
        }
    }
}
