namespace yowsup.layers.protocol_profiles.protocolentities {
    
    using YowConstants = yowsup.common.YowConstants;
    
    using IqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.IqProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using System.Collections.Generic;
    
    using System.Diagnostics;
    
    using System;
    
    public static class iq_unregister {
        
        public class UnregisterIqProtocolEntity
            : IqProtocolEntity {
            
            public string XMLNS;
            
            public string XMLNS = "urn:xmpp:whatsapp:account";
            
            public UnregisterIqProtocolEntity()
                : base(to: YowConstants.WHATSAPP_SERVER) {
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(UnregisterIqProtocolEntity, this).toProtocolTreeNode();
                var rmNode = ProtocolTreeNode("remove", new Dictionary<object, object> {
                    {
                        "xmlns",
                        this.@__class__.XMLNS}});
                node.addChild(rmNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = IqProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = UnregisterIqProtocolEntity;
                var removeNode = node.getChild("remove");
                Debug.Assert(removeNode["xmlns"] == UnregisterIqProtocolEntity.XMLNS);
                Debug.Assert(String.Format("Not an account delete xmlns, got %s", removeNode["xmlns"]));
                return entity;
            }
        }
    }
}
