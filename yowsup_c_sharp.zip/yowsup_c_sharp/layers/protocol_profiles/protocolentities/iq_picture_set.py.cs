namespace yowsup.layers.protocol_profiles.protocolentities
{

    using PictureIqProtocolEntity = iq_picture.PictureIqProtocolEntity;

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using System;

    using System.Collections.Generic;

    public static class iq_picture_set {
        
        // 
        //     <iq type="set" id="{{id}}" xmlns="w:profile:picture", to={{jid}}">
        //         <picture type="image" id="{{another_id}}">
        //         {{Binary bytes of the picture when type is set.}}
        //         </picture>
        //     </iq>
        // 
        public class SetPictureIqProtocolEntity
            : PictureIqProtocolEntity {
            
            public object pictureData;
            
            public object pictureId;
            
            public object previewData;
            
            public SetPictureIqProtocolEntity(
                object jid,
                object previewData,
                object pictureData,
                object pictureId = null,
                object _id = null)
                : base(_id, "set") {
                this.setSetPictureProps(previewData, pictureData, pictureId);
            }
            
            public virtual object setSetPictureProps(object previewData, object pictureData, object pictureId = null) {
                this.setPictureData(pictureData);
                this.setPictureId(pictureId || Convert.ToInt32(time.time()).ToString());
                this.setPreviewData(previewData);
            }
            
            public virtual object setPictureData(object pictureData) {
                this.pictureData = pictureData;
            }
            
            public virtual object getPictureData() {
                return this.pictureData;
            }
            
            public virtual object setPreviewData(object previewData) {
                this.previewData = previewData;
            }
            
            public virtual object getPreviewData() {
                return this.previewData;
            }
            
            public virtual object setPictureId(object pictureId) {
                this.pictureId = pictureId;
            }
            
            public virtual object getPictureId() {
                return this.pictureId;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(PictureIqProtocolEntity, this).toProtocolTreeNode();
                var attribs = new Dictionary<object, object> {
                    {
                        "type",
                        "image"},
                    {
                        "id",
                        this.pictureId}};
                var pictureNode = ProtocolTreeNode("picture", attribs, null, this.getPictureData());
                var previewNode = ProtocolTreeNode("picture", new Dictionary<object, object> {
                    {
                        "type",
                        "preview"}}, null, this.getPreviewData());
                node.addChild(pictureNode);
                node.addChild(previewNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = PictureIqProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = SetPictureIqProtocolEntity;
                object pictureNode = null;
                object previewNode = null;
                foreach (var child in node.getAllChildren("picture")) {
                    var nodeType = child.getAttributeValue("type");
                    if (nodeType == "image") {
                        pictureNode = child;
                    } else if (nodeType == "preview") {
                        previewNode = child;
                    }
                }
                entity.setSetPictureProps(previewNode.getData(), pictureNode.getData(), pictureNode.getAttributeValue("id"));
                return entity;
            }
        }
    }
}
