namespace yowsup.layers.protocol_profiles.protocolentities
{

    using IqProtocolEntityTest = yowsup.layers.protocol_iq.protocolentities.test_iq.IqProtocolEntityTest;

    using GetPrivacyIqProtocolEntity = yowsup.layers.protocol_profiles.protocolentities.GetPrivacyIqProtocolEntity;

    public static class test_iq_privacy_get {
        
        public static object entity = GetPrivacyIqProtocolEntity();
        
        public class GetPrivacyIqProtocolEntityTest
            : IqProtocolEntityTest {
            
            public object node;
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(GetPrivacyIqProtocolEntityTest, this).setUp();
                this.ProtocolEntity = GetPrivacyIqProtocolEntity;
                this.node = entity.toProtocolTreeNode();
            }
        }
    }
}
