namespace yowsup.layers.protocol_profiles.protocolentities {
    
    using YowConstants = yowsup.common.YowConstants;
    
    using IqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.IqProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using System.Diagnostics;
    
    using System;
    
    using System.Collections.Generic;
    
    using System.Linq;
    
    public static class iq_statuses_get {
        
        public class GetStatusesIqProtocolEntity
            : IqProtocolEntity {
            
            public object jids;
            
            public string XMLNS;
            
            public string XMLNS = "status";
            
            public GetStatusesIqProtocolEntity(object jids, object _id = null)
                : base(_id, _type: "get", to: YowConstants.WHATSAPP_SERVER) {
                this.setGetStatusesProps(jids);
            }
            
            public virtual object setGetStatusesProps(object jids) {
                Debug.Assert(object.ReferenceEquals(type(jids), list));
                Debug.Assert("jids must be a list of jids");
                this.jids = jids;
            }
            
            public override object ToString() {
                var @out = super(GetStatusesIqProtocolEntity, this).@__str__();
                @out += String.Format("Numbers: %s\n", ",".join(this.numbers));
                return @out;
            }
            
            public virtual object toProtocolTreeNode() {
                var users = (from jid in this.jids
                    select ProtocolTreeNode("user", new Dictionary<object, object> {
                        {
                            "jid",
                            jid}})).ToList();
                var node = super(GetStatusesIqProtocolEntity, this).toProtocolTreeNode();
                var statusNode = ProtocolTreeNode("status", null, users);
                node.addChild(statusNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = IqProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = GetStatusesIqProtocolEntity;
                var statusNode = node.getChild("status");
                var userNodes = statusNode.getAllChildren();
                var jids = (from user in userNodes
                    select user["jid"]).ToList();
                entity.setGetStatusesProps(jids);
                return entity;
            }
        }
    }
}
