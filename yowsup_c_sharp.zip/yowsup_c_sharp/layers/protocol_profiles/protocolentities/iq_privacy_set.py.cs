namespace yowsup.layers.protocol_profiles.protocolentities {
    
    using IqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.IqProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using System.Collections.Generic;
    
    public static class iq_privacy_set {
        
        static iq_privacy_set() {
            @"
<iq xmlns=""privacy"" type=""set"" id=""{{IQ_ID}}"">
<privacy>
<category name=""status"" value=""none"">
<category name=""profile"" value=""none"">
<category name=""last"" value=""none"">
</category>
</privacy>
</iq>
";
        }
        
        public class SetPrivacyIqProtocolEntity
            : IqProtocolEntity {
            
            public object names;
            
            public List<string> NAMES;
            
            public SetPrivacyIqProtocolEntity value;
            
            public List<string> VALUES;
            
            public string XMLNS;
            
            public List<string> NAMES = new List<string> {
                "status",
                "profile",
                "last"
            };
            
            public List<string> VALUES = new List<string> {
                "all",
                "contacts",
                "none"
            };
            
            public string XMLNS = "privacy";
            
            public SetPrivacyIqProtocolEntity(object value = "all", object names = null) {
                // names can be a string with some element in VALUES or an array with strings with elements in VALUES
                // by default, all names are used
                super(SetPrivacyIqProtocolEntity, this).@__init__(this.@__class__.XMLNS, _type: "set");
                this.setNames(names);
                this.setValue(value);
            }
            
            [staticmethod]
            public static object checkValidNames(object names) {
                names = names ? names : SetPrivacyIqProtocolEntity.NAMES;
                if (!object.ReferenceEquals(type(names), list)) {
                    names = new List<object> {
                        names
                    };
                }
                foreach (var name in names) {
                    if (!SetPrivacyIqProtocolEntity.NAMES.Contains(name)) {
                        throw new Exception("Name should be in: '" + "', '".join(SetPrivacyIqProtocolEntity.NAMES) + "' but is '" + name + "'");
                    }
                }
                return names;
            }
            
            [staticmethod]
            public static object checkValidValue(object value) {
                if (!SetPrivacyIqProtocolEntity.VALUES.Contains(value)) {
                    throw new Exception("Value should be in: '" + "', '".join(SetPrivacyIqProtocolEntity.VALUES) + "' but is '" + value + "'");
                }
                return value;
            }
            
            public virtual object setNames(object names) {
                this.names = SetPrivacyIqProtocolEntity.checkValidNames(names);
            }
            
            public virtual object setValue(object value) {
                this.value = SetPrivacyIqProtocolEntity.checkValidValue(value);
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(SetPrivacyIqProtocolEntity, this).toProtocolTreeNode();
                var queryNode = ProtocolTreeNode(this.@__class__.XMLNS);
                foreach (var name in this.names) {
                    var listNode = ProtocolTreeNode("category", new Dictionary<object, object> {
                        {
                            "name",
                            name},
                        {
                            "value",
                            this.value}});
                    queryNode.addChild(listNode);
                }
                node.addChild(queryNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = IqProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = SetPrivacyIqProtocolEntity;
                var privacyNode = node.getChild(SetPrivacyIqProtocolEntity.XMLNS);
                var names = new List<object>();
                foreach (var categoryNode in privacyNode.getAllChildren()) {
                    names.append(categoryNode["name"]);
                }
                entity.setNames(names);
                entity.setValue("all");
                return entity;
            }
        }
    }
}
