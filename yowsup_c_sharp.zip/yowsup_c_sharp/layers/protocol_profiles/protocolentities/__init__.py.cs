namespace yowsup.layers.protocol_profiles.protocolentities
{

    public static class @__init__ {
    }
}
