namespace yowsup.layers.protocol_profiles.protocolentities {
    
    using IqProtocolEntityTest = yowsup.layers.protocol_iq.protocolentities.test_iq.IqProtocolEntityTest;
    
    using UnregisterIqProtocolEntity = yowsup.layers.protocol_profiles.protocolentities.UnregisterIqProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using System.Collections.Generic;
    
    public static class test_iq_unregister {
        
        public class UnregisterIqProtocolEntityTest
            : IqProtocolEntityTest {
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(UnregisterIqProtocolEntityTest, this).setUp();
                this.ProtocolEntity = UnregisterIqProtocolEntity;
                this.node.addChild(ProtocolTreeNode("remove", new Dictionary<object, object> {
                    {
                        "xmlns",
                        "urn:xmpp:whatsapp:account"}}));
            }
        }
    }
}
