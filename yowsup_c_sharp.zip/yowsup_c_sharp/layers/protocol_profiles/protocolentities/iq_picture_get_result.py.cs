namespace yowsup.layers.protocol_profiles.protocolentities {
    
    using PictureIqProtocolEntity = iq_picture.PictureIqProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using System.Collections.Generic;
    
    public static class iq_picture_get_result {
        
        // 
        //     <iq type="result" from="{{jid}}" id="{{id}}">
        //         <picture type="image | preview" id="{{another_id}}">
        //         {{Binary bytes of the picture.}}
        //         </picture>
        //     </iq>
        //     
        public class ResultGetPictureIqProtocolEntity
            : PictureIqProtocolEntity {
            
            public object pictureData;
            
            public object pictureId;
            
            public object preview;
            
            public ResultGetPictureIqProtocolEntity(
                object jid,
                object pictureData,
                object pictureId,
                object preview = true,
                object _id = null)
                : base(_id, "result") {
                this.setResultPictureProps(pictureData, pictureId, preview);
            }
            
            public virtual object setResultPictureProps(object pictureData, object pictureId, object preview = true) {
                this.preview = preview;
                this.pictureData = pictureData;
                this.pictureId = pictureId;
            }
            
            public virtual object isPreview() {
                return this.preview;
            }
            
            public virtual object getPictureData() {
                return this.pictureData;
            }
            
            public virtual object getPictureId() {
                return this.pictureId;
            }
            
            public virtual object writeToFile(object path) {
                using (var outFile = open(path, "wb")) {
                    outFile.write(this.getPictureData());
                }
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(ResultGetPictureIqProtocolEntity, this).toProtocolTreeNode();
                var pictureNode = ProtocolTreeNode(new Dictionary<object, object> {
                    {
                        "type",
                        this.isPreview() ? "preview" : "image"}}, data: this.getPictureData());
                node.addChild(pictureNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = PictureIqProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = ResultGetPictureIqProtocolEntity;
                var pictureNode = node.getChild("picture");
                entity.setResultPictureProps(pictureNode.getData(), pictureNode.getAttributeValue("id"), pictureNode.getAttributeValue("type") == "preview");
                return entity;
            }
        }
    }
}
