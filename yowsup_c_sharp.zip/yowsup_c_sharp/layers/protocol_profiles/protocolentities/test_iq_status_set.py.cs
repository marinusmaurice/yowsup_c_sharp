namespace yowsup.layers.protocol_profiles.protocolentities {
    
    using IqProtocolEntityTest = yowsup.layers.protocol_iq.protocolentities.test_iq.IqProtocolEntityTest;
    
    using SetStatusIqProtocolEntity = yowsup.layers.protocol_profiles.protocolentities.SetStatusIqProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using System.Collections.Generic;
    
    public static class test_iq_status_set {
        
        public class SetStatusIqProtocolEntityTest
            : IqProtocolEntityTest {
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(SetStatusIqProtocolEntityTest, this).setUp();
                this.ProtocolEntity = SetStatusIqProtocolEntity;
                var statusNode = ProtocolTreeNode("status", new Dictionary<object, object> {
                }, new List<object>(), new byte[] { (byte)'H', (byte)'e', (byte)'y', (byte)' ', (byte)'t', (byte)'h', (byte)'e', (byte)'r', (byte)'e', (byte)',', (byte)' ', (byte)'I', (byte)''', (byte)'m', (byte)' ', (byte)'u', (byte)'s', (byte)'i', (byte)'n', (byte)'g', (byte)' ', (byte)'W', (byte)'h', (byte)'a', (byte)'t', (byte)'s', (byte)'A', (byte)'p', (byte)'p' });
                this.node.addChild(statusNode);
            }
        }
    }
}
