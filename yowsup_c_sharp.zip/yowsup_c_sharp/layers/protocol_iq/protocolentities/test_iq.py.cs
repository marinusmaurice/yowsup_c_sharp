namespace yowsup.layers.protocol_iq.protocolentities
{

    using IqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.iq.IqProtocolEntity;

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using ProtocolEntityTest = yowsup.structs.protocolentity.ProtocolEntityTest;

    using System.Collections.Generic;

    public static class test_iq {
        
        public class IqProtocolEntityTest
            : unittest.TestCase, ProtocolEntityTest {
            
            public object node;
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                this.ProtocolEntity = IqProtocolEntity;
                this.node = ProtocolTreeNode("iq", new Dictionary<object, object> {
                    {
                        "id",
                        "test_id"},
                    {
                        "type",
                        "get"},
                    {
                        "xmlns",
                        "iq_xmlns"}}, null, null);
            }
        }
    }
}
