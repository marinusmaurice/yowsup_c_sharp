namespace yowsup.layers.protocol_iq.protocolentities {
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using IqProtocolEntity = iq.IqProtocolEntity;
    
    using System;
    
    using System.Collections.Generic;
    
    public static class iq_error {
        
        // <iq id="1417113419-0" from="{{jid}}" type="error">
        //     <error text="not-acceptable" code="406" backoff="3600">
        //     </error>
        //     </iq>
        //     
        public class ErrorIqProtocolEntity
            : IqProtocolEntity {
            
            public int backoff;
            
            public object code;
            
            public object text;
            
            public ErrorIqProtocolEntity(
                object _id,
                object _from,
                object code,
                object text,
                object backoff = 0)
                : base(_id: _id, _type: "error", _from: _from) {
                this.setErrorProps(code, text, backoff);
            }
            
            public virtual object setErrorProps(object code, object text, object backoff) {
                this.code = code;
                this.text = text;
                this.backoff = backoff ? Convert.ToInt32(backoff) : 0;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(ErrorIqProtocolEntity, this).toProtocolTreeNode();
                var errorNode = ProtocolTreeNode("error", new Dictionary<object, object> {
                    {
                        "text",
                        this.text},
                    {
                        "code",
                        this.code}});
                if (this.backoff) {
                    errorNode.setAttribute("backoff", this.backoff.ToString());
                }
                node.addChild(errorNode);
                return node;
            }
            
            public override object ToString() {
                var @out = super(ErrorIqProtocolEntity, this).@__str__();
                @out += String.Format("Code: %s\n", this.code);
                @out += String.Format("Text: %s\n", this.text);
                @out += String.Format("Backoff: %s\n", this.backoff);
                return @out;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = IqProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = ErrorIqProtocolEntity;
                var errorNode = node.getChild("error");
                entity.setErrorProps(errorNode.getAttributeValue("code"), errorNode.getAttributeValue("text"), errorNode.getAttributeValue("backoff"));
                return entity;
            }
        }
    }
}
