namespace yowsup.layers.protocol_iq.protocolentities
{

    using IqProtocolEntity = iq.IqProtocolEntity;

    public static class iq_ping {
        
        // 
        //     Receive
        //     <iq type="get" xmlns="urn:xmpp:ping" from="s.whatsapp.net" id="1416174955-ping">
        //     </iq>
        //     Send
        //     <iq type="get" xmlns="w:p" to="s.whatsapp.net" id="1416174955-ping">
        //     </iq>
        //     
        public class PingIqProtocolEntity
            : IqProtocolEntity {
            
            public PingIqProtocolEntity(object _from = null, object to = null, object _id = null)
                : base(_id: _id, _type: "get", _from: _from, to: to) {
            }
        }
    }
}
