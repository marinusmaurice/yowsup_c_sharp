namespace yowsup.layers.protocol_iq.protocolentities {
    
    using IqProtocolEntityTest = yowsup.layers.protocol_iq.protocolentities.test_iq.IqProtocolEntityTest;
    
    public static class test_iq_result {
        
        public class ResultIqProtocolEntityTest
            : IqProtocolEntityTest {
            
            public virtual object setUp() {
                super(ResultIqProtocolEntityTest, this).setUp();
                this.node.setAttribute("type", "result");
            }
        }
    }
}
