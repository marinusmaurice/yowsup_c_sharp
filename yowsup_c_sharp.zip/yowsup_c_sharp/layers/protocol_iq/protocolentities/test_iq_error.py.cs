namespace yowsup.layers.protocol_iq.protocolentities {
    
    using IqProtocolEntityTest = yowsup.layers.protocol_iq.protocolentities.test_iq.IqProtocolEntityTest;
    
    using ErrorIqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.ErrorIqProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using System.Collections.Generic;
    
    public static class test_iq_error {
        
        public class ErrorIqProtocolEntityTest
            : IqProtocolEntityTest {
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(ErrorIqProtocolEntityTest, this).setUp();
                this.ProtocolEntity = ErrorIqProtocolEntity;
                var errorNode = ProtocolTreeNode("error", new Dictionary<object, object> {
                    {
                        "code",
                        "123"},
                    {
                        "text",
                        "abc"}});
                this.node.addChild(errorNode);
            }
        }
    }
}
