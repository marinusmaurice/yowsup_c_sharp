namespace yowsup.layers.protocol_iq.protocolentities {
    
    using IqProtocolEntity = iq.IqProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    public static class iq_props {
        
        public class PropsIqProtocolEntity
            : IqProtocolEntity {
            
            public PropsIqProtocolEntity()
                : base(_type: "get") {
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(PropsIqProtocolEntity, this).toProtocolTreeNode();
                node.addChild(ProtocolTreeNode("props"));
                return node;
            }
        }
    }
}
