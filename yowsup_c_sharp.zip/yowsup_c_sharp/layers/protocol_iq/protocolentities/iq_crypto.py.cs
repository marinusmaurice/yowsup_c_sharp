namespace yowsup.layers.protocol_iq.protocolentities {
    
    using IqProtocolEntity = iq.IqProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using System.Collections.Generic;
    
    public static class iq_crypto {
        
        public class CryptoIqProtocolEntity
            : IqProtocolEntity {
            
            public CryptoIqProtocolEntity()
                : base(_type: "get") {
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(CryptoIqProtocolEntity, this).toProtocolTreeNode();
                var cryptoNode = ProtocolTreeNode("crypto", new Dictionary<object, object> {
                    {
                        "action",
                        "create"}});
                var googleNode = ProtocolTreeNode("google", data: "fe5cf90c511fb899781bbed754577098e460d048312c8b36c11c91ca4b49ca34".decode("hex"));
                cryptoNode.addChild(googleNode);
                node.addChild(cryptoNode);
                return node;
            }
        }
    }
}
