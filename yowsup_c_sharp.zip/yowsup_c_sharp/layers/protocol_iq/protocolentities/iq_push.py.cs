namespace yowsup.layers.protocol_iq.protocolentities {
    
    using IqProtocolEntity = iq.IqProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    public static class iq_push {
        
        public class PushIqProtocolEntity
            : IqProtocolEntity {
            
            public PushIqProtocolEntity()
                : base(_type: "get") {
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(PushIqProtocolEntity, this).toProtocolTreeNode();
                node.addChild(ProtocolTreeNode("config"));
                return node;
            }
        }
    }
}
