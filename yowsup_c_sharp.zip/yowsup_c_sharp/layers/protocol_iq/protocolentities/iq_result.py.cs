namespace yowsup.layers.protocol_iq.protocolentities
{

    using IqProtocolEntity = iq.IqProtocolEntity;

    public static class iq_result {
        
        // 
        //     <iq type="result" id="{{id}}" from="{{FROM}}">
        //     </iq>
        //     
        public class ResultIqProtocolEntity
            : IqProtocolEntity {
            
            public ResultIqProtocolEntity(object xmlns = null, object _id = null, object to = null, object _from = null)
                : base(_id: _id, _type: "result", to: to, _from: _from) {
            }
        }
    }
}
