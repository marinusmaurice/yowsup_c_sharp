namespace yowsup.layers.protocol_iq.protocolentities
{

    using ResultIqProtocolEntity = iq_result.ResultIqProtocolEntity;

    public static class iq_result_pong {
        
        // 
        //     <iq type="result" xmlns="w:p" to="self.domain" id="1416174955-ping">
        //     </iq>
        //     
        public class PongResultIqProtocolEntity
            : ResultIqProtocolEntity {
            
            public PongResultIqProtocolEntity(object to, object _id = null)
                : base(_id: _id, to: to) {
            }
        }
    }
}
