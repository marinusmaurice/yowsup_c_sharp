namespace yowsup.layers.protocol_iq.protocolentities
{

    public static class @__init__ {
    }
}
