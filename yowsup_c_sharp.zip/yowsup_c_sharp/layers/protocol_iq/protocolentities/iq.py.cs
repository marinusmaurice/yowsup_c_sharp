namespace yowsup.layers.protocol_iq.protocolentities
{

    using ProtocolEntity = yowsup.structs.ProtocolEntity;

    using System;

    using System.Diagnostics;

    using System.Collections.Generic;

    public static class iq {
        
        // 
        //     <iq type="{{get | set}}" id="{{id}}" xmlns="{{xmlns}}" to="{{TO}}" from="{{FROM}}">
        //     </iq>
        //     
        public class IqProtocolEntity
            : ProtocolEntity {
            
            public object _from;
            
            public object _id;
            
            public object _type;
            
            public object to;
            
            public string TYPE_ERROR;
            
            public string TYPE_GET;
            
            public string TYPE_RESULT;
            
            public string TYPE_SET;
            
            public Tuple<string, string, string, string> TYPES;
            
            public object xmlns;
            
            public string TYPE_SET = "set";
            
            public string TYPE_GET = "get";
            
            public string TYPE_ERROR = "error";
            
            public string TYPE_RESULT = "result";
            
            public Tuple<string, string, string, string> TYPES = (TYPE_SET, TYPE_GET, TYPE_RESULT, TYPE_ERROR);
            
            public IqProtocolEntity(
                object xmlns = null,
                object _id = null,
                object _type = null,
                object to = null,
                object _from = null) {
                Debug.Assert(this.@__class__.TYPES.Contains(_type));
                Debug.Assert(String.Format("Iq of type %s is not implemented, can accept only (%s)", _type, " | ".join(this.@__class__.TYPES)));
                Debug.Assert(!to || !_from);
                Debug.Assert("Can't set from and to at the same time");
                this._id = _id == null ? this._generateId(true) : _id;
                this._from = _from;
                this._type = _type;
                this.xmlns = xmlns;
                this.to = to;
            }
            
            public virtual object getId() {
                return this._id;
            }
            
            public virtual object getType() {
                return this._type;
            }
            
            public virtual object getXmlns() {
                return this.xmlns;
            }
            
            public virtual object getFrom(object full = true) {
                return full ? this._from : this._from.split("@")[0];
            }
            
            public virtual object getTo() {
                return this.to;
            }
            
            public virtual object toProtocolTreeNode() {
                var attribs = new Dictionary<object, object> {
                    {
                        "id",
                        this._id},
                    {
                        "type",
                        this._type}};
                if (this.xmlns) {
                    attribs["xmlns"] = this.xmlns;
                }
                if (this.to) {
                    attribs["to"] = this.to;
                } else if (this._from) {
                    attribs["from"] = this._from;
                }
                return this._createProtocolTreeNode(attribs, null, data: null);
            }
            
            public override object ToString() {
                var @out = "Iq:\n";
                @out += String.Format("ID: %s\n", this._id);
                @out += String.Format("Type: %s\n", this._type);
                if (this.xmlns) {
                    @out += String.Format("xmlns: %s\n", this.xmlns);
                }
                if (this.to) {
                    @out += String.Format("to: %s\n", this.to);
                } else if (this._from) {
                    @out += String.Format("from: %s\n", this._from);
                }
                return @out;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                return new IqProtocolEntity(node.getAttributeValue("xmlns"), node.getAttributeValue("id"), node.getAttributeValue("type"), node.getAttributeValue("to"), node.getAttributeValue("from"));
            }
        }
    }
}
