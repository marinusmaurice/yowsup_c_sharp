namespace yowsup.layers.protocol_iq
{

    public static class @__init__ {
    }
}
