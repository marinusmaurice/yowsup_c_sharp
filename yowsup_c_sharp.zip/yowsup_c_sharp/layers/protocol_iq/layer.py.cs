namespace yowsup.layers.protocol_iq
{

    using Thread = threading.Thread;

    using Lock = threading.Lock;

    using YowProtocolLayer = yowsup.layers.YowProtocolLayer;

    using EventCallback = yowsup.layers.EventCallback;

    using YowConstants = yowsup.common.YowConstants;

    using YowNetworkLayer = yowsup.layers.network.YowNetworkLayer;

    using YowAuthenticationProtocolLayer = yowsup.layers.auth.YowAuthenticationProtocolLayer;

    using System.Collections.Generic;

    using System;

    using System.Diagnostics;

    using System.Linq;

    public static class layer {
        
        public class YowIqProtocolLayer
            : YowProtocolLayer {
            
            public object @__logger;
            
            public string @__name__;
            
            public Dictionary<object, object> _pingQueue;
            
            public object _pingQueueLock;
            
            public None _pingThread;
            
            public string PROP_PING_INTERVAL;
            
            public string PROP_PING_INTERVAL = "org.openwhatsapp.yowsup.prop.pinginterval";
            
            public YowIqProtocolLayer() {
                var handleMap = new Dictionary<object, object> {
                    {
                        "iq",
                        (this.recvIq, this.sendIq)}};
                this._pingThread = null;
                this._pingQueue = new Dictionary<object, object> {
                };
                this._pingQueueLock = Lock();
                this.@__logger = logging.getLogger(@__name__);
                super(YowIqProtocolLayer, this).@__init__(handleMap);
            }
            
            public override object ToString() {
                return "Iq Layer";
            }
            
            public virtual object onPong(object protocolTreeNode, object pingEntity) {
                this.gotPong(pingEntity.getId());
                this.toUpper(ResultIqProtocolEntity.fromProtocolTreeNode(protocolTreeNode));
            }
            
            public virtual object sendIq(object entity) {
                if (entity.getXmlns() == "w:p") {
                    this._sendIq(entity, this.onPong);
                } else if (("urn:xmpp:whatsapp:push", "w", "urn:xmpp:whatsapp:account", "encrypt").Contains(entity.getXmlns())) {
                    this.toLower(entity.toProtocolTreeNode());
                }
            }
            
            public virtual object recvIq(object node) {
                if (node["xmlns"] == "urn:xmpp:ping") {
                    var entity = PongResultIqProtocolEntity(YowConstants.DOMAIN, node["id"]);
                    this.toLower(entity.toProtocolTreeNode());
                }
            }
            
            public virtual object gotPong(object pingId) {
                this._pingQueueLock.acquire();
                if (this._pingQueue.Contains(pingId)) {
                    this._pingQueue = new Dictionary<object, object> {
                    };
                }
                this._pingQueueLock.release();
            }
            
            public virtual object waitPong(object id) {
                this._pingQueueLock.acquire();
                this._pingQueue[id] = null;
                var pingQueueSize = this._pingQueue.Count;
                this._pingQueueLock.release();
                this.@__logger.debug(String.Format("ping queue size: %d", pingQueueSize));
                if (pingQueueSize >= 2) {
                    this.getStack().boadcastEvent(YowLayerEvent(YowNetworkLayer.EVENT_STATE_DISCONNECT, reason: "Ping Timeout"));
                }
            }
            
            [EventCallback(YowAuthenticationProtocolLayer.EVENT_AUTHED)]
            public virtual object onAuthed(object @event) {
                var interval = this.getProp(this.@__class__.PROP_PING_INTERVAL, 50);
                if (!this._pingThread && interval > 0) {
                    this._pingQueue = new Dictionary<object, object> {
                    };
                    this._pingThread = new YowPingThread(this, interval);
                    this.@__logger.debug("starting ping thread.");
                    this._pingThread.start();
                }
            }
            
            public virtual object stop_thread() {
                if (this._pingThread) {
                    this.@__logger.debug("stopping ping thread");
                    if (this._pingThread) {
                        this._pingThread.stop();
                        this._pingThread = null;
                    }
                    this._pingQueue = new Dictionary<object, object> {
                    };
                }
            }
            
            [EventCallback(YowNetworkLayer.EVENT_STATE_DISCONNECT)]
            public virtual object onDisconnect(object @event) {
                this.stop_thread();
            }
            
            [EventCallback(YowNetworkLayer.EVENT_STATE_DISCONNECTED)]
            public virtual object onDisconnected(object @event) {
                this.stop_thread();
            }
        }
        
        public class YowPingThread
            : Thread {
            
            public object @__logger;
            
            public string @__name__;
            
            public object _interval;
            
            public object _layer;
            
            public bool _stop;
            
            public bool daemon;
            
            public string name;
            
            public YowPingThread(object layer, object interval) {
                Debug.Assert(object.ReferenceEquals(type(layer), YowIqProtocolLayer));
                Debug.Assert(String.Format("layer must be a YowIqProtocolLayer, got %s instead.", type(layer)));
                this._layer = layer;
                this._interval = interval;
                this._stop = false;
                this.@__logger = logging.getLogger(@__name__);
                super(YowPingThread, this).@__init__();
                this.daemon = true;
                this.name = String.Format("YowPing%s", this.name);
            }
            
            public virtual object run() {
                while (!this._stop) {
                    foreach (var i in Enumerable.Range(0, this._interval - 0)) {
                        time.sleep(1);
                        if (this._stop) {
                            this.@__logger.debug(String.Format("%s - ping thread stopped", this.name));
                            return;
                        }
                    }
                    var ping = PingIqProtocolEntity();
                    this._layer.waitPong(ping.getId());
                    if (!this._stop) {
                        this._layer.sendIq(ping);
                    }
                }
            }
            
            public virtual object stop() {
                this._stop = true;
            }
        }
    }
}
