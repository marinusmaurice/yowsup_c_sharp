namespace yowsup.layers.protocol_media
{

    public static class @__init__ {
    }
}
