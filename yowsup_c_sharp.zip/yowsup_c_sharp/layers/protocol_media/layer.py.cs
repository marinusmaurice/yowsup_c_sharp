namespace yowsup.layers.protocol_media
{

    using YowProtocolLayer = yowsup.layers.YowProtocolLayer;

    using ImageDownloadableMediaMessageProtocolEntity = protocolentities.ImageDownloadableMediaMessageProtocolEntity;

    using AudioDownloadableMediaMessageProtocolEntity = protocolentities.AudioDownloadableMediaMessageProtocolEntity;

    using VideoDownloadableMediaMessageProtocolEntity = protocolentities.VideoDownloadableMediaMessageProtocolEntity;

    using DocumentDownloadableMediaMessageProtocolEntity = protocolentities.DocumentDownloadableMediaMessageProtocolEntity;

    using StickerDownloadableMediaMessageProtocolEntity = protocolentities.StickerDownloadableMediaMessageProtocolEntity;

    using LocationMediaMessageProtocolEntity = protocolentities.LocationMediaMessageProtocolEntity;

    using ContactMediaMessageProtocolEntity = protocolentities.ContactMediaMessageProtocolEntity;

    using ResultRequestUploadIqProtocolEntity = protocolentities.ResultRequestUploadIqProtocolEntity;

    using MediaMessageProtocolEntity = protocolentities.MediaMessageProtocolEntity;

    using ExtendedTextMediaMessageProtocolEntity = protocolentities.ExtendedTextMediaMessageProtocolEntity;

    using IqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.IqProtocolEntity;

    using ErrorIqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.ErrorIqProtocolEntity;

    using System.Collections.Generic;

    using System;

    public static class layer {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class YowMediaProtocolLayer
            : YowProtocolLayer {
            
            public YowMediaProtocolLayer() {
                var handleMap = new Dictionary<object, object> {
                    {
                        "message",
                        (this.recvMessageStanza, this.sendMessageEntity)},
                    {
                        "iq",
                        (this.recvIq, this.sendIq)}};
                super(YowMediaProtocolLayer, this).@__init__(handleMap);
            }
            
            public override object ToString() {
                return "Media Layer";
            }
            
            public virtual object sendMessageEntity(object entity) {
                if (entity.getType() == "media") {
                    this.entityToLower(entity);
                }
            }
            
            public virtual object recvMessageStanza(object node) {
                object entity;
                if (node.getAttributeValue("type") == "media") {
                    var mediaNode = node.getChild("proto");
                    if (mediaNode.getAttributeValue("mediatype") == "image") {
                        entity = ImageDownloadableMediaMessageProtocolEntity.fromProtocolTreeNode(node);
                        this.toUpper(entity);
                    } else if (mediaNode.getAttributeValue("mediatype") == "sticker") {
                        entity = StickerDownloadableMediaMessageProtocolEntity.fromProtocolTreeNode(node);
                        this.toUpper(entity);
                    } else if (("audio", "ptt").Contains(mediaNode.getAttributeValue("mediatype"))) {
                        entity = AudioDownloadableMediaMessageProtocolEntity.fromProtocolTreeNode(node);
                        this.toUpper(entity);
                    } else if (("video", "gif").Contains(mediaNode.getAttributeValue("mediatype"))) {
                        entity = VideoDownloadableMediaMessageProtocolEntity.fromProtocolTreeNode(node);
                        this.toUpper(entity);
                    } else if (mediaNode.getAttributeValue("mediatype") == "location") {
                        entity = LocationMediaMessageProtocolEntity.fromProtocolTreeNode(node);
                        this.toUpper(entity);
                    } else if (mediaNode.getAttributeValue("mediatype") == "contact") {
                        entity = ContactMediaMessageProtocolEntity.fromProtocolTreeNode(node);
                        this.toUpper(entity);
                    } else if (mediaNode.getAttributeValue("mediatype") == "document") {
                        entity = DocumentDownloadableMediaMessageProtocolEntity.fromProtocolTreeNode(node);
                        this.toUpper(entity);
                    } else if (mediaNode.getAttributeValue("mediatype") == "url") {
                        entity = ExtendedTextMediaMessageProtocolEntity.fromProtocolTreeNode(node);
                        this.toUpper(entity);
                    } else {
                        logger.warn(String.Format("Unsupported mediatype: %s, will send receipts", mediaNode.getAttributeValue("mediatype")));
                        this.toLower(MediaMessageProtocolEntity.fromProtocolTreeNode(node).ack(true).toProtocolTreeNode());
                    }
                }
            }
            
            // 
            //         :type entity: IqProtocolEntity
            //         
            public virtual object sendIq(object entity) {
                if (entity.getType() == IqProtocolEntity.TYPE_SET && entity.getXmlns() == "w:m") {
                    //media upload!
                    this._sendIq(entity, this.onRequestUploadSuccess, this.onRequestUploadError);
                }
            }
            
            // 
            //         :type node: ProtocolTreeNode
            //         
            public virtual object recvIq(object node) {
            }
            
            public virtual object onRequestUploadSuccess(object resultNode, object requestUploadEntity) {
                this.toUpper(ResultRequestUploadIqProtocolEntity.fromProtocolTreeNode(resultNode));
            }
            
            public virtual object onRequestUploadError(object errorNode, object requestUploadEntity) {
                this.toUpper(ErrorIqProtocolEntity.fromProtocolTreeNode(errorNode));
            }
        }
    }
}
