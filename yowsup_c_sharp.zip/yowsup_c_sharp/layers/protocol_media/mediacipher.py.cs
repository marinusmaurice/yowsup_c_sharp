namespace yowsup.layers.protocol_media
{

    using HKDFv3 = axolotl.kdf.hkdfv3.HKDFv3;

    using ByteUtil = axolotl.util.byteutil.ByteUtil;

    using Cipher = cryptography.hazmat.primitives.ciphers.Cipher;

    using algorithms = cryptography.hazmat.primitives.ciphers.algorithms;

    using modes = cryptography.hazmat.primitives.ciphers.modes;

    using default_backend = cryptography.hazmat.backends.default_backend;

    using padding = cryptography.hazmat.primitives.padding;

    public static class mediacipher {
        
        public class MediaCipher
            : object {
            
            public string INFO_AUDIO;
            
            public string INFO_DOCUM;
            
            public string INFO_IMAGE;
            
            public string INFO_VIDEO;
            
            public string INFO_IMAGE = new byte[] { (byte)'W', (byte)'h', (byte)'a', (byte)'t', (byte)'s', (byte)'A', (byte)'p', (byte)'p', (byte)' ', (byte)'I', (byte)'m', (byte)'a', (byte)'g', (byte)'e', (byte)' ', (byte)'K', (byte)'e', (byte)'y', (byte)'s' };
            
            public string INFO_AUDIO = new byte[] { (byte)'W', (byte)'h', (byte)'a', (byte)'t', (byte)'s', (byte)'A', (byte)'p', (byte)'p', (byte)' ', (byte)'A', (byte)'u', (byte)'d', (byte)'i', (byte)'o', (byte)' ', (byte)'K', (byte)'e', (byte)'y', (byte)'s' };
            
            public string INFO_VIDEO = new byte[] { (byte)'W', (byte)'h', (byte)'a', (byte)'t', (byte)'s', (byte)'A', (byte)'p', (byte)'p', (byte)' ', (byte)'V', (byte)'i', (byte)'d', (byte)'e', (byte)'o', (byte)' ', (byte)'K', (byte)'e', (byte)'y', (byte)'s' };
            
            public string INFO_DOCUM = new byte[] { (byte)'W', (byte)'h', (byte)'a', (byte)'t', (byte)'s', (byte)'A', (byte)'p', (byte)'p', (byte)' ', (byte)'D', (byte)'o', (byte)'c', (byte)'u', (byte)'m', (byte)'e', (byte)'n', (byte)'t', (byte)' ', (byte)'K', (byte)'e', (byte)'y', (byte)'s' };
            
            public virtual object encrypt_image(object plaintext, object ref_key) {
                return this.encrypt(plaintext, ref_key, this.INFO_IMAGE);
            }
            
            public virtual object encrypt_audio(object ciphertext, object ref_key) {
                return this.encrypt(ciphertext, ref_key, this.INFO_AUDIO);
            }
            
            public virtual object encrypt_video(object ciphertext, object ref_key) {
                return this.encrypt(ciphertext, ref_key, this.INFO_VIDEO);
            }
            
            public virtual object encrypt_document(object ciphertext, object ref_key) {
                return this.encrypt(ciphertext, ref_key, this.INFO_DOCUM);
            }
            
            public virtual object decrypt_image(object ciphertext, object ref_key) {
                return this.decrypt(ciphertext, ref_key, this.INFO_IMAGE);
            }
            
            public virtual object decrypt_audio(object ciphertext, object ref_key) {
                return this.decrypt(ciphertext, ref_key, this.INFO_AUDIO);
            }
            
            public virtual object decrypt_video(object ciphertext, object ref_key) {
                return this.decrypt(ciphertext, ref_key, this.INFO_VIDEO);
            }
            
            public virtual object decrypt_document(object ciphertext, object ref_key) {
                return this.decrypt(ciphertext, ref_key, this.INFO_DOCUM);
            }
            
            public virtual object encrypt(object plaintext, object ref_key, object media_info) {
                object padded_plaintext;
                var derived = HKDFv3().deriveSecrets(ref_key, media_info, 112);
                var parts = ByteUtil.split(derived, 16, 32);
                var iv = parts[0];
                var key = parts[1];
                var mac_key = derived[48::80];
                var cipher_encryptor = Cipher(algorithms.AES(key), modes.CBC(iv), backend: default_backend()).encryptor();
                if (plaintext.Count % 16 != 0) {
                    var padder = padding.PKCS7(128).padder();
                    padded_plaintext = padder.update(plaintext) + padder.finalize();
                } else {
                    padded_plaintext = plaintext;
                }
                var ciphertext = cipher_encryptor.update(padded_plaintext) + cipher_encryptor.finalize();
                var mac = hmac.@new(mac_key, digestmod: hashlib.sha256);
                mac.update(iv);
                mac.update(ciphertext);
                return ciphertext + mac.digest()[::10];
            }
            
            public virtual object decrypt(object ciphertext, object ref_key, object media_info) {
                var derived = HKDFv3().deriveSecrets(ref_key, media_info, 112);
                var parts = ByteUtil.split(derived, 16, 32);
                var iv = parts[0];
                var key = parts[1];
                var mac_key = derived[48::80];
                var media_ciphertext = ciphertext[:: - 10];
                var mac_value = ciphertext[-10];
                var mac = hmac.@new(mac_key, digestmod: hashlib.sha256);
                mac.update(iv);
                mac.update(media_ciphertext);
                if (mac_value != mac.digest()[::10]) {
                    throw new ValueError("Invalid MAC");
                }
                var cipher_decryptor = Cipher(algorithms.AES(key), modes.CBC(iv), backend: default_backend()).decryptor();
                var decrypted = cipher_decryptor.update(media_ciphertext) + cipher_decryptor.finalize();
                var unpadder = padding.PKCS7(128).unpadder();
                return unpadder.update(decrypted) + unpadder.finalize();
            }
        }
    }
}
