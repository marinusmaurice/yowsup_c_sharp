namespace yowsup.layers.protocol_media
{

    using WARequest = yowsup.common.http.warequest.WARequest;

    using sleep = time.sleep;

    using MimeTools = yowsup.common.tools.MimeTools;

    using System.Collections.Generic;

    using System;

    public static class mediauploader {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class MediaUploader
            : WARequest, threading.Thread {
            
            public object accountJid;
            
            public object asynchronous;
            
            public object errorCallback;
            
            public object jid;
            
            public object progressCallback;
            
            public List<string> pvars;
            
            public object resumeOffset;
            
            public object sock;
            
            public object sourcePath;
            
            public object successCallback;
            
            public object uploadUrl;
            
            public object url;
            
            public MediaUploader(
                object jid,
                object accountJid,
                object sourcePath,
                object uploadUrl,
                object resumeOffset = 0,
                object successClbk = null,
                object errorClbk = null,
                object progressCallback = null,
                object asynchronous = true) {
                this.asynchronous = asynchronous;
                this.jid = jid;
                this.accountJid = accountJid;
                this.sourcePath = sourcePath;
                this.uploadUrl = uploadUrl;
                this.resumeOffset = resumeOffset;
                this.successCallback = successClbk;
                this.errorCallback = errorClbk;
                this.progressCallback = progressCallback;
                this.pvars = new List<string> {
                    "name",
                    "type",
                    "size",
                    "url",
                    "error",
                    "mimetype",
                    "filehash",
                    "width",
                    "height"
                };
                this.setParser(JSONResponseParser());
                this.sock = socket.socket();
            }
            
            public virtual object start() {
                if (this.asynchronous) {
                    threading.Thread.@__init__(this);
                    super(MediaUploader, this).start();
                } else {
                    this.run();
                }
            }
            
            public virtual object run() {
                var sourcePath = this.sourcePath;
                var uploadUrl = this.uploadUrl;
                var _host = uploadUrl.replace("https://", "");
                this.url = _host[::_host.index("/")];
                try {
                    var filename = os.path.basename(sourcePath);
                    var filetype = MimeTools.getMIME(filename);
                    var filesize = os.path.getsize(sourcePath);
                    this.sock.connect((this.url, this.port));
                    var ssl_sock = ssl.wrap_socket(this.sock);
                    var m = hashlib.md5();
                    m.update(filename.encode());
                    var crypto = m.hexdigest() + os.path.splitext(filename)[1];
                    var boundary = "zzXXzzYYzzXXzzQQ";
                    var contentLength = 0;
                    var hBAOS = "--" + boundary + "\r\n";
                    hBAOS += "Content-Disposition: form-data; name=\"to\"\r\n\r\n";
                    hBAOS += this.jid + "\r\n";
                    hBAOS += "--" + boundary + "\r\n";
                    hBAOS += "Content-Disposition: form-data; name=\"from\"\r\n\r\n";
                    hBAOS += this.accountJid.replace("@whatsapp.net", "") + "\r\n";
                    hBAOS += "--" + boundary + "\r\n";
                    hBAOS += "Content-Disposition: form-data; name=\"file\"; filename=\"" + crypto + "\"\r\n";
                    hBAOS += "Content-Type: " + filetype + "\r\n\r\n";
                    var fBAOS = "\r\n--" + boundary + "--\r\n";
                    contentLength += hBAOS.Count;
                    contentLength += fBAOS.Count;
                    contentLength += filesize;
                    var POST = String.Format("POST %s\r\n", uploadUrl);
                    POST += "Content-Type: multipart/form-data; boundary=" + boundary + "\r\n";
                    POST += String.Format("Host: %s\r\n", this.url);
                    POST += String.Format("User-Agent: %s\r\n", this.getUserAgent());
                    POST += "Content-Length: " + contentLength.ToString() + "\r\n\r\n";
                    ssl_sock.write(bytearray(POST.encode()));
                    ssl_sock.write(bytearray(hBAOS.encode()));
                    var totalsent = 0;
                    var buf = 1024;
                    var f = open(sourcePath, "rb");
                    var stream = f.read();
                    f.close();
                    var status = 0;
                    var lastEmit = 0;
                    while (totalsent < Convert.ToInt32(filesize)) {
                        ssl_sock.write(stream[::buf]);
                        status = totalsent * 100 / filesize;
                        if (lastEmit != status && status != 100 && filesize > 12288) {
                            if (this.progressCallback) {
                                this.progressCallback(this.sourcePath, this.jid, uploadUrl, Convert.ToInt32(status));
                            }
                        }
                        lastEmit = status;
                        stream = stream[buf];
                        totalsent = totalsent + buf;
                    }
                    ssl_sock.write(bytearray(fBAOS.encode()));
                    sleep(1);
                    var data = ssl_sock.recv(8192);
                    data += ssl_sock.recv(8192);
                    data += ssl_sock.recv(8192);
                    data += ssl_sock.recv(8192);
                    data += ssl_sock.recv(8192);
                    data += ssl_sock.recv(8192);
                    data += ssl_sock.recv(8192);
                    if (this.progressCallback) {
                        this.progressCallback(this.sourcePath, this.jid, uploadUrl, 100);
                    }
                    var lines = data.decode().splitlines();
                    object result = null;
                    foreach (var l in lines) {
                        if (l.startswith("{")) {
                            result = this.parser.parse(l, this.pvars);
                            beak;
                        }
                    }
                    if (!result) {
                        throw new Exception("json data not found");
                    }
                    if (result["url"] != null) {
                        if (this.successCallback) {
                            this.successCallback(sourcePath, this.jid, result["url"]);
                        }
                    } else {
                        logger.exception(String.Format("uploadUrl: %s, result of uploading media has no url", uploadUrl));
                        if (this.errorCallback) {
                            this.errorCallback(sourcePath, this.jid, uploadUrl);
                        }
                    }
                } catch {
                    logger.exception(String.Format("Error occured at transfer %s", sys.exc_info()[1]));
                    if (this.errorCallback) {
                        this.errorCallback(sourcePath, this.jid, uploadUrl);
                    }
                }
            }
        }
    }
}
