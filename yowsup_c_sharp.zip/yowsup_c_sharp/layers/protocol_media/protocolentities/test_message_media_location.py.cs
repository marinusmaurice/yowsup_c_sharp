namespace yowsup.layers.protocol_media.protocolentities {
    
    using MediaMessageProtocolEntityTest = yowsup.layers.protocol_media.protocolentities.test_message_media.MediaMessageProtocolEntityTest;
    
    using LocationMediaMessageProtocolEntity = yowsup.layers.protocol_media.protocolentities.LocationMediaMessageProtocolEntity;
    
    using Message = yowsup.layers.protocol_messages.proto.e2e_pb2.Message;
    
    public static class test_message_media_location {
        
        public class LocationMediaMessageProtocolEntityTest
            : MediaMessageProtocolEntityTest {
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(LocationMediaMessageProtocolEntityTest, this).setUp();
                this.ProtocolEntity = LocationMediaMessageProtocolEntity;
                var m = Message();
                var location_message = Message.LocationMessage();
                location_message.degrees_latitude = 30.089037;
                location_message.degrees_longitude = 31.319488;
                location_message.name = "kaos";
                location_message.url = "kaos_url";
                m.location_message.MergeFrom(location_message);
                var proto_node = this.node.getChild("proto");
                proto_node["mediatype"] = "location";
                proto_node.setData(m.SerializeToString());
            }
        }
    }
}
