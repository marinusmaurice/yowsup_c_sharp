namespace yowsup.layers.protocol_media.protocolentities
{

    using DownloadableMediaMessageProtocolEntity = message_media_downloadable.DownloadableMediaMessageProtocolEntity;

    public static class message_media_downloadable_image {
        
        public class ImageDownloadableMediaMessageProtocolEntity
            : DownloadableMediaMessageProtocolEntity {
            
            public ImageDownloadableMediaMessageProtocolEntity(object image_attrs, object message_meta_attrs) {
                // type: (ImageAttributes, MessageMetaAttributes) -> None
                super(ImageDownloadableMediaMessageProtocolEntity, this).@__init__("image", MessageAttributes(image: image_attrs), message_meta_attrs);
            }
            
            public object media_specific_attributes {
                get {
                    return this.message_attributes.image;
                }
            }
            
            public object downloadablemedia_specific_attributes {
                get {
                    return this.message_attributes.image.downloadablemedia_attributes;
                }
            }
            
            public object width {
                get {
                    return this.media_specific_attributes.width;
                }
                set {
                    this.media_specific_attributes.width = value;
                }
            }
            
            public object height {
                get {
                    return this.media_specific_attributes.height;
                }
                set {
                    this.media_specific_attributes.height = value;
                }
            }
            
            public object jpeg_thumbnail {
                get {
                    return this.media_specific_attributes.jpeg_thumbnail;
                }
                set {
                    this.media_specific_attributes.jpeg_thumbnail = value != null ? value : "";
                }
            }
            
            public object caption {
                get {
                    return this.media_specific_attributes.caption;
                }
                set {
                    this.media_specific_attributes.caption = value != null ? value : "";
                }
            }
        }
    }
}
