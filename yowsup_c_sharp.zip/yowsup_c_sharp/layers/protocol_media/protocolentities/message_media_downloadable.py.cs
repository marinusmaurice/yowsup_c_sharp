namespace yowsup.layers.protocol_media.protocolentities
{

    using MediaMessageProtocolEntity = message_media.MediaMessageProtocolEntity;

    using System;

    public static class message_media_downloadable {
        
        public class DownloadableMediaMessageProtocolEntity
            : MediaMessageProtocolEntity {
            
            public DownloadableMediaMessageProtocolEntity(object media_type, object message_attrs, object message_meta_attrs) {
                // type: (str, MessageAttributes, MessageMetaAttributes) -> None
                super(DownloadableMediaMessageProtocolEntity, this).@__init__(media_type, message_attrs, message_meta_attrs);
            }
            
            public object downloadablemedia_specific_attributes {
                get {
                    throw new NotImplementedException();
                }
            }
            
            public object url {
                get {
                    return this.downloadablemedia_specific_attributes.url;
                }
                set {
                    this.downloadablemedia_specific_attributes.url = value;
                }
            }
            
            public object mimetype {
                get {
                    return this.downloadablemedia_specific_attributes.mimetype;
                }
                set {
                    this.downloadablemedia_specific_attributes.mimetype = value;
                }
            }
            
            public object file_sha256 {
                get {
                    return this.downloadablemedia_specific_attributes.file_sha256;
                }
                set {
                    this.downloadablemedia_specific_attributes.file_sha256 = value;
                }
            }
            
            public object file_length {
                get {
                    return this.downloadablemedia_specific_attributes.file_length;
                }
                set {
                    this.downloadablemedia_specific_attributes.file_length = value;
                }
            }
            
            public object media_key {
                get {
                    return this.downloadablemedia_specific_attributes.media_key;
                }
                set {
                    this.downloadablemedia_specific_attributes.media_key = value;
                }
            }
        }
    }
}
