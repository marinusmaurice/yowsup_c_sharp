namespace yowsup.layers.protocol_media.protocolentities
{

    using DownloadableMediaMessageProtocolEntity = message_media_downloadable.DownloadableMediaMessageProtocolEntity;

    public static class message_media_downloadable_video {
        
        public class VideoDownloadableMediaMessageProtocolEntity
            : DownloadableMediaMessageProtocolEntity {
            
            public VideoDownloadableMediaMessageProtocolEntity(object video_attrs, object message_meta_attrs) {
                // type: (VideoAttributes, MessageMetaAttributes) -> None
                super(VideoDownloadableMediaMessageProtocolEntity, this).@__init__("video", MessageAttributes(video: video_attrs), message_meta_attrs);
            }
            
            public object media_specific_attributes {
                get {
                    return this.message_attributes.video;
                }
            }
            
            public object downloadablemedia_specific_attributes {
                get {
                    return this.message_attributes.video.downloadablemedia_attributes;
                }
            }
            
            public object width {
                get {
                    return this.media_specific_attributes.width;
                }
                set {
                    this.media_specific_attributes.width = value;
                }
            }
            
            public object height {
                get {
                    return this.media_specific_attributes.height;
                }
                set {
                    this.media_specific_attributes.height = value;
                }
            }
            
            public object seconds {
                get {
                    return this.media_specific_attributes.seconds;
                }
                set {
                    this.media_specific_attributes.seconds = value;
                }
            }
            
            public object gif_playback {
                get {
                    return this.media_specific_attributes.gif_playback;
                }
                set {
                    this.media_specific_attributes.gif_playback = value;
                }
            }
            
            public object jpeg_thumbnail {
                get {
                    return this.media_specific_attributes.jpeg_thumbnail;
                }
                set {
                    this.media_specific_attributes.jpeg_thumbnail = value;
                }
            }
            
            public object caption {
                get {
                    return this.media_specific_attributes.caption;
                }
                set {
                    this.media_specific_attributes.caption = value;
                }
            }
            
            public object gif_attribution {
                get {
                    return this.proto.gif_attribution;
                }
                set {
                    this.media_specific_attributes.gif_attributions = value;
                }
            }
            
            public object streaming_sidecar {
                get {
                    return this.media_specific_attributes.streaming_sidecar;
                }
                set {
                    this.media_specific_attributes.streaming_sidecar = value;
                }
            }
        }
    }
}
