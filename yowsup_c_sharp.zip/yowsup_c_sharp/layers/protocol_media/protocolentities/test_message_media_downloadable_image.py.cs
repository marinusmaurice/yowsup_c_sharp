namespace yowsup.layers.protocol_media.protocolentities {
    
    using ImageDownloadableMediaMessageProtocolEntity = yowsup.layers.protocol_media.protocolentities.message_media_downloadable_image.ImageDownloadableMediaMessageProtocolEntity;
    
    using MediaMessageProtocolEntityTest = test_message_media.MediaMessageProtocolEntityTest;
    
    using Message = yowsup.layers.protocol_messages.proto.e2e_pb2.Message;
    
    public static class test_message_media_downloadable_image {
        
        public class ImageDownloadableMediaMessageProtocolEntityTest
            : MediaMessageProtocolEntityTest {
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(ImageDownloadableMediaMessageProtocolEntityTest, this).setUp();
                this.ProtocolEntity = ImageDownloadableMediaMessageProtocolEntity;
                var proto_node = this.node.getChild("proto");
                var m = Message();
                var media_message = Message.ImageMessage();
                media_message.url = "url";
                media_message.mimetype = "image/jpeg";
                media_message.caption = "caption";
                media_message.file_sha256 = new byte[] { (byte)'S', (byte)'H', (byte)'A', (byte)'2', (byte)'5', (byte)'6' };
                media_message.file_length = 123;
                media_message.height = 20;
                media_message.width = 20;
                media_message.media_key = new byte[] { (byte)'M', (byte)'E', (byte)'D', (byte)'I', (byte)'A', (byte)'_', (byte)'K', (byte)'E', (byte)'Y' };
                media_message.jpeg_thumbnail = new byte[] { (byte)'T', (byte)'H', (byte)'U', (byte)'M', (byte)'B', (byte)'N', (byte)'A', (byte)'I', (byte)'L' };
                m.image_message.MergeFrom(media_message);
                proto_node.setData(m.SerializeToString());
            }
        }
    }
}
