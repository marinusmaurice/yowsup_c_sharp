namespace yowsup.layers.protocol_media.protocolentities {
    
    using MediaMessageProtocolEntityTest = yowsup.layers.protocol_media.protocolentities.test_message_media.MediaMessageProtocolEntityTest;
    
    using ContactMediaMessageProtocolEntity = yowsup.layers.protocol_media.protocolentities.ContactMediaMessageProtocolEntity;
    
    using Message = yowsup.layers.protocol_messages.proto.e2e_pb2.Message;
    
    public static class test_message_media_contact {
        
        public class ContactMediaMessageProtocolEntityTest
            : MediaMessageProtocolEntityTest {
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(ContactMediaMessageProtocolEntityTest, this).setUp();
                this.ProtocolEntity = ContactMediaMessageProtocolEntity;
                var m = Message();
                var contact_message = Message.ContactMessage();
                contact_message.display_name = "abc";
                contact_message.vcard = new byte[] { (byte)'V', (byte)'C', (byte)'A', (byte)'R', (byte)'D', (byte)'_', (byte)'D', (byte)'A', (byte)'T', (byte)'A' };
                m.contact_message.MergeFrom(contact_message);
                var proto_node = this.node.getChild("proto");
                proto_node["mediatype"] = "contact";
                proto_node.setData(m.SerializeToString());
            }
        }
    }
}
