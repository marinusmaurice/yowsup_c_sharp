namespace yowsup.layers.protocol_media.protocolentities
{

    using DownloadableMediaMessageProtocolEntity = message_media_downloadable.DownloadableMediaMessageProtocolEntity;

    public static class message_media_downloadable_audio {
        
        public class AudioDownloadableMediaMessageProtocolEntity
            : DownloadableMediaMessageProtocolEntity {
            
            public AudioDownloadableMediaMessageProtocolEntity(object audio_attrs, object message_meta_attrs) {
                // type: (AudioAttributes, MessageMetaAttributes) -> None
                super(AudioDownloadableMediaMessageProtocolEntity, this).@__init__("audio", MessageAttributes(audio: audio_attrs), message_meta_attrs);
            }
            
            public object media_specific_attributes {
                get {
                    return this.message_attributes.audio;
                }
            }
            
            public object downloadablemedia_specific_attributes {
                get {
                    return this.message_attributes.audio.downloadablemedia_attributes;
                }
            }
            
            // 
            //         :type value: int
            //         
            public object seconds {
                get {
                    return this.media_specific_attributes.seconds;
                }
                set {
                    this.media_specific_attributes.seconds = value;
                }
            }
            
            // 
            //         :type value: bool
            //         
            public object ptt {
                get {
                    return this.media_specific_attributes.ptt;
                }
                set {
                    this.media_specific_attributes.ptt = value;
                }
            }
            
            public object streaming_sidecar {
                get {
                    return this.media_specific_attributes.streaming_sidecar;
                }
                set {
                    this.media_specific_attributes.streaming_sidecar = value;
                }
            }
        }
    }
}
