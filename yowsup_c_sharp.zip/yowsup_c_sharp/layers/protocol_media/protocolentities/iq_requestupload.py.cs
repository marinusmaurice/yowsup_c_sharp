namespace yowsup.layers.protocol_media.protocolentities
{

    using YowConstants = yowsup.common.YowConstants;

    using IqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.IqProtocolEntity;

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using WATools = yowsup.common.tools.WATools;

    using System;

    using System.Diagnostics;

    using System.Collections.Generic;

    public static class iq_requestupload {
        
        // 
        //     <iq to="s.whatsapp.net" type="set" xmlns="w:m">
        //         <media hash="{{b64_hash}}" type="{{type}}" size="{{size_bytes}}" orighash={{b64_orighash?}}></media>
        //     </iq>
        //     
        public class RequestUploadIqProtocolEntity
            : IqProtocolEntity {
            
            public object b64Hash;
            
            public string MEDIA_TYPE_AUDIO;
            
            public string MEDIA_TYPE_DOCUM;
            
            public string MEDIA_TYPE_IMAGE;
            
            public string MEDIA_TYPE_VIDEO;
            
            public object mediaType;
            
            public object origHash;
            
            public int size;
            
            public Tuple<string, string, string, string> TYPES_MEDIA;
            
            public string XMLNS;
            
            public string MEDIA_TYPE_IMAGE = "image";
            
            public string MEDIA_TYPE_VIDEO = "video";
            
            public string MEDIA_TYPE_AUDIO = "audio";
            
            public string MEDIA_TYPE_DOCUM = "document";
            
            public string XMLNS = "w:m";
            
            public Tuple<string, string, string, string> TYPES_MEDIA = (MEDIA_TYPE_AUDIO, MEDIA_TYPE_IMAGE, MEDIA_TYPE_VIDEO, MEDIA_TYPE_DOCUM);
            
            public RequestUploadIqProtocolEntity(
                object mediaType,
                object b64Hash = null,
                object size = null,
                object origHash = null,
                object filePath = null)
                : base(_type: "set", to: YowConstants.WHATSAPP_SERVER) {
                Debug.Assert(b64Hash && size || filePath);
                Debug.Assert("Either specify hash and size, or specify filepath and let me generate the rest");
                if (filePath) {
                    Debug.Assert(os.path.exists(filePath));
                    Debug.Assert(String.Format("Either specified path does not exist, or yowsup doesn't have permission to read: %s", filePath));
                    b64Hash = this.@__class__.getFileHashForUpload(filePath);
                    size = os.path.getsize(filePath);
                }
                this.setRequestArguments(mediaType, b64Hash, size, origHash);
            }
            
            public virtual object setRequestArguments(object mediaType, object b64Hash, object size, object origHash = null) {
                Debug.Assert(this.@__class__.TYPES_MEDIA.Contains(mediaType));
                Debug.Assert(String.Format("Expected media type to be in %s, got %s", this.@__class__.TYPES_MEDIA, mediaType));
                this.mediaType = mediaType;
                this.b64Hash = b64Hash;
                this.size = Convert.ToInt32(size);
                this.origHash = origHash;
            }
            
            [staticmethod]
            public static object getFileHashForUpload(object filePath) {
                return WATools.getFileHashForUpload(filePath);
            }
            
            public override object ToString() {
                var @out = super(RequestUploadIqProtocolEntity, this).@__str__();
                @out += String.Format("Media Type: %s\n", this.mediaType);
                @out += String.Format("B64Hash: %s\n", this.b64Hash);
                @out += String.Format("Size: %s\n", this.size);
                if (this.origHash) {
                    @out += String.Format("OrigHash: %s\n", this.origHash);
                }
                return @out;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(RequestUploadIqProtocolEntity, this).toProtocolTreeNode();
                var attribs = new Dictionary<object, object> {
                    {
                        "hash",
                        this.b64Hash},
                    {
                        "type",
                        this.mediaType},
                    {
                        "size",
                        this.size.ToString()}};
                if (this.origHash) {
                    attribs["orighash"] = this.origHash;
                }
                var mediaNode = ProtocolTreeNode("encr_media", attribs);
                node.addChild(mediaNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                Debug.Assert(node.getAttributeValue("type") == "set");
                Debug.Assert(String.Format("Expected set as iq type in request upload, got %s", node.getAttributeValue("type")));
                var entity = IqProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = RequestUploadIqProtocolEntity;
                var mediaNode = node.getChild("encr_media");
                entity.setRequestArguments(mediaNode.getAttributeValue("type"), mediaNode.getAttributeValue("hash"), mediaNode.getAttributeValue("size"), mediaNode.getAttributeValue("orighash"));
                return entity;
            }
        }
    }
}
