namespace yowsup.layers.protocol_media.protocolentities {
    
    using IqProtocolEntityTest = yowsup.layers.protocol_iq.protocolentities.test_iq.IqProtocolEntityTest;
    
    using RequestUploadIqProtocolEntity = yowsup.layers.protocol_media.protocolentities.RequestUploadIqProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using System.Collections.Generic;
    
    public static class test_iq_requestupload {
        
        public class RequestUploadIqProtocolEntityTest
            : IqProtocolEntityTest {
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(RequestUploadIqProtocolEntityTest, this).setUp();
                var mediaNode = ProtocolTreeNode("encr_media", new Dictionary<object, object> {
                    {
                        "hash",
                        "hash"},
                    {
                        "size",
                        "1234"},
                    {
                        "orighash",
                        "orighash"},
                    {
                        "type",
                        "image"}});
                this.ProtocolEntity = RequestUploadIqProtocolEntity;
                this.node.setAttribute("type", "set");
                this.node.addChild(mediaNode);
            }
        }
    }
}
