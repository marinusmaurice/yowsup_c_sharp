namespace yowsup.layers.protocol_media.protocolentities
{

    using MediaMessageProtocolEntity = message_media.MediaMessageProtocolEntity;

    public static class message_media_contact {
        
        public class ContactMediaMessageProtocolEntity
            : MediaMessageProtocolEntity {
            
            public ContactMediaMessageProtocolEntity(object contact_attrs, object message_meta_attrs) {
                // type: (ContactAttributes, MessageMetaAttributes) -> None
                super(ContactMediaMessageProtocolEntity, this).@__init__("contact", MessageAttributes(contact: contact_attrs), message_meta_attrs);
            }
            
            public object media_specific_attributes {
                get {
                    return this.message_attributes.contact;
                }
            }
            
            public object display_name {
                get {
                    return this.media_specific_attributes.display_name;
                }
                set {
                    this.media_specific_attributes.display_name = value;
                }
            }
            
            public object vcard {
                get {
                    return this.media_specific_attributes.vcard;
                }
                set {
                    this.media_specific_attributes.vcard = value;
                }
            }
        }
    }
}
