namespace yowsup.layers.protocol_media.protocolentities {
    
    using MediaMessageProtocolEntityTest = yowsup.layers.protocol_media.protocolentities.test_message_media.MediaMessageProtocolEntityTest;
    
    using ExtendedTextMediaMessageProtocolEntity = yowsup.layers.protocol_media.protocolentities.ExtendedTextMediaMessageProtocolEntity;
    
    using Message = yowsup.layers.protocol_messages.proto.e2e_pb2.Message;
    
    public static class test_message_media_extendedtext {
        
        public class ExtendedTextMediaMessageProtocolEntityTest
            : MediaMessageProtocolEntityTest {
            
            public object _entity;
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(ExtendedTextMediaMessageProtocolEntityTest, this).setUp();
                this.ProtocolEntity = ExtendedTextMediaMessageProtocolEntity;
                var m = Message();
                var media_message = Message.ExtendedTextMessage();
                media_message.canonical_url = "url";
                media_message.text = "text";
                media_message.matched_text = "matched_text";
                media_message.description = "desc";
                media_message.title = "title";
                media_message.jpeg_thumbnail = new byte[] { (byte)'t', (byte)'h', (byte)'u', (byte)'m', (byte)'b' };
                m.extended_text_message.MergeFrom(media_message);
                var proto_node = this.node.getChild("proto");
                proto_node["mediatype"] = "url";
                proto_node.setData(m.SerializeToString());
                this._entity = ExtendedTextMediaMessageProtocolEntity.fromProtocolTreeNode(this.node);
            }
            
            public virtual object test_properties() {
                this.assertEqual("url", this._entity.canonical_url);
                this.assertEqual("text", this._entity.text);
                this.assertEqual("matched_text", this._entity.matched_text);
                this.assertEqual("desc", this._entity.description);
                this.assertEqual("title", this._entity.title);
                this.assertEqual(new byte[] { (byte)'t', (byte)'h', (byte)'u', (byte)'m', (byte)'b' }, this._entity.jpeg_thumbnail);
            }
        }
    }
}
