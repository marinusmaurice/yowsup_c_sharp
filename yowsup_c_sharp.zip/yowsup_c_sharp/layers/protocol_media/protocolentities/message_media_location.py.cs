namespace yowsup.layers.protocol_media.protocolentities
{

    using MediaMessageProtocolEntity = message_media.MediaMessageProtocolEntity;

    public static class message_media_location {
        
        public class LocationMediaMessageProtocolEntity
            : MediaMessageProtocolEntity {
            
            public LocationMediaMessageProtocolEntity(object location_attrs, object message_meta_attrs) {
                // type: (LocationAttributes, MessageMetaAttributes) -> None
                super(LocationMediaMessageProtocolEntity, this).@__init__("location", MessageAttributes(location: location_attrs), message_meta_attrs);
            }
            
            public object media_specific_attributes {
                get {
                    return this.message_attributes.contact;
                }
            }
            
            public object degrees_latitude {
                get {
                    return this.media_specific_attributes.degrees_latitude;
                }
                set {
                    this.media_specific_attributes.degrees_latitude = value;
                }
            }
            
            public object degrees_longitude {
                get {
                    return this.media_specific_attributes.degrees_longitude;
                }
                set {
                    this.media_specific_attributes.degrees_longitude = value;
                }
            }
            
            public object name {
                get {
                    return this.media_specific_attributes.name;
                }
                set {
                    this.media_specific_attributes.name = value;
                }
            }
            
            public object address {
                get {
                    return this.proto.addrees;
                }
                set {
                    this.media_specific_attributes.address = value;
                }
            }
            
            public object url {
                get {
                    return this.media_specific_attributes.url;
                }
                set {
                    this.media_specific_attributes.url = value;
                }
            }
            
            public object duration {
                get {
                    return this.media_specific_attributes.duration;
                }
                set {
                    this.media_specific_attributes.duration = value;
                }
            }
            
            public object accuracy_in_meters {
                get {
                    return this.media_specific_attributes.accuracy_in_meters;
                }
                set {
                    this.media_specific_attributes.accuracy_in_meters = value;
                }
            }
            
            public object speed_in_mps {
                get {
                    return this.media_specific_attributes.speed_in_mps;
                }
                set {
                    this.media_specific_attributes.speed_in_mps = value;
                }
            }
            
            public object degrees_clockwise_from_magnetic_north {
                get {
                    return this.media_specific_attributes.degrees_clockwise_from_magnetic_north;
                }
                set {
                    this.media_specific_attributes.degrees_clockwise_from_magnetic_north = value;
                }
            }
            
            public object axolotl_sender_key_distribution_message {
                get {
                    return this.media_specific_attributes.axolotl_sender_key_distribution_message;
                }
                set {
                    this.media_specific_attributes.axolotl_sender_key_distribution_message = value;
                }
            }
            
            public object jpeg_thumbnail {
                get {
                    return this.media_specific_attributes.jpeg_thumbnail;
                }
                set {
                    this.media_specific_attributes.jpeg_thumbnail = value;
                }
            }
        }
    }
}
