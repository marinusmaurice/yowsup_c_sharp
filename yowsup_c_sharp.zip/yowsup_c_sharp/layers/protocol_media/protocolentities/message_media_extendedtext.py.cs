namespace yowsup.layers.protocol_media.protocolentities
{

    using MediaMessageProtocolEntity = message_media.MediaMessageProtocolEntity;

    public static class message_media_extendedtext {
        
        public class ExtendedTextMediaMessageProtocolEntity
            : MediaMessageProtocolEntity {
            
            public ExtendedTextMediaMessageProtocolEntity(object extended_text_attrs, object message_meta_attrs) {
                // type: (ExtendedTextAttributes, MessageMetaAttributes) -> None
                super(ExtendedTextMediaMessageProtocolEntity, this).@__init__("url", MessageAttributes(extended_text: extended_text_attrs), message_meta_attrs);
            }
            
            public object media_specific_attributes {
                get {
                    return this.message_attributes.extended_text;
                }
            }
            
            public object text {
                get {
                    return this.media_specific_attributes.text;
                }
                set {
                    this.media_specific_attributes.text = value;
                }
            }
            
            public object matched_text {
                get {
                    return this.media_specific_attributes.matched_text;
                }
                set {
                    this.media_specific_attributes.matched_text = value;
                }
            }
            
            public object canonical_url {
                get {
                    return this.media_specific_attributes.canonical_url;
                }
                set {
                    this.media_specific_attributes.canonical_url = value;
                }
            }
            
            public object description {
                get {
                    return this.media_specific_attributes.description;
                }
                set {
                    this.media_specific_attributes.description = value;
                }
            }
            
            public object title {
                get {
                    return this.media_specific_attributes.title;
                }
                set {
                    this.media_specific_attributes.title = value;
                }
            }
            
            public object jpeg_thumbnail {
                get {
                    return this.media_specific_attributes.jpeg_thumbnail;
                }
                set {
                    this.media_specific_attributes.jpeg_thumbnail = value;
                }
            }
        }
    }
}
