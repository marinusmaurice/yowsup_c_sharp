namespace yowsup.layers.protocol_media.protocolentities {
    
    using ResultIqProtocolEntityTest = yowsup.layers.protocol_iq.protocolentities.test_iq_result.ResultIqProtocolEntityTest;
    
    using ResultRequestUploadIqProtocolEntity = yowsup.layers.protocol_media.protocolentities.ResultRequestUploadIqProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using System.Collections.Generic;
    
    public static class test_iq_requestupload_result {
        
        public class ResultRequestUploadIqProtocolEntityTest
            : ResultIqProtocolEntityTest {
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(ResultRequestUploadIqProtocolEntityTest, this).setUp();
                var mediaNode = ProtocolTreeNode("encr_media", new Dictionary<object, object> {
                    {
                        "url",
                        "url"},
                    {
                        "ip",
                        "1.2.3.4"}});
                this.ProtocolEntity = ResultRequestUploadIqProtocolEntity;
                this.node.addChild(mediaNode);
            }
        }
    }
}
