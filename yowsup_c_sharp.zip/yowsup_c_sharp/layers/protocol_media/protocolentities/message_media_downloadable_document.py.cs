namespace yowsup.layers.protocol_media.protocolentities
{

    using DownloadableMediaMessageProtocolEntity = message_media_downloadable.DownloadableMediaMessageProtocolEntity;

    public static class message_media_downloadable_document {
        
        public class DocumentDownloadableMediaMessageProtocolEntity
            : DownloadableMediaMessageProtocolEntity {
            
            public DocumentDownloadableMediaMessageProtocolEntity(object document_attrs, object message_meta_attrs)
                : base(MessageAttributes(document: document_attrs), message_meta_attrs) {
            }
            
            public object media_specific_attributes {
                get {
                    return this.message_attributes.document;
                }
            }
            
            public object downloadablemedia_specific_attributes {
                get {
                    return this.message_attributes.document.downloadablemedia_attributes;
                }
            }
            
            public object file_name {
                get {
                    return this.media_specific_attributes.file_name;
                }
                set {
                    this.media_specific_attributes.file_name = value;
                }
            }
            
            public object file_length {
                get {
                    return this.media_specific_attributes.file_length;
                }
                set {
                    this.media_specific_attributes.file_length = value;
                }
            }
            
            public object title {
                get {
                    return this.media_specific_attributes.title;
                }
                set {
                    this.media_specific_attributes.title = value;
                }
            }
            
            public object page_count {
                get {
                    return this.media_specific_attributes.page_count;
                }
                set {
                    this.media_specific_attributes.page_count = value;
                }
            }
            
            public object jpeg_thumbnail {
                get {
                    return this.media_specific_attributes.image_message.jpeg_thumbnail;
                }
                set {
                    this.media_specific_attributes.image_message.jpeg_thumbnail = value;
                }
            }
        }
    }
}
