namespace yowsup.layers.protocol_media.protocolentities {
    
    using VideoDownloadableMediaMessageProtocolEntity = yowsup.layers.protocol_media.protocolentities.message_media_downloadable_video.VideoDownloadableMediaMessageProtocolEntity;
    
    using Message = yowsup.layers.protocol_messages.proto.e2e_pb2.Message;
    
    using MediaMessageProtocolEntityTest = test_message_media.MediaMessageProtocolEntityTest;
    
    public static class test_message_media_downloadable_video {
        
        public class VideoDownloadableMediaMessageProtocolEntityTest
            : MediaMessageProtocolEntityTest {
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(VideoDownloadableMediaMessageProtocolEntityTest, this).setUp();
                this.ProtocolEntity = VideoDownloadableMediaMessageProtocolEntity;
                var proto_node = this.node.getChild("proto");
                var m = Message();
                var media_message = Message.VideoMessage();
                media_message.url = "url";
                media_message.mimetype = "video/mp4";
                media_message.caption = "caption";
                media_message.file_sha256 = new byte[] { (byte)'s', (byte)'h', (byte)'a', (byte)'v', (byte)'a', (byte)'l' };
                media_message.file_length = 4;
                media_message.width = 1;
                media_message.height = 2;
                media_message.seconds = 3;
                media_message.media_key = new byte[] { (byte)'M', (byte)'E', (byte)'D', (byte)'I', (byte)'A', (byte)'_', (byte)'K', (byte)'E', (byte)'Y' };
                media_message.jpeg_thumbnail = new byte[] { (byte)'T', (byte)'H', (byte)'U', (byte)'M', (byte)'B', (byte)'N', (byte)'A', (byte)'I', (byte)'L' };
                media_message.gif_attribution = 0;
                media_message.gif_playback = false;
                media_message.streaming_sidecar = "";
                m.video_message.MergeFrom(media_message);
                proto_node.setData(m.SerializeToString());
            }
        }
    }
}
