namespace yowsup.layers.protocol_media.protocolentities
{

    using ProtomessageProtocolEntity = yowsup.layers.protocol_messages.protocolentities.protomessage.ProtomessageProtocolEntity;

    using System;

    public static class message_media {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class MediaMessageProtocolEntity
            : ProtomessageProtocolEntity {
            
            public object _media_type;
            
            public string TYPE_MEDIA_AUDIO;
            
            public string TYPE_MEDIA_CONTACT;
            
            public string TYPE_MEDIA_DOCUMENT;
            
            public string TYPE_MEDIA_GIF;
            
            public string TYPE_MEDIA_IMAGE;
            
            public string TYPE_MEDIA_LOCATION;
            
            public string TYPE_MEDIA_PTT;
            
            public string TYPE_MEDIA_STICKER;
            
            public string TYPE_MEDIA_URL;
            
            public string TYPE_MEDIA_VIDEO;
            
            public Tuple<string, string, string, string, string, string, string, string, string, string> TYPES_MEDIA;
            
            public string TYPE_MEDIA_IMAGE = "image";
            
            public string TYPE_MEDIA_VIDEO = "video";
            
            public string TYPE_MEDIA_AUDIO = "audio";
            
            public string TYPE_MEDIA_CONTACT = "contact";
            
            public string TYPE_MEDIA_LOCATION = "location";
            
            public string TYPE_MEDIA_DOCUMENT = "document";
            
            public string TYPE_MEDIA_GIF = "gif";
            
            public string TYPE_MEDIA_PTT = "ptt";
            
            public string TYPE_MEDIA_URL = "url";
            
            public string TYPE_MEDIA_STICKER = "sticker";
            
            public Tuple<string, string, string, string, string, string, string, string, string, string> TYPES_MEDIA = (TYPE_MEDIA_IMAGE, TYPE_MEDIA_AUDIO, TYPE_MEDIA_VIDEO, TYPE_MEDIA_CONTACT, TYPE_MEDIA_LOCATION, TYPE_MEDIA_DOCUMENT, TYPE_MEDIA_GIF, TYPE_MEDIA_PTT, TYPE_MEDIA_URL, TYPE_MEDIA_STICKER);
            
            public MediaMessageProtocolEntity(object media_type, object message_attrs, object message_meta_attrs)
                : base(message_attrs, message_meta_attrs) {
                this.media_type = media_type;
            }
            
            public override object ToString() {
                var @out = super(MediaMessageProtocolEntity, this).@__str__();
                @out += String.Format("\nmediatype=%s", this.media_type);
                return @out;
            }
            
            public object media_type {
                get {
                    return this._media_type;
                }
                set {
                    if (!MediaMessageProtocolEntity.TYPES_MEDIA.Contains(value)) {
                        logger.warn(String.Format("media type: '%s' is not supported", value));
                    }
                    this._media_type = value;
                }
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(MediaMessageProtocolEntity, this).toProtocolTreeNode();
                var protoNode = node.getChild("proto");
                protoNode["mediatype"] = this.media_type;
                return node;
            }
            
            [classmethod]
            public static object fromProtocolTreeNode(object cls, object node) {
                var entity = ProtomessageProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = cls;
                entity.media_type = node.getChild("proto")["mediatype"];
                return entity;
            }
        }
    }
}
