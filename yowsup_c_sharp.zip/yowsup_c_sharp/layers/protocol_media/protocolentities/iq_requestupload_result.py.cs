namespace yowsup.layers.protocol_media.protocolentities {
    
    using YowConstants = yowsup.common.YowConstants;
    
    using ResultIqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.ResultIqProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using System;
    
    using System.Collections.Generic;
    
    public static class iq_requestupload_result {
        
        public class ResultRequestUploadIqProtocolEntity
            : ResultIqProtocolEntity {
            
            public object duplicate;
            
            public object ip;
            
            public int resumeOffset;
            
            public object url;
            
            public ResultRequestUploadIqProtocolEntity(
                object _id,
                object url,
                object ip = null,
                object resumeOffset = 0,
                object duplicate = false)
                : base(_from: YowConstants.WHATSAPP_SERVER) {
                this.setUploadProps(url, ip, resumeOffset, duplicate);
            }
            
            public virtual object setUploadProps(object url, object ip = null, object resumeOffset = 0, object duplicate = false) {
                this.url = url;
                this.ip = ip;
                this.resumeOffset = resumeOffset || 0;
                this.duplicate = duplicate;
            }
            
            public virtual object isDuplicate() {
                return this.duplicate;
            }
            
            public virtual object getUrl() {
                return this.url;
            }
            
            public virtual object getResumeOffset() {
                return this.resumeOffset;
            }
            
            public virtual object getIp() {
                return this.ip;
            }
            
            public override object ToString() {
                var @out = super(ResultRequestUploadIqProtocolEntity, this).@__str__();
                @out += String.Format("URL: %s\n", this.url);
                if (this.ip) {
                    @out += String.Format("IP: %s\n", this.ip);
                }
                return @out;
            }
            
            public virtual object toProtocolTreeNode() {
                object mediaNode;
                var node = super(ResultRequestUploadIqProtocolEntity, this).toProtocolTreeNode();
                if (!this.isDuplicate()) {
                    mediaNode = ProtocolTreeNode("encr_media", new Dictionary<object, object> {
                        {
                            "url",
                            this.url}});
                    if (this.ip) {
                        mediaNode["ip"] = this.ip;
                    }
                    if (this.resumeOffset) {
                        mediaNode["resume"] = this.resumeOffset.ToString();
                    }
                } else {
                    mediaNode = ProtocolTreeNode("duplicate", new Dictionary<object, object> {
                        {
                            "url",
                            this.url}});
                }
                node.addChild(mediaNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = ResultIqProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = ResultRequestUploadIqProtocolEntity;
                var mediaNode = node.getChild("encr_media");
                if (mediaNode) {
                    entity.setUploadProps(mediaNode["url"], mediaNode["ip"], mediaNode["resume"]);
                } else {
                    var duplicateNode = node.getChild("duplicate");
                    if (duplicateNode) {
                        entity.setUploadProps(duplicateNode["url"], duplicateNode["ip"], duplicate: true);
                    }
                }
                return entity;
            }
        }
    }
}
