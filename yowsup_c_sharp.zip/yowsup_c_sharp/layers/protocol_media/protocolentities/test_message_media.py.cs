namespace yowsup.layers.protocol_media.protocolentities {
    
    using MediaMessageProtocolEntity = yowsup.layers.protocol_media.protocolentities.message_media.MediaMessageProtocolEntity;
    
    using MessageProtocolEntityTest = yowsup.layers.protocol_messages.protocolentities.test_message.MessageProtocolEntityTest;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using Message = yowsup.layers.protocol_messages.proto.e2e_pb2.Message;
    
    using System.Collections.Generic;
    
    public static class test_message_media {
        
        public class MediaMessageProtocolEntityTest
            : MessageProtocolEntityTest {
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(MediaMessageProtocolEntityTest, this).setUp();
                this.ProtocolEntity = MediaMessageProtocolEntity;
                var proto_node = ProtocolTreeNode("proto", new Dictionary<object, object> {
                    {
                        "mediatype",
                        "image"}}, null, Message().SerializeToString());
                this.node.addChild(proto_node);
            }
        }
    }
}
