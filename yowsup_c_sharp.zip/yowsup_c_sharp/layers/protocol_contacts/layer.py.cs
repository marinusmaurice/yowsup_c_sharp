namespace yowsup.layers.protocol_contacts
{

    using YowProtocolLayer = yowsup.layers.YowProtocolLayer;

    using System.Collections.Generic;

    using System;

    public static class layer {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class YowContactsIqProtocolLayer
            : YowProtocolLayer {
            
            public YowContactsIqProtocolLayer() {
                var handleMap = new Dictionary<object, object> {
                    {
                        "iq",
                        (this.recvIq, this.sendIq)},
                    {
                        "notification",
                        (this.recvNotification, null)}};
                super(YowContactsIqProtocolLayer, this).@__init__(handleMap);
            }
            
            public override object ToString() {
                return "Contact Iq Layer";
            }
            
            public virtual object recvNotification(object node) {
                if (node["type"] == "contacts") {
                    if (node.getChild("remove")) {
                        this.toUpper(RemoveContactNotificationProtocolEntity.fromProtocolTreeNode(node));
                    } else if (node.getChild("add")) {
                        this.toUpper(AddContactNotificationProtocolEntity.fromProtocolTreeNode(node));
                    } else if (node.getChild("update")) {
                        this.toUpper(UpdateContactNotificationProtocolEntity.fromProtocolTreeNode(node));
                    } else if (node.getChild("sync")) {
                        this.toUpper(ContactsSyncNotificationProtocolEntity.fromProtocolTreeNode(node));
                    } else {
                        logger.warning(String.Format("Unsupported notification type: %s ", node["type"]));
                        logger.debug(String.Format("Unsupported notification node: %s", node));
                    }
                }
            }
            
            public virtual object recvIq(object node) {
                if (node["type"] == "result" && node.getChild("sync")) {
                    this.toUpper(ResultSyncIqProtocolEntity.fromProtocolTreeNode(node));
                }
            }
            
            public virtual object sendIq(object entity) {
                if (entity.getXmlns() == "urn:xmpp:whatsapp:sync") {
                    this.toLower(entity.toProtocolTreeNode());
                }
            }
        }
    }
}
