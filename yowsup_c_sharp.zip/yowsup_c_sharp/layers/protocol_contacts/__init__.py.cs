namespace yowsup.layers.protocol_contacts
{

    public static class @__init__ {
    }
}
