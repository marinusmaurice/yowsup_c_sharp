namespace yowsup.layers.protocol_contacts {
    
    using YowProtocolLayerTest = yowsup.layers.YowProtocolLayerTest;
    
    using YowContactsIqProtocolLayer = yowsup.layers.protocol_contacts.YowContactsIqProtocolLayer;
    
    using addEntity = yowsup.layers.protocol_contacts.protocolentities.test_notification_contact_add.entity;
    
    using updateEntity = yowsup.layers.protocol_contacts.protocolentities.test_notification_contact_update.entity;
    
    using removeEntity = yowsup.layers.protocol_contacts.protocolentities.test_notification_contact_remove.entity;
    
    using syncResultEntity = yowsup.layers.protocol_contacts.protocolentities.test_iq_sync_result.entity;
    
    using syncGetEntity = yowsup.layers.protocol_contacts.protocolentities.test_iq_sync_get.entity;
    
    public static class test_layer {
        
        public class YowContactsIqProtocolLayerTest
            : YowProtocolLayerTest, YowContactsIqProtocolLayer {
            
            public virtual object setUp() {
                YowContactsIqProtocolLayer.@__init__(this);
            }
            
            public virtual object test_sync() {
                this.assertSent(syncGetEntity);
            }
            
            public virtual object test_syncResult() {
                this.assertReceived(syncResultEntity);
            }
            
            public virtual object test_notificationAdd() {
                this.assertReceived(addEntity);
            }
            
            public virtual object test_notificationUpdate() {
                this.assertReceived(updateEntity);
            }
            
            public virtual object test_notificationRemove() {
                this.assertReceived(removeEntity);
            }
        }
    }
}
