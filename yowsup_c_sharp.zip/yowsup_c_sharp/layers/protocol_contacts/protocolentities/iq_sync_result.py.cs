namespace yowsup.layers.protocol_contacts.protocolentities {
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using SyncIqProtocolEntity = iq_sync.SyncIqProtocolEntity;
    
    using System.Diagnostics;
    
    using System;
    
    using System.Collections.Generic;
    
    using System.Linq;
    
    public static class iq_sync_result {
        
        // 
        //     <iq type="result" from="491632092557@s.whatsapp.net" id="1417046561-4">
        //     <sync index="0" wait="166952" last="true" version="1417046548593182" sid="1.30615237617e+17">
        //         <in>
        //             <user jid="{{jid}}>{{number}}</user>
        //         </in>
        //         <out>
        //             <user jid="{{jid}}">
        //             {{number}}
        //         </user>
        //         </out>
        //         <invalid>
        //             <user>
        //                 abcdefgh
        //             </user>
        //         </invalid>
        // 
        //     </sync>
        //     </iq>
        //     
        public class ResultSyncIqProtocolEntity
            : SyncIqProtocolEntity {
            
            public object inNumbers;
            
            public object invalidNumbers;
            
            public object outNumbers;
            
            public object version;
            
            public int wait;
            
            public ResultSyncIqProtocolEntity(
                object _id,
                object sid,
                object index,
                object last,
                object version,
                object inNumbers,
                object outNumbers,
                object invalidNumbers,
                object wait = null)
                : base(_id, sid, index, last) {
                this.setResultSyncProps(version, inNumbers, outNumbers, invalidNumbers, wait);
            }
            
            public virtual object setResultSyncProps(
                object version,
                object inNumbers,
                object outNumbers,
                object invalidNumbers,
                object wait = null) {
                Debug.Assert(object.ReferenceEquals(type(inNumbers), dict));
                Debug.Assert("in numbers must be a dict {number -> jid}");
                Debug.Assert(object.ReferenceEquals(type(outNumbers), dict));
                Debug.Assert("out numbers must be a dict {number -> jid}");
                Debug.Assert(object.ReferenceEquals(type(invalidNumbers), list));
                Debug.Assert("invalid numbers must be a list");
                this.inNumbers = inNumbers;
                this.outNumbers = outNumbers;
                this.invalidNumbers = invalidNumbers;
                this.wait = wait != null ? Convert.ToInt32(wait) : null;
                this.version = version;
            }
            
            public override object ToString() {
                var @out = super(SyncIqProtocolEntity, this).@__str__();
                if (this.wait != null) {
                    @out += String.Format("Wait: %s\n", this.wait);
                }
                @out += String.Format("Version: %s\n", this.version);
                @out += String.Format("In Numbers: %s\n", ",".join(this.inNumbers));
                @out += String.Format("Out Numbers: %s\n", ",".join(this.outNumbers));
                @out += String.Format("Invalid Numbers: %s\n", ",".join(this.invalidNumbers));
                return @out;
            }
            
            public virtual object toProtocolTreeNode() {
                var outUsers = (from _tup_1 in this.outNumbers.items().Chop((number,jid) => (number, jid))
                    let number = _tup_1.Item1
                    let jid = _tup_1.Item2
                    select ProtocolTreeNode("user", new Dictionary<object, object> {
                        {
                            "jid",
                            jid}}, null, number.encode())).ToList();
                var inUsers = (from _tup_2 in this.inNumbers.items().Chop((number,jid) => (number, jid))
                    let number = _tup_2.Item1
                    let jid = _tup_2.Item2
                    select ProtocolTreeNode("user", new Dictionary<object, object> {
                        {
                            "jid",
                            jid}}, null, number.encode())).ToList();
                var invalidUsers = (from number in this.invalidNumbers
                    select ProtocolTreeNode("user", new Dictionary<object, object> {
                    }, null, number.encode())).ToList();
                var node = super(ResultSyncIqProtocolEntity, this).toProtocolTreeNode();
                var syncNode = node.getChild("sync");
                syncNode.setAttribute("version", this.version);
                if (this.wait != null) {
                    syncNode.setAttribute("wait", this.wait.ToString());
                }
                if (outUsers.Count) {
                    syncNode.addChild(ProtocolTreeNode("out", children: outUsers));
                }
                if (inUsers.Count) {
                    syncNode.addChild(ProtocolTreeNode("in", children: inUsers));
                }
                if (invalidUsers.Count) {
                    syncNode.addChildren(new List<object> {
                        ProtocolTreeNode("invalid", children: invalidUsers)
                    });
                }
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var syncNode = node.getChild("sync");
                var outNode = syncNode.getChild("out");
                var inNode = syncNode.getChild("in");
                var invalidNode = syncNode.getChild("invalid");
                var outUsers = outNode ? outNode.getAllChildren() : new List<object>();
                var inUsers = inNode ? inNode.getAllChildren() : new List<object>();
                var invalidUsers = invalidNode ? (from inode in invalidNode.getAllChildren()
                    select inode.data.decode()).ToList() : new List<object>();
                var outUsersDict = new Dictionary<object, object> {
                };
                foreach (var u in outUsers) {
                    outUsersDict[u.data.decode()] = u.getAttributeValue("jid");
                }
                var inUsersDict = new Dictionary<object, object> {
                };
                foreach (var u in inUsers) {
                    inUsersDict[u.data.decode()] = u.getAttributeValue("jid");
                }
                var entity = SyncIqProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = ResultSyncIqProtocolEntity;
                entity.setResultSyncProps(syncNode.getAttributeValue("version"), inUsersDict, outUsersDict, invalidUsers, syncNode.getAttributeValue("wait"));
                return entity;
            }
        }
    }
}
