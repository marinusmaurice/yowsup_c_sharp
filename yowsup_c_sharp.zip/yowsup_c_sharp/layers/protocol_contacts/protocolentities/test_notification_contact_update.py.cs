namespace yowsup.layers.protocol_contacts.protocolentities
{

    using UpdateContactNotificationProtocolEntity = yowsup.layers.protocol_contacts.protocolentities.UpdateContactNotificationProtocolEntity;

    using ProtocolEntityTest = yowsup.structs.protocolentity.ProtocolEntityTest;

    using System;

    public static class test_notification_contact_update {
        
        public static object entity = UpdateContactNotificationProtocolEntity("1234", "jid@s.whatsapp.net", Convert.ToInt32(time.time()), "notify", false, "contactjid@s.whatsapp.net");
        
        public class UpdateContactNotificationProtocolEntityTest
            : ProtocolEntityTest, unittest.TestCase {
            
            public object node;
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                this.ProtocolEntity = UpdateContactNotificationProtocolEntity;
                this.node = entity.toProtocolTreeNode();
            }
        }
    }
}
