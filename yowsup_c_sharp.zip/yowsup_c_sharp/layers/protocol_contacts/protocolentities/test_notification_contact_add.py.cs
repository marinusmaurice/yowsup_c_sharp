namespace yowsup.layers.protocol_contacts.protocolentities
{

    using AddContactNotificationProtocolEntity = yowsup.layers.protocol_contacts.protocolentities.AddContactNotificationProtocolEntity;

    using ProtocolEntityTest = yowsup.structs.protocolentity.ProtocolEntityTest;

    using System;

    public static class test_notification_contact_add {
        
        public static object entity = AddContactNotificationProtocolEntity("1234", "jid@s.whatsapp.net", Convert.ToInt32(time.time()), "notify", false, "sender@s.whatsapp.net");
        
        public class AddContactNotificationProtocolEntityTest
            : ProtocolEntityTest, unittest.TestCase {
            
            public object node;
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(AddContactNotificationProtocolEntityTest, this).setUp();
                this.ProtocolEntity = AddContactNotificationProtocolEntity;
                this.node = entity.toProtocolTreeNode();
            }
        }
    }
}
