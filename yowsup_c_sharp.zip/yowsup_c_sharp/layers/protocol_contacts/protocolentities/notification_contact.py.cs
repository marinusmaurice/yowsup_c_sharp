namespace yowsup.layers.protocol_contacts.protocolentities
{

    using NotificationProtocolEntity = yowsup.layers.protocol_notifications.protocolentities.NotificationProtocolEntity;

    public static class notification_contact {
        
        // 
        //     <notification offline="0" id="{{NOTIFICATION_ID}}" notify="{{NOTIFY_NAME}}" type="contacts" 
        //             t="{{TIMESTAMP}}" from="{{SENDER_JID}}">
        //     </notification>
        //     
        //     
        public class ContactNotificationProtocolEntity
            : NotificationProtocolEntity {
            
            public ContactNotificationProtocolEntity(
                object _id,
                object _from,
                object timestamp,
                object notify,
                object offline = false)
                : base(_id, _from, timestamp, notify, offline) {
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = NotificationProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = ContactNotificationProtocolEntity;
                return entity;
            }
        }
    }
}
