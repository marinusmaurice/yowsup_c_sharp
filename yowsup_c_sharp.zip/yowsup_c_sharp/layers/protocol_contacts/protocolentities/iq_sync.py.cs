namespace yowsup.layers.protocol_contacts.protocolentities
{

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using IqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.IqProtocolEntity;

    using System;

    using System.Collections.Generic;

    public static class iq_sync {
        
        // 
        //     <iq type="get" id="{{id}}" xmlns="urn:xmpp:whatsapp:sync">
        //         <sync
        //             sid="{{str((int(time.time()) + 11644477200) * 10000000)}}"
        //             index="{{0 | ?}}"
        //             last="{{true | false?}}"
        //         >
        //         </sync>
        //     </iq>
        //     
        public class SyncIqProtocolEntity
            : IqProtocolEntity {
            
            public int index;
            
            public object last;
            
            public string sid;
            
            public SyncIqProtocolEntity(
                object _type,
                object _id = null,
                object sid = null,
                object index = 0,
                object last = true)
                : base(_id: _id, _type: _type) {
                this.setSyncProps(sid, index, last);
            }
            
            public virtual object setSyncProps(object sid, object index, object last) {
                this.sid = sid ? sid : ((Convert.ToInt32(time.time()) + 11644477200) * 10000000).ToString();
                this.index = Convert.ToInt32(index);
                this.last = last;
            }
            
            public override object ToString() {
                var @out = super(SyncIqProtocolEntity, this).@__str__();
                @out += String.Format("sid: %s\n", this.sid);
                @out += String.Format("index: %s\n", this.index);
                @out += String.Format("last: %s\n", this.last);
                return @out;
            }
            
            public virtual object toProtocolTreeNode() {
                var syncNodeAttrs = new Dictionary<object, object> {
                    {
                        "sid",
                        this.sid},
                    {
                        "index",
                        this.index.ToString()},
                    {
                        "last",
                        this.last ? "true" : "false"}};
                var syncNode = ProtocolTreeNode("sync", syncNodeAttrs);
                var node = super(SyncIqProtocolEntity, this).toProtocolTreeNode();
                node.addChild(syncNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var syncNode = node.getChild("sync");
                var entity = IqProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = SyncIqProtocolEntity;
                entity.setSyncProps(syncNode.getAttributeValue("sid"), syncNode.getAttributeValue("index"), syncNode.getAttributeValue("last"));
                return entity;
            }
        }
    }
}
