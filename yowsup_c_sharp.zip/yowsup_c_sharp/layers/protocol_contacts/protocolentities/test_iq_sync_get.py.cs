namespace yowsup.layers.protocol_contacts.protocolentities
{

    using GetSyncIqProtocolEntity = yowsup.layers.protocol_contacts.protocolentities.iq_sync_get.GetSyncIqProtocolEntity;

    using ProtocolEntityTest = yowsup.structs.protocolentity.ProtocolEntityTest;

    using System.Collections.Generic;

    public static class test_iq_sync_get {
        
        public static object entity = GetSyncIqProtocolEntity(new List<string> {
            "12345678",
            "8764543121"
        });
        
        public class GetSyncIqProtocolEntityTest
            : ProtocolEntityTest, unittest.TestCase {
            
            public object node;
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                this.ProtocolEntity = GetSyncIqProtocolEntity;
                this.node = entity.toProtocolTreeNode();
            }
        }
    }
}
