namespace yowsup.layers.protocol_contacts.protocolentities {
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using ContactNotificationProtocolEntity = notification_contact.ContactNotificationProtocolEntity;
    
    using System.Collections.Generic;
    
    public static class notification_contact_add {
        
        // 
        //     <notification offline="0" id="{{NOTIFICATION_ID}}" notify="{{NOTIFY_NAME}}" type="contacts" 
        //             t="{{TIMESTAMP}}" from="{{SENDER_JID}}">
        //         <add jid="{{SET_JID}}"> </add>
        //     </notification>
        //     
        public class AddContactNotificationProtocolEntity
            : ContactNotificationProtocolEntity {
            
            public object contactJid;
            
            public AddContactNotificationProtocolEntity(
                object _id,
                object _from,
                object timestamp,
                object notify,
                object offline,
                object contactJid)
                : base(_from, timestamp, notify, offline) {
                this.setData(contactJid);
            }
            
            public virtual object setData(object jid) {
                this.contactJid = jid;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(AddContactNotificationProtocolEntity, this).toProtocolTreeNode();
                var removeNode = ProtocolTreeNode("add", new Dictionary<object, object> {
                    {
                        "jid",
                        this.contactJid}}, null, null);
                node.addChild(removeNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = ContactNotificationProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = AddContactNotificationProtocolEntity;
                var removeNode = node.getChild("add");
                entity.setData(removeNode.getAttributeValue("jid"));
                return entity;
            }
        }
    }
}
