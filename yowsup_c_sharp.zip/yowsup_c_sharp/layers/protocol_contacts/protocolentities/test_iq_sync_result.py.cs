namespace yowsup.layers.protocol_contacts.protocolentities
{

    using ResultSyncIqProtocolEntity = yowsup.layers.protocol_contacts.protocolentities.iq_sync_result.ResultSyncIqProtocolEntity;

    using ProtocolEntityTest = yowsup.structs.protocolentity.ProtocolEntityTest;

    using System.Collections.Generic;

    public static class test_iq_sync_result {
        
        public static object entity = ResultSyncIqProtocolEntity("123", "1.30615237617e+17", 0, true, "123456", new Dictionary<object, object> {
            {
                "12345678",
                "12345678@s.whatsapp.net"}}, new Dictionary<object, object> {
            {
                "12345678",
                "12345678@s.whatsapp.net"}}, new List<string> {
            "1234"
        });
        
        public class ResultSyncIqProtocolEntityTest
            : ProtocolEntityTest, unittest.TestCase {
            
            public object node;
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                this.ProtocolEntity = ResultSyncIqProtocolEntity;
                this.node = entity.toProtocolTreeNode();
            }
            
            public virtual object test_delta_result() {
                this.node.getChild("sync").Remove("wait");
                this.test_generation();
            }
        }
    }
}
