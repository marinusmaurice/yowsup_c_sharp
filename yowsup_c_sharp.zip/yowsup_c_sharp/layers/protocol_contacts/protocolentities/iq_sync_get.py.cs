namespace yowsup.layers.protocol_contacts.protocolentities
{

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using SyncIqProtocolEntity = iq_sync.SyncIqProtocolEntity;

    using System;

    using System.Diagnostics;

    using System.Collections.Generic;

    using System.Linq;

    public static class iq_sync_get {
        
        public class GetSyncIqProtocolEntity
            : SyncIqProtocolEntity {
            
            public object context;
            
            public string CONTEXT_INTERACTIVE;
            
            public string CONTEXT_REGISTRATION;
            
            public Tuple<string, string> CONTEXTS;
            
            public object mode;
            
            public string MODE_DELTA;
            
            public string MODE_FULL;
            
            public Tuple<string, string> MODES;
            
            public object numbers;
            
            public string MODE_FULL = "full";
            
            public string MODE_DELTA = "delta";
            
            public string CONTEXT_REGISTRATION = "registration";
            
            public string CONTEXT_INTERACTIVE = "interactive";
            
            public Tuple<string, string> CONTEXTS = (CONTEXT_REGISTRATION, CONTEXT_INTERACTIVE);
            
            public Tuple<string, string> MODES = (MODE_FULL, MODE_DELTA);
            
            static GetSyncIqProtocolEntity() {
                @"
    <iq type=""get"" id=""{{id}}"" xmlns=""urn:xmpp:whatsapp:sync"">
        <sync mode=""{{full | ?}}""
            context=""{{registration | ?}}""
            sid=""{{str((int(time.time()) + 11644477200) * 10000000)}}""
            index=""{{0 | ?}}""
            last=""{{true | false?}}""
        >
            <user>
                {{num1}}
            </user>
            <user>
                {{num2}}
            </user>

        </sync>
    </iq>
    ";
            }
            
            public GetSyncIqProtocolEntity(
                object numbers,
                object mode = MODE_FULL,
                object context = CONTEXT_INTERACTIVE,
                object sid = null,
                object index = 0,
                object last = true)
                : base(sid: sid, index: index, last: last) {
                this.setGetSyncProps(numbers, mode, context);
            }
            
            public virtual object setGetSyncProps(object numbers, object mode, object context) {
                Debug.Assert(object.ReferenceEquals(type(numbers), list));
                Debug.Assert("numbers must be a list");
                Debug.Assert(this.@__class__.MODES.Contains(mode));
                Debug.Assert(String.Format("mode must be in %s", this.@__class__.MODES));
                Debug.Assert(this.@__class__.CONTEXTS.Contains(context));
                Debug.Assert(String.Format("context must be in %s", this.@__class__.CONTEXTS));
                this.numbers = numbers;
                this.mode = mode;
                this.context = context;
            }
            
            public override object ToString() {
                var @out = super(GetSyncIqProtocolEntity, this).@__str__();
                @out += String.Format("Mode: %s\n", this.mode);
                @out += String.Format("Context: %s\n", this.context);
                @out += String.Format("numbers: %s\n", ",".join(this.numbers));
                return @out;
            }
            
            public virtual object toProtocolTreeNode() {
                var users = (from number in this.numbers
                    select ProtocolTreeNode("user", new Dictionary<object, object> {
                    }, null, number.encode())).ToList();
                var node = super(GetSyncIqProtocolEntity, this).toProtocolTreeNode();
                var syncNode = node.getChild("sync");
                syncNode.setAttribute("mode", this.mode);
                syncNode.setAttribute("context", this.context);
                syncNode.addChildren(users);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var syncNode = node.getChild("sync");
                var userNodes = syncNode.getAllChildren();
                var numbers = (from userNode in userNodes
                    select userNode.data.decode()).ToList();
                var entity = SyncIqProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = GetSyncIqProtocolEntity;
                entity.setGetSyncProps(numbers, syncNode.getAttributeValue("mode"), syncNode.getAttributeValue("context"));
                return entity;
            }
        }
    }
}
