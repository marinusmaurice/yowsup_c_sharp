namespace yowsup.layers.protocol_contacts.protocolentities {
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using ContactNotificationProtocolEntity = notification_contact.ContactNotificationProtocolEntity;
    
    using System;
    
    using System.Collections.Generic;
    
    public static class notificiation_contacts_sync {
        
        // 
        //     <notification from="4917667738517@s.whatsapp.net" t="1437251557" offline="0" type="contacts" id="4174521704">
        //         <sync after="1437251557"></sync>
        //     </notification>
        //     
        public class ContactsSyncNotificationProtocolEntity
            : ContactNotificationProtocolEntity {
            
            public int after;
            
            public ContactsSyncNotificationProtocolEntity(
                object _id,
                object _from,
                object timestamp,
                object notify,
                object offline,
                object after)
                : base(_from, timestamp, notify, offline) {
                this.setData(after);
            }
            
            public virtual object setData(object after) {
                this.after = Convert.ToInt32(after);
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(ContactsSyncNotificationProtocolEntity, this).toProtocolTreeNode();
                var syncNode = ProtocolTreeNode("sync", new Dictionary<object, object> {
                    {
                        "after",
                        this.after.ToString()}}, null, null);
                node.addChild(syncNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = ContactNotificationProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = ContactsSyncNotificationProtocolEntity;
                var syncNode = node.getChild("sync");
                entity.setData(syncNode.getAttributeValue("after"));
                return entity;
            }
        }
    }
}
