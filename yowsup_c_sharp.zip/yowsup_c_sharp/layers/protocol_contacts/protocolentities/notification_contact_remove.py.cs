namespace yowsup.layers.protocol_contacts.protocolentities {
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using ContactNotificationProtocolEntity = notification_contact.ContactNotificationProtocolEntity;
    
    using System.Collections.Generic;
    
    public static class notification_contact_remove {
        
        // 
        //     <notification offline="0" id="{{NOTIFICATION_ID}}" notify="{{NOTIFY_NAME}}" type="contacts" 
        //             t="{{TIMESTAMP}}" from="{{SENDER_JID}}">
        //         <remove jid="{{SET_JID}}"> </remove>
        //     </notification>
        //     
        public class RemoveContactNotificationProtocolEntity
            : ContactNotificationProtocolEntity {
            
            public object contactJid;
            
            public RemoveContactNotificationProtocolEntity(
                object _id,
                object _from,
                object timestamp,
                object notify,
                object offline,
                object contactJid)
                : base(_from, timestamp, notify, offline) {
                this.setData(contactJid);
            }
            
            public virtual object setData(object jid) {
                this.contactJid = jid;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(RemoveContactNotificationProtocolEntity, this).toProtocolTreeNode();
                var removeNode = ProtocolTreeNode("remove", new Dictionary<object, object> {
                    {
                        "jid",
                        this.contactJid}}, null, null);
                node.addChild(removeNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = ContactNotificationProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = RemoveContactNotificationProtocolEntity;
                var removeNode = node.getChild("remove");
                entity.setData(removeNode.getAttributeValue("jid"));
                return entity;
            }
        }
    }
}
