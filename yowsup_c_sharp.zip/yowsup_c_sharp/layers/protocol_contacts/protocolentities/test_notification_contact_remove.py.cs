namespace yowsup.layers.protocol_contacts.protocolentities
{

    using RemoveContactNotificationProtocolEntity = yowsup.layers.protocol_contacts.protocolentities.RemoveContactNotificationProtocolEntity;

    using ProtocolEntityTest = yowsup.structs.protocolentity.ProtocolEntityTest;

    using System;

    public static class test_notification_contact_remove {
        
        public static object entity = RemoveContactNotificationProtocolEntity("1234", "jid@s.whatsapp.net", Convert.ToInt32(time.time()), "notify", false, "contactjid@s.whatsapp.net");
        
        public class RemoveContactNotificationProtocolEntityTest
            : ProtocolEntityTest, unittest.TestCase {
            
            public object node;
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                this.ProtocolEntity = RemoveContactNotificationProtocolEntity;
                this.node = entity.toProtocolTreeNode();
            }
        }
    }
}
