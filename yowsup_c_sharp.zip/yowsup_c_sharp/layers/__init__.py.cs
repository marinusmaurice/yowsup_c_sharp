namespace yowsup.layers
{

    using Queue = queue;

    using System.Collections;

    using System.Collections.Generic;

    using System.Linq;

    public static class @__init__ {
    }
    
    public class YowLayerEvent {
        
        public object args;
        
        public bool detached;
        
        public object name;
        
        public YowLayerEvent(object name, Hashtable kwargs) {
            this.name = name;
            this.detached = false;
            if (kwargs.Contains("detached")) {
                kwargs.Remove("detached");
                this.detached = true;
            }
            this.args = kwargs;
        }
        
        public virtual object isDetached() {
            return this.detached;
        }
        
        public virtual object getName() {
            return this.name;
        }
        
        public virtual object getArg(object name) {
            return this.args.Contains(name) ? this.args[name] : null;
        }
    }
    
    public class EventCallback
        : object {
        
        public object eventName;
        
        public EventCallback(object eventName) {
            this.eventName = eventName;
        }
        
        public virtual object @__call__(object fn) {
            fn.event_callback = this.eventName;
            return fn;
        }
    }
    
    public class YowLayer
        : object {
        
        public object @__detachedQueue;
        
        public object @__lower;
        
        public object @__stack;
        
        public object @__upper;
        
        public Dictionary<object, object> _props;
        
        public Dictionary<object, object> event_callbacks;
        
        public None interface;
        
        public object @lock;
        
        public None @__upper = null;
        
        public None @__lower = null;
        
        public Dictionary<object, object> _props = new Dictionary<object, object> {
        };
        
        public object @__detachedQueue = Queue.Queue();
        
        public YowLayer() {
            this.setLayers(null, null);
            this.interface = null;
            this.event_callbacks = new Dictionary<object, object> {
            };
            this.@__stack = null;
            this.@lock = threading.Lock();
            var members = inspect.getmembers(this, predicate: inspect.ismethod);
            foreach (var m in members) {
                if (hasattr(m[1], "event_callback")) {
                    var fname = m[0];
                    var fn = m[1];
                    this.event_callbacks[fn.event_callback] = getattr(this, fname);
                }
            }
        }
        
        public virtual object getLayerInterface(object YowLayerClass = null) {
            return YowLayerClass == null ? this.interface : this.@__stack.getLayerInterface(YowLayerClass);
        }
        
        public virtual object setStack(object stack) {
            this.@__stack = stack;
        }
        
        public virtual object getStack() {
            return this.@__stack;
        }
        
        public virtual object setLayers(object upper, object lower) {
            this.@__upper = upper;
            this.@__lower = lower;
        }
        
        public virtual object send(object data) {
            this.toLower(data);
        }
        
        public virtual object receive(object data) {
            this.toUpper(data);
        }
        
        public virtual object toUpper(object data) {
            if (this.@__upper) {
                this.@__upper.receive(data);
            }
        }
        
        public virtual object toLower(object data) {
            this.@lock.acquire();
            if (this.@__lower) {
                this.@__lower.send(data);
            }
            this.@lock.release();
        }
        
        public virtual object emitEvent(object yowLayerEvent) {
            if (this.@__upper && !this.@__upper.onEvent(yowLayerEvent)) {
                if (yowLayerEvent.isDetached()) {
                    yowLayerEvent.detached = false;
                    this.getStack().execDetached(() => this.@__upper.emitEvent(yowLayerEvent));
                } else {
                    this.@__upper.emitEvent(yowLayerEvent);
                }
            }
        }
        
        public virtual object boadcastEvent(object yowLayerEvent) {
            if (this.@__lower && !this.@__lower.onEvent(yowLayerEvent)) {
                if (yowLayerEvent.isDetached()) {
                    yowLayerEvent.detached = false;
                    this.getStack().execDetached(() => this.@__lower.boadcastEvent(yowLayerEvent));
                } else {
                    this.@__lower.boadcastEvent(yowLayerEvent);
                }
            }
        }
        
        static YowLayer() {
            @"return true to stop propagating the event";
        }
        
        public virtual object onEvent(object yowLayerEvent) {
            var eventName = yowLayerEvent.getName();
            if (this.event_callbacks.Contains(eventName)) {
                return this.event_callbacks[eventName](yowLayerEvent);
            }
            return false;
        }
        
        public virtual object getProp(object key, object @default = null) {
            return this.getStack().getProp(key, @default);
        }
        
        public virtual object setProp(object key, object val) {
            return this.getStack().setProp(key, val);
        }
    }
    
    public class YowProtocolLayer
        : YowLayer {
        
        public Dictionary<object, object> handleMap;
        
        public Dictionary<object, object> iqRegistry;
        
        public YowProtocolLayer(object handleMap = null) {
            this.handleMap = handleMap || new Dictionary<object, object> {
            };
            this.iqRegistry = new Dictionary<object, object> {
            };
        }
        
        public virtual object receive(object node) {
            if (!this.processIqRegistry(node)) {
                if (this.handleMap.Contains(node.tag)) {
                    var _tup_1 = this.handleMap[node.tag];
                    var recv = _tup_1.Item1;
                    if (recv) {
                        recv(node);
                    }
                }
            }
        }
        
        public virtual object send(object entity) {
            if (this.handleMap.Contains(entity.getTag())) {
                var _tup_1 = this.handleMap[entity.getTag()];
                var send = _tup_1.Item2;
                if (send) {
                    send(entity);
                }
            }
        }
        
        public virtual object entityToLower(object entity) {
            //super(YowProtocolLayer, self).toLower(entity.toProtocolTreeNode())
            this.toLower(entity.toProtocolTreeNode());
        }
        
        public virtual object isGroupJid(object jid) {
            return jid.Contains("-");
        }
        
        public virtual object raiseErrorForNode(object node) {
            throw new ValueError(String.Format("Unimplemented notification type %s ", node));
        }
        
        public virtual object _sendIq(object iqEntity, object onSuccess = null, object onError = null) {
            this.iqRegistry[iqEntity.getId()] = (iqEntity, onSuccess, onError);
            this.toLower(iqEntity.toProtocolTreeNode());
        }
        
        public virtual object processIqRegistry(object protocolTreeNode) {
            if (protocolTreeNode.tag == "iq") {
                var iq_id = protocolTreeNode["id"];
                if (this.iqRegistry.Contains(iq_id)) {
                    var _tup_1 = this.iqRegistry[iq_id];
                    var originalIq = _tup_1.Item1;
                    var successClbk = _tup_1.Item2;
                    var errorClbk = _tup_1.Item3;
                    this.iqRegistry.Remove(iq_id);
                    if (protocolTreeNode["type"] == "result" && successClbk) {
                        successClbk(protocolTreeNode, originalIq);
                    } else if (protocolTreeNode["type"] == "error" && errorClbk) {
                        errorClbk(protocolTreeNode, originalIq);
                    }
                    return true;
                }
            }
            return false;
        }
    }
    
    public class YowParallelLayer
        : YowLayer {
        
        public tuple sublayers;
        
        public YowParallelLayer(object sublayers = null) {
            this.sublayers = sublayers || new List<object>();
            this.sublayers = tuple((from sublayer in sublayers
                select sublayer()).ToList());
            foreach (var s in this.sublayers) {
                //s.setLayers(self, self)
                s.toLower = this.toLower;
                s.toUpper = this.toUpper;
                s.boadcastEvent = this.subBroadcastEvent;
                s.emitEvent = this.subEmitEvent;
            }
        }
        
        public virtual object getLayerInterface(object YowLayerClass) {
            foreach (var s in this.sublayers) {
                if (s.@__class__ == YowLayerClass) {
                    return s.getLayerInterface();
                }
            }
        }
        
        public virtual object setStack(object stack) {
            super(YowParallelLayer, this).setStack(stack);
            foreach (var s in this.sublayers) {
                s.setStack(this.getStack());
            }
        }
        
        public virtual object receive(object data) {
            foreach (var s in this.sublayers) {
                s.receive(data);
            }
        }
        
        public virtual object send(object data) {
            foreach (var s in this.sublayers) {
                s.send(data);
            }
        }
        
        public virtual object subBroadcastEvent(object yowLayerEvent) {
            this.onEvent(yowLayerEvent);
            this.boadcastEvent(yowLayerEvent);
        }
        
        public virtual object subEmitEvent(object yowLayerEvent) {
            this.onEvent(yowLayerEvent);
            this.emitEvent(yowLayerEvent);
        }
        
        public virtual object onEvent(object yowLayerEvent) {
            var stopEvent = false;
            foreach (var s in this.sublayers) {
                stopEvent = stopEvent || s.onEvent(yowLayerEvent);
            }
            return stopEvent;
        }
        
        public override object ToString() {
            return " - ".join((from l in this.sublayers
                select l.@__str__()).ToList());
        }
    }
    
    public class YowLayerInterface
        : object {
        
        public object _layer;
        
        public YowLayerInterface(object layer) {
            this._layer = layer;
        }
    }
    
    public class YowLayerTest
        : unittest.TestCase {
        
        public object boadcastEvent;
        
        public object emitEvent;
        
        public List<object> lowerEventSink;
        
        public List<object> lowerSink;
        
        public object toLower;
        
        public object toUpper;
        
        public List<object> upperEventSink;
        
        public List<object> upperSink;
        
        public YowLayerTest(params object [] args) {
            this.upperSink = new List<object>();
            this.lowerSink = new List<object>();
            this.toUpper = this.receiveOverrider;
            this.toLower = this.sendOverrider;
            this.upperEventSink = new List<object>();
            this.lowerEventSink = new List<object>();
            this.emitEvent = this.emitEventOverrider;
            this.boadcastEvent = this.boadcastEventOverrider;
        }
        
        public virtual object receiveOverrider(object data) {
            this.upperSink.append(data);
        }
        
        public virtual object sendOverrider(object data) {
            this.lowerSink.append(data);
        }
        
        public virtual object emitEventOverrider(object @event) {
            this.upperEventSink.append(@event);
        }
        
        public virtual object boadcastEventOverrider(object @event) {
            this.lowerEventSink.append(@event);
        }
        
        public virtual object assert_emitEvent(object @event) {
            this.emitEvent(@event);
            try {
                this.assertEqual(@event, this.upperEventSink.pop());
            } catch (IndexError) {
                throw new AssertionError(String.Format("Event '%s' was not emited through this layer", @event.getName()));
            }
        }
        
        public virtual object assert_broadcastEvent(object @event) {
            this.boadcastEvent(@event);
            try {
                this.assertEqual(@event, this.lowerEventSink.pop());
            } catch (IndexError) {
                throw new AssertionError(String.Format("Event '%s' was not broadcasted through this layer", @event.getName()));
            }
        }
    }
    
    public class YowProtocolLayerTest
        : YowLayerTest {
        
        public virtual object assertSent(object entity) {
            this.send(entity);
            try {
                this.assertEqual(entity.toProtocolTreeNode(), this.lowerSink.pop());
            } catch (IndexError) {
                throw new AssertionError(String.Format("Entity '%s' was not sent through this layer", entity.getTag()));
            }
        }
        
        public virtual object assertReceived(object entity) {
            var node = entity.toProtocolTreeNode();
            this.receive(node);
            try {
                this.assertEqual(node, this.upperSink.pop().toProtocolTreeNode());
            } catch (IndexError) {
                throw new AssertionError(String.Format("'%s' was not received through this layer", entity.getTag()));
            }
        }
    }
}
