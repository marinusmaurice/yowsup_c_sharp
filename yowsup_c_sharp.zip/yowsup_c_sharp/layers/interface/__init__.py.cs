namespace yowsup.layers.interface {
    
    using YowInterfaceLayer = interface.YowInterfaceLayer;
    
    using ProtocolEntityCallback = interface.ProtocolEntityCallback;
    
    public static class @__init__ {
    }
}
