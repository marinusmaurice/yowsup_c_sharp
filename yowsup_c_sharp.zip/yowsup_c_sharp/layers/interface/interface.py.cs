using YowLayer = yowsup.layers.YowLayer;
    
using YowLayerEvent = yowsup.layers.YowLayerEvent;
    
using IqProtocolEntity = yowsup.layers.protocol_iq.protocolentities.IqProtocolEntity;
    
using YowAuthenticationProtocolLayer = yowsup.layers.auth.YowAuthenticationProtocolLayer;
    
using RequestUploadIqProtocolEntity = yowsup.layers.protocol_media.protocolentities.iq_requestupload.RequestUploadIqProtocolEntity;
    
using MediaUploader = yowsup.layers.protocol_media.mediauploader.MediaUploader;
    
using YowNetworkLayer = yowsup.layers.network.layer.YowNetworkLayer;
    
using StreamErrorProtocolEntity = yowsup.layers.auth.protocolentities.StreamErrorProtocolEntity;
    
using EventCallback = yowsup.layers.EventCallback;
    
using inspect;
    
using logging;
    
using System.Collections.Generic;
    
using System.Diagnostics;
    
using System;

namespace yowsup.layers.@interface {
    
    
    public static class @interface {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class ProtocolEntityCallback
            : object {
            
            public object entityType;
            
            public ProtocolEntityCallback(object entityType) {
                this.entityType = entityType;
            }
            
            public virtual object @__call__(object fn) {
                fn.entity_callback = this.entityType;
                return fn;
            }
        }
        
        public class YowInterfaceLayer
            : YowLayer {
            
            public Dictionary<object, object> entity_callbacks;
            
            public Dictionary<object, object> iqRegistry;
            
          //  public string PROP_RECONNECT_ON_STREAM_ERR;
            
            public bool reconnect;
            
            public string PROP_RECONNECT_ON_STREAM_ERR = "org.openwhatsapp.yowsup.prop.interface.reconnect_on_stream_error";
            
            public YowInterfaceLayer() {
                this.reconnect = false;
                this.entity_callbacks = new Dictionary<object, object> {
                };
                this.iqRegistry = new Dictionary<object, object> {
                };
                // self.receiptsRegistry = {}
                var members = inspect.getmembers(this, predicate: inspect.ismethod);
                foreach (var m in members) {
                    if (hasattr(m[1], "entity_callback")) {
                        var fname = m[0];
                        var fn = m[1];
                        this.entity_callbacks[fn.entity_callback] = getattr(this, fname);
                    }
                }
            }
            
            public virtual object _sendIq(object iqEntity, object onSuccess = null, object onError = null) {
                Debug.Assert(iqEntity.getTag() == "iq");
                Debug.Assert(String.Format("Expected *IqProtocolEntity in _sendIq, got %s", iqEntity.getTag()));
                this.iqRegistry[iqEntity.getId()] = (iqEntity, onSuccess, onError);
                this.toLower(iqEntity);
            }
            
            // 
            //         :type entity: IqProtocolEntity
            //         
            public virtual object processIqRegistry(object entity) {
                if (entity.getTag() == "iq") {
                    var iq_id = entity.getId();
                    if (this.iqRegistry.Contains(iq_id)) {
                        var _tup_1 = this.iqRegistry[iq_id];
                        var originalIq = _tup_1.Item1;
                        var successClbk = _tup_1.Item2;
                        var errorClbk = _tup_1.Item3;
                        this.iqRegistry.Remove(iq_id);
                        if (entity.getType() == IqProtocolEntity.TYPE_RESULT && successClbk) {
                            successClbk(entity, originalIq);
                        } else if (entity.getType() == IqProtocolEntity.TYPE_ERROR && errorClbk) {
                            errorClbk(entity, originalIq);
                        }
                        return true;
                    }
                }
                return false;
            }
            
            public virtual object getOwnJid(object full = true) {
                return this.getLayerInterface(YowAuthenticationProtocolLayer).getUsername(full);
            }
            
            public virtual object connect() {
                this.getLayerInterface(YowNetworkLayer).connect();
            }
            
            public virtual object disconnect() {
                var disconnectEvent = YowLayerEvent(YowNetworkLayer.EVENT_STATE_DISCONNECT);
                this.boadcastEvent(disconnectEvent);
            }
            
            public virtual object send(object data)
            {
                return data.ToString().ToLower();
            }
            
            public virtual object receive(object entity) {
                if (!this.processIqRegistry(entity)) {
                    var entityType = entity.getTag();
                    if (this.entity_callbacks.Contains(entityType)) {
                        this.entity_callbacks[entityType](entity);
                    } else {
                        this.toUpper(entity);
                    }
                }
            }
            
            [ProtocolEntityCallback("stream:error")]
            public virtual object onStreamError(object streamErrorEntity) {
                logger.error(streamErrorEntity);
                if (this.getProp(this.@__class__.PROP_RECONNECT_ON_STREAM_ERR, true)) {
                    if (streamErrorEntity.getErrorType() == StreamErrorProtocolEntity.TYPE_CONFLICT) {
                        logger.warn("Not reconnecting because you signed in in another location");
                    } else {
                        logger.info("Initiating reconnect");
                        this.reconnect = true;
                    }
                } else {
                    logger.warn(String.Format("Not reconnecting because property %s is not set", this.@__class__.PROP_RECONNECT_ON_STREAM_ERR));
                }
                this.toUpper(streamErrorEntity);
                this.disconnect();
            }
            
            [EventCallback(YowNetworkLayer.EVENT_STATE_CONNECTED)]
            public virtual object onConnected(object yowLayerEvent) {
                this.reconnect = false;
            }
            
            [EventCallback(YowNetworkLayer.EVENT_STATE_DISCONNECTED)]
            public virtual object onDisconnected(object yowLayerEvent) {
                if (this.reconnect) {
                    this.reconnect = false;
                    this.connect();
                }
            }
            
            public virtual object _sendMediaMessage(object builder, object success, object error = null, object progress = null) {
                // axolotlIface = self.getLayerInterface(YowAxolotlLayer)
                // if axolotlIface:
                //     axolotlIface.encryptMedia(builder)
                var iq = RequestUploadIqProtocolEntity(builder.mediaType, filePath: builder.getFilepath(), encrypted: builder.isEncrypted());
                Func<object, object, object> successFn = (resultEntity,requestUploadEntity) => {
                    return this.@__onRequestUploadSuccess(resultEntity, requestUploadEntity, builder, success, error, progress);
                };
                Func<object, object, object> errorFn = (errorEntity,requestUploadEntity) => {
                    return this.@__onRequestUploadError(errorEntity, requestUploadEntity, error);
                };
                this._sendIq(iq, successFn, errorFn);
            }
            
            public virtual object @__onRequestUploadSuccess(
                object resultRequestUploadIqProtocolEntity,
                object requestUploadEntity,
                object builder,
                object success,
                object error = null,
                object progress = null) {
                if (resultRequestUploadIqProtocolEntity.isDuplicate()) {
                    return success(builder.build(resultRequestUploadIqProtocolEntity.getUrl(), resultRequestUploadIqProtocolEntity.getIp()));
                } else {
                    var mediaUploader = MediaUploader(builder.jid, this.getOwnJid(), builder.getFilepath(), resultRequestUploadIqProtocolEntity.getUrl(), resultRequestUploadIqProtocolEntity.getResumeOffset(), successFn, errorFn, progress, asynchronous: true);
                    mediaUploader.start();
                }
                Func<object, object, object, object> successFn = (path,jid,url) => {
                    return this.@__onMediaUploadSuccess(builder, url, resultRequestUploadIqProtocolEntity.getIp(), success);
                };
                Func<object, object, object, object> errorFn = (path,jid,errorText) => {
                    return this.@__onMediaUploadError(builder, errorText, error);
                };
            }
            
            public virtual object @__onRequestUploadError(object errorEntity, object requestUploadEntity, object builder, object error = null) {
                if (error) {
                    return error(errorEntity.code, errorEntity.text, errorEntity.backoff);
                }
            }
            
            public virtual object @__onMediaUploadSuccess(object builder, object url, object ip, object successClbk) {
                var messageNode = builder.build(url, ip);
                return successClbk(messageNode);
            }
            
            public virtual object @__onMediaUploadError(object builder, object errorText, object errorClbk = null) {
                if (errorClbk) {
                    return errorClbk(0, errorText, 0);
                }
            }
            
            public override object ToString() {
                return "Interface Layer";
            }
        }
    }
}
