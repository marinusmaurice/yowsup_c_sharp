namespace yowsup.layers.auth
{

    public static class @__init__ {
    }
}
