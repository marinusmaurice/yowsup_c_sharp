namespace yowsup.layers.auth {
    
    using YowLayerInterface = yowsup.layers.YowLayerInterface;
    
    public static class layer_interface_authentication {
        
        public class YowAuthenticationProtocolLayerInterface
            : YowLayerInterface {
            
            public virtual object setCredentials(object phone, object keypair) {
                this._layer.setCredentials((phone, keypair));
            }
            
            public virtual object getUsername(object full = false) {
                return this._layer.getUsername(full);
            }
        }
    }
}
