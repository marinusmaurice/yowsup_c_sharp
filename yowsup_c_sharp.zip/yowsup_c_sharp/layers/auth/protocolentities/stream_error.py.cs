namespace yowsup.layers.auth.protocolentities {
    
    using ProtocolEntity = yowsup.structs.ProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using System;
    
    using System.Collections.Generic;
    
    public static class stream_error {
        
        public class StreamErrorProtocolEntity
            : ProtocolEntity {
            
            public object data;
            
            public string TYPE_ACK;
            
            public string TYPE_CONFLICT;
            
            public string TYPE_XML_NOT_WELL_FORMED;
            
            public Tuple<string, string, string> TYPES;
            
            public string TYPE_CONFLICT = "conflict";
            
            static StreamErrorProtocolEntity() {
                @"
     <stream:error>
        <conflict></conflict>
        <text>Replaced by new connection</text>
     </stream:error>
    ";
                @"
     <stream:error>
        <ack></ack>
     </stream:error>
    ";
                @"
    <stream:error>
        <xml-not-well-formed>
        </xml-not-well-formed>
    </stream:error>
    ";
            }
            
            public string TYPE_ACK = "ack";
            
            public string TYPE_XML_NOT_WELL_FORMED = "xml-not-well-formed";
            
            public Tuple<string, string, string> TYPES = (TYPE_CONFLICT, TYPE_ACK, TYPE_XML_NOT_WELL_FORMED);
            
            public StreamErrorProtocolEntity(object data = null) {
                data = data || new Dictionary<object, object> {
                };
                this.setErrorData(data);
            }
            
            public virtual object setErrorData(object data) {
                this.data = data;
            }
            
            public virtual object getErrorData() {
                return this.data;
            }
            
            public virtual object getErrorType() {
                foreach (var k in this.data.keys()) {
                    if (this.@__class__.TYPES.Contains(k)) {
                        return k;
                    }
                }
            }
            
            public override object ToString() {
                var @out = String.Format("Stream Error type: %s\n", this.getErrorType());
                @out += String.Format("%s", this.getErrorData());
                @out += "\n";
                return @out;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(StreamErrorProtocolEntity, this).toProtocolTreeNode();
                var type = this.getErrorType();
                node.addChild(ProtocolTreeNode(type));
                if (type == this.@__class__.TYPE_CONFLICT && this.data.Contains("text")) {
                    node.addChild(ProtocolTreeNode("text", data: this.data["text"]));
                }
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object protocolTreeNode) {
                var data = new Dictionary<object, object> {
                };
                foreach (var child in protocolTreeNode.getAllChildren()) {
                    data[child.tag] = child.data;
                }
                return new StreamErrorProtocolEntity(data);
            }
        }
    }
}
