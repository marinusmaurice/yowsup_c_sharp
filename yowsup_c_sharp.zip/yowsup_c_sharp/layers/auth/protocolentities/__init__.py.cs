namespace yowsup.layers.auth.protocolentities
{

    public static class @__init__ {
    }
}
