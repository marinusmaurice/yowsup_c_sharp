namespace yowsup.layers.auth.protocolentities
{

    using ProtocolEntity = yowsup.structs.ProtocolEntity;

    using System.Collections.Generic;

    public static class auth {
        
        public class AuthProtocolEntity
            : ProtocolEntity {
            
            public object mechanism;
            
            public object nonce;
            
            public object passive;
            
            public object user;
            
            public AuthProtocolEntity(object user, object mechanism = "WAUTH-2", object passive = false, object nonce = null) {
                this.user = user;
                this.mechanism = mechanism;
                this.passive = passive;
                this.nonce = nonce;
            }
            
            public virtual object toProtocolTreeNode() {
                var attributes = new Dictionary<object, object> {
                    {
                        "user",
                        this.user},
                    {
                        "mechanism",
                        this.mechanism},
                    {
                        "passive",
                        this.passive ? "true" : "false"}};
                return this._createProtocolTreeNode(attributes, children: null, data: this.nonce);
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                return new AuthProtocolEntity(node.getAttributeValue("user"), node.getAttributeValue("mechanism"), node.getAttributeValue("passive") != "false", node.getData());
            }
        }
    }
}
