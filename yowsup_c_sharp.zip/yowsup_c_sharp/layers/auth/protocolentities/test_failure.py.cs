namespace yowsup.layers.auth.protocolentities
{

    using FailureProtocolEntity = yowsup.layers.auth.protocolentities.failure.FailureProtocolEntity;

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using ProtocolEntityTest = yowsup.structs.protocolentity.ProtocolEntityTest;

    using System.Collections.Generic;

    public static class test_failure {
        
        public class FailureProtocolEntityTest
            : ProtocolEntityTest, unittest.TestCase {
            
            public object node;
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                this.ProtocolEntity = FailureProtocolEntity;
                this.node = ProtocolTreeNode("failure", new Dictionary<object, object> {
                    {
                        "reason",
                        "not-authorized"}});
            }
        }
    }
}
