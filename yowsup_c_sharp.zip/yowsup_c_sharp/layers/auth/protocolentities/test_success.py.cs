namespace yowsup.layers.auth.protocolentities
{

    using SuccessProtocolEntity = yowsup.layers.auth.protocolentities.success.SuccessProtocolEntity;

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using ProtocolEntityTest = yowsup.structs.protocolentity.ProtocolEntityTest;

    using System.Collections.Generic;

    public static class test_success {
        
        public class SuccessProtocolEntityTest
            : ProtocolEntityTest, unittest.TestCase {
            
            public object node;
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                this.ProtocolEntity = SuccessProtocolEntity;
                var attribs = new Dictionary<object, object> {
                    {
                        "creation",
                        "1234"},
                    {
                        "location",
                        "atn"},
                    {
                        "props",
                        "2"},
                    {
                        "t",
                        "1415470561"}};
                this.node = ProtocolTreeNode("success", attribs);
            }
        }
    }
}
