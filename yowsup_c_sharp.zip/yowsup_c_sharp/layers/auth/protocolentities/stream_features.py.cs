namespace yowsup.layers.auth.protocolentities {
    
    using ProtocolEntity = yowsup.structs.ProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using System.Collections.Generic;
    
    using System.Linq;
    
    public static class stream_features {
        
        public class StreamFeaturesProtocolEntity
            : ProtocolEntity {
            
            public List<object> features;
            
            public StreamFeaturesProtocolEntity(object features = null) {
                this.setFeatures(features);
            }
            
            public virtual object setFeatures(object features = null) {
                this.features = features || new List<object>();
            }
            
            public virtual object toProtocolTreeNode() {
                var featureNodes = (from feature in this.features
                    select ProtocolTreeNode(feature)).ToList();
                return this._createProtocolTreeNode(new Dictionary<object, object> {
                }, children: featureNodes, data: null);
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                return new StreamFeaturesProtocolEntity((from fnode in node.getAllChildren()
                    select fnode.tag).ToList());
            }
        }
    }
}
