namespace yowsup.layers.auth.protocolentities
{

    using ProtocolEntity = yowsup.structs.ProtocolEntity;

    using System;

    using System.Collections.Generic;

    public static class success {
        
        public class SuccessProtocolEntity
            : ProtocolEntity {
            
            public int creation;
            
            public object location;
            
            public object props;
            
            public int t;
            
            public SuccessProtocolEntity(object creation, object props, object t, object location) {
                this.location = location;
                this.creation = Convert.ToInt32(creation);
                this.props = props;
                this.t = Convert.ToInt32(t);
            }
            
            public override object ToString() {
                var @out = "Account:\n";
                @out += String.Format("Location: %s\n", this.location);
                @out += String.Format("Creation: %s\n", this.creation);
                @out += String.Format("Props: %s\n", this.props);
                @out += String.Format("t: %s\n", this.t);
                return @out;
            }
            
            public virtual object toProtocolTreeNode() {
                var attributes = new Dictionary<object, object> {
                    {
                        "location",
                        this.location},
                    {
                        "creation",
                        this.creation.ToString()},
                    {
                        "props",
                        this.props},
                    {
                        "t",
                        this.t.ToString()}};
                return this._createProtocolTreeNode(attributes);
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                return new SuccessProtocolEntity(node.getAttributeValue("creation"), node.getAttributeValue("props"), node.getAttributeValue("t"), node.getAttributeValue("location"));
            }
        }
    }
}
