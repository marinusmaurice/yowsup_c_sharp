namespace yowsup.layers.auth.protocolentities
{

    using ProtocolEntity = yowsup.structs.ProtocolEntity;

    using System.Collections.Generic;

    public static class response {
        
        public class ResponseProtocolEntity
            : ProtocolEntity {
            
            public object data;
            
            public object xmlns;
            
            public ResponseProtocolEntity(object data, object xmlns = "urn:ietf:params:xml:ns:xmpp-sasl") {
                this.xmlns = xmlns;
                this.data = data;
            }
            
            public virtual object toProtocolTreeNode() {
                return this._createProtocolTreeNode(new Dictionary<object, object> {
                    {
                        "xmlns",
                        this.xmlns}}, children: null, data: this.data);
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                return new ResponseProtocolEntity(node.getData(), node.getAttributeValue("xmlns"));
            }
        }
    }
}
