namespace yowsup.layers.auth.protocolentities
{

    using ProtocolEntity = yowsup.structs.ProtocolEntity;

    using System.Collections.Generic;

    using System;

    using System.Linq;

    public static class challenge {
        
        public class ChallengeProtocolEntity
            : ProtocolEntity {
            
            public object nonce;
            
            public ChallengeProtocolEntity(object nonce) {
                this.nonce = nonce;
            }
            
            public virtual object getNonce() {
                return this.nonce;
            }
            
            public virtual object toProtocolTreeNode() {
                //return self._createProtocolTreeNode({}, children = None, data = self.nonce)
                return this._createProtocolTreeNode(new Dictionary<object, object> {
                }, children: new List<object>(), data: "".join(map(chr, this.nonce)));
            }
            
            public override object ToString() {
                var @out = "Challenge\n";
                @out += String.Format("Nonce: %s\n", this.nonce);
                return @out;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var nonce = map(ord, node.getData()).ToList();
                var entity = new ChallengeProtocolEntity(bytearray(nonce));
                return entity;
            }
        }
    }
}
