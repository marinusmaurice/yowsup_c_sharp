namespace yowsup.layers.auth.protocolentities
{

    using ProtocolEntity = yowsup.structs.ProtocolEntity;

    using System;

    using System.Collections.Generic;

    public static class failure {
        
        public class FailureProtocolEntity
            : ProtocolEntity {
            
            public object reason;
            
            public FailureProtocolEntity(object reason) {
                this.reason = reason;
            }
            
            public override object ToString() {
                var @out = "Failure:\n";
                @out += String.Format("Reason: %s\n", this.reason);
                return @out;
            }
            
            public virtual object getReason() {
                return this.reason;
            }
            
            public virtual object toProtocolTreeNode() {
                return this._createProtocolTreeNode(new Dictionary<object, object> {
                    {
                        "reason",
                        this.reason}});
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                return new FailureProtocolEntity(node["reason"]);
            }
        }
    }
}
