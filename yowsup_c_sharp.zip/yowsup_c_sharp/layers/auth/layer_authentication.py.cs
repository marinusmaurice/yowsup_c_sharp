namespace yowsup.layers.auth
{

    using YowConstants = yowsup.common.YowConstants;

    using YowProtocolLayer = yowsup.layers.YowProtocolLayer;

    using EventCallback = yowsup.layers.EventCallback;

    using YowNetworkLayer = yowsup.layers.network.YowNetworkLayer;

    using StreamErrorProtocolEntity = protocolentities.StreamErrorProtocolEntity;

    using System.Collections.Generic;

    using System;

    public static class layer_authentication {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class YowAuthenticationProtocolLayer
            : YowProtocolLayer {
            
            public string EVENT_AUTH;
            
            public string EVENT_AUTHED;
            
            public object interface;
            
            public string PROP_CREDENTIALS;
            
            public string PROP_PASSIVE;
            
            public string EVENT_AUTHED = "org.openwhatsapp.yowsup.event.auth.authed";
            
            public string EVENT_AUTH = "org.openwhatsapp.yowsup.event.auth";
            
            public string PROP_CREDENTIALS = "org.openwhatsapp.yowsup.prop.auth.credentials";
            
            public string PROP_PASSIVE = "org.openwhatsapp.yowsup.prop.auth.passive";
            
            public YowAuthenticationProtocolLayer() {
                var handleMap = new Dictionary<object, object> {
                    {
                        "stream:features",
                        (this.handleStreamFeatures, null)},
                    {
                        "failure",
                        (this.handleFailure, null)},
                    {
                        "success",
                        (this.handleSuccess, null)},
                    {
                        "stream:error",
                        (this.handleStreamError, null)}};
                super(YowAuthenticationProtocolLayer, this).@__init__(handleMap);
                this.interface = YowAuthenticationProtocolLayerInterface(this);
            }
            
            public override object ToString() {
                return "Authentication Layer";
            }
            
            [EventCallback(YowNetworkLayer.EVENT_STATE_CONNECTED)]
            public virtual object on_connected(object @event) {
                this.boadcastEvent(YowLayerEvent(this.EVENT_AUTH, passive: this.getProp(this.PROP_PASSIVE, false)));
            }
            
            public virtual object setCredentials(object credentials) {
                logger.warning("setCredentials is deprecated and has no effect, user stack.setProfile instead");
            }
            
            public virtual object getUsername(object full = false) {
                var username = this.getProp("profile").username;
                return !full ? username : String.Format("%s@%s", username, YowConstants.WHATSAPP_SERVER);
            }
            
            public virtual object handleStreamFeatures(object node) {
                var nodeEntity = StreamFeaturesProtocolEntity.fromProtocolTreeNode(node);
                this.toUpper(nodeEntity);
            }
            
            public virtual object handleSuccess(object node) {
                var successEvent = YowLayerEvent(this.@__class__.EVENT_AUTHED, passive: this.getProp(this.@__class__.PROP_PASSIVE));
                this.boadcastEvent(successEvent);
                var nodeEntity = SuccessProtocolEntity.fromProtocolTreeNode(node);
                this.toUpper(nodeEntity);
            }
            
            public virtual object handleFailure(object node) {
                var nodeEntity = FailureProtocolEntity.fromProtocolTreeNode(node);
                this.toUpper(nodeEntity);
                this.boadcastEvent(YowLayerEvent(YowNetworkLayer.EVENT_STATE_DISCONNECT, reason: "Authentication Failure"));
            }
            
            public virtual object handleStreamError(object node) {
                var nodeEntity = StreamErrorProtocolEntity.fromProtocolTreeNode(node);
                var errorType = nodeEntity.getErrorType();
                if (!errorType) {
                    throw new NotImplementedException(String.Format("Unhandled stream:error node:\n%s", node));
                }
                this.toUpper(nodeEntity);
            }
        }
    }
}
