namespace yowsup.layers.protocol_calls.protocolentities {
    
    using ProtocolEntity = yowsup.structs.ProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using System;
    
    using System.Collections.Generic;
    
    public static class call {
        
        // 
        //     <call offline="0" from="{{CALLER_JID}}" id="{{ID}}" t="{{TIMESTAMP}}" notify="{{CALLER_PUSHNAME}}" retry="{{RETRY}}" e="{{?}}">
        //     </call>
        //     
        //     
        public class CallProtocolEntity
            : ProtocolEntity {
            
            public object _from;
            
            public object _id;
            
            public object _to;
            
            public object _type;
            
            public object callId;
            
            public object e;
            
            public object notify;
            
            public bool offline;
            
            public object retry;
            
            public int timestamp;
            
            public CallProtocolEntity(
                object _id,
                object _type,
                object timestamp,
                object notify = null,
                object offline = null,
                object retry = null,
                object e = null,
                object callId = null,
                object _from = null,
                object _to = null) {
                this._id = _id || this._generateId();
                this._type = _type;
                this._from = _from;
                this._to = _to;
                this.timestamp = Convert.ToInt32(timestamp);
                this.notify = notify;
                this.offline = offline == "1";
                this.retry = retry;
                this.e = e;
                this.callId = callId;
            }
            
            public override object ToString() {
                var @out = "Call\n";
                if (this.getFrom() != null) {
                    @out += String.Format("From: %s\n", this.getFrom());
                }
                if (this.getTo() != null) {
                    @out += String.Format("To: %s\n", this.getTo());
                }
                if (this.getType() != null) {
                    @out += String.Format("Type: %s\n", this.getType());
                }
                if (this.getCallId() != null) {
                    @out += String.Format("Call ID: %s\n", this.getCallId());
                }
                return @out;
            }
            
            public virtual object getFrom(object full = true) {
                return full ? this._from : this._from.split("@")[0];
            }
            
            public virtual object getTo() {
                return this._to;
            }
            
            public virtual object getId() {
                return this._id;
            }
            
            public virtual object getType() {
                return this._type;
            }
            
            public virtual object getCallId() {
                return this.callId;
            }
            
            public virtual object getTimestamp() {
                return this.timestamp;
            }
            
            public virtual object toProtocolTreeNode() {
                var children = new List<object>();
                var attribs = new Dictionary<object, object> {
                    {
                        "t",
                        this.timestamp.ToString()},
                    {
                        "offline",
                        this.offline ? "1" : "0"},
                    {
                        "id",
                        this._id}};
                if (this._from != null) {
                    attribs["from"] = this._from;
                }
                if (this._to != null) {
                    attribs["to"] = this._to;
                }
                if (this.retry != null) {
                    attribs["retry"] = this.retry;
                }
                if (this.e != null) {
                    attribs["e"] = this.e;
                }
                if (this.notify != null) {
                    attribs["notify"] = this.notify;
                }
                if (new List<string> {
                    "offer",
                    "transport",
                    "relaylatency",
                    "reject",
                    "terminate"
                }.Contains(this._type)) {
                    var child = ProtocolTreeNode(this._type, new Dictionary<object, object> {
                        {
                            "call-id",
                            this.callId}});
                    children.append(child);
                }
                return this._createProtocolTreeNode(attribs, children: children, data: null);
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                (_type, callId) = new List<None> {
                    null
                } * 2;
                var offer = node.getChild("offer");
                var transport = node.getChild("transport");
                var relaylatency = node.getChild("relaylatency");
                var reject = node.getChild("reject");
                var terminate = node.getChild("terminate");
                if (offer) {
                    var _type = "offer";
                    var callId = offer.getAttributeValue("call-id");
                } else if (transport) {
                    _type = "transport";
                    callId = transport.getAttributeValue("call-id");
                } else if (relaylatency) {
                    _type = "relaylatency";
                    callId = relaylatency.getAttributeValue("call-id");
                } else if (reject) {
                    _type = "reject";
                    callId = reject.getAttributeValue("call-id");
                } else if (terminate) {
                    _type = "terminate";
                    callId = terminate.getAttributeValue("call-id");
                }
                return new CallProtocolEntity(node.getAttributeValue("id"), _type, node.getAttributeValue("t"), node.getAttributeValue("notify"), node.getAttributeValue("offline"), node.getAttributeValue("retry"), node.getAttributeValue("e"), callId, node.getAttributeValue("from"), node.getAttributeValue("to"));
            }
        }
    }
}
