namespace yowsup.layers.protocol_calls.protocolentities
{

    public static class @__init__ {
    }
}
