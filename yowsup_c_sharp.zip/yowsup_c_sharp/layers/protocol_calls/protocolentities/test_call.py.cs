namespace yowsup.layers.protocol_calls.protocolentities
{

    using CallProtocolEntity = yowsup.layers.protocol_calls.protocolentities.call.CallProtocolEntity;

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using ProtocolEntityTest = yowsup.structs.protocolentity.ProtocolEntityTest;

    using System.Collections.Generic;

    public static class test_call {
        
        public class CallProtocolEntityTest
            : ProtocolEntityTest, unittest.TestCase {
            
            public object node;
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                this.ProtocolEntity = CallProtocolEntity;
                var children = new List<object> {
                    ProtocolTreeNode("offer", new Dictionary<object, object> {
                        {
                            "call-id",
                            "call_id"}})
                };
                var attribs = new Dictionary<object, object> {
                    {
                        "t",
                        "12345"},
                    {
                        "from",
                        "from_jid"},
                    {
                        "offline",
                        "0"},
                    {
                        "id",
                        "message_id"},
                    {
                        "notify",
                        "notify_name"}};
                this.node = ProtocolTreeNode("call", attribs, children);
            }
        }
    }
}
