namespace yowsup.layers.protocol_calls
{

    public static class @__init__ {
    }
}
