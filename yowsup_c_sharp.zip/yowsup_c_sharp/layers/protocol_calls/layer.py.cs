namespace yowsup.layers.protocol_calls {
    
    using YowProtocolLayer = yowsup.layers.YowProtocolLayer;
    
    using OutgoingAckProtocolEntity = yowsup.layers.protocol_acks.protocolentities.OutgoingAckProtocolEntity;
    
    using OutgoingReceiptProtocolEntity = yowsup.layers.protocol_receipts.protocolentities.OutgoingReceiptProtocolEntity;
    
    using System.Collections.Generic;
    
    public static class layer {
        
        public class YowCallsProtocolLayer
            : YowProtocolLayer {
            
            public YowCallsProtocolLayer() {
                var handleMap = new Dictionary<object, object> {
                    {
                        "call",
                        (this.recvCall, this.sendCall)}};
                super(YowCallsProtocolLayer, this).@__init__(handleMap);
            }
            
            public override object ToString() {
                return "call Layer";
            }
            
            public virtual object sendCall(object entity) {
                if (entity.getTag() == "call") {
                    this.toLower(entity.toProtocolTreeNode());
                }
            }
            
            public virtual object recvCall(object node) {
                var entity = CallProtocolEntity.fromProtocolTreeNode(node);
                if (entity.getType() == "offer") {
                    var receipt = OutgoingReceiptProtocolEntity(node["id"], node["from"], callId: entity.getCallId());
                    this.toLower(receipt.toProtocolTreeNode());
                } else {
                    var ack = OutgoingAckProtocolEntity(node["id"], "call", null, node["from"]);
                    this.toLower(ack.toProtocolTreeNode());
                }
                this.toUpper(entity);
            }
        }
    }
}
