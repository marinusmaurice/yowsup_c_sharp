using YowLayer = yowsup.layers.YowLayer;

using System.Linq;

using System;

namespace yowsup.layers.logger
{

 
    public static class layer {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class YowLoggerLayer
            : YowLayer {
            
            public virtual object send(string data) {
                var ldata = object.ReferenceEquals(typeof(data), bytearray) ? data.ToList() : data;
                logger.debug(String.Format("tx:\n%s", ldata));
                return data.ToString().ToLower();
            }
            
            public virtual object receive(string data) {
                var ldata = object.ReferenceEquals(type(data), bytearray) ? data.ToList() : data;
                logger.debug(String.Format("rx:\n%s", ldata));
                return data.ToString().ToUpper();
            }
            
            public override string ToString() {
                return "Logger Layer";
            }
        }
    }
}
