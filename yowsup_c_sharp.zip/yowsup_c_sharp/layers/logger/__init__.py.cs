namespace yowsup.layers.logger
{

    public static class @__init__ {
    }
}
