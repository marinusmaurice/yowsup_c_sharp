namespace yowsup.layers.protocol_messages
{

    using YowProtocolLayer = yowsup.layers.YowProtocolLayer;

    using TextMessageProtocolEntity = protocolentities.TextMessageProtocolEntity;

    using ExtendedTextMessageProtocolEntity = protocolentities.ExtendedTextMessageProtocolEntity;

    using AttributesConverter = yowsup.layers.protocol_messages.protocolentities.attributes.converter.AttributesConverter;

    using MessageMetaAttributes = yowsup.layers.protocol_messages.protocolentities.attributes.attributes_message_meta.MessageMetaAttributes;

    using OutgoingReceiptProtocolEntity = yowsup.layers.protocol_receipts.protocolentities.OutgoingReceiptProtocolEntity;

    using System.Collections.Generic;

    using System;

    public static class layer {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class YowMessagesProtocolLayer
            : YowProtocolLayer {
            
            public YowMessagesProtocolLayer() {
                var handleMap = new Dictionary<object, object> {
                    {
                        "message",
                        (this.recvMessageStanza, this.sendMessageEntity)}};
                super(YowMessagesProtocolLayer, this).@__init__(handleMap);
            }
            
            public override object ToString() {
                return "Messages Layer";
            }
            
            public virtual object sendMessageEntity(object entity) {
                if (entity.getType() == "text") {
                    this.entityToLower(entity);
                }
            }
            
            //##recieved node handlers handlers
            public virtual object recvMessageStanza(object node) {
                var protoNode = node.getChild("proto");
                if (protoNode) {
                    if (protoNode && protoNode["mediatype"] == null) {
                        var message = AttributesConverter.get().protobytes_to_message(protoNode.getData());
                        if (message.conversation) {
                            this.toUpper(TextMessageProtocolEntity(message.conversation, MessageMetaAttributes.from_message_protocoltreenode(node)));
                        } else if (message.extended_text) {
                            this.toUpper(ExtendedTextMessageProtocolEntity(message.extended_text, MessageMetaAttributes.from_message_protocoltreenode(node)));
                        } else if (!message.sender_key_distribution_message) {
                            // Will send receipts for unsupported message types to prevent stream errors
                            logger.warning(String.Format("Unsupported message type: %s, will send receipts to prevent stream errors", message));
                            this.toLower(OutgoingReceiptProtocolEntity(messageIds: new List<object> {
                                node["id"]
                            }, to: node["from"], participant: node["participant"]).toProtocolTreeNode());
                        }
                    }
                }
            }
        }
    }
}
