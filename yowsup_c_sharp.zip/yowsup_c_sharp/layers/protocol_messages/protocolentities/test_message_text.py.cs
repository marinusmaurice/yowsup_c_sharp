namespace yowsup.layers.protocol_messages.protocolentities {
    
    using TextMessageProtocolEntity = yowsup.layers.protocol_messages.protocolentities.message_text.TextMessageProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using MessageProtocolEntityTest = yowsup.layers.protocol_messages.protocolentities.test_message.MessageProtocolEntityTest;
    
    using Message = yowsup.layers.protocol_messages.proto.e2e_pb2.Message;
    
    using System.Collections.Generic;
    
    public static class test_message_text {
        
        public class TextMessageProtocolEntityTest
            : MessageProtocolEntityTest {
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(TextMessageProtocolEntityTest, this).setUp();
                this.ProtocolEntity = TextMessageProtocolEntity;
                var m = Message();
                m.conversation = "body_data";
                var proto_node = ProtocolTreeNode("proto", new Dictionary<object, object> {
                }, null, m.SerializeToString());
                this.node.addChild(proto_node);
            }
        }
    }
}
