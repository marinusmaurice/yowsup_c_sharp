namespace yowsup.layers.protocol_messages.protocolentities {
    
    using ProtocolEntity = yowsup.structs.ProtocolEntity;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using System.Collections.Generic;
    
    public static class proto {
        
        public class ProtoProtocolEntity
            : ProtocolEntity {
            
            public object mediaType;
            
            public object protoData;
            
            public ProtoProtocolEntity(object protoData, object mediaType = null) {
                this.mediaType = mediaType;
                this.protoData = protoData;
            }
            
            public virtual object getProtoData() {
                return this.protoData;
            }
            
            public virtual object getMediaType() {
                return this.mediaType;
            }
            
            public virtual object toProtocolTreeNode() {
                var attribs = new Dictionary<object, object> {
                };
                if (this.mediaType) {
                    attribs["mediatype"] = this.mediaType;
                }
                return ProtocolTreeNode("proto", attribs, data: this.protoData);
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                return new ProtoProtocolEntity(node.data, node["mediatype"]);
            }
        }
    }
}
