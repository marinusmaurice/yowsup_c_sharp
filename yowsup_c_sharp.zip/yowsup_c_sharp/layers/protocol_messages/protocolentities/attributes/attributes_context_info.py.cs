namespace yowsup.layers.protocol_messages.protocolentities.attributes {
    
    using System.Collections.Generic;
    
    using System;
    
    public static class attributes_context_info {
        
        public class ContextInfoAttributes
            : object {
            
            public object _edit_version;
            
            public object _mentioned_jid;
            
            public object _participant;
            
            public object _quoted_message;
            
            public object _remote_jid;
            
            public object _revoke_message;
            
            public object _stanza_id;
            
            public ContextInfoAttributes(
                object stanza_id = null,
                object participant = null,
                object quoted_message = null,
                object remote_jid = null,
                object mentioned_jid = null,
                object edit_version = null,
                object revoke_message = null) {
                this._stanza_id = stanza_id;
                this._participant = participant;
                this._quoted_message = quoted_message;
                this._remote_jid = remote_jid;
                this._mentioned_jid = mentioned_jid || new List<object>();
                this._edit_version = edit_version;
                this._revoke_message = revoke_message;
            }
            
            public override object ToString() {
                var attribs = new List<object>();
                if (this._stanza_id != null) {
                    attribs.append(("stanza_id", this.stanza_id));
                }
                if (this._participant != null) {
                    attribs.append(("participant", this.participant));
                }
                if (this.quoted_message != null) {
                    attribs.append(("quoted_message", this.quoted_message));
                }
                if (this._remote_jid != null) {
                    attribs.append(("remote_jid", this.remote_jid));
                }
                if (this.mentioned_jid != null && this.mentioned_jid.Count) {
                    attribs.append(("mentioned_jid", this.mentioned_jid));
                }
                if (this.edit_version != null) {
                    attribs.append(("edit_version", this.edit_version));
                }
                if (this.revoke_message != null) {
                    attribs.append(("revoke_message", this.revoke_message));
                }
                return String.Format("[%s]", " ".join(map(item => String.Format("%s=%s", item), attribs)));
            }
            
            public object stanza_id {
                get {
                    return this._stanza_id;
                }
                set {
                    this._stanza_id = value;
                }
            }
            
            public object participant {
                get {
                    return this._participant;
                }
                set {
                    this._participant = value;
                }
            }
            
            public object quoted_message {
                get {
                    return this._quoted_message;
                }
                set {
                    this._quoted_message = value;
                }
            }
            
            public object remote_jid {
                get {
                    return this._remote_jid;
                }
                set {
                    this._remote_jid = value;
                }
            }
            
            public object mentioned_jid {
                get {
                    return this._mentioned_jid;
                }
                set {
                    this._mentioned_jid = value;
                }
            }
            
            public object edit_version {
                get {
                    return this._edit_version;
                }
                set {
                    this._edit_version = value;
                }
            }
            
            public object revoke_message {
                get {
                    return this._revoke_message;
                }
                set {
                    this._revoke_message = value;
                }
            }
        }
    }
}
