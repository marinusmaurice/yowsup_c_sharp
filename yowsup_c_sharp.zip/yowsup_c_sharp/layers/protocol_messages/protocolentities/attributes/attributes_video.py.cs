namespace yowsup.layers.protocol_messages.protocolentities.attributes {
    
    using System.Collections.Generic;
    
    using System;
    
    public static class attributes_video {
        
        public class VideoAttributes
            : object {
            
            public object _caption;
            
            public object _downloadablemedia_attributes;
            
            public object _gif_attribution;
            
            public object _gif_playback;
            
            public object _height;
            
            public object _jpeg_thumbnail;
            
            public object _seconds;
            
            public object _streaming_sidecar;
            
            public object _width;
            
            public VideoAttributes(
                object downloadablemedia_attributes,
                object width,
                object height,
                object seconds,
                object gif_playback = null,
                object jpeg_thumbnail = null,
                object gif_attribution = null,
                object caption = null,
                object streaming_sidecar = null) {
                this._downloadablemedia_attributes = downloadablemedia_attributes;
                this._width = width;
                this._height = height;
                this._seconds = seconds;
                this._gif_playback = gif_playback;
                this._jpeg_thumbnail = jpeg_thumbnail;
                this._gif_attribution = gif_attribution;
                this._caption = caption;
                this._streaming_sidecar = streaming_sidecar;
            }
            
            public override object ToString() {
                var attrs = new List<object>();
                if (this.width != null) {
                    attrs.append(("width", this.width));
                }
                if (this.height != null) {
                    attrs.append(("height", this.height));
                }
                if (this.seconds != null) {
                    attrs.append(("seconds", this.seconds));
                }
                if (this.gif_playback != null) {
                    attrs.append(("gif_playback", this.gif_playback));
                }
                if (this.jpeg_thumbnail != null) {
                    attrs.append(("jpeg_thumbnail", "[binary data]"));
                }
                if (this.gif_attribution != null) {
                    attrs.append(("gif_attribution", this.gif_attribution));
                }
                if (this.caption != null) {
                    attrs.append(("caption", this.caption));
                }
                if (this.streaming_sidecar != null) {
                    attrs.append(("streaming_sidecar", "[binary data]"));
                }
                attrs.append(("downloadable", this.downloadablemedia_attributes));
                return String.Format("[%s]", " ".join(map(item => String.Format("%s=%s", item), attrs)));
            }
            
            public object downloadablemedia_attributes {
                get {
                    return this._downloadablemedia_attributes;
                }
                set {
                    this._downloadablemedia_attributes = value;
                }
            }
            
            public object width {
                get {
                    return this._width;
                }
                set {
                    this._width = value;
                }
            }
            
            public object height {
                get {
                    return this._height;
                }
                set {
                    this._height = value;
                }
            }
            
            public object seconds {
                get {
                    return this._seconds;
                }
                set {
                    this._seconds = value;
                }
            }
            
            public object gif_playback {
                get {
                    return this._gif_playback;
                }
                set {
                    this._gif_playback = value;
                }
            }
            
            public object jpeg_thumbnail {
                get {
                    return this._jpeg_thumbnail;
                }
                set {
                    this._jpeg_thumbnail = value;
                }
            }
            
            public object gif_attribution {
                get {
                    return this._gif_attribution;
                }
                set {
                    this._gif_attribution = value;
                }
            }
            
            public object caption {
                get {
                    return this._caption;
                }
                set {
                    this._caption = value;
                }
            }
            
            public object streaming_sidecar {
                get {
                    return this._streaming_sidecar;
                }
                set {
                    this._streaming_sidecar = value;
                }
            }
        }
    }
}
