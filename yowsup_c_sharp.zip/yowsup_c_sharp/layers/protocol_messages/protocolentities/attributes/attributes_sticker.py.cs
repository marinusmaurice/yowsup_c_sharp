namespace yowsup.layers.protocol_messages.protocolentities.attributes {
    
    using System.Collections.Generic;
    
    using System;
    
    public static class attributes_sticker {
        
        public class StickerAttributes
            : object {
            
            public object _downloadablemedia_attributes;
            
            public object _height;
            
            public object _png_thumbnail;
            
            public object _width;
            
            public StickerAttributes(object downloadablemedia_attributes, object width, object height, object png_thumbnail = null) {
                this._downloadablemedia_attributes = downloadablemedia_attributes;
                this._width = width;
                this._height = height;
                this._png_thumbnail = png_thumbnail;
            }
            
            public override object ToString() {
                var attrs = new List<object>();
                if (this.width != null) {
                    attrs.append(("width", this.width));
                }
                if (this.height != null) {
                    attrs.append(("height", this.height));
                }
                if (this.png_thumbnail != null) {
                    attrs.append(("png_thumbnail", this.png_thumbnail));
                }
                attrs.append(("downloadable", this.downloadablemedia_attributes));
                return String.Format("[%s]", " ".join(map(item => String.Format("%s=%s", item), attrs)));
            }
            
            public object downloadablemedia_attributes {
                get {
                    return this._downloadablemedia_attributes;
                }
                set {
                    this._downloadablemedia_attributes = value;
                }
            }
            
            public object width {
                get {
                    return this._width;
                }
                set {
                    this._width = value;
                }
            }
            
            public object height {
                get {
                    return this._height;
                }
                set {
                    this._height = value;
                }
            }
            
            public object png_thumbnail {
                get {
                    return this._png_thumbnail;
                }
                set {
                    this._png_thumbnail = value;
                }
            }
        }
    }
}
