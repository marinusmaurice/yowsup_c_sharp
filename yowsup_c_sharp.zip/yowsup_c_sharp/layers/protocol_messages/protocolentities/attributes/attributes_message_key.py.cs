namespace yowsup.layers.protocol_messages.protocolentities.attributes {
    
    using System.Collections.Generic;
    
    using System;
    
    public static class attributes_message_key {
        
        public class MessageKeyAttributes
            : object {
            
            public object _from_me;
            
            public object _id;
            
            public object _participant;
            
            public object _remote_jid;
            
            public MessageKeyAttributes(object remote_jid, object from_me, object id, object participant) {
                this._remote_jid = remote_jid;
                this._from_me = from_me;
                this._id = id;
                this._participant = participant;
            }
            
            public override object ToString() {
                var attrs = new List<object>();
                if (this.remote_jid != null) {
                    attrs.append(("remote_jid", this.remote_jid));
                }
                if (this.from_me != null) {
                    attrs.append(("from_me", this.from_me));
                }
                if (this.id != null) {
                    attrs.append(("id", this.id));
                }
                if (this.participant != null) {
                    attrs.append(("participant", this.participant));
                }
                return String.Format("[%s]", " ".join(map(item => String.Format("%s=%s", item), attrs)));
            }
            
            public object remote_jid {
                get {
                    return this._remote_jid;
                }
                set {
                    this._remote_jid = value;
                }
            }
            
            public object from_me {
                get {
                    return this._from_me;
                }
                set {
                    this._from_me = value;
                }
            }
            
            public object id {
                get {
                    return this._id;
                }
                set {
                    this._id = value;
                }
            }
            
            public object participant {
                get {
                    return this._participant;
                }
                set {
                    this._participant = value;
                }
            }
        }
    }
}
