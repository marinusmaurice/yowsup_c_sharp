namespace yowsup.layers.protocol_messages.protocolentities.attributes
{

    using System.Collections.Generic;

    using System;

    public static class attributes_message {
        
        public class MessageAttributes
            : object {
            
            public object _audio;
            
            public object _contact;
            
            public object _conversation;
            
            public object _document;
            
            public object _extended_text;
            
            public object _image;
            
            public object _location;
            
            public object _protocol;
            
            public object _sender_key_distribution_message;
            
            public object _sticker;
            
            public object _video;
            
            public MessageAttributes(
                object conversation = null,
                object image = null,
                object contact = null,
                object location = null,
                object extended_text = null,
                object document = null,
                object audio = null,
                object video = null,
                object sticker = null,
                object sender_key_distribution_message = null,
                object protocol = null) {
                this._conversation = conversation;
                this._image = image;
                this._contact = contact;
                this._location = location;
                this._extended_text = extended_text;
                this._document = document;
                this._audio = audio;
                this._video = video;
                this._sticker = sticker;
                this._sender_key_distribution_message = sender_key_distribution_message;
                this._protocol = protocol;
            }
            
            public override object ToString() {
                var attrs = new List<object>();
                if (this.conversation != null) {
                    attrs.append(("conversation", this.conversation));
                }
                if (this.image != null) {
                    attrs.append(("image", this.image));
                }
                if (this.contact != null) {
                    attrs.append(("contact", this.contact));
                }
                if (this.location != null) {
                    attrs.append(("location", this.location));
                }
                if (this.extended_text != null) {
                    attrs.append(("extended_text", this.extended_text));
                }
                if (this.document != null) {
                    attrs.append(("document", this.document));
                }
                if (this.audio != null) {
                    attrs.append(("audio", this.audio));
                }
                if (this.video != null) {
                    attrs.append(("video", this.video));
                }
                if (this.sticker != null) {
                    attrs.append(("sticker", this.sticker));
                }
                if (this._sender_key_distribution_message != null) {
                    attrs.append(("sender_key_distribution_message", this.sender_key_distribution_message));
                }
                if (this._protocol != null) {
                    attrs.append(("protocol", this.protocol));
                }
                return String.Format("[%s]", " ".join(map(item => String.Format("%s=%s", item), attrs)));
            }
            
            public object conversation {
                get {
                    return this._conversation;
                }
                set {
                    this._conversation = value;
                }
            }
            
            public object image {
                get {
                    return this._image;
                }
                set {
                    this._image = value;
                }
            }
            
            public object contact {
                get {
                    return this._contact;
                }
                set {
                    this._contact = value;
                }
            }
            
            public object location {
                get {
                    return this._location;
                }
                set {
                    this._location = value;
                }
            }
            
            public object extended_text {
                get {
                    return this._extended_text;
                }
                set {
                    this._extended_text = value;
                }
            }
            
            public object document {
                get {
                    return this._document;
                }
                set {
                    this._document = value;
                }
            }
            
            public object audio {
                get {
                    return this._audio;
                }
                set {
                    this._audio = value;
                }
            }
            
            public object video {
                get {
                    return this._video;
                }
                set {
                    this._video = value;
                }
            }
            
            public object sticker {
                get {
                    return this._sticker;
                }
                set {
                    this._sticker = value;
                }
            }
            
            public object sender_key_distribution_message {
                get {
                    return this._sender_key_distribution_message;
                }
                set {
                    this._sender_key_distribution_message = value;
                }
            }
            
            public object protocol {
                get {
                    return this._protocol;
                }
                set {
                    this._protocol = value;
                }
            }
        }
    }
}
