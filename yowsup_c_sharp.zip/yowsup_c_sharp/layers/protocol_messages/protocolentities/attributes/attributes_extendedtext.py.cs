namespace yowsup.layers.protocol_messages.protocolentities.attributes {
    
    using System.Collections.Generic;
    
    using System;
    
    public static class attributes_extendedtext {
        
        public class ExtendedTextAttributes
            : object {
            
            public object _canonical_url;
            
            public object _context_info;
            
            public object _description;
            
            public object _jpeg_thumbnail;
            
            public object _matched_text;
            
            public object _text;
            
            public object _title;
            
            public ExtendedTextAttributes(
                object text,
                object matched_text,
                object canonical_url,
                object description,
                object title,
                object jpeg_thumbnail,
                object context_info) {
                this._text = text;
                this._matched_text = matched_text;
                this._canonical_url = canonical_url;
                this._description = description;
                this._title = title;
                this._jpeg_thumbnail = jpeg_thumbnail;
                this._context_info = context_info;
            }
            
            public override object ToString() {
                var attrs = new List<object>();
                if (this.text != null) {
                    attrs.append(("text", this.text));
                }
                if (this.matched_text != null) {
                    attrs.append(("matched_text", this.matched_text));
                }
                if (this.canonical_url != null) {
                    attrs.append(("canonical_url", this.canonical_url));
                }
                if (this.description != null) {
                    attrs.append(("description", this.description));
                }
                if (this.title != null) {
                    attrs.append(("title", this.title));
                }
                if (this.jpeg_thumbnail != null) {
                    attrs.append(("jpeg_thumbnail", "[binary data]"));
                }
                if (this.context_info != null) {
                    attrs.append(("context_info", this.context_info));
                }
                return String.Format("[%s]", " ".join(map(item => String.Format("%s=%s", item), attrs)));
            }
            
            public object text {
                get {
                    return this._text;
                }
                set {
                    this._text = value;
                }
            }
            
            public object matched_text {
                get {
                    return this._matched_text;
                }
                set {
                    this._matched_text = value;
                }
            }
            
            public object canonical_url {
                get {
                    return this._canonical_url;
                }
                set {
                    this._canonical_url = value;
                }
            }
            
            public object description {
                get {
                    return this._description;
                }
                set {
                    this._description = value;
                }
            }
            
            public object title {
                get {
                    return this._title;
                }
                set {
                    this._title = value;
                }
            }
            
            public object jpeg_thumbnail {
                get {
                    return this._jpeg_thumbnail;
                }
                set {
                    this._jpeg_thumbnail = value;
                }
            }
            
            public object context_info {
                get {
                    return this._context_info;
                }
                set {
                    this._context_info = value;
                }
            }
        }
    }
}
