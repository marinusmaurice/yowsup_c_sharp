namespace yowsup.layers.protocol_messages.protocolentities.attributes {
    
    using System.Collections.Generic;
    
    using System;
    
    public static class attributes_contact {
        
        public class ContactAttributes
            : object {
            
            public object _context_info;
            
            public object _display_name;
            
            public object _vcard;
            
            public object context_info;
            
            public ContactAttributes(object display_name, object vcard, object context_info = null) {
                this._display_name = display_name;
                this._vcard = vcard;
                this._context_info = context_info;
            }
            
            public override object ToString() {
                var attrs = new List<object>();
                if (this.display_name != null) {
                    attrs.append(("display_name", this.display_name));
                }
                if (this.vcard != null) {
                    attrs.append(("vcard", "[binary data]"));
                }
                if (this.context_info != null) {
                    attrs.append(("context_info", this.context_info));
                }
                return String.Format("[%s]", " ".join(map(item => String.Format("%s=%s", item), attrs)));
            }
            
            public object display_name {
                get {
                    return this._display_name;
                }
                set {
                    this._display_name = value;
                }
            }
            
            public object vcard {
                get {
                    return this._vcard;
                }
                set {
                    this._vcard = value;
                }
            }
            
            public object context_info {
                get {
                    return this._context_info;
                }
                set {
                    this.context_info = value;
                }
            }
        }
    }
}
