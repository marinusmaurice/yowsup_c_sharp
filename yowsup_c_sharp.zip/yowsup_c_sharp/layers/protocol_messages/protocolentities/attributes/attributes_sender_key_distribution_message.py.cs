namespace yowsup.layers.protocol_messages.protocolentities.attributes {
    
    using System.Collections.Generic;
    
    using System;
    
    public static class attributes_sender_key_distribution_message {
        
        public class SenderKeyDistributionMessageAttributes
            : object {
            
            public object _axolotl_sender_key_distribution_message;
            
            public object _group_id;
            
            public SenderKeyDistributionMessageAttributes(object group_id, object axolotl_sender_key_distribution_message) {
                this._group_id = group_id;
                this._axolotl_sender_key_distribution_message = axolotl_sender_key_distribution_message;
            }
            
            public override object ToString() {
                var attrs = new List<object>();
                if (this.group_id != null) {
                    attrs.append(("group_id", this.group_id));
                }
                if (this.axolotl_sender_key_distribution_message != null) {
                    attrs.append(("axolotl_sender_key_distribution_message", "[binary omitted]"));
                }
                return String.Format("[%s]", " ".join(map(item => String.Format("%s=%s", item), attrs)));
            }
            
            public object group_id {
                get {
                    return this._group_id;
                }
                set {
                    this._group_id = value;
                }
            }
            
            public object axolotl_sender_key_distribution_message {
                get {
                    return this._axolotl_sender_key_distribution_message;
                }
                set {
                    this._axolotl_sender_key_distribution_message = value;
                }
            }
        }
    }
}
