namespace yowsup.layers.protocol_messages.protocolentities.attributes {
    
    using ContextInfoAttributes = yowsup.layers.protocol_messages.protocolentities.attributes.attributes_context_info.ContextInfoAttributes;
    
    using System.Diagnostics;
    
    public static class attributes_media {
        
        public class MediaAttributes
            : object {
            
            public object _context_info;
            
            public MediaAttributes(object context_info = null) {
                if (context_info) {
                    Debug.Assert(object.ReferenceEquals(type(context_info), ContextInfoAttributes));
                    Debug.Assert(type(context_info));
                    this._context_info = context_info;
                } else {
                    this._context_info = null;
                }
            }
            
            public object context_info {
                get {
                    return this._context_info;
                }
                set {
                    Debug.Assert(object.ReferenceEquals(type(value), ContextInfoAttributes));
                    Debug.Assert(type(value));
                    this._context_info = value;
                }
            }
        }
    }
}
