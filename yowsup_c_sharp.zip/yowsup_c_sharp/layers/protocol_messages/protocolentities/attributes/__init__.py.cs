namespace yowsup.layers.protocol_messages.protocolentities.attributes {
    
    public static class @__init__ {
    }
}
