namespace yowsup.layers.protocol_messages.protocolentities.attributes
{

    using MediaAttributes = yowsup.layers.protocol_messages.protocolentities.attributes.attributes_media.MediaAttributes;

    using MimeTools = yowsup.common.tools.MimeTools;

    using System;

    public static class attributes_downloadablemedia {
        
        public class DownloadableMediaMessageAttributes
            : MediaAttributes {
            
            public object _file_length;
            
            public object _file_sha256;
            
            public object _media_key;
            
            public object _mimetype;
            
            public object _url;
            
            public DownloadableMediaMessageAttributes(
                object mimetype,
                object file_length,
                object file_sha256,
                object url = null,
                object media_key = null,
                object context_info = null) {
                this._mimetype = mimetype;
                this._file_length = file_length;
                this._file_sha256 = file_sha256;
                this._url = url;
                this._media_key = media_key;
            }
            
            public override object ToString() {
                return String.Format("[url=%s, mimetype=%s, file_length=%d, file_sha256=%s, media_key=%s]", this.url, this.mimetype, this.file_length, this.file_sha256 ? base64.b64encode(this.file_sha256) : null, this.media_key ? base64.b64encode(this.media_key) : null);
            }
            
            public object url {
                get {
                    return this._url;
                }
                set {
                    this._url = value;
                }
            }
            
            public object mimetype {
                get {
                    return this._mimetype;
                }
                set {
                    this._mimetype = value;
                }
            }
            
            public object file_length {
                get {
                    return this._file_length;
                }
                set {
                    this._file_length = value;
                }
            }
            
            public object file_sha256 {
                get {
                    return this._file_sha256;
                }
                set {
                    this._file_sha256 = value;
                }
            }
            
            public object media_key {
                get {
                    return this._media_key;
                }
                set {
                    this._media_key = value;
                }
            }
            
            [staticmethod]
            public static object from_file(
                object filepath,
                object mimetype = null,
                object file_length = null,
                object file_sha256 = null,
                object url = null,
                object media_key = null,
                object context_info = null) {
                mimetype = mimetype == null ? MimeTools.getMIME(filepath) : mimetype;
                file_length = file_length == null ? os.path.getsize(filepath) : file_length;
                if (file_sha256 == null) {
                    using (var f = open(filepath, "rb")) {
                        file_sha256 = hashlib.sha256(f.read()).digest();
                    }
                }
                return new DownloadableMediaMessageAttributes(mimetype, file_length, file_sha256, url, media_key, context_info);
            }
        }
    }
}
