namespace yowsup.layers.protocol_messages.protocolentities.attributes {
    
    using System.Collections.Generic;
    
    using System;
    
    public static class attributes_location {
        
        public class LocationAttributes
            : object {
            
            public object _accuracy_in_meters;
            
            public object _address;
            
            public object _axolotl_sender_key_distribution_message;
            
            public object _degrees_clockwise_from_magnetic_north;
            
            public object _degrees_latitude;
            
            public object _degrees_longitude;
            
            public object _duration;
            
            public object _jpeg_thumbnail;
            
            public object _name;
            
            public object _speed_in_mps;
            
            public object _url;
            
            public LocationAttributes(
                object degrees_latitude,
                object degrees_longitude,
                object name = null,
                object address = null,
                object url = null,
                object duration = null,
                object accuracy_in_meters = null,
                object speed_in_mps = null,
                object degrees_clockwise_from_magnetic_north = null,
                object axolotl_sender_key_distribution_message = null,
                object jpeg_thumbnail = null) {
                this._degrees_latitude = degrees_latitude;
                this._degrees_longitude = degrees_longitude;
                this._name = name;
                this._address = address;
                this._url = url;
                this._duration = duration;
                this._accuracy_in_meters = accuracy_in_meters;
                this._speed_in_mps = speed_in_mps;
                this._degrees_clockwise_from_magnetic_north = degrees_clockwise_from_magnetic_north;
                this._axolotl_sender_key_distribution_message = axolotl_sender_key_distribution_message;
                this._jpeg_thumbnail = jpeg_thumbnail;
            }
            
            public override object ToString() {
                var attrs = new List<object>();
                if (this.degrees_latitude != null) {
                    attrs.append(("degrees_latitude", this.degrees_latitude));
                }
                if (this.degrees_longitude != null) {
                    attrs.append(("degrees_longitude", this.degrees_longitude));
                }
                if (this.name != null) {
                    attrs.append(("name", this.name));
                }
                if (this.address != null) {
                    attrs.append(("address", this.address));
                }
                if (this.url != null) {
                    attrs.append(("url", this.url));
                }
                if (this.duration != null) {
                    attrs.append(("duration", this.duration));
                }
                if (this.accuracy_in_meters != null) {
                    attrs.append(("accuracy_in_meters", this.accuracy_in_meters));
                }
                if (this.speed_in_mps != null) {
                    attrs.append(("speed_in_mps", this.speed_in_mps));
                }
                if (this.degrees_clockwise_from_magnetic_north != null) {
                    attrs.append(("degrees_clockwise_from_magnetic_north", this.degrees_clockwise_from_magnetic_north));
                }
                if (this.axolotl_sender_key_distribution_message != null) {
                    attrs.append(("axolotl_sender_key_distribution_message", "[binary data]"));
                }
                if (this.jpeg_thumbnail != null) {
                    attrs.append(("jpeg_thumbnail", "[binary data]"));
                }
                return String.Format("[%s]", " ".join(map(item => String.Format("%s=%s", item), attrs)));
            }
            
            public object degrees_latitude {
                get {
                    return this._degrees_latitude;
                }
                set {
                    this._degrees_latitude = value;
                }
            }
            
            public object degrees_longitude {
                get {
                    return this._degrees_longitude;
                }
                set {
                    this._degrees_longitude = value;
                }
            }
            
            public object name {
                get {
                    return this._name;
                }
                set {
                    this._name = value;
                }
            }
            
            public object address {
                get {
                    return this._address;
                }
                set {
                    this._address = value;
                }
            }
            
            public object url {
                get {
                    return this._url;
                }
                set {
                    this._url = value;
                }
            }
            
            public object duration {
                get {
                    return this._duration;
                }
                set {
                    this._duration = value;
                }
            }
            
            public object accuracy_in_meters {
                get {
                    return this._accuracy_in_meters;
                }
                set {
                    this._accuracy_in_meters = value;
                }
            }
            
            public object speed_in_mps {
                get {
                    return this._speed_in_mps;
                }
                set {
                    this._speed_in_mps = value;
                }
            }
            
            public object degrees_clockwise_from_magnetic_north {
                get {
                    return this._degrees_clockwise_from_magnetic_north;
                }
                set {
                    this._degrees_clockwise_from_magnetic_north = value;
                }
            }
            
            public object axolotl_sender_key_distribution_message {
                get {
                    return this._axolotl_sender_key_distribution_message;
                }
                set {
                    this._axolotl_sender_key_distribution_message = value;
                }
            }
            
            public object jpeg_thumbnail {
                get {
                    return this._jpeg_thumbnail;
                }
                set {
                    this._jpeg_thumbnail = value;
                }
            }
        }
    }
}
