namespace yowsup.layers.protocol_messages.protocolentities.attributes {
    
    using System;
    
    using System.Diagnostics;
    
    public static class attributes_message_meta {
        
        public class MessageMetaAttributes
            : object {
            
            public Func<object> id;
            
            public object notify;
            
            public bool offline;
            
            public object participant;
            
            public object recipient;
            
            public int retry;
            
            public object sender;
            
            public int timestamp;
            
            public MessageMetaAttributes(
                object id = null,
                object sender = null,
                object recipient = null,
                object notify = null,
                object timestamp = null,
                object participant = null,
                object offline = null,
                object retry = null) {
                Debug.Assert(sender || recipient);
                Debug.Assert("Must specify either sender or recipient jid to create the message ");
                Debug.Assert(!(sender && recipient));
                Debug.Assert("Can't set both attributes to message at same time (sender, recipient) ");
                this.id = id;
                this.sender = sender;
                this.recipient = recipient;
                this.notify = notify;
                this.timestamp = timestamp ? Convert.ToInt32(timestamp) : null;
                this.participant = participant;
                this.offline = ("1", true).Contains(offline);
                this.retry = retry ? Convert.ToInt32(retry) : null;
            }
            
            [staticmethod]
            public static object from_message_protocoltreenode(object node) {
                return new MessageMetaAttributes(node["id"], node["from"], node["to"], node["notify"], node["t"], node["participant"], node["offline"], node["retry"]);
            }
        }
    }
}
