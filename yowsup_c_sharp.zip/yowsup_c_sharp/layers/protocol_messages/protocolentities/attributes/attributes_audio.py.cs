namespace yowsup.layers.protocol_messages.protocolentities.attributes
{

    using System.Collections.Generic;

    using System;

    public static class attributes_audio {
        
        public class AudioAttributes
            : object {
            
            public object _downloadablemedia_attributes;
            
            public object _ptt;
            
            public object _seconds;
            
            public object _streaming_sidecar;
            
            public AudioAttributes(object downloadablemedia_attributes, object seconds, object ptt, object streaming_sidecar = null) {
                // type: (DownloadableMediaMessageAttributes, int, bool, bytes) -> None
                this._downloadablemedia_attributes = downloadablemedia_attributes;
                this._seconds = seconds;
                this._ptt = ptt;
                this._streaming_sidecar = streaming_sidecar;
            }
            
            public override object ToString() {
                var attrs = new List<object>();
                if (this.seconds != null) {
                    attrs.append(("seconds", this.seconds));
                }
                if (this.ptt != null) {
                    attrs.append(("ptt", this.ptt));
                }
                if (this._streaming_sidecar != null) {
                    attrs.append(("streaming_sidecar", "[binary data]"));
                }
                attrs.append(("downloadable", this.downloadablemedia_attributes));
                return String.Format("[%s]", " ".join(map(item => String.Format("%s=%s", item), attrs)));
            }
            
            public object downloadablemedia_attributes {
                get {
                    return this._downloadablemedia_attributes;
                }
                set {
                    this._downloadablemedia_attributes = value;
                }
            }
            
            public object seconds {
                get {
                    return this._seconds;
                }
                set {
                    this._seconds = value;
                }
            }
            
            public object ptt {
                get {
                    return this._ptt;
                }
                set {
                    this._ptt = value;
                }
            }
            
            public object streaming_sidecar {
                get {
                    return this._streaming_sidecar;
                }
                set {
                    this._streaming_sidecar = value;
                }
            }
        }
    }
}
