namespace yowsup.layers.protocol_messages.protocolentities.attributes
{

    using DownloadableMediaMessageAttributes = yowsup.layers.protocol_messages.protocolentities.attributes.attributes_downloadablemedia.DownloadableMediaMessageAttributes;

    using System.Collections.Generic;

    using System;

    public static class attributes_document {
        
        public class DocumentAttributes
            : object {
            
            public object _downloadablemedia_attributes;
            
            public object _file_length;
            
            public object _file_name;
            
            public object _jpeg_thumbnail;
            
            public object _page_count;
            
            public object _title;
            
            public DocumentAttributes(
                object downloadablemedia_attributes,
                object file_name,
                object file_length,
                object title = null,
                object page_count = null,
                object jpeg_thumbnail = null) {
                this._downloadablemedia_attributes = downloadablemedia_attributes;
                this._file_name = file_name;
                this._file_length = file_length;
                this._title = title;
                this._page_count = page_count;
                this._jpeg_thumbnail = jpeg_thumbnail;
            }
            
            public override object ToString() {
                var attrs = new List<object>();
                if (this.file_name != null) {
                    attrs.append(("file_name", this.file_name));
                }
                if (this.file_length != null) {
                    attrs.append(("file_length", this.file_length));
                }
                if (this.title != null) {
                    attrs.append(("title", this.title));
                }
                if (this.page_count != null) {
                    attrs.append(("page_count", this.page_count));
                }
                if (this.jpeg_thumbnail != null) {
                    attrs.append(("jpeg_thumbnail", this.jpeg_thumbnail));
                }
                attrs.append(("downloadable", this.downloadablemedia_attributes));
                return String.Format("[%s]", " ".join(map(item => String.Format("%s=%s", item), attrs)));
            }
            
            public object downloadablemedia_attributes {
                get {
                    return this._downloadablemedia_attributes;
                }
                set {
                    this._downloadablemedia_attributes = value;
                }
            }
            
            public object file_name {
                get {
                    return this._file_name;
                }
                set {
                    this._file_name = value;
                }
            }
            
            public object file_length {
                get {
                    return this._file_length;
                }
                set {
                    this._file_length = value;
                }
            }
            
            public object title {
                get {
                    return this._title;
                }
                set {
                    this._title = value;
                }
            }
            
            public object page_count {
                get {
                    return this._page_count;
                }
                set {
                    this._page_count = value;
                }
            }
            
            public object jpeg_thumbnail {
                get {
                    return this._jpeg_thumbnail;
                }
                set {
                    this._jpeg_thumbnail = value;
                }
            }
            
            [staticmethod]
            public static object from_filepath(object filepath) {
                return new DocumentAttributes(DownloadableMediaMessageAttributes.from_file(filepath), os.path.basename(filepath), os.path.getsize(filepath));
            }
        }
    }
}
