namespace yowsup.layers.protocol_messages.protocolentities.attributes {
    
    using MessageKeyAttributes = yowsup.layers.protocol_messages.protocolentities.attributes.attributes_message_key.MessageKeyAttributes;
    
    using System.Collections.Generic;
    
    using System;
    
    using System.Diagnostics;
    
    public static class attributes_protocol {
        
        public class ProtocolAttributes
            : object {
            
            public object _key;
            
            public object _type;
            
            public int TYPE_REOVOKE;
            
            public Dictionary<int, string> TYPES;
            
            public int TYPE_REOVOKE = 0;
            
            public Dictionary<int, string> TYPES = new Dictionary<object, object> {
                {
                    TYPE_REOVOKE,
                    "REVOKE"}};
            
            public ProtocolAttributes(object key, object type) {
                this.key = key;
                this.type = type;
            }
            
            public override object ToString() {
                return String.Format("[type=%s, key=%s]", this.TYPES[this.type], this.key);
            }
            
            public object key {
                get {
                    return this._key;
                }
                set {
                    Debug.Assert(value is MessageKeyAttributes);
                    Debug.Assert(type(value));
                    this._key = value;
                }
            }
            
            public object type {
                get {
                    return this._type;
                }
                set {
                    Debug.Assert(this.TYPES.Contains(value));
                    Debug.Assert(String.Format("Unknown type: %s", value));
                    this._type = value;
                }
            }
        }
    }
}
