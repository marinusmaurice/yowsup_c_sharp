namespace yowsup.layers.protocol_messages.protocolentities.attributes
{

    using Message = yowsup.layers.protocol_messages.proto.e2e_pb2.Message;

    using MessageKey = yowsup.layers.protocol_messages.proto.protocol_pb2.MessageKey;

    using ContextInfo = yowsup.layers.protocol_messages.proto.e2e_pb2.ContextInfo;

    using MessageKeyAttributes = yowsup.layers.protocol_messages.protocolentities.attributes.attributes_protocol.MessageKeyAttributes;

    using System.Collections.Generic;

    public static class converter {
        
        public class AttributesConverter
            : object {
            
            public AttributesConverter @__instance;
            
            public None @__instance = null;
            
            [classmethod]
            public static object get(object cls) {
                if (cls.@__instance == null) {
                    cls.@__instance = new AttributesConverter();
                }
                return cls.@__instance;
            }
            
            public virtual object sender_key_distribution_message_to_proto(object sender_key_distribution_message_attributes) {
                // type: (SenderKeyDistributionMessageAttributes) -> Message.SenderKeyDistributionMessage
                var message = Message.SenderKeyDistributionMessage();
                message.group_id = sender_key_distribution_message_attributes.group_id;
                message.axolotl_sender_key_distribution_message = sender_key_distribution_message_attributes.axolotl_sender_key_distribution_message;
                return message;
            }
            
            public virtual object proto_to_sender_key_distribution_message(object proto) {
                return SenderKeyDistributionMessageAttributes(proto.group_id, proto.axolotl_sender_key_distribution_message);
            }
            
            public virtual object message_key_to_proto(object message_key) {
                // type: (MessageKeyAttributes) -> MessageKey
                var @out = MessageKey();
                @out.remote_jid = message_key.remote_jid;
                @out.from_me = message_key.from_me;
                @out.id = message_key.id;
                @out.participant = message_key.participant;
                return @out;
            }
            
            public virtual object proto_to_message_key(object proto) {
                return MessageKeyAttributes(proto.remote_jid, proto.from_me, proto.id, proto.participant);
            }
            
            public virtual object protocol_to_proto(object protocol) {
                // type: (ProtocolAttributes) -> Message.ProtocolMessage
                var message = Message.ProtocolMessage();
                message.key.MergeFrom(this.message_key_to_proto(protocol.key));
                message.type = protocol.type;
                return message;
            }
            
            public virtual object proto_to_protocol(object proto) {
                return ProtocolAttributes(this.proto_to_message_key(proto.key), proto.type);
            }
            
            public virtual object contact_to_proto(object contact_attributes) {
                // type: (ContactAttributes) -> Message.ContactMessage
                var contact_message = Message.ContactMessage();
                contact_message.display_name = contact_attributes.display_name;
                contact_message.vcard = contact_attributes.vcard;
                if (contact_attributes.context_info != null) {
                    contact_message.context_info.MergeFrom(this.contextinfo_to_proto(contact_attributes.context_info));
                }
                return contact_message;
            }
            
            public virtual object proto_to_contact(object proto) {
                // type: (Message.ContactMessage) -> ContactAttributes
                return ContactAttributes(proto.display_name, proto.vcard, proto.HasField("context_info") ? this.proto_to_contextinfo(proto.context_info) : null);
            }
            
            public virtual object location_to_proto(object location_attributes) {
                // type: (LocationAttributes) -> Message.LocationMessage
                var location_message = Message.LocationMessage();
                if (location_attributes.degrees_latitude != null) {
                    location_message.degrees_latitude = location_attributes.degrees_latitude;
                }
                if (location_attributes.degrees_longitude != null) {
                    location_message.degrees_longitude = location_attributes.degrees_longitude;
                }
                if (location_attributes.name != null) {
                    location_message.name = location_attributes.name;
                }
                if (location_attributes.address != null) {
                    location_message.address = location_attributes.address;
                }
                if (location_attributes.url != null) {
                    location_message.url = location_attributes.url;
                }
                if (location_attributes.duration != null) {
                    location_message.duration = location_attributes.duration;
                }
                if (location_attributes.accuracy_in_meters != null) {
                    location_message.accuracy_in_meters = location_attributes.accuracy_in_meters;
                }
                if (location_attributes.speed_in_mps != null) {
                    location_message.speed_in_mps = location_attributes.speed_in_mps;
                }
                if (location_attributes.degrees_clockwise_from_magnetic_north != null) {
                    location_message.degrees_clockwise_from_magnetic_north = location_attributes.degrees_clockwise_from_magnetic_north;
                }
                if (location_attributes.axolotl_sender_key_distribution_message != null) {
                    location_message._axolotl_sender_key_distribution_message = location_attributes.axolotl_sender_key_distribution_message;
                }
                if (location_attributes.jpeg_thumbnail != null) {
                    location_message.jpeg_thumbnail = location_attributes.jpeg_thumbnail;
                }
                return location_message;
            }
            
            public virtual object proto_to_location(object proto) {
                // type: (Message.LocationMessage) -> LocationAttributes
                return LocationAttributes(proto.HasField("degrees_latitude") ? proto.degrees_latitude : null, proto.HasField("degrees_longitude") ? proto.degrees_longitude : null, proto.HasField("name") ? proto.name : null, proto.HasField("address") ? proto.address : null, proto.HasField("url") ? proto.url : null, proto.HasField("duration") ? proto.duration : null, proto.HasField("accuracy_in_meters") ? proto.accuracy_in_meters : null, proto.HasField("speed_in_mps") ? proto.speed_in_mps : null, proto.HasField("degrees_clockwise_from_magnetic_north") ? proto.degrees_clockwise_from_magnetic_north : null, proto.HasField("axolotl_sender_key_distribution_message") ? proto.axolotl_sender_key_distribution_message : null, proto.HasField("jpeg_thumbnail") ? proto.jpeg_thumbnail : null);
            }
            
            public virtual object image_to_proto(object image_attributes) {
                // type: (ImageAttributes) -> Message.ImageMessage
                var image_message = Message.ImageMessage();
                image_message.width = image_attributes.width;
                image_message.height = image_attributes.height;
                if (image_attributes.caption != null) {
                    image_message.caption = image_attributes.caption;
                }
                if (image_attributes.jpeg_thumbnail != null) {
                    image_message.jpeg_thumbnail = image_attributes.jpeg_thumbnail;
                }
                return this.downloadablemedia_to_proto(image_attributes.downloadablemedia_attributes, image_message);
            }
            
            public virtual object proto_to_image(object proto) {
                // type: (Message.ImageMessage) -> ImageAttributes
                return ImageAttributes(this.proto_to_downloadablemedia(proto), proto.width, proto.height, proto.HasField("caption") ? proto.caption : null, proto.HasField("jpeg_thumbnail") ? proto.jpeg_thumbnail : null);
            }
            
            public virtual object extendedtext_to_proto(object extendedtext_attributes) {
                // type: (ExtendedTextAttributes) -> Message.ExtendedTextMessage
                var m = Message.ExtendedTextMessage();
                if (extendedtext_attributes.text != null) {
                    m.text = extendedtext_attributes.text;
                }
                if (extendedtext_attributes.matched_text != null) {
                    m.matched_text = extendedtext_attributes.matched_text;
                }
                if (extendedtext_attributes.canonical_url != null) {
                    m.canonical_url = extendedtext_attributes.canonical_url;
                }
                if (extendedtext_attributes.description != null) {
                    m.description = extendedtext_attributes.description;
                }
                if (extendedtext_attributes.title != null) {
                    m.title = extendedtext_attributes.title;
                }
                if (extendedtext_attributes.jpeg_thumbnail != null) {
                    m.jpeg_thumbnail = extendedtext_attributes.jpeg_thumbnail;
                }
                if (extendedtext_attributes.context_info != null) {
                    m.context_info.MergeFrom(this.contextinfo_to_proto(extendedtext_attributes.context_info));
                }
                return m;
            }
            
            public virtual object proto_to_extendedtext(object proto) {
                // type: (Message.ExtendedTextMessage) -> ExtendedTextAttributes
                return ExtendedTextAttributes(proto.HasField("text") ? proto.text : null, proto.HasField("matched_text") ? proto.matched_text : null, proto.HasField("canonical_url") ? proto.canonical_url : null, proto.HasField("description") ? proto.description : null, proto.HasField("title") ? proto.title : null, proto.HasField("jpeg_thumbnail") ? proto.jpeg_thumbnail : null, proto.HasField("context_info") ? this.proto_to_contextinfo(proto.context_info) : null);
            }
            
            public virtual object document_to_proto(object document_attributes) {
                // type: (DocumentAttributes) -> Message.DocumentMessage
                var m = Message.DocumentMessage();
                if (document_attributes.file_name != null) {
                    m.file_name = document_attributes.file_name;
                }
                if (document_attributes.file_length != null) {
                    m.file_length = document_attributes.file_length;
                }
                if (document_attributes.title != null) {
                    m.title = document_attributes.title;
                }
                if (document_attributes.page_count != null) {
                    m.page_count = document_attributes.page_count;
                }
                if (document_attributes.jpeg_thumbnail != null) {
                    m.jpeg_thumbnail = document_attributes.jpeg_thumbnail;
                }
                return this.downloadablemedia_to_proto(document_attributes.downloadablemedia_attributes, m);
            }
            
            public virtual object proto_to_document(object proto) {
                return DocumentAttributes(this.proto_to_downloadablemedia(proto), proto.HasField("file_name") ? proto.file_name : null, proto.HasField("file_length") ? proto.file_length : null, proto.HasField("title") ? proto.title : null, proto.HasField("page_count") ? proto.page_count : null, proto.HasField("jpeg_thumbnail") ? proto.jpeg_thumbnail : null);
            }
            
            public virtual object audio_to_proto(object audio_attributes) {
                // type: (AudioAttributes) -> Message.AudioMessage
                var m = Message.AudioMessage();
                if (audio_attributes.seconds != null) {
                    m.seconds = audio_attributes.seconds;
                }
                if (audio_attributes.ptt != null) {
                    m.ptt = audio_attributes.ptt;
                }
                return this.downloadablemedia_to_proto(audio_attributes.downloadablemedia_attributes, m);
            }
            
            public virtual object proto_to_audio(object proto) {
                return AudioAttributes(this.proto_to_downloadablemedia(proto), proto.seconds, proto.ptt);
            }
            
            public virtual object video_to_proto(object video_attributes) {
                // type: (VideoAttributes) -> Message.VideoMessage
                var m = Message.VideoMessage();
                if (video_attributes.width != null) {
                    m.width = video_attributes.width;
                }
                if (video_attributes.height != null) {
                    m.height = video_attributes.height;
                }
                if (video_attributes.seconds != null) {
                    m.seconds = video_attributes.seconds;
                }
                if (video_attributes.gif_playback != null) {
                    m.gif_playback = video_attributes.gif_playback;
                }
                if (video_attributes.jpeg_thumbnail != null) {
                    m.jpeg_thumbnail = video_attributes.jpeg_thumbnail;
                }
                if (video_attributes.gif_attribution != null) {
                    m.gif_attribution = video_attributes.gif_attribution;
                }
                if (video_attributes.caption != null) {
                    m.caption = video_attributes.caption;
                }
                if (video_attributes.streaming_sidecar != null) {
                    m.streaming_sidecar = video_attributes.streaming_sidecar;
                }
                return this.downloadablemedia_to_proto(video_attributes.downloadablemedia_attributes, m);
            }
            
            public virtual object proto_to_video(object proto) {
                return VideoAttributes(this.proto_to_downloadablemedia(proto), proto.width, proto.height, proto.seconds, proto.gif_playback, proto.jpeg_thumbnail, proto.gif_attribution, proto.caption, proto.streaming_sidecar);
            }
            
            public virtual object sticker_to_proto(object sticker_attributes) {
                // type: (StickerAttributes) -> Message.StickerMessage
                var m = Message.StickerMessage();
                if (sticker_attributes.width != null) {
                    m.width = sticker_attributes.width;
                }
                if (sticker_attributes.height != null) {
                    m.height = sticker_attributes.height;
                }
                if (sticker_attributes.png_thumbnail != null) {
                    m.png_thumbnail = sticker_attributes.png_thumbnail;
                }
                return this.downloadablemedia_to_proto(sticker_attributes.downloadablemedia_attributes, m);
            }
            
            public virtual object proto_to_sticker(object proto) {
                return StickerAttributes(this.proto_to_downloadablemedia(proto), proto.width, proto.height, proto.png_thumbnail);
            }
            
            public virtual object downloadablemedia_to_proto(object downloadablemedia_attributes, object proto) {
                // type: (DownloadableMediaMessageAttributes, object) -> object
                proto.mimetype = downloadablemedia_attributes.mimetype;
                proto.file_length = downloadablemedia_attributes.file_length;
                proto.file_sha256 = downloadablemedia_attributes.file_sha256;
                if (downloadablemedia_attributes.url != null) {
                    proto.url = downloadablemedia_attributes.url;
                }
                if (downloadablemedia_attributes.media_key != null) {
                    proto.media_key = downloadablemedia_attributes.media_key;
                }
                return this.media_to_proto(downloadablemedia_attributes, proto);
            }
            
            public virtual object proto_to_downloadablemedia(object proto) {
                return DownloadableMediaMessageAttributes(mimetype: proto.mimetype, file_length: proto.file_length, file_sha256: proto.file_sha256, url: proto.url, media_key: proto.media_key, context_info: proto.HasField("context_info") ? this.proto_to_contextinfo(proto.context_info) : null);
            }
            
            public virtual object media_to_proto(object media_attributes, object proto) {
                // type: (MediaAttributes, object) -> object
                if (media_attributes.context_info) {
                    proto.context_info.MergeFrom(this.contextinfo_to_proto(media_attributes.context_info));
                }
                return proto;
            }
            
            public virtual object proto_to_media(object proto) {
                return MediaAttributes(context_info: proto.HasField("context_info") ? proto.context_info : null);
            }
            
            public virtual object contextinfo_to_proto(object contextinfo_attributes) {
                // type: (ContextInfoAttributes) -> ContextInfo
                var cxt_info = ContextInfo();
                if (contextinfo_attributes.stanza_id != null) {
                    cxt_info.stanza_id = contextinfo_attributes.stanza_id;
                }
                if (contextinfo_attributes.participant != null) {
                    cxt_info.participant = contextinfo_attributes.participant;
                }
                if (contextinfo_attributes.quoted_message) {
                    cxt_info.quoted_message.MergeFrom(this.message_to_proto(contextinfo_attributes.quoted_message));
                }
                if (contextinfo_attributes.remote_jid != null) {
                    cxt_info.remote_jid = contextinfo_attributes.remote_jid;
                }
                if (contextinfo_attributes.mentioned_jid != null && contextinfo_attributes.mentioned_jid.Count) {
                    cxt_info.mentioned_jid[":"] = contextinfo_attributes.mentioned_jid;
                }
                if (contextinfo_attributes.edit_version != null) {
                    cxt_info.edit_version = contextinfo_attributes.edit_version;
                }
                if (contextinfo_attributes.revoke_message != null) {
                    cxt_info.revoke_message = contextinfo_attributes.revoke_message;
                }
                return cxt_info;
            }
            
            public virtual object proto_to_contextinfo(object proto) {
                // type: (ContextInfo) -> ContextInfoAttributes
                return ContextInfoAttributes(stanza_id: proto.HasField("stanza_id") ? proto.stanza_id : null, participant: proto.HasField("participant") ? proto.participant : null, quoted_message: proto.HasField("quoted_message") ? this.proto_to_message(proto.quoted_message) : null, remote_jid: proto.HasField("remote_jid") ? proto.remote_jid : null, mentioned_jid: proto.mentioned_jid.Count ? proto.mentioned_jid : new List<object>(), edit_version: proto.HasField("edit_version") ? proto.edit_version : null, revoke_message: proto.HasField("revoke_message") ? proto.revoke_message : null);
            }
            
            public virtual object message_to_proto(object message_attributes) {
                // type: (MessageAttributes) -> Message
                var message = Message();
                if (message_attributes.conversation) {
                    message.conversation = message_attributes.conversation;
                }
                if (message_attributes.image) {
                    message.image_message.MergeFrom(this.image_to_proto(message_attributes.image));
                }
                if (message_attributes.contact) {
                    message.contact_message.MergeFrom(this.contact_to_proto(message_attributes.contact));
                }
                if (message_attributes.location) {
                    message.location_message.MergeFrom(this.location_to_proto(message_attributes.location));
                }
                if (message_attributes.extended_text) {
                    message.extended_text_message.MergeFrom(this.extendedtext_to_proto(message_attributes.extended_text));
                }
                if (message_attributes.document) {
                    message.document_message.MergeFrom(this.document_to_proto(message_attributes.document));
                }
                if (message_attributes.audio) {
                    message.audio_message.MergeFrom(this.audio_to_proto(message_attributes.audio));
                }
                if (message_attributes.video) {
                    message.video_message.MergeFrom(this.video_to_proto(message_attributes.video));
                }
                if (message_attributes.sticker) {
                    message.sticker_message.MergeFrom(this.sticker_to_proto(message_attributes.sticker));
                }
                if (message_attributes.sender_key_distribution_message) {
                    message.sender_key_distribution_message.MergeFrom(this.sender_key_distribution_message_to_proto(message_attributes.sender_key_distribution_message));
                }
                if (message_attributes.protocol) {
                    message.protocol_message.MergeFrom(this.protocol_to_proto(message_attributes.protocol));
                }
                return message;
            }
            
            public virtual object proto_to_message(object proto) {
                // type: (Message) -> MessageAttributes
                var conversation = proto.conversation ? proto.conversation : null;
                var image = proto.HasField("image_message") ? this.proto_to_image(proto.image_message) : null;
                var contact = proto.HasField("contact_message") ? this.proto_to_contact(proto.contact_message) : null;
                var location = proto.HasField("location_message") ? this.proto_to_location(proto.location_message) : null;
                var extended_text = proto.HasField("extended_text_message") ? this.proto_to_extendedtext(proto.extended_text_message) : null;
                var document = proto.HasField("document_message") ? this.proto_to_document(proto.document_message) : null;
                var audio = proto.HasField("audio_message") ? this.proto_to_audio(proto.audio_message) : null;
                var video = proto.HasField("video_message") ? this.proto_to_video(proto.video_message) : null;
                var sticker = proto.HasField("sticker_message") ? this.proto_to_sticker(proto.sticker_message) : null;
                var sender_key_distribution_message = proto.HasField("sender_key_distribution_message") ? this.proto_to_sender_key_distribution_message(proto.sender_key_distribution_message) : null;
                var protocol = proto.HasField("protocol_message") ? this.proto_to_protocol(proto.protocol_message) : null;
                return MessageAttributes(conversation, image, contact, location, extended_text, document, audio, video, sticker, sender_key_distribution_message, protocol);
            }
            
            public virtual object protobytes_to_message(object protobytes) {
                // type: (bytes) -> MessageAttributes
                var m = Message();
                m.ParseFromString(protobytes);
                return this.proto_to_message(m);
            }
            
            public virtual object message_to_protobytes(object message) {
                // type: (MessageAttributes) -> bytes
                return this.message_to_proto(message).SerializeToString();
            }
        }
    }
}
