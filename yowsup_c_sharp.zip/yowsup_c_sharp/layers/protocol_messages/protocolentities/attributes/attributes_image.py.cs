namespace yowsup.layers.protocol_messages.protocolentities.attributes
{

    using ImageTools = yowsup.common.tools.ImageTools;

    using DownloadableMediaMessageAttributes = yowsup.layers.protocol_messages.protocolentities.attributes.attributes_downloadablemedia.DownloadableMediaMessageAttributes;

    using System.Collections.Generic;

    using System;

    using System.Diagnostics;

    public static class attributes_image {
        
        public class ImageAttributes
            : object {
            
            public string _caption;
            
            public object _downloadablemedia_attributes;
            
            public object _height;
            
            public string _jpeg_thumbnail;
            
            public object _width;
            
            public ImageAttributes(
                object downloadablemedia_attributes,
                object width,
                object height,
                object caption = null,
                object jpeg_thumbnail = null) {
                this._downloadablemedia_attributes = downloadablemedia_attributes;
                this._width = width;
                this._height = height;
                this._caption = caption;
                this._jpeg_thumbnail = jpeg_thumbnail;
            }
            
            public override object ToString() {
                var attrs = new List<object>();
                if (this.width != null) {
                    attrs.append(("width", this.width));
                }
                if (this.height != null) {
                    attrs.append(("height", this.height));
                }
                if (this.caption != null) {
                    attrs.append(("caption", this.caption));
                }
                if (this.jpeg_thumbnail != null) {
                    attrs.append(("jpeg_thumbnail", "[binary data]"));
                }
                attrs.append(("downloadable", this.downloadablemedia_attributes));
                return String.Format("[%s]", " ".join(map(item => String.Format("%s=%s", item), attrs)));
            }
            
            public object downloadablemedia_attributes {
                get {
                    return this._downloadablemedia_attributes;
                }
                set {
                    this._downloadablemedia_attributes = value;
                }
            }
            
            public object width {
                get {
                    return this._width;
                }
                set {
                    this._width = value;
                }
            }
            
            public object height {
                get {
                    return this._height;
                }
                set {
                    this._height = value;
                }
            }
            
            public object caption {
                get {
                    return this._caption;
                }
                set {
                    this._caption = value ? value : "";
                }
            }
            
            public object jpeg_thumbnail {
                get {
                    return this._jpeg_thumbnail;
                }
                set {
                    this._jpeg_thumbnail = value ? value : "";
                }
            }
            
            [staticmethod]
            public static object from_filepath(object filepath, object dimensions = null, object caption = null, object jpeg_thumbnail = null) {
                Debug.Assert(os.path.exists(filepath));
                if (!jpeg_thumbnail) {
                    jpeg_thumbnail = ImageTools.generatePreviewFromImage(filepath);
                }
                dimensions = dimensions || ImageTools.getImageDimensions(filepath);
                var _tup_1 = dimensions ? dimensions : (null, null);
                var width = _tup_1.Item1;
                var height = _tup_1.Item2;
                Debug.Assert(width && height);
                Debug.Assert(new byte[] { (byte)'C', (byte)'o', (byte)'u', (byte)'l', (byte)'d', (byte)' ', (byte)'n', (byte)'o', (byte)'t', (byte)' ', (byte)'d', (byte)'e', (byte)'t', (byte)'e', (byte)'r', (byte)'m', (byte)'i', (byte)'n', (byte)'e', (byte)' ', (byte)'i', (byte)'m', (byte)'a', (byte)'g', (byte)'e', (byte)' ', (byte)'d', (byte)'i', (byte)'m', (byte)'e', (byte)'n', (byte)'s', (byte)'i', (byte)'o', (byte)'n', (byte)'s', (byte)',', (byte)' ', (byte)'i', (byte)'n', (byte)'s', (byte)'t', (byte)'a', (byte)'l', (byte)'l', (byte)' ', (byte)'p', (byte)'i', (byte)'l', (byte)'l', (byte)'o', (byte)'w', (byte)' ', (byte)'o', (byte)'r', (byte)' ', (byte)'p', (byte)'a', (byte)'s', (byte)'s', (byte)' ', (byte)'d', (byte)'i', (byte)'m', (byte)'e', (byte)'n', (byte)'s', (byte)'i', (byte)'o', (byte)'n', (byte)'s' });
                return new ImageAttributes(DownloadableMediaMessageAttributes.from_file(filepath), width, height, caption, jpeg_thumbnail);
            }
        }
    }
}
