namespace yowsup.layers.protocol_messages.protocolentities {
    
    using ProtomessageProtocolEntity = protomessage.ProtomessageProtocolEntity;
    
    using MessageMetaAttributes = message.MessageMetaAttributes;
    
    using MessageAttributes = attributes.attributes_message.MessageAttributes;
    
    using System.Diagnostics;
    
    public static class message_text {
        
        public class TextMessageProtocolEntity
            : ProtomessageProtocolEntity {
            
            public object conversation;
            
            public TextMessageProtocolEntity(object body, object message_meta_attributes = null, object to = null) {
                // flexible attributes for temp backwards compat
                Debug.Assert(@bool(message_meta_attributes) ^ @bool(to));
                Debug.Assert("Either set message_meta_attributes, or to, and not both");
                if (to) {
                    message_meta_attributes = MessageMetaAttributes(recipient: to);
                }
                super(TextMessageProtocolEntity, this).@__init__("text", new MessageAttributes(body), message_meta_attributes);
                this.setBody(body);
            }
            
            public object conversation {
                get {
                    return this.message_attributes.conversation;
                }
                set {
                    this.message_attributes.conversation = value;
                }
            }
            
            public virtual object getBody() {
                //obsolete
                return this.conversation;
            }
            
            public virtual object setBody(object body) {
                //obsolete
                this.conversation = body;
            }
        }
    }
}
