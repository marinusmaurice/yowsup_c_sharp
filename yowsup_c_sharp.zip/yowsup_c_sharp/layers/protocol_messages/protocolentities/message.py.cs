namespace yowsup.layers.protocol_messages.protocolentities {
    
    using ProtocolEntity = yowsup.structs.ProtocolEntity;
    
    using OutgoingReceiptProtocolEntity = yowsup.layers.protocol_receipts.protocolentities.OutgoingReceiptProtocolEntity;
    
    using MessageMetaAttributes = yowsup.layers.protocol_messages.protocolentities.attributes.attributes_message_meta.MessageMetaAttributes;
    
    using deepcopy = copy.deepcopy;
    
    using System.Diagnostics;
    
    using System.Collections.Generic;
    
    using System;
    
    public static class message {
        
        public class MessageProtocolEntity
            : ProtocolEntity {
            
            public object _from;
            
            public object _id;
            
            public object _type;
            
            public string MESSAGE_TYPE_MEDIA;
            
            public string MESSAGE_TYPE_TEXT;
            
            public object notify;
            
            public object offline;
            
            public object participant;
            
            public object retry;
            
            public object timestamp;
            
            public object to;
            
            public string MESSAGE_TYPE_TEXT = "text";
            
            public string MESSAGE_TYPE_MEDIA = "media";
            
            public MessageProtocolEntity(object messageType, object messageMetaAttributes) {
                Debug.Assert(object.ReferenceEquals(type(messageMetaAttributes), MessageMetaAttributes));
                this._type = messageType;
                this._id = messageMetaAttributes.id || this._generateId();
                this._from = messageMetaAttributes.sender;
                this.to = messageMetaAttributes.recipient;
                this.timestamp = messageMetaAttributes.timestamp || this._getCurrentTimestamp();
                this.notify = messageMetaAttributes.notify;
                this.offline = messageMetaAttributes.offline;
                this.retry = messageMetaAttributes.retry;
                this.participant = messageMetaAttributes.participant;
            }
            
            public virtual object getType() {
                return this._type;
            }
            
            public virtual object getId() {
                return this._id;
            }
            
            public virtual object getTimestamp() {
                return this.timestamp;
            }
            
            public virtual object getFrom(object full = true) {
                return full ? this._from : this._from.split("@")[0];
            }
            
            public virtual object isBroadcast() {
                return false;
            }
            
            public virtual object getTo(object full = true) {
                return full ? this.to : this.to.split("@")[0];
            }
            
            public virtual object getParticipant(object full = true) {
                return full ? this.participant : this.participant.split("@")[0];
            }
            
            public virtual object getAuthor(object full = true) {
                return this.isGroupMessage() ? this.getParticipant(full) : this.getFrom(full);
            }
            
            public virtual object getNotify() {
                return this.notify;
            }
            
            public virtual object toProtocolTreeNode() {
                var attribs = new Dictionary<object, object> {
                    {
                        "type",
                        this._type},
                    {
                        "id",
                        this._id}};
                if (this.participant) {
                    attribs["participant"] = this.participant;
                }
                if (this.isOutgoing()) {
                    attribs["to"] = this.to;
                } else {
                    attribs["from"] = this._from;
                    attribs["t"] = this.timestamp.ToString();
                    if (this.offline != null) {
                        attribs["offline"] = this.offline ? "1" : "0";
                    }
                    if (this.notify) {
                        attribs["notify"] = this.notify;
                    }
                    if (this.retry) {
                        attribs["retry"] = this.retry.ToString();
                    }
                }
                object xNode = null;
                //if self.isOutgoing():
                //    serverNode = ProtocolTreeNode("server", {})
                //    xNode = ProtocolTreeNode("x", {"xmlns": "jabber:x:event"}, [serverNode])
                return this._createProtocolTreeNode(attribs, children: xNode ? new List<None> {
                    xNode
                } : null, data: null);
            }
            
            public virtual object isOutgoing() {
                return this._from == null;
            }
            
            public virtual object isGroupMessage() {
                if (this.isOutgoing()) {
                    return this.to.Contains("-");
                }
                return this.participant != null;
            }
            
            public override object ToString() {
                var @out = "Message:\n";
                @out += String.Format("ID: %s\n", this._id);
                @out += this.isOutgoing() ? String.Format("To: %s\n", this.to) : String.Format("From: %s\n", this._from);
                @out += String.Format("Type:  %s\n", this._type);
                @out += String.Format("Timestamp: %s\n", this.timestamp);
                if (this.participant) {
                    @out += String.Format("Participant: %s\n", this.participant);
                }
                return @out;
            }
            
            public virtual object ack(object read = false) {
                return OutgoingReceiptProtocolEntity(this.getId(), this.getFrom(), read, participant: this.getParticipant());
            }
            
            public virtual object forward(object to, object _id = null) {
                var OutgoingMessage = deepcopy(this);
                OutgoingMessage.to = to;
                OutgoingMessage._from = null;
                OutgoingMessage._id = _id == null ? this._generateId() : _id;
                return OutgoingMessage;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                return new MessageProtocolEntity(node["type"], MessageMetaAttributes.from_message_protocoltreenode(node));
            }
        }
    }
}
