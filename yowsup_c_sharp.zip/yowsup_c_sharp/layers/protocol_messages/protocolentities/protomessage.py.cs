namespace yowsup.layers.protocol_messages.protocolentities
{

    using MessageProtocolEntity = message.MessageProtocolEntity;

    using AttributesConverter = yowsup.layers.protocol_messages.protocolentities.attributes.converter.AttributesConverter;

    using Message = yowsup.layers.protocol_messages.proto.e2e_pb2.Message;

    using System;

    public static class protomessage {
        
        public static logger logger = logging.getLogger(@__name__);
        
        // 
        //     <message t="{{TIME_STAMP}}" from="{{CONTACT_JID}}"
        //         offline="{{OFFLINE}}" type="text" id="{{MESSAGE_ID}}" notify="{{NOTIFY_NAME}}">
        //             <proto>
        //                 {{SERIALIZE_PROTO_DATA}}
        //             </proto>
        //     </message>
        //     
        public class ProtomessageProtocolEntity
            : MessageProtocolEntity {
            
            public object _message_attributes;
            
            public ProtomessageProtocolEntity(object messageType, object message_attributes, object messageMetaAttributes)
                : base(messageMetaAttributes) {
                this._message_attributes = message_attributes;
            }
            
            public override object ToString() {
                var @out = super(ProtomessageProtocolEntity, this).@__str__();
                return String.Format("%s\nmessage_attributes=%s", @out, this._message_attributes);
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(ProtomessageProtocolEntity, this).toProtocolTreeNode();
                node.addChild(ProtoProtocolEntity(AttributesConverter.get().message_to_protobytes(this._message_attributes)).toProtocolTreeNode());
                return node;
            }
            
            public object message_attributes {
                get {
                    return this._message_attributes;
                }
                set {
                    this._message_attributes = value;
                }
            }
            
            [classmethod]
            public static object fromProtocolTreeNode(object cls, object node) {
                var entity = MessageProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = cls;
                var m = Message();
                m.ParseFromString(node.getChild("proto").getData());
                entity.message_attributes = AttributesConverter.get().proto_to_message(m);
                return entity;
            }
        }
    }
}
