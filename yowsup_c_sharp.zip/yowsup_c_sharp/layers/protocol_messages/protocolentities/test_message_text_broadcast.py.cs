namespace yowsup.layers.protocol_messages.protocolentities {
    
    using TextMessageProtocolEntityTest = yowsup.layers.protocol_messages.protocolentities.test_message_text.TextMessageProtocolEntityTest;
    
    using BoadcastTextMessage = yowsup.layers.protocol_messages.protocolentities.message_text_broadcast.BoadcastTextMessage;
    
    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;
    
    using System.Collections.Generic;
    
    using System.Linq;
    
    public static class test_message_text_broadcast {
        
        public class BoadcastTextMessageTest
            : TextMessageProtocolEntityTest {
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                super(BoadcastTextMessageTest, this).setUp();
                this.ProtocolEntity = BoadcastTextMessage;
                var boadcastNode = ProtocolTreeNode("broadcast");
                var jids = new List<string> {
                    "jid1",
                    "jid2"
                };
                var toNodes = (from jid in jids
                    select ProtocolTreeNode("to", new Dictionary<object, object> {
                        {
                            "jid",
                            jid}})).ToList();
                boadcastNode.addChildren(toNodes);
                this.node.addChild(boadcastNode);
            }
        }
    }
}
