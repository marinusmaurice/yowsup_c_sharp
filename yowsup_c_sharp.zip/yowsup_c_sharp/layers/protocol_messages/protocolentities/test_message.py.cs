namespace yowsup.layers.protocol_messages.protocolentities
{

    using MessageProtocolEntity = yowsup.layers.protocol_messages.protocolentities.message.MessageProtocolEntity;

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using ProtocolEntityTest = yowsup.structs.protocolentity.ProtocolEntityTest;

    using System.Collections.Generic;

    public static class test_message {
        
        public class MessageProtocolEntityTest
            : ProtocolEntityTest, unittest.TestCase {
            
            public object node;
            
            public object ProtocolEntity;
            
            public virtual object setUp() {
                this.ProtocolEntity = MessageProtocolEntity;
                // ORDER_MATTERS for node.toString() to output return attribs in same order
                var attribs = new Dictionary<object, object> {
                    {
                        "type",
                        "message_type"},
                    {
                        "id",
                        "message-id"},
                    {
                        "t",
                        "12345"},
                    {
                        "offline",
                        "0"},
                    {
                        "from",
                        "from_jid"},
                    {
                        "notify",
                        "notify_name"}};
                this.node = ProtocolTreeNode("message", attribs);
            }
        }
    }
}
