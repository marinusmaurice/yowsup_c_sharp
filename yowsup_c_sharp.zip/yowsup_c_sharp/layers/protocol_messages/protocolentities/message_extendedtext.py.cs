namespace yowsup.layers.protocol_messages.protocolentities
{

    using ProtomessageProtocolEntity = yowsup.layers.protocol_messages.protocolentities.protomessage.ProtomessageProtocolEntity;

    public static class message_extendedtext {
        
        public class ExtendedTextMessageProtocolEntity
            : ProtomessageProtocolEntity {
            
            public ExtendedTextMessageProtocolEntity(object extended_text_attrs, object message_meta_attrs) {
                // type: (ExtendedTextAttributes, MessageMetaAttributes) -> None
                super(ExtendedTextMessageProtocolEntity, this).@__init__("text", MessageAttributes(extended_text: extended_text_attrs), message_meta_attrs);
            }
            
            public object text {
                get {
                    return this.message_attributes.extended_text.text;
                }
                set {
                    this.message_attributes.extended_text.text = value;
                }
            }
            
            public object context_info {
                get {
                    return this.message_attributes.extended_text.context_info;
                }
                set {
                    this.message_attributes.extended_text.context_info = value;
                }
            }
        }
    }
}
