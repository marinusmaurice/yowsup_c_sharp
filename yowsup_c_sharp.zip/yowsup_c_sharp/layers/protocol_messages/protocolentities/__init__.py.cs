namespace yowsup.layers.protocol_messages.protocolentities
{

    public static class @__init__ {
    }
}
