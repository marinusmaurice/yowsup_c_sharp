namespace yowsup.layers.protocol_messages.protocolentities
{

    using TextMessageProtocolEntity = message_text.TextMessageProtocolEntity;

    using ProtocolTreeNode = yowsup.structs.ProtocolTreeNode;

    using System;

    using System.Diagnostics;

    using System.Collections.Generic;

    using System.Linq;

    public static class message_text_broadcast {
        
        public class BoadcastTextMessage
            : TextMessageProtocolEntity {
            
            public object jids;
            
            public BoadcastTextMessage(object jids, object body) {
                var boadcastTime = Convert.ToInt32(time.time() * 1000);
                super(BoadcastTextMessage, this).@__init__(body, to: String.Format("%s@broadcast", boadcastTime));
                this.setBroadcastProps(jids);
            }
            
            public virtual object setBroadcastProps(object jids) {
                Debug.Assert(object.ReferenceEquals(type(jids), list));
                Debug.Assert(String.Format("jids must be a list, got %s instead.", type(jids)));
                this.jids = jids;
            }
            
            public virtual object toProtocolTreeNode() {
                var node = super(BoadcastTextMessage, this).toProtocolTreeNode();
                var toNodes = (from jid in this.jids
                    select ProtocolTreeNode("to", new Dictionary<object, object> {
                        {
                            "jid",
                            jid}})).ToList();
                var boadcastNode = ProtocolTreeNode("broadcast", children: toNodes);
                node.addChild(boadcastNode);
                return node;
            }
            
            [staticmethod]
            public static object fromProtocolTreeNode(object node) {
                var entity = TextMessageProtocolEntity.fromProtocolTreeNode(node);
                entity.@__class__ = BoadcastTextMessage;
                var jids = (from toNode in node.getChild("broadcast").getAllChildren()
                    select toNode.getAttributeValue("jid")).ToList();
                entity.setBroadcastProps(jids);
                return entity;
            }
        }
    }
}
