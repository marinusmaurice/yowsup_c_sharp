namespace yowsup.layers.protocol_messages
{

    public static class @__init__ {
    }
}
