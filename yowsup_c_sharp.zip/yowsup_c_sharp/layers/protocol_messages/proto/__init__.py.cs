namespace yowsup.layers.protocol_messages.proto {
    
    public static class @__init__ {
    }
}
