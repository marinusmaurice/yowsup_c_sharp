namespace yowsup.layers.protocol_messages.proto
{

    using _descriptor = google.protobuf.descriptor;

    using _message = google.protobuf.message;

    using _reflection = google.protobuf.reflection;

    using _symbol_database = google.protobuf.symbol_database;

    using System.Collections.Generic;

    public static class protocol_pb2 {
        
        public static object _b = sys.version_info[0] < 3 && x => x || x => x.encode("latin1");
        
        public static object _sym_db = _symbol_database.Default();
        
        public static object DESCRIPTOR = _descriptor.FileDescriptor(name: "protocol.proto", package: "", syntax: "proto2", serialized_options: null, serialized_pb: _b("\n\x0eprotocol.proto\"R\n\nMessageKey\x12\x12\n\nremote_jid\x18\x01 \x01(\t\x12\x0f\n\x07\x66rom_me\x18\x02 \x01(\x08\x12\n\n\x02id\x18\x03 \x01(\t\x12\x13\n\x0bparticipant\x18\x04 \x01(\t"));
        
        public static object _MESSAGEKEY = _descriptor.Descriptor(name: "MessageKey", full_name: "MessageKey", filename: null, file: DESCRIPTOR, containing_type: null, fields: new List<object> {
            _descriptor.FieldDescriptor(name: "remote_jid", full_name: "MessageKey.remote_jid", index: 0, number: 1, type: 9, cpp_type: 9, label: 1, has_default_value: false, default_value: _b("").decode("utf-8"), message_type: null, enum_type: null, containing_type: null, is_extension: false, extension_scope: null, serialized_options: null, file: DESCRIPTOR),
            _descriptor.FieldDescriptor(name: "from_me", full_name: "MessageKey.from_me", index: 1, number: 2, type: 8, cpp_type: 7, label: 1, has_default_value: false, default_value: false, message_type: null, enum_type: null, containing_type: null, is_extension: false, extension_scope: null, serialized_options: null, file: DESCRIPTOR),
            _descriptor.FieldDescriptor(name: "id", full_name: "MessageKey.id", index: 2, number: 3, type: 9, cpp_type: 9, label: 1, has_default_value: false, default_value: _b("").decode("utf-8"), message_type: null, enum_type: null, containing_type: null, is_extension: false, extension_scope: null, serialized_options: null, file: DESCRIPTOR),
            _descriptor.FieldDescriptor(name: "participant", full_name: "MessageKey.participant", index: 3, number: 4, type: 9, cpp_type: 9, label: 1, has_default_value: false, default_value: _b("").decode("utf-8"), message_type: null, enum_type: null, containing_type: null, is_extension: false, extension_scope: null, serialized_options: null, file: DESCRIPTOR)
        }, extensions: new List<object>(), nested_types: new List<object>(), enum_types: new List<object>(), serialized_options: null, is_extendable: false, syntax: "proto2", extension_ranges: new List<object>(), oneofs: new List<object>(), serialized_start: 18, serialized_end: 100);
        
        static protocol_pb2() {
            DESCRIPTOR.message_types_by_name["MessageKey"] = _MESSAGEKEY;
            _sym_db.RegisterFileDescriptor(DESCRIPTOR);
            _sym_db.RegisterMessage(MessageKey);
        }
        
        public static object MessageKey = _reflection.GeneratedProtocolMessageType("MessageKey", ValueTuple.Create(_message.Message), new dict(DESCRIPTOR: _MESSAGEKEY, @__module__: "protocol_pb2"));
    }
}
