namespace yowsup.axolotl.store.sqlite
{

    using PreKeyStore = axolotl.state.prekeystore.PreKeyStore;

    using PreKeyRecord = axolotl.state.prekeyrecord.PreKeyRecord;

    using System.Linq;

    public static class liteprekeystore {
        
        public class LitePreKeyStore
            : PreKeyStore {
            
            public object dbConn;
            
            public LitePreKeyStore(object dbConn) {
                this.dbConn = dbConn;
                dbConn.execute("CREATE TABLE IF NOT EXISTS prekeys (_id INTEGER PRIMARY KEY AUTOINCREMENT,prekey_id INTEGER UNIQUE, sent_to_server BOOLEAN, record BLOB);");
            }
            
            public virtual object loadPreKey(object preKeyId) {
                var q = "SELECT record FROM prekeys WHERE prekey_id = ?";
                var cursor = this.dbConn.cursor();
                cursor.execute(q, ValueTuple.Create(preKeyId));
                var result = cursor.fetchone();
                if (!result) {
                    throw InvalidKeyIdException("No such prekeyrecord!");
                }
                return PreKeyRecord(serialized: result[0]);
            }
            
            public virtual object loadUnsentPendingPreKeys() {
                var q = "SELECT record FROM prekeys WHERE sent_to_server is NULL or sent_to_server = ?";
                var cursor = this.dbConn.cursor();
                cursor.execute(q, ValueTuple.Create(0));
                var result = cursor.fetchall();
                return (from result in result
                    select PreKeyRecord(serialized: result[0])).ToList();
            }
            
            // 
            //         :param preKeyIds:
            //         :type preKeyIds: list
            //         :return:
            //         :rtype:
            //         
            public virtual object setAsSent(object prekeyIds) {
                foreach (var prekeyId in prekeyIds) {
                    var q = "UPDATE prekeys SET sent_to_server = ? WHERE prekey_id = ?";
                    var cursor = this.dbConn.cursor();
                    cursor.execute(q, (1, prekeyId));
                }
                this.dbConn.commit();
            }
            
            public virtual object loadPendingPreKeys() {
                var q = "SELECT record FROM prekeys";
                var cursor = this.dbConn.cursor();
                cursor.execute(q);
                var result = cursor.fetchall();
                return (from result in result
                    select PreKeyRecord(serialized: result[0])).ToList();
            }
            
            public virtual object storePreKey(object preKeyId, object preKeyRecord) {
                //self.removePreKey(preKeyId)
                var q = "INSERT INTO prekeys (prekey_id, record) VALUES(?,?)";
                var cursor = this.dbConn.cursor();
                var serialized = preKeyRecord.serialize();
                cursor.execute(q, (preKeyId, sys.version_info < (2, 7) ? buffer(serialized) : serialized));
                this.dbConn.commit();
            }
            
            public virtual object containsPreKey(object preKeyId) {
                var q = "SELECT record FROM prekeys WHERE prekey_id = ?";
                var cursor = this.dbConn.cursor();
                cursor.execute(q, ValueTuple.Create(preKeyId));
                return cursor.fetchone() != null;
            }
            
            public virtual object removePreKey(object preKeyId) {
                var q = "DELETE FROM prekeys WHERE prekey_id = ?";
                var cursor = this.dbConn.cursor();
                cursor.execute(q, ValueTuple.Create(preKeyId));
                this.dbConn.commit();
            }
            
            public virtual object loadMaxPreKeyId() {
                var q = "SELECT max(prekey_id) FROM prekeys";
                var cursor = this.dbConn.cursor();
                cursor.execute(q);
                var result = cursor.fetchone();
                return result[0] == null ? 0 : result[0];
            }
        }
    }
}
