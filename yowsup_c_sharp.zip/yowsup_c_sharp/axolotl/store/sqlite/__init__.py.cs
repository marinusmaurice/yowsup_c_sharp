namespace yowsup.axolotl.store.sqlite {
    
    public static class @__init__ {
    }
}
