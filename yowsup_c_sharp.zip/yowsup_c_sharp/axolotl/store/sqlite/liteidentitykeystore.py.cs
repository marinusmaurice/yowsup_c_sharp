namespace yowsup.axolotl.store.sqlite
{

    using IdentityKeyStore = axolotl.state.identitykeystore.IdentityKeyStore;

    using IdentityKey = axolotl.identitykey.IdentityKey;

    using IdentityKeyPair = axolotl.identitykeypair.IdentityKeyPair;

    using KeyHelper = axolotl.util.keyhelper.KeyHelper;

    public static class liteidentitykeystore {
        
        public class LiteIdentityKeyStore
            : IdentityKeyStore {
            
            public object dbConn;
            
            public LiteIdentityKeyStore(object dbConn) {
                this.dbConn = dbConn;
                dbConn.execute("CREATE TABLE IF NOT EXISTS identities (_id INTEGER PRIMARY KEY AUTOINCREMENT,recipient_id INTEGER UNIQUE,registration_id INTEGER, public_key BLOB, private_key BLOB,next_prekey_id INTEGER, timestamp INTEGER);");
                if (this.getLocalRegistrationId() == null || this.getIdentityKeyPair() == null) {
                    var identity = KeyHelper.generateIdentityKeyPair();
                    var registration_id = KeyHelper.generateRegistrationId(true);
                    this._storeLocalData(registration_id, identity);
                }
            }
            
            public virtual object getIdentityKeyPair() {
                var q = "SELECT public_key, private_key FROM identities WHERE recipient_id = -1";
                var c = this.dbConn.cursor();
                c.execute(q);
                var result = c.fetchone();
                if (result) {
                    var _tup_1 = result;
                    var publicKey = _tup_1.Item1;
                    var privateKey = _tup_1.Item2;
                    return IdentityKeyPair(IdentityKey(DjbECPublicKey(publicKey[1])), DjbECPrivateKey(privateKey));
                }
                return null;
            }
            
            public virtual object getLocalRegistrationId() {
                var q = "SELECT registration_id FROM identities WHERE recipient_id = -1";
                var c = this.dbConn.cursor();
                c.execute(q);
                var result = c.fetchone();
                return result ? result[0] : null;
            }
            
            public virtual object _storeLocalData(object registrationId, object identityKeyPair) {
                var q = "INSERT INTO identities(recipient_id, registration_id, public_key, private_key) VALUES(-1, ?, ?, ?)";
                var c = this.dbConn.cursor();
                var pubKey = identityKeyPair.getPublicKey().getPublicKey().serialize();
                var privKey = identityKeyPair.getPrivateKey().serialize();
                if (sys.version_info < (2, 7)) {
                    pubKey = buffer(pubKey);
                    privKey = buffer(privKey);
                }
                c.execute(q, (registrationId, pubKey, privKey));
                this.dbConn.commit();
            }
            
            public virtual object saveIdentity(object recipientId, object identityKey) {
                var q = "DELETE FROM identities WHERE recipient_id=?";
                this.dbConn.cursor().execute(q, ValueTuple.Create(recipientId));
                this.dbConn.commit();
                q = "INSERT INTO identities (recipient_id, public_key) VALUES(?, ?)";
                var c = this.dbConn.cursor();
                var pubKey = identityKey.getPublicKey().serialize();
                c.execute(q, (recipientId, sys.version_info < (2, 7) ? buffer(pubKey) : pubKey));
                this.dbConn.commit();
            }
            
            public virtual object isTrustedIdentity(object recipientId, object identityKey) {
                var q = "SELECT public_key from identities WHERE recipient_id = ?";
                var c = this.dbConn.cursor();
                c.execute(q, ValueTuple.Create(recipientId));
                var result = c.fetchone();
                if (!result) {
                    return true;
                }
                var pubKey = identityKey.getPublicKey().serialize();
                if (sys.version_info < (2, 7)) {
                    pubKey = buffer(pubKey);
                }
                return result[0] == pubKey;
            }
        }
    }
}
