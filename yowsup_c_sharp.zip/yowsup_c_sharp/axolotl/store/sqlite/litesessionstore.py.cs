namespace yowsup.axolotl.store.sqlite
{

    using SessionStore = axolotl.state.sessionstore.SessionStore;

    using SessionRecord = axolotl.state.sessionrecord.SessionRecord;

    using System.Linq;

    public static class litesessionstore {
        
        public class LiteSessionStore
            : SessionStore {
            
            public object dbConn;
            
            public LiteSessionStore(object dbConn) {
                this.dbConn = dbConn;
                dbConn.execute("CREATE TABLE IF NOT EXISTS sessions (_id INTEGER PRIMARY KEY AUTOINCREMENT,recipient_id INTEGER UNIQUE, device_id INTEGER, record BLOB, timestamp INTEGER);");
            }
            
            public virtual object loadSession(object recipientId, object deviceId) {
                var q = "SELECT record FROM sessions WHERE recipient_id = ? AND device_id = ?";
                var c = this.dbConn.cursor();
                c.execute(q, (recipientId, deviceId));
                var result = c.fetchone();
                if (result) {
                    return SessionRecord(serialized: result[0]);
                } else {
                    return SessionRecord();
                }
            }
            
            public virtual object getSubDeviceSessions(object recipientId) {
                var q = "SELECT device_id from sessions WHERE recipient_id = ?";
                var c = this.dbConn.cursor();
                c.execute(q, ValueTuple.Create(recipientId));
                var result = c.fetchall();
                var deviceIds = (from r in result
                    select r[0]).ToList();
                return deviceIds;
            }
            
            public virtual object storeSession(object recipientId, object deviceId, object sessionRecord) {
                this.deleteSession(recipientId, deviceId);
                var q = "INSERT INTO sessions(recipient_id, device_id, record) VALUES(?,?,?)";
                var c = this.dbConn.cursor();
                var serialized = sessionRecord.serialize();
                c.execute(q, (recipientId, deviceId, sys.version_info < (2, 7) ? buffer(serialized) : serialized));
                this.dbConn.commit();
            }
            
            public virtual object containsSession(object recipientId, object deviceId) {
                var q = "SELECT record FROM sessions WHERE recipient_id = ? AND device_id = ?";
                var c = this.dbConn.cursor();
                c.execute(q, (recipientId, deviceId));
                var result = c.fetchone();
                return result != null;
            }
            
            public virtual object deleteSession(object recipientId, object deviceId) {
                var q = "DELETE FROM sessions WHERE recipient_id = ? AND device_id = ?";
                this.dbConn.cursor().execute(q, (recipientId, deviceId));
                this.dbConn.commit();
            }
            
            public virtual object deleteAllSessions(object recipientId) {
                var q = "DELETE FROM sessions WHERE recipient_id = ?";
                this.dbConn.cursor().execute(q, ValueTuple.Create(recipientId));
                this.dbConn.commit();
            }
        }
    }
}
