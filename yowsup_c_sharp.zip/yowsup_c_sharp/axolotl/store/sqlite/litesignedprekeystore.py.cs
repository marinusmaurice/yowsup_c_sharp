namespace yowsup.axolotl.store.sqlite
{

    using SignedPreKeyStore = axolotl.state.signedprekeystore.SignedPreKeyStore;

    using SignedPreKeyRecord = axolotl.state.signedprekeyrecord.SignedPreKeyRecord;

    using InvalidKeyIdException = axolotl.invalidkeyidexception.InvalidKeyIdException;

    using System;

    using System.Collections.Generic;

    public static class litesignedprekeystore {
        
        public class LiteSignedPreKeyStore
            : SignedPreKeyStore {
            
            public object dbConn;
            
            public LiteSignedPreKeyStore(object dbConn) {
                this.dbConn = dbConn;
                dbConn.execute("CREATE TABLE IF NOT EXISTS signed_prekeys (_id INTEGER PRIMARY KEY AUTOINCREMENT,prekey_id INTEGER UNIQUE, timestamp INTEGER, record BLOB);");
            }
            
            public virtual object loadSignedPreKey(object signedPreKeyId) {
                var q = "SELECT record FROM signed_prekeys WHERE prekey_id = ?";
                var cursor = this.dbConn.cursor();
                cursor.execute(q, ValueTuple.Create(signedPreKeyId));
                var result = cursor.fetchone();
                if (!result) {
                    throw InvalidKeyIdException(String.Format("No such signedprekeyrecord! %s ", signedPreKeyId));
                }
                return SignedPreKeyRecord(serialized: result[0]);
            }
            
            public virtual object loadSignedPreKeys() {
                var q = "SELECT record FROM signed_prekeys";
                var cursor = this.dbConn.cursor();
                cursor.execute(q);
                var result = cursor.fetchall();
                var results = new List<object>();
                foreach (var row in result) {
                    results.append(SignedPreKeyRecord(serialized: row[0]));
                }
                return results;
            }
            
            public virtual object storeSignedPreKey(object signedPreKeyId, object signedPreKeyRecord) {
                //q = "DELETE FROM signed_prekeys WHERE prekey_id = ?"
                //self.dbConn.cursor().execute(q, (signedPreKeyId,))
                //self.dbConn.commit()
                var q = "INSERT INTO signed_prekeys (prekey_id, record) VALUES(?,?)";
                var cursor = this.dbConn.cursor();
                var record = signedPreKeyRecord.serialize();
                cursor.execute(q, (signedPreKeyId, sys.version_info < (2, 7) ? buffer(record) : record));
                this.dbConn.commit();
            }
            
            public virtual object containsSignedPreKey(object signedPreKeyId) {
                var q = "SELECT record FROM signed_prekeys WHERE prekey_id = ?";
                var cursor = this.dbConn.cursor();
                cursor.execute(q, ValueTuple.Create(signedPreKeyId));
                return cursor.fetchone() != null;
            }
            
            public virtual object removeSignedPreKey(object signedPreKeyId) {
                var q = "DELETE FROM signed_prekeys WHERE prekey_id = ?";
                var cursor = this.dbConn.cursor();
                cursor.execute(q, ValueTuple.Create(signedPreKeyId));
                this.dbConn.commit();
            }
        }
    }
}
