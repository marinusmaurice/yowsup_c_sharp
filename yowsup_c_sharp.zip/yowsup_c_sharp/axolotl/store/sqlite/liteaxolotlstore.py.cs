namespace yowsup.axolotl.store.sqlite
{

    using AxolotlStore = axolotl.state.axolotlstore.AxolotlStore;

    public static class liteaxolotlstore {
        
        public class LiteAxolotlStore
            : AxolotlStore {
            
            public object _db;
            
            public object identityKeyStore;
            
            public object preKeyStore;
            
            public object senderKeyStore;
            
            public object sessionStore;
            
            public object signedPreKeyStore;
            
            public LiteAxolotlStore(object db) {
                var conn = sqlite3.connect(db, check_same_thread: false);
                conn.text_factory = bytes;
                this._db = db;
                this.identityKeyStore = LiteIdentityKeyStore(conn);
                this.preKeyStore = LitePreKeyStore(conn);
                this.signedPreKeyStore = LiteSignedPreKeyStore(conn);
                this.sessionStore = LiteSessionStore(conn);
                this.senderKeyStore = LiteSenderKeyStore(conn);
            }
            
            public override object ToString() {
                return this._db;
            }
            
            public virtual object getIdentityKeyPair() {
                return this.identityKeyStore.getIdentityKeyPair();
            }
            
            public virtual object getLocalRegistrationId() {
                return this.identityKeyStore.getLocalRegistrationId();
            }
            
            public virtual object saveIdentity(object recepientId, object identityKey) {
                this.identityKeyStore.saveIdentity(recepientId, identityKey);
            }
            
            public virtual object isTrustedIdentity(object recepientId, object identityKey) {
                return this.identityKeyStore.isTrustedIdentity(recepientId, identityKey);
            }
            
            public virtual object loadPreKey(object preKeyId) {
                return this.preKeyStore.loadPreKey(preKeyId);
            }
            
            public virtual object loadPreKeys() {
                return this.preKeyStore.loadPendingPreKeys();
            }
            
            public virtual object storePreKey(object preKeyId, object preKeyRecord) {
                this.preKeyStore.storePreKey(preKeyId, preKeyRecord);
            }
            
            public virtual object containsPreKey(object preKeyId) {
                return this.preKeyStore.containsPreKey(preKeyId);
            }
            
            public virtual object removePreKey(object preKeyId) {
                this.preKeyStore.removePreKey(preKeyId);
            }
            
            public virtual object loadSession(object recepientId, object deviceId) {
                return this.sessionStore.loadSession(recepientId, deviceId);
            }
            
            public virtual object getSubDeviceSessions(object recepientId) {
                return this.sessionStore.getSubDeviceSessions(recepientId);
            }
            
            public virtual object storeSession(object recepientId, object deviceId, object sessionRecord) {
                this.sessionStore.storeSession(recepientId, deviceId, sessionRecord);
            }
            
            public virtual object containsSession(object recepientId, object deviceId) {
                return this.sessionStore.containsSession(recepientId, deviceId);
            }
            
            public virtual object deleteSession(object recepientId, object deviceId) {
                this.sessionStore.deleteSession(recepientId, deviceId);
            }
            
            public virtual object deleteAllSessions(object recepientId) {
                this.sessionStore.deleteAllSessions(recepientId);
            }
            
            public virtual object loadSignedPreKey(object signedPreKeyId) {
                return this.signedPreKeyStore.loadSignedPreKey(signedPreKeyId);
            }
            
            public virtual object loadSignedPreKeys() {
                return this.signedPreKeyStore.loadSignedPreKeys();
            }
            
            public virtual object storeSignedPreKey(object signedPreKeyId, object signedPreKeyRecord) {
                this.signedPreKeyStore.storeSignedPreKey(signedPreKeyId, signedPreKeyRecord);
            }
            
            public virtual object containsSignedPreKey(object signedPreKeyId) {
                return this.signedPreKeyStore.containsSignedPreKey(signedPreKeyId);
            }
            
            public virtual object removeSignedPreKey(object signedPreKeyId) {
                this.signedPreKeyStore.removeSignedPreKey(signedPreKeyId);
            }
            
            public virtual object loadSenderKey(object senderKeyName) {
                return this.senderKeyStore.loadSenderKey(senderKeyName);
            }
            
            public virtual object storeSenderKey(object senderKeyName, object senderKeyRecord) {
                this.senderKeyStore.storeSenderKey(senderKeyName, senderKeyRecord);
            }
        }
    }
}
