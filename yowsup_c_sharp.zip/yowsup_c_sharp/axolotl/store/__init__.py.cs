namespace yowsup.axolotl.store {
    
    public static class @__init__ {
    }
}
