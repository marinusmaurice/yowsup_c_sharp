namespace yowsup.axolotl {
    
    public static class exceptions {
        
        public class NoSessionException
            : Exception {
        }
        
        public class UntrustedIdentityException
            : Exception {
            
            public object _identity_key;
            
            public object _name;
            
            public UntrustedIdentityException(object name, object identity_key) {
                this._name = name;
                this._identity_key = identity_key;
            }
            
            public object name {
                get {
                    return this._name;
                }
            }
            
            public object identity_key {
                get {
                    return this._identity_key;
                }
            }
        }
        
        public class InvalidMessageException
            : Exception {
        }
        
        public class InvalidKeyIdException
            : Exception {
        }
        
        public class DuplicateMessageException
            : Exception {
        }
    }
}
