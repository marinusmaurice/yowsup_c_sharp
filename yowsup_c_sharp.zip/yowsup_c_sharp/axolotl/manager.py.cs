namespace yowsup.axolotl
{

    using KeyHelper = axolotl.util.keyhelper.KeyHelper;

    using SenderKeyName = axolotl.groups.senderkeyname.SenderKeyName;

    using AxolotlAddress = axolotl.axolotladdress.AxolotlAddress;

    using SessionCipher = axolotl.sessioncipher.SessionCipher;

    using GroupCipher = axolotl.groups.groupcipher.GroupCipher;

    using GroupSessionBuilder = axolotl.groups.groupsessionbuilder.GroupSessionBuilder;

    using SessionBuilder = axolotl.sessionbuilder.SessionBuilder;

    using PreKeyWhisperMessage = axolotl.protocol.prekeywhispermessage.PreKeyWhisperMessage;

    using WhisperMessage = axolotl.protocol.whispermessage.WhisperMessage;

    using UntrustedIdentityException = axolotl.untrustedidentityexception.UntrustedIdentityException;

    using InvalidMessageException = axolotl.invalidmessageexception.InvalidMessageException;

    using DuplicateMessageException = axolotl.duplicatemessagexception.DuplicateMessageException;

    using InvalidKeyIdException = axolotl.invalidkeyidexception.InvalidKeyIdException;

    using NoSessionException = axolotl.nosessionexception.NoSessionException;

    using SenderKeyDistributionMessage = axolotl.protocol.senderkeydistributionmessage.SenderKeyDistributionMessage;

    using exceptions = yowsup.axolotl.exceptions;

    using System.Collections.Generic;

    using System.Diagnostics;

    using System;

    using System.Linq;

    public static class manager {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class AxolotlManager
            : object {
            
            public Dictionary<object, object> _group_ciphers;
            
            public object _group_session_builder;
            
            public object _identity;
            
            public object _registration_id;
            
            public Dictionary<object, object> _session_ciphers;
            
            public object _store;
            
            public object _username;
            
      
            
            public int COUNT_GEN_PREKEYS = 812;
            
            public int THRESHOLD_REGEN = 10;
            
            public int MAX_SIGNED_PREKEY_ID = 16777215;
            
            public AxolotlManager(object store, object username) {
                this._username = username;
                this._store = store;
                this._identity = this._store.getIdentityKeyPair();
                this._registration_id = this._store.getLocalRegistrationId();
                Debug.Assert(this._registration_id != null);
                Debug.Assert(this._identity != null);
                this._group_session_builder = GroupSessionBuilder(this._store);
                this._session_ciphers = new Dictionary<object, object> {
                };
                this._group_ciphers = new Dictionary<object, object> {
                };
                logger.debug(String.Format("Initialized AxolotlManager [username=%s, db=%s]", this._username, store));
            }
            
            public object registration_id {
                get {
                    return this._registration_id;
                }
            }
            
            public object identity {
                get {
                    return this._identity;
                }
            }
            
            public virtual object level_prekeys(bool force = false) {
                logger.debug(String.Format("level_prekeys(force=%s)", force));
                var len_pending_prekeys = this._store.loadPreKeys().Count;
                logger.debug(String.Format("len(pending_prekeys) = %d", len_pending_prekeys));
                if (force || len_pending_prekeys < this.THRESHOLD_REGEN) {
                    var count_gen = this.COUNT_GEN_PREKEYS;
                    var max_prekey_id = this._store.preKeyStore.loadMaxPreKeyId();
                    logger.info(String.Format("Generating %d prekeys, current max_prekey_id=%d", count_gen, max_prekey_id));
                    var prekeys = KeyHelper.generatePreKeys(max_prekey_id + 1, count_gen);
                    logger.info(String.Format("Storing %d prekeys", prekeys.Count));
                    foreach (var i in Enumerable.Range(0, prekeys.Count - 0)) {
                        var key = prekeys[i];
                        if (logger.level <= logging.DEBUG) {
                            sys.stdout.write(String.Format("Storing prekey %d/%d \r", i + 1, prekeys.Count));
                            sys.stdout.flush();
                        }
                        this._store.storePreKey(key.getId(), key);
                    }
                    return prekeys;
                }
                return new List<object>();
            }
            
            public virtual object load_unsent_prekeys() {
                logger.debug("load_unsent_prekeys");
                var unsent = this._store.preKeyStore.loadUnsentPendingPreKeys();
                if (unsent.Count > 0) {
                    logger.info(String.Format("Loaded %d unsent prekeys", unsent.Count));
                }
                return unsent;
            }
            
            // 
            //         :param prekeyIds:
            //         :type prekeyIds: list
            //         :return:
            //         :rtype:
            //         
            public virtual object set_prekeys_as_sent(object prekeyIds) {
                logger.debug(String.Format("set_prekeys_as_sent(prekeyIds=[%d prekeyIds])", prekeyIds.Count));
                this._store.preKeyStore.setAsSent((from prekey in prekeyIds
                    select prekey.getId()).ToList());
            }
            
            public virtual object generate_signed_prekey() {
                object new_signed_prekey_id;
                logger.debug("generate_signed_prekey");
                var latest_signed_prekey = this.load_latest_signed_prekey(generate: false);
                if (latest_signed_prekey != null) {
                    if (latest_signed_prekey.getId() == this.MAX_SIGNED_PREKEY_ID) {
                        new_signed_prekey_id = this.MAX_SIGNED_PREKEY_ID / 2 + 1;
                    } else {
                        new_signed_prekey_id = latest_signed_prekey.getId() + 1;
                    }
                } else {
                    new_signed_prekey_id = 0;
                }
                var signed_prekey = KeyHelper.generateSignedPreKey(this._identity, new_signed_prekey_id);
                this._store.storeSignedPreKey(signed_prekey.getId(), signed_prekey);
                return signed_prekey;
            }
            
            public virtual object load_latest_signed_prekey(object generate = false) {
                logger.debug("load_latest_signed_prekey");
                var signed_prekeys = this._store.loadSignedPreKeys();
                if (signed_prekeys.Count) {
                    return signed_prekeys[-1];
                }
                return generate ? this.generate_signed_prekey() : null;
            }
            
            public virtual object _get_session_cipher(object recipientid) {
                object session_cipher;
                logger.debug(String.Format("get_session_cipher(recipientid=%s)", recipientid));
                if (this._session_ciphers.Contains(recipientid)) {
                    session_cipher = this._session_ciphers[recipientid];
                } else {
                    session_cipher = SessionCipher(this._store, this._store, this._store, this._store, recipientid, 1);
                    this._session_ciphers[recipientid] = session_cipher;
                }
                return session_cipher;
            }
            
            public virtual object _get_group_cipher(object groupid, object username) {
                object group_cipher;
                logger.debug(String.Format("get_group_cipher(groupid=%s, username=%s)", groupid, username));
                var senderkeyname = SenderKeyName(groupid, AxolotlAddress(username, 0));
                if (this._group_ciphers.Contains(senderkeyname)) {
                    group_cipher = this._group_ciphers[senderkeyname];
                } else {
                    group_cipher = GroupCipher(this._store.senderKeyStore, senderkeyname);
                    this._group_ciphers[senderkeyname] = group_cipher;
                }
                return group_cipher;
            }
            
            public virtual object _generate_random_padding() {
                logger.debug("generate_random_padding");
                var num = random.randint(1, 255);
                return bytes(bytearray(new List<object> {
                    num
                } * num));
            }
            
            public virtual object _unpad(object data) {
                var padding_byte = object.ReferenceEquals(type(data[-1]), @int) ? data[-1] : ord(data[-1]);
                var padding = padding_byte & 0xFF;
                return data[:: - padding];
            }
            
            public virtual object encrypt(object recipient_id, object message) {
                // to avoid the hassle of encoding issues and associated unnecessary crashes,
                // don't log the message content.
                // see https://github.com/tgalal/yowsup/issues/2732
                logger.debug(String.Format("encrypt(recipientid=%s, message=[omitted])", recipient_id));
                @"
        :param recipient_id:
        :type recipient_id: str
        :param data:
        :type data: bytes
        :return:
        :rtype:
        ";
                var cipher = this._get_session_cipher(recipient_id);
                return cipher.encrypt(message + this._generate_random_padding());
            }
            
            public virtual object decrypt_pkmsg(object senderid, object data, object unpad) {
                logger.debug(String.Format("decrypt_pkmsg(senderid=%s, data=(omitted), unpad=%s)", senderid, unpad));
                var pkmsg = PreKeyWhisperMessage(serialized: data);
                try {
                    var plaintext = this._get_session_cipher(senderid).decryptPkmsg(pkmsg);
                    return unpad ? this._unpad(plaintext) : plaintext;
                } catch (NoSessionException) {
                    throw exceptions.NoSessionException();
                } catch (InvalidKeyIdException) {
                    throw exceptions.InvalidKeyIdException();
                } catch (InvalidMessageException) {
                    throw exceptions.InvalidMessageException();
                } catch (DuplicateMessageException) {
                    throw exceptions.DuplicateMessageException();
                }
            }
            
            public virtual object decrypt_msg(object senderid, object data, object unpad) {
                logger.debug(String.Format("decrypt_msg(senderid=%s, data=[omitted], unpad=%s)", senderid, unpad));
                var msg = WhisperMessage(serialized: data);
                try {
                    var plaintext = this._get_session_cipher(senderid).decryptMsg(msg);
                    return unpad ? this._unpad(plaintext) : plaintext;
                } catch (NoSessionException) {
                    throw exceptions.NoSessionException();
                } catch (InvalidKeyIdException) {
                    throw exceptions.InvalidKeyIdException();
                } catch (InvalidMessageException) {
                    throw exceptions.InvalidMessageException();
                } catch (DuplicateMessageException) {
                    throw exceptions.DuplicateMessageException();
                }
            }
            
            // 
            //         :param groupid:
            //         :type groupid: str
            //         :param message:
            //         :type message: bytes
            //         :return:
            //         :rtype:
            //         
            public virtual object group_encrypt(object groupid, object message) {
                // to avoid the hassle of encoding issues and associated unnecessary crashes,
                // don't log the message content.
                // see https://github.com/tgalal/yowsup/issues/2732
                logger.debug(String.Format("group_encrypt(groupid=%s, message=[omitted])", groupid));
                var group_cipher = this._get_group_cipher(groupid, this._username);
                return group_cipher.encrypt(message + this._generate_random_padding());
            }
            
            public virtual object group_decrypt(object groupid, object participantid, object data) {
                logger.debug(String.Format("group_decrypt(groupid=%s, participantid=%s, data=[omitted])", groupid, participantid));
                var group_cipher = this._get_group_cipher(groupid, participantid);
                try {
                    var plaintext = group_cipher.decrypt(data);
                    plaintext = this._unpad(plaintext);
                    return plaintext;
                } catch (NoSessionException) {
                    throw exceptions.NoSessionException();
                } catch (DuplicateMessageException) {
                    throw exceptions.DuplicateMessageException();
                } catch (InvalidMessageException) {
                    throw exceptions.InvalidMessageException();
                }
            }
            
            public virtual object group_create_skmsg(object groupid) {
                logger.debug(String.Format("group_create_skmsg(groupid=%s)", groupid));
                var senderKeyName = SenderKeyName(groupid, AxolotlAddress(this._username, 0));
                return this._group_session_builder.create(senderKeyName);
            }
            
            // 
            //         :param groupid:
            //         :type groupid: str
            //         :param participantid:
            //         :type participantid: str
            //         :param skmsgdata:
            //         :type skmsgdata: bytearray
            //         :return:
            //         :rtype:
            //         
            public virtual object group_create_session(object groupid, object participantid, object skmsgdata) {
                logger.debug(String.Format("group_create_session(groupid=%s, participantid=%s, skmsgdata=[omitted])", groupid, participantid));
                var senderKeyName = SenderKeyName(groupid, AxolotlAddress(participantid, 0));
                var senderkeydistributionmessage = SenderKeyDistributionMessage(serialized: skmsgdata);
                this._group_session_builder.process(senderKeyName, senderkeydistributionmessage);
            }
            
            // 
            //         :param username:
            //         :type username: str
            //         :param prekeybundle:
            //         :type prekeybundle: PreKeyBundle
            //         :return:
            //         :rtype:
            //         
            public virtual object create_session(object username, object prekeybundle, object autotrust = false) {
                logger.debug(String.Format("create_session(username=%s, prekeybundle=[omitted], autotrust=%s)", username, autotrust));
                var session_builder = SessionBuilder(this._store, this._store, this._store, this._store, username, 1);
                try {
                    session_builder.processPreKeyBundle(prekeybundle);
                } catch (UntrustedIdentityException) {
                    if (autotrust) {
                        this.trust_identity(ex.getName(), ex.getIdentityKey());
                    } else {
                        throw exceptions.UntrustedIdentityException(ex.getName(), ex.getIdentityKey());
                    }
                }
            }
            
            // 
            //         :param username:
            //         :type username: str
            //         :return:
            //         :rtype:
            //         
            public virtual object session_exists(object username) {
                logger.debug(String.Format("session_exists(%s)?", username));
                return this._store.containsSession(username, 1);
            }
            
            public virtual object load_senderkey(object groupid) {
                logger.debug(String.Format("load_senderkey(groupid=%s)", groupid));
                var senderkeyname = SenderKeyName(groupid, AxolotlAddress(this._username, 0));
                return this._store.loadSenderKey(senderkeyname);
            }
            
            public virtual object trust_identity(object recipientid, object identitykey) {
                logger.debug(String.Format("trust_identity(recipientid=%s, identitykey=[omitted])", recipientid));
                this._store.saveIdentity(recipientid, identitykey);
            }
        }
    }
}
