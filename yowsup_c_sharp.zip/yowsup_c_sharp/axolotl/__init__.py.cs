namespace yowsup.axolotl
{

    public static class @__init__ {
        
        public static logger logger = logging.getLogger(@__name__);
    }
}
