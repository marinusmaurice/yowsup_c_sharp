namespace yowsup.axolotl
{

    using StorageTools = yowsup.common.tools.StorageTools;

    using System;

    public static class factory {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class AxolotlManagerFactory
            : object {
            
            public string DB;
            
            public string DB = "axolotl.db";
            
            public virtual object get_manager(object profile_name, object username) {
                logger.debug(String.Format("get_manager(profile_name=%s, username=%s)", profile_name, username));
                var dbpath = StorageTools.constructPath(profile_name, this.DB);
                var store = LiteAxolotlStore(dbpath);
                return AxolotlManager(store, username);
            }
        }
    }
}
