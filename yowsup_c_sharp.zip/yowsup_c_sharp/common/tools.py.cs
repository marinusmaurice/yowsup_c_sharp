namespace yowsup.common
{

    using YowConstants = constants.YowConstants;

    using KeyPair = consonance.structs.keypair.KeyPair;

    using user_config_dir = appdirs.user_config_dir;

    using System;

    using System.Collections.Generic;

    public static class tools {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class Jid {
            
            [staticmethod]
            public static object normalize(object number) {
                if (number.Contains("@")) {
                    return number;
                } else if (number.Contains("-")) {
                    return String.Format("%s@%s", number, YowConstants.WHATSAPP_GROUP_SERVER);
                }
                return String.Format("%s@%s", number, YowConstants.WHATSAPP_SERVER);
            }
        }
        
        public class HexTools {
            
            public object decode_hex;
            
            public object decode_hex = codecs.getdecoder("hex_codec");
            
            [staticmethod]
            public static object decodeHex(object hexString) {
                var result = HexTools.decode_hex(hexString)[0];
                if (sys.version_info >= (3, 0)) {
                    result = result.decode("latin-1");
                }
                return result;
            }
        }
        
        public class WATools {
            
            [staticmethod]
            public static object generateIdentity() {
                return os.urandom(20);
            }
            
            // 
            //         :return:
            //         :rtype: str
            //         
            [classmethod]
            public static object generatePhoneId(object cls) {
                return cls.generateUUID().ToString();
            }
            
            // 
            //         :return:
            //         :rtype: bytes
            //         
            [classmethod]
            public static object generateDeviceId(object cls) {
                return cls.generateUUID().bytes;
            }
            
            // 
            //         :return:
            //         :rtype: uuid.UUID
            //         
            [classmethod]
            public static object generateUUID(object cls) {
                return uuid.uuid4();
            }
            
            // 
            //         :return:
            //         :rtype: KeyPair
            //         
            [classmethod]
            public static object generateKeyPair(object cls) {
                return KeyPair.generate();
            }
            
            [staticmethod]
            public static object getFileHashForUpload(object filePath) {
                var sha1 = hashlib.sha256();
                var f = open(filePath, "rb");
                try {
                    sha1.update(f.read());
                } finally {
                    f.close();
                }
                var b64Hash = base64.b64encode(sha1.digest());
                return object.ReferenceEquals(type(b64Hash), str) ? b64Hash : b64Hash.decode();
            }
        }
        
        public class StorageTools {
            
            public string NAME_CONFIG;
            
            public string NAME_CONFIG = "config.json";
            
            [staticmethod]
            public static object constructPath(params object [] path) {
                path = os.path.join(path);
                var fullPath = os.path.join(user_config_dir(YowConstants.YOWSUP), path);
                if (!os.path.exists(os.path.dirname(fullPath))) {
                    os.makedirs(os.path.dirname(fullPath));
                }
                return fullPath;
            }
            
            [staticmethod]
            public static object getStorageForProfile(object profile_name) {
                if (type(profile_name) != str) {
                    profile_name = profile_name.ToString();
                }
                return StorageTools.constructPath(profile_name);
            }
            
            [staticmethod]
            public static object writeProfileData(object profile_name, object name, object val) {
                logger.debug(String.Format("writeProfileData(profile_name=%s, name=%s, val=[omitted])", profile_name, name));
                var path = os.path.join(StorageTools.getStorageForProfile(profile_name), name);
                logger.debug(String.Format("Writing %s", path));
                using (var attrFile = open(path, object.ReferenceEquals(type(val), str) ? "w" : "wb")) {
                    attrFile.write(val);
                }
            }
            
            [staticmethod]
            public static object readProfileData(object profile_name, object name, object @default = null) {
                logger.debug(String.Format("readProfileData(profile_name=%s, name=%s)", profile_name, name));
                var path = StorageTools.getStorageForProfile(profile_name);
                var dataFilePath = os.path.join(path, name);
                if (os.path.isfile(dataFilePath)) {
                    logger.debug(String.Format("Reading %s", dataFilePath));
                    using (var attrFile = open(dataFilePath, "rb")) {
                        return attrFile.read();
                    }
                } else {
                    logger.debug(String.Format("%s does not exist", dataFilePath));
                }
                return @default;
            }
            
            [classmethod]
            public static object writeProfileConfig(object cls, object profile_name, object config) {
                cls.writeProfileData(profile_name, cls.NAME_CONFIG, config);
            }
            
            [classmethod]
            public static object readProfileConfig(object cls, object profile_name, object config) {
                return cls.readProfileData(profile_name, cls.NAME_CONFIG);
            }
        }
        
        public class ImageTools {
            
            [staticmethod]
            public static object scaleImage(
                object infile,
                object outfile,
                object imageFormat,
                object width,
                object height) {
                using (var imp = PILOptionalModule()) {
                    Image = imp("Image");
                    im = Image.open(infile);
                    //Convert P mode images
                    if (im.mode != "RGB") {
                        im = im.convert("RGB");
                    }
                    im.thumbnail((width, height));
                    im.save(outfile, imageFormat);
                    return true;
                }
                return false;
            }
            
            [staticmethod]
            public static object getImageDimensions(object imageFile) {
                using (var imp = PILOptionalModule()) {
                    Image = imp("Image");
                    im = Image.open(imageFile);
                    return im.size;
                }
            }
            
            [staticmethod]
            public static object generatePreviewFromImage(object image) {
                var _tup_1 = tempfile.mkstemp();
                var fd = _tup_1.Item1;
                var path = _tup_1.Item2;
                object preview = null;
                if (ImageTools.scaleImage(image, path, "JPEG", YowConstants.PREVIEW_WIDTH, YowConstants.PREVIEW_HEIGHT)) {
                    var fileObj = os.fdopen(fd, "rb+");
                    fileObj.seek(0);
                    preview = fileObj.read();
                    fileObj.close();
                }
                os.remove(path);
                return preview;
            }
        }
        
        public class MimeTools {
            
            public object e;
            
            public object MIME_FILE;
            
            public object MIME_FILE = os.path.join(os.path.dirname(@__file__), "mime.types");
            
            static MimeTools() {
                mimetypes.init();
                mimetypes.init(new List<object> {
                    MIME_FILE
                });
                logger.warning("Mime types supported can't be read. System mimes will be used. Cause: " + e.message);
            }
            
            [staticmethod]
            public static object getMIME(object filepath) {
                var mimeType = mimetypes.guess_type(filepath)[0];
                if (mimeType == null) {
                    throw new Exception("Unsupported/unrecognized file type for: " + filepath);
                }
                return mimeType;
            }
        }
        
        public class VideoTools {
            
            [staticmethod]
            public static object getVideoProperties(object videoFile) {
                using (var imp = FFVideoOptionalModule()) {
                    VideoStream = imp("VideoStream");
                    s = VideoStream(videoFile);
                    return Tuple.Create(s.width, s.height, s.bitrate, s.duration);
                }
            }
            
            [staticmethod]
            public static object generatePreviewFromVideo(object videoFile) {
                using (var imp = FFVideoOptionalModule()) {
                    VideoStream = imp("VideoStream");
                    _tup_1 = tempfile.mkstemp(".jpg");
                    fd = _tup_1.Item1;
                    path = _tup_1.Item2;
                    stream = VideoStream(videoFile);
                    stream.get_frame_at_sec(0).image().save(path);
                    preview = ImageTools.generatePreviewFromImage(path);
                    os.remove(path);
                    return preview;
                }
            }
        }
    }
}
