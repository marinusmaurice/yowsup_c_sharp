namespace yowsup.common
{

    using System;

    public static class optionalmodules {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class OptionalModule
            : object {
            
            public object failMessage;
            
            public object modulename;
            
            public object require;
            
            public OptionalModule(object modulename, object failMessage = null, object require = false) {
                this.modulename = modulename;
                this.require = require;
                this.failMessage = failMessage;
            }
            
            public virtual object @__enter__() {
                return this.importFn;
            }
            
            public virtual object importFn(object what = null) {
                var imp = !what ? this.modulename : String.Format("%s.%s", this.modulename, what);
                return importlib.import_module(imp);
            }
            
            public virtual object @__exit__(object exc_type, object exc_val, object exc_tb) {
                if (exc_val is ImportError) {
                    var failMessage = this.failMessage != null ? this.failMessage : String.Format("%s import failed", this.modulename);
                    if (failMessage) {
                        logger.error(failMessage);
                    }
                    if (this.require) {
                        throw;
                    }
                    return true;
                }
            }
        }
        
        public class PILOptionalModule
            : OptionalModule {
            
            public PILOptionalModule(object failMessage = null, object require = false)
                : base(failMessage: failMessage, require: require) {
            }
        }
        
        public class FFVideoOptionalModule
            : OptionalModule {
            
            public FFVideoOptionalModule(object failMessage = null, object require = false)
                : base(failMessage: failMessage, require: require) {
            }
        }
    }
}
