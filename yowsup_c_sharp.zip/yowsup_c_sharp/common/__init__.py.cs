namespace yowsup.common
{

    public static class @__init__ {
    }
}
