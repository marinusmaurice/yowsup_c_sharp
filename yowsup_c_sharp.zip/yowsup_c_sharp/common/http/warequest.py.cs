using yowsup;
using Curve = axolotl.ecc.curve.Curve;

using WATools = yowsup.common.tools.WATools;

using Config = yowsup.config.v1.config.Config;

using YowProfile = yowsup.profile.profile.YowProfile;

using System.Collections.Generic;

using System.Diagnostics;

using System;

using System.Linq;
namespace yowsup.common.http
{

  

    public static class warequest {
        
        static warequest() {
            ssl._create_default_https_context = ssl._create_unverified_context;
        }
        
        public static logger logger = logging.getLogger("@__name__");
        
        public class WARequest
            : object {
            
            public object _axolotlmanager;
            
            public object _config;
            
            public string _p_in;
            
          
            
            public Dictionary<object, object> headers;
           
            public List<object> @params;
            
            public None parser;
            
            public int port;
            
            public List<object> pvars;
            
            public object response;
            
            public object result;
            
            public bool sent;
            
            public object status;
            
            public string type;
            
            public int OK = 200;
            
            public byte[] ENC_PUBKEY = Curve.decodePoint(new byte[] {
                5,
                142,
                140,
                15,
                116,
                195,
                235,
                197,
                215,
                166,
                134,
                92,
                108,
                60,
                132,
                56,
                86,
                176,
                97,
                33,
                204,
                232,
                234,
                119,
                77,
                34,
                251,
                111,
                18,
                37,
                18,
                48,
                45
            });
            
            public WARequest(object config_or_profile) {
                object profile;
                this.pvars = new List<object>();
                this.port = 443;
                this.type = "GET";
                this.parser = null;
                this.@params = new List<object>();
                this.headers = new Dictionary<object, object> {
                };
                this.sent = false;
                this.response = null;
                if (config_or_profile is Config) {
                    logger.warning("Passing Config to WARequest is deprecated, pass a YowProfile instead");
                    profile = YowProfile(config_or_profile.phone, config_or_profile);
                } else {
                    Debug.Assert(config_or_profile is YowProfile);
                    profile = config_or_profile;
                }
                this._config = profile.config;
                var config = this._config;
                this._p_in = config.phone.ToString()[config.cc.ToString().Count];
                this._axolotlmanager = profile.axolotl_manager;
                if (config.expid == null) {
                    config.expid = WATools.generateDeviceId();
                }
                if (config.fdid == null) {
                    config.fdid = WATools.generatePhoneId();
                }
                if (config.client_static_keypair == null) {
                    config.client_static_keypair = WATools.generateKeyPair();
                }
                this.addParam("cc", config.cc);
                this.addParam("in", this._p_in);
                this.addParam("lg", "en");
                this.addParam("lc", "GB");
                this.addParam("mistyped", "6");
                this.addParam("authkey", this.b64encode(config.client_static_keypair.public.data));
                this.addParam("e_regid", this.b64encode(@struct.pack(">I", this._axolotlmanager.registration_id)));
                this.addParam("e_keytype", this.b64encode(new byte[] { 0x05 }));
                this.addParam("e_ident", this.b64encode(this._axolotlmanager.identity.publicKey.serialize()[1]));
                var signedprekey = this._axolotlmanager.load_latest_signed_prekey(generate: true);
                this.addParam("e_skey_id", this.b64encode(@struct.pack(">I", signedprekey.getId())[1]));
                this.addParam("e_skey_val", this.b64encode(signedprekey.getKeyPair().publicKey.serialize()[1]));
                this.addParam("e_skey_sig", this.b64encode(signedprekey.getSignature()));
                this.addParam("fdid", config.fdid);
                this.addParam("expid", this.b64encode(config.expid));
                this.addParam("network_radio_type", "1");
                this.addParam("simnum", "1");
                this.addParam("hasinrc", "1");
                this.addParam("pid", Convert.ToInt32(random.uniform(100, 9999)));
                this.addParam("rc", 0);
                if (this._config.id) {
                    this.addParam("id", this._config.id);
                }
            }
            
            public virtual object setParsableVariables(object pvars) {
                this.pvars = pvars;
            }
            
            public virtual object onResponse(object name, object value) {
                if (name == "status") {
                    this.status = value;
                } else if (name == "result") {
                    this.result = value;
                }
            }
            
            public virtual object addParam(object name, object value) {
                this.params.append((name, value));
            }
            
            public virtual object removeParam(object name) {
                foreach (var i in Enumerable.Range(0, this.params.Count - 0)) {
                    if (this.params[i][0] == name) {
                        this.params.Remove(i);
                    }
                }
            }
            
            public virtual object addHeaderField(object name, object value) {
                this.headers[name] = value;
            }
            
            public virtual object clearParams() {
                this.params = new List<object>();
            }
            
            public virtual object getUserAgent() {
                return YowsupEnv.getCurrent().getUserAgent();
            }
            
            public virtual object send(object parser = null, object encrypt = true, object preview = false) {
                logger.debug(String.Format("send(parser=%s, encrypt=%s, preview=%s)", parser == null ? null : "[omitted]", encrypt, preview));
                if (this.type == "POST") {
                    return this.sendPostRequest(parser);
                }
                return this.sendGetRequest(parser, encrypt, preview: preview);
            }
            
            public virtual object setParser(object parser) {
                if (parser is ResponseParser) {
                    this.parser = parser;
                } else {
                    logger.error("Invalid parser");
                }
            }
            
            public virtual object getConnectionParameters() {
                object path;
                object host;
                if (!this.url) {
                    return Tuple.Create("", "", this.port);
                }
                try {
                    var url = this.url.split("://", 1);
                    url = url.Count == 1 ? url[0] : url[1];
                    var _tup_1 = url.split("/", 1);
                    host = _tup_1.Item1;
                    path = _tup_1.Item2;
                } catch (ValueError) {
                    host = url;
                    path = "";
                }
                path = "/" + path;
                return Tuple.Create(host, this.port, path);
            }
            
            // 
            //         :param params:
            //         :type params: list
            //         :param key:
            //         :type key: ECPublicKey
            //         :return:
            //         :rtype: list
            //         
            public virtual object encryptParams(object params, object key) {
                var keypair = Curve.generateKeyPair();
                var encodedparams = this.urlencodeParams(params);
                var cipher = AESGCM(Curve.calculateAgreement(key, keypair.privateKey));
                var ciphertext = cipher.encrypt(new byte[] { 0x00, 0x00, 0x00, 0x00 } + @struct.pack(">Q", 0), encodedparams.encode(), "");
                var payload = base64.b64encode(keypair.publicKey.serialize()[1] + ciphertext);
                return new List<Tuple<string, object>> {
                    (new byte[] { (byte)'E', (byte)'N', (byte)'C' }, payload)
                };
            }
            
            public virtual object sendGetRequest(object parser = null, object encrypt_params = true, object preview = false) {
                object params;
                logger.debug(String.Format("sendGetRequest(parser=%s, encrypt_params=%s, preview=%s)", parser == null ? null : "[omitted]", encrypt_params, preview));
                this.response = null;
                if (encrypt_params) {
                    logger.debug("Encrypting parameters");
                    if (logger.level <= logging.DEBUG) {
                        logger.debug("pre-encrypt (encoded) parameters = \n%s", this.urlencodeParams(this.params));
                    }
                    params = this.encryptParams(this.params, this.ENC_PUBKEY);
                } else {
                    //# params will be logged right before sending
                    params = this.params;
                }
                parser = parser || this.parser || ResponseParser();
                var headers = new dict(new Dictionary<object, object> {
                    {
                        "User-Agent",
                        this.getUserAgent()},
                    {
                        "Accept",
                        parser.getMeta()}}.items().ToList() + this.headers.items().ToList());
                var _tup_1 = this.getConnectionParameters();
                var host = _tup_1.Item1;
                var port = _tup_1.Item2;
                var path = _tup_1.Item3;
                this.response = WARequest.sendRequest(host, port, path, headers, params, "GET", preview: preview);
                if (preview) {
                    logger.info("Preview request, skip response handling and return None");
                    return null;
                }
                if (!(this.response.status == WARequest.OK)) {
                    logger.error(String.Format("Request not success, status was %s", this.response.status));
                    return new Dictionary<object, object> {
                    };
                }
                var data = this.response.read();
                logger.info(data);
                this.sent = true;
                return parser.parse(data.decode(), this.pvars);
            }
            
            public virtual object sendPostRequest(object parser = null) {
                this.response = null;
                var params = this.params;
                parser = parser || this.parser || ResponseParser();
                var headers = new dict(new Dictionary<object, object> {
                    {
                        "User-Agent",
                        this.getUserAgent()},
                    {
                        "Accept",
                        parser.getMeta()},
                    {
                        "Content-Type",
                        "application/x-www-form-urlencoded"}}.items().ToList() + this.headers.items().ToList());
                var _tup_1 = this.getConnectionParameters();
                var host = _tup_1.Item1;
                var port = _tup_1.Item2;
                var path = _tup_1.Item3;
                this.response = WARequest.sendRequest(host, port, path, headers, params, "POST");
                if (!(this.response.status == WARequest.OK)) {
                    logger.error(String.Format("Request not success, status was %s", this.response.status));
                    return new Dictionary<object, object> {
                    };
                }
                var data = this.response.read();
                logger.info(data);
                this.sent = true;
                return parser.parse(data.decode(), this.pvars);
            }
            
            public virtual object b64encode(object value) {
                return base64.urlsafe_b64encode(value).replace(new byte[] { (byte)'=' }, "");
            }
            
            [classmethod]
            public static object urlencode(object cls, object value) {
                if (!(str, bytes).Contains(type(value))) {
                    value = value.ToString();
                }
                var @out = "";
                foreach (var char in value) {
                    if (object.ReferenceEquals(type(char), @int)) {
                        var char = bytearray(new List<object> {
                            char
                        });
                    }
                    var quoted = urllib_quote(char, safe: "");
                    @out += quoted[0] != new byte[] { (byte)'%' } ? quoted : quoted.lower();
                }
                return @out.replace("-", "%2d").replace("_", "%5f").replace("~", "%7e");
            }
            
            [classmethod]
            public static object urlencodeParams(object cls, object params) {
                var merged = new List<object>();
                foreach (var _tup_1 in params) {
                    var k = _tup_1.Item1;
                    var v = _tup_1.Item2;
                    merged.append(String.Format("%s=%s", k, cls.urlencode(v)));
                }
                return "&".join(merged);
            }
            
            [classmethod]
            public static object sendRequest(
                object cls,
                object host,
                object port,
                object path,
                object headers,
                object params,
                object reqType = "GET",
                object preview = false) {
                object conn;
                logger.debug(String.Format("sendRequest(host=%s, port=%s, path=%s, headers=%s, params=%s, reqType=%s, preview=%s)", host, port, path, headers, params, reqType, preview));
                params = cls.urlencodeParams(params);
                path = reqType == "GET" && params ? path + "?" + params : path;
                if (!preview) {
                    logger.debug(String.Format("Opening connection to %s", host));
                    conn = port == 443 ? httplib.HTTPSConnection(host, port) : httplib.HTTPConnection(host, port);
                } else {
                    logger.debug(String.Format("Should open connection to %s, but this is a preview", host));
                    conn = null;
                }
                if (!preview) {
                    logger.debug(String.Format("Sending %s request to %s", reqType, path));
                    conn.request(reqType, path, params, headers);
                } else {
                    logger.debug(String.Format("Should send %s request to %s, but this is a preview", reqType, path));
                    return null;
                }
                var response = conn.getresponse();
                return response;
            }
        }
    }
}
