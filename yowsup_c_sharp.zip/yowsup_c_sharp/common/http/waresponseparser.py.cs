namespace yowsup.common.http
{

    using minidom = xml.dom.minidom;

    using System.Collections.Generic;

    public static class waresponseparser {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class ResponseParser
            : object {
            
            public string meta;
            
            public ResponseParser() {
                this.meta = "*";
            }
            
            public virtual object parse(object text, object pvars) {
                return text;
            }
            
            public virtual object getMeta() {
                return this.meta;
            }
            
            public virtual object getVars(object pvars) {
                if (object.ReferenceEquals(type(pvars), dict)) {
                    return pvars;
                }
                if (object.ReferenceEquals(type(pvars), list)) {
                    var @out = new Dictionary<object, object> {
                    };
                    foreach (var p in pvars) {
                        @out[p] = p;
                    }
                    return @out;
                }
            }
        }
        
        public class XMLResponseParser
            : ResponseParser {
            
            public string meta;
            
            public XMLResponseParser() {
                try {
                } catch (ImportError) {
                    Console.WriteLine("libxml2 XMLResponseParser requires libxml2");
                    sys.exit(1);
                }
                this.meta = "text/xml";
            }
            
            public virtual object parse(object xml, object pvars) {
                var doc = libxml2.parseDoc(xml);
                pvars = this.getVars(pvars);
                var vals = new Dictionary<object, object> {
                };
                foreach (var _tup_1 in pvars.items()) {
                    var k = _tup_1.Item1;
                    var v = _tup_1.Item2;
                    var res = doc.xpathEval(v);
                    vals[k] = new List<object>();
                    foreach (var r in res) {
                        //if not vals.has_key(r.name):
                        //   vals[r.name] = []
                        if (r.type == "element") {
                            //vals[r.name].append(self.xmlToDict(minidom.parseString(str(r)))[r.name])
                            vals[k].append(this.xmlToDict(minidom.parseString(r.ToString()))[r.name]);
                        } else if (r.type == "attribute") {
                            vals[k].append(r.content);
                        } else {
                            logger.error("UNKNOWN TYPE");
                        }
                    }
                    if (vals[k].Count == 1) {
                        vals[k] = vals[k][0];
                    } else if (vals[k].Count == 0) {
                        vals[k] = null;
                    }
                }
                return vals;
            }
            
            public virtual object xmlToDict(object xmlNode) {
                object node;
                if (xmlNode.nodeName == "#document") {
                    node = new Dictionary<object, object> {
                        {
                            xmlNode.firstChild.nodeName,
                            new Dictionary<object, object> {
                            }}};
                    node[xmlNode.firstChild.nodeName] = this.xmlToDict(xmlNode.firstChild);
                    return node;
                }
                node = new Dictionary<object, object> {
                };
                var curr = node;
                if (xmlNode.attributes) {
                    foreach (var _tup_1 in xmlNode.attributes.items()) {
                        var name = _tup_1.Item1;
                        var value = _tup_1.Item2;
                        curr[name] = value;
                    }
                }
                foreach (var n in xmlNode.childNodes) {
                    if (n.nodeType == n.TEXT_NODE) {
                        curr["__TEXT__"] = n.data;
                        continue;
                    }
                    if (!curr.Contains(n.nodeName)) {
                        curr[n.nodeName] = new List<object>();
                    }
                    if (xmlNode.getElementsByTagName(n.nodeName).Count > 1) {
                        //curr[n.nodeName] = []
                        curr[n.nodeName].append(this.xmlToDict(n));
                    } else {
                        curr[n.nodeName] = this.xmlToDict(n);
                    }
                }
                return node;
            }
        }
        
        public class JSONResponseParser
            : ResponseParser {
            
            public string meta;
            
            public JSONResponseParser() {
                this.meta = "text/json";
            }
            
            public virtual object parse(object jsonData, object pvars) {
                var d = json.loads(jsonData);
                pvars = this.getVars(pvars);
                var parsed = new Dictionary<object, object> {
                };
                foreach (var _tup_1 in pvars.items()) {
                    var k = _tup_1.Item1;
                    var v = _tup_1.Item2;
                    parsed[k] = this.query(d, v);
                }
                return parsed;
            }
            
            public virtual object query(object d, object key) {
                var keys = key.split(".", 1);
                var currKey = keys[0];
                if (d.Contains(currKey)) {
                    var item = d[currKey];
                    if (keys.Count == 1) {
                        return item;
                    }
                    if (object.ReferenceEquals(type(item), dict)) {
                        return this.query(item, keys[1]);
                    } else if (object.ReferenceEquals(type(item), list)) {
                        var output = new List<object>();
                        foreach (var i in item) {
                            output.append(this.query(i, keys[1]));
                        }
                        return output;
                    } else {
                        return null;
                    }
                }
            }
        }
        
        public class PListResponseParser
            : ResponseParser {
            
            public string meta;
            
            public PListResponseParser() {
                this.meta = "text/xml";
            }
            
            public virtual object parse(object xml, object pvars) {
                object pl;
                //tmp = minidom.parseString(xml)
                if (sys.version_info >= (3, 0)) {
                    pl = plistlib.readPlistFromBytes(xml.encode());
                } else {
                    pl = plistlib.readPlistFromString(xml);
                }
                var parsed = new Dictionary<object, object> {
                };
                pvars = this.getVars(pvars);
                foreach (var _tup_1 in pvars.items()) {
                    var k = _tup_1.Item1;
                    var v = _tup_1.Item2;
                    parsed[k] = pl.Contains(k) ? pl[k] : null;
                }
                return parsed;
            }
        }
    }
}
