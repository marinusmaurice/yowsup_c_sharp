namespace yowsup.common.http
{

    public static class test_warequest {
    }
}
