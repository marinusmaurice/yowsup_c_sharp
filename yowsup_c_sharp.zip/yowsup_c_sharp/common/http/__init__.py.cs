namespace yowsup.common.http
{

    public static class @__init__ {
    }
}
