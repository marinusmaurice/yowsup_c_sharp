// 
// Copyright (c) <2012> Tarek Galal <tare2.galal@gmail.com>
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy of this
// software and associated documentation files (the "Software"), to deal in the Software
// without restriction, including without limitation the rights to use, copy, modify,
// merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to the following
// conditions:
// 
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
// INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
// HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE
// OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
// 
namespace yowsup.common.http
{

    using urlparse = urllib.parse.urlparse;

    using System;

    public static class httpproxy {
        
        public class HttpProxy {
            
            public object address;
            
            public object password;
            
            public object username;
            
            public HttpProxy(object address, object username = null, object password = null) {
                this.address = address;
                this.username = username;
                this.password = password;
            }
            
            public virtual object @__repr__() {
                return repr(this.address);
            }
            
            public virtual object handler() {
                return new HttpProxyHandler(this);
            }
            
            [staticmethod]
            public static object getFromEnviron() {
                object url = null;
                foreach (var key in ("http_proxy", "https_proxy")) {
                    url = os.environ.get(key);
                    if (url) {
                        beak;
                    }
                }
                if (!url) {
                    return null;
                }
                var dat = urlparse(url);
                var port = dat.scheme == "http" ? 80 : 443;
                if (dat.port != null) {
                    port = Convert.ToInt32(dat.port);
                }
                var host = dat.hostname;
                return new HttpProxy((host, port), dat.username, dat.password);
            }
        }
        
        public class HttpProxyHandler {
            
            public string data;
            
            public object proxy;
            
            public string state;
            
            public HttpProxyHandler(object proxy) {
                this.state = "init";
                this.proxy = proxy;
            }
            
            public virtual object onConnect() {
            }
            
            public virtual object connect(object socket, object pair) {
                var proxy = this.proxy;
                object authHeader = null;
                if (proxy.username && proxy.password) {
                    var key = bytes != str ? bytes(proxy.username, "ascii") + new byte[] { (byte)':' } + bytes(proxy.password, "ascii") : bytes(proxy.username) + new byte[] { (byte)':' } + proxy.password;
                    var auth = base64.b64encode(key);
                    authHeader = new byte[] { (byte)'P', (byte)'r', (byte)'o', (byte)'x', (byte)'y', (byte)'-', (byte)'A', (byte)'u', (byte)'t', (byte)'h', (byte)'o', (byte)'r', (byte)'i', (byte)'z', (byte)'a', (byte)'t', (byte)'i', (byte)'o', (byte)'n', (byte)':', (byte)' ', (byte)'B', (byte)'a', (byte)'s', (byte)'i', (byte)'c', (byte)' ' } + auth + new byte[] { \\, \n };
                }
                var data = bytearray(String.Format("CONNECT %s:%d HTTP/1.1\r\nHost: %s:%d\r\n", 2 * pair), "ascii");
                if (authHeader) {
                    data += authHeader;
                }
                data += new byte[] { \\, \n };
                this.state = "connect";
                this.data = data;
                socket.connect(proxy.address);
            }
            
            public virtual object send(object socket) {
                if (this.state == "connect") {
                    socket.send(this.data);
                    this.state = "sent";
                }
            }
            
            public virtual object recv(object socket, object size) {
                if (this.state == "sent") {
                    var data = socket.recv(size);
                    data = data.decode("ascii");
                    var status = data.split(" ", 2);
                    if (status[1] != "200") {
                        throw new Exception(String.Format("%s", data[::data.index("\r\n")]));
                    }
                    this.state = "end";
                    this.onConnect();
                    return data;
                }
            }
        }
    }
}
