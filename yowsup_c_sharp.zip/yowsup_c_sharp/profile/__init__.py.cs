namespace yowsup.profile {
    
    public static class @__init__ {
    }
}
