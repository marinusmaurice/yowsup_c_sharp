namespace yowsup.profile
{

    using System;

    public static class profile {
        
        public static logger logger = logging.getLogger("@__name__");
        
        public class YowProfile
            : object {
            
            public None _axolotl_manager;
            
            public None _config;
            
            public object _config_manager;
            
            public object _profile_name;
            
            public YowProfile(object profile_name, object config = null) {
                // type: (str, Config) -> None
                logger.debug(String.Format("Constructed Profile(profile_name=%s)", profile_name));
                this._profile_name = profile_name;
                this._config = config;
                this._config_manager = ConfigManager();
                this._axolotl_manager = null;
            }
            
            public override string ToString() {
                return String.Format("YowProfile(profile_name=%s)", this._profile_name);
            }
            
            public virtual object _load_config() {
                // type: () -> Config
                logger.debug(String.Format("load_config for %s", this._profile_name));
                return this._config_manager.load(this._profile_name);
            }
            
            public virtual object _load_axolotl_manager() {
                // type: () -> AxolotlManager
                return AxolotlManagerFactory().get_manager(this._profile_name, this.username);
            }
            
            public virtual object write_config(object config) {
                // type: (Config) -> None
                logger.debug(String.Format("write_config for %s", this._profile_name));
                this._config_manager.save(this._profile_name, config);
            }
            
            public object config {
                get {
                    if (this._config == null) {
                        this._config = this._load_config();
                    }
                    return this._config;
                }
            }
            
            public object axolotl_manager {
                get {
                    if (this._axolotl_manager == null) {
                        this._axolotl_manager = this._load_axolotl_manager();
                    }
                    return this._axolotl_manager;
                }
            }
            
            public object username {
                get {
                    var config = this.config;
                    return config.login || config.phone || this._profile_name;
                }
            }
        }
    }
}
