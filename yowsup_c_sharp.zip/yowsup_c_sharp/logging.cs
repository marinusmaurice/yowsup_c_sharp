﻿using System;

namespace yowsup
{
    public class logging
    {
        internal static logger getLogger(object name__)
        {
            throw new NotImplementedException();
        }
    }

    public class logger
    {
        internal void debug(string v)
        {
            throw new NotImplementedException();
        }

        internal void warn(string v)
        {
            throw new NotImplementedException();
        }

        internal void warning(string v)
        {
            throw new NotImplementedException();
        }

        internal void error(string v)
        {
            throw new NotImplementedException();
        }
    }
}