namespace yowsup.structs
{

    public static class @__init__ {
    }
}
