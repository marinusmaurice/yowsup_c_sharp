using System.Collections.Generic;
using System.Diagnostics;
using System;

namespace yowsup.structs
{
    public static class protocoltreenode {
        
        public class ProtocolTreeNode
            { 
            public bool _truncate_str_data;
            
            public Dictionary<object, object> attributes;
            
            public List<object> children;
            
            public object data;
            
            public object tag;
            
            public int _STR_MAX_LEN_DATA = 500;
            
            public string _STR_INDENT = "  ";
            
            public ProtocolTreeNode(object tag, Dictionary<object, object> attributes = null, List<object> children = null, object data = null) {
                // type: (str, dict, list[ProtocolTreeNode], bytes) -> None
                if (data != null) {
                  //TODO:
                  //  Debug.Assert(object.ReferenceEquals(type(data), bytes));
                  //  Debug.Assert(type(data));
                }
                this.tag = tag;
                if(attributes == null)
                    this.attributes = new Dictionary<object, object>();
                else
                    this.attributes = attributes;

                if(children == null)
                    this.children = new List<object>();
                else
                    this.children = new List<object>();
                this.data = data;
                this._truncate_str_data = true;
                //TODO:
                //Debug.Assert(object.ReferenceEquals(type(this.children), list));
                //Debug.Assert(String.Format("Children must be a list, got %s", type(this.children)));
            }
            
            // 
            //         :param protocolTreeNode: ProtocolTreeNode
            //         :return: bool
            //         
            public virtual object @__eq__(object protocolTreeNode) {
                //
                if (protocolTreeNode.@__class__ == ProtocolTreeNode && this.tag == protocolTreeNode.tag && this.data == protocolTreeNode.data && this.attributes == protocolTreeNode.attributes && this.getAllChildren().Count == protocolTreeNode.getAllChildren().Count) {
                    var found = false;
                    foreach (var c in this.getAllChildren()) {
                        foreach (var c2 in protocolTreeNode.getAllChildren()) {
                            if (c == c2) {
                                found = true;
                                beak;
                            }
                        }
                        if (!found) {
                            return false;
                        }
                    }
                    found = false;
                    foreach (var c in protocolTreeNode.getAllChildren()) {
                        foreach (var c2 in this.getAllChildren()) {
                            if (c == c2) {
                                found = true;
                                beak;
                            }
                        }
                        if (!found) {
                            return false;
                        }
                    }
                    return true;
                }
                return false;
            }
            
            public virtual object @__hash__() {
                return hash(this.tag) ^ hash(tuple(this.attributes.items())) ^ hash(this.data);
            }
            
            public override string ToString() {
                object postfix;
                var @out = String.Format("<%s", this.tag);
                var attrs = " ".join(map(item => String.Format("%s=\"%s\"", item), this.attributes.items()));
                var children = "\n".join(map(str, this.children));
                var data = this.data || "";
                var len_data = data.Count;
                if (attrs) {
                    @out = String.Format(new byte[] { (byte)'%', (byte)'s', (byte)' ', (byte)'%', (byte)'s' }, @out, attrs);
                }
                if (children || data) {
                    @out = String.Format("%s>", @out);
                    if (children) {
                        @out = String.Format("%s\n%s%s", @out, this._STR_INDENT, children.replace("\n", "\n" + this._STR_INDENT));
                    }
                    if (len_data) {
                        if (this._truncate_str_data && len_data > this._STR_MAX_LEN_DATA) {
                            data = data[::self._STR_MAX_LEN_DATA];
                            postfix = String.Format("...[truncated %s bytes]", len_data - this._STR_MAX_LEN_DATA);
                        } else {
                            postfix = "";
                        }
                        data = String.Format("0x%s", binascii.hexlify(data).decode());
                        @out = String.Format("%s\n%s%s%s", @out, this._STR_INDENT, data, postfix);
                    }
                    @out = String.Format("%s\n</%s>", @out, this.tag);
                } else {
                    @out = String.Format("%s />", @out);
                }
                return @out;
            }
            
            public virtual object getData() {
                return this.data;
            }
            
            public virtual object setData(object data) {
                this.data = data;
            }
            
            public static object tagEquals(object node, object @string) {
                return node != null && node.tag != null && node.tag == @string;
            }
            
            public static object require(object node, object @string) {
                if (!ProtocolTreeNode.tagEquals(node, @string)) {
                    throw new Exception("failed require. string: " + @string);
                }
            }
            
            public virtual object @__getitem__(object key) {
                return this.getAttributeValue(key);
            }
            
            public virtual object @__setitem__(object key, object val) {
                this.setAttribute(key, val);
            }
            
            public virtual object @__delitem__(object key) {
                this.removeAttribute(key);
            }
            
            public virtual object getChild(object identifier) {
                if (type(identifier) == @int) {
                    if (this.children.Count > identifier) {
                        return this.children[identifier];
                    } else {
                        return null;
                    }
                }
                foreach (var c in this.children) {
                    if (identifier == c.tag) {
                        return c;
                    }
                }
                return null;
            }
            
            public virtual object hasChildren() {
                return this.children.Count > 0;
            }
            
            public virtual object addChild(object childNode) {
                this.children.append(childNode);
            }
            
            public virtual object addChildren(object children) {
                foreach (var c in children) {
                    this.addChild(c);
                }
            }
            
            public virtual object getAttributeValue(object @string) {
                try {
                    return this.attributes[@string];
                } catch (KeyError) {
                    return null;
                }
            }
            
            public virtual object removeAttribute(object key) {
                if (this.attributes.Contains(key)) {
                    this.attributes.Remove(key);
                }
            }
            
            public virtual object setAttribute(object key, object value) {
                this.attributes[key] = value;
            }
            
            public virtual object getAllChildren(object tag = null) {
                var ret = new List<object>();
                if (tag == null) {
                    return this.children;
                }
                foreach (var c in this.children) {
                    if (tag == c.tag) {
                        ret.append(c);
                    }
                }
                return ret;
            }
        }
    }
}
