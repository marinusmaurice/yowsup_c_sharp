using System;

namespace yowsup.structs
{

    

    public static class protocolentity {
        
        public class ProtocolEntity
            : object {
                      
            public object tag;
            
            public int @__ID_GEN = 0;
            
            public ProtocolEntity(object tag) {
                this.tag = tag;
            }
            
            public virtual object getTag() {
                return this.tag;
            }
            
            public virtual object isType(object typ) {
                return this.tag == typ;
            }
            
            public virtual object _createProtocolTreeNode(object attributes, object children = null, object data = null) {
                return ProtocolTreeNode(this.getTag(), attributes, children, data);
            }
            
            public virtual object _getCurrentTimestamp() {
                return Convert.ToInt32(time.time());
            }
            
            public virtual object _generateId(object short = false) {
                ProtocolEntity.@__ID_GEN += 1;
                return short ? ProtocolEntity.@__ID_GEN.ToString() : Convert.ToInt32(time.time()).ToString() + "-" + ProtocolEntity.@__ID_GEN.ToString();
            }
            
            public virtual object toProtocolTreeNode() {
            }
            
            [staticmethod]
            public virtual object fromProtocolTreeNode(object protocolTreeNode) {
            }
        }
        
        public class ProtocolEntityTest
            : object {
            
            public None node;
            
            public None ProtocolEntity;
            
            public virtual object setUp() {
                this.ProtocolEntity = null;
                this.node = null;
            }
            
            // def assertEqual(self, entity, node):
            //     raise AssertionError("Should never execute that")
            public virtual object test_generation() {
                if (this.ProtocolEntity == null) {
                    throw new ValueError("Test case not setup!");
                }
                var entity = this.ProtocolEntity.fromProtocolTreeNode(this.node);
                try {
                    this.assertEqual(entity.toProtocolTreeNode(), this.node);
                } catch {
                    Console.WriteLine(entity.toProtocolTreeNode());
                    Console.WriteLine("\nNOTEQ\n");
                    Console.WriteLine(this.node);
                    throw;
                }
            }
        }
    }
}
