using YowAuthenticationProtocolLayer = yowsup.layers.auth.YowAuthenticationProtocolLayer;

using YowCoderLayer = yowsup.layers.coder.YowCoderLayer;

using YowLoggerLayer = yowsup.layers.logger.YowLoggerLayer;

using YowNetworkLayer = yowsup.layers.network.YowNetworkLayer;

using YowMessagesProtocolLayer = yowsup.layers.protocol_messages.YowMessagesProtocolLayer;

using YowMediaProtocolLayer = yowsup.layers.protocol_media.YowMediaProtocolLayer;

using YowAckProtocolLayer = yowsup.layers.protocol_acks.YowAckProtocolLayer;

using YowReceiptProtocolLayer = yowsup.layers.protocol_receipts.YowReceiptProtocolLayer;

using YowGroupsProtocolLayer = yowsup.layers.protocol_groups.YowGroupsProtocolLayer;

using YowPresenceProtocolLayer = yowsup.layers.protocol_presence.YowPresenceProtocolLayer;

using YowIbProtocolLayer = yowsup.layers.protocol_ib.YowIbProtocolLayer;

using YowNotificationsProtocolLayer = yowsup.layers.protocol_notifications.YowNotificationsProtocolLayer;

using YowIqProtocolLayer = yowsup.layers.protocol_iq.YowIqProtocolLayer;

using YowContactsIqProtocolLayer = yowsup.layers.protocol_contacts.YowContactsIqProtocolLayer;

using YowChatstateProtocolLayer = yowsup.layers.protocol_chatstate.YowChatstateProtocolLayer;

using YowPrivacyProtocolLayer = yowsup.layers.protocol_privacy.YowPrivacyProtocolLayer;

using YowProfilesProtocolLayer = yowsup.layers.protocol_profiles.YowProfilesProtocolLayer;

using YowCallsProtocolLayer = yowsup.layers.protocol_calls.YowCallsProtocolLayer;

using YowNoiseLayer = yowsup.layers.noise.layer.YowNoiseLayer;

using YowNoiseSegmentsLayer = yowsup.layers.noise.layer_noise_segments.YowNoiseSegmentsLayer;

using System;

namespace yowsup.stacks
{





    public static class @__init__
    {

        public static Tuple<object, object, object, object, object> YOWSUP_CORE_LAYERS = (YowLoggerLayer, YowCoderLayer, YowNoiseLayer, YowNoiseSegmentsLayer, YowNetworkLayer);

        public static Tuple<object, object, object, object, object, object, object, object, object, object> YOWSUP_PROTOCOL_LAYERS_BASIC = (YowAuthenticationProtocolLayer, YowMessagesProtocolLayer, YowReceiptProtocolLayer, YowAckProtocolLayer, YowPresenceProtocolLayer, YowIbProtocolLayer, YowIqProtocolLayer, YowNotificationsProtocolLayer, YowContactsIqProtocolLayer, YowChatstateProtocolLayer);

        public static object YOWSUP_PROTOCOL_LAYERS_GROUPS = ValueTuple.Create(YowGroupsProtocolLayer) + YOWSUP_PROTOCOL_LAYERS_BASIC;

        public static object YOWSUP_PROTOCOL_LAYERS_MEDIA = ValueTuple.Create(YowMediaProtocolLayer) + YOWSUP_PROTOCOL_LAYERS_BASIC;

        public static object YOWSUP_PROTOCOL_LAYERS_PROFILES = ValueTuple.Create(YowProfilesProtocolLayer) + YOWSUP_PROTOCOL_LAYERS_BASIC;

        public static object YOWSUP_PROTOCOL_LAYERS_CALLS = ValueTuple.Create(YowCallsProtocolLayer) + YOWSUP_PROTOCOL_LAYERS_BASIC;

        public static object YOWSUP_PROTOCOL_LAYERS_FULL = (YowGroupsProtocolLayer, YowMediaProtocolLayer, YowPrivacyProtocolLayer, YowProfilesProtocolLayer, YowCallsProtocolLayer) + YOWSUP_PROTOCOL_LAYERS_BASIC;

        public static object YOWSUP_FULL_STACK = ValueTuple.Create(YOWSUP_PROTOCOL_LAYERS_FULL) + YOWSUP_CORE_LAYERS;
    }
}
