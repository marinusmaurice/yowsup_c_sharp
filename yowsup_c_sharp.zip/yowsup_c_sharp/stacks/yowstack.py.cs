namespace yowsup.stacks
{

    using YowParallelLayer = yowsup.layers.YowParallelLayer;

    using YowLayer = yowsup.layers.YowLayer;

    using YowNoiseLayer = yowsup.layers.noise.layer.YowNoiseLayer;

    using YowNoiseSegmentsLayer = yowsup.layers.noise.layer_noise_segments.YowNoiseSegmentsLayer;

    using YowAuthenticationProtocolLayer = yowsup.layers.auth.YowAuthenticationProtocolLayer;

    using YowCoderLayer = yowsup.layers.coder.YowCoderLayer;

    using YowLoggerLayer = yowsup.layers.logger.YowLoggerLayer;

    using YowNetworkLayer = yowsup.layers.network.YowNetworkLayer;

    using YowMessagesProtocolLayer = yowsup.layers.protocol_messages.YowMessagesProtocolLayer;

    using YowMediaProtocolLayer = yowsup.layers.protocol_media.YowMediaProtocolLayer;

    using YowAckProtocolLayer = yowsup.layers.protocol_acks.YowAckProtocolLayer;

    using YowReceiptProtocolLayer = yowsup.layers.protocol_receipts.YowReceiptProtocolLayer;

    using YowGroupsProtocolLayer = yowsup.layers.protocol_groups.YowGroupsProtocolLayer;

    using YowPresenceProtocolLayer = yowsup.layers.protocol_presence.YowPresenceProtocolLayer;

    using YowIbProtocolLayer = yowsup.layers.protocol_ib.YowIbProtocolLayer;

    using YowNotificationsProtocolLayer = yowsup.layers.protocol_notifications.YowNotificationsProtocolLayer;

    using YowIqProtocolLayer = yowsup.layers.protocol_iq.YowIqProtocolLayer;

    using YowContactsIqProtocolLayer = yowsup.layers.protocol_contacts.YowContactsIqProtocolLayer;

    using YowChatstateProtocolLayer = yowsup.layers.protocol_chatstate.YowChatstateProtocolLayer;

    using YowPrivacyProtocolLayer = yowsup.layers.protocol_privacy.YowPrivacyProtocolLayer;

    using YowProfilesProtocolLayer = yowsup.layers.protocol_profiles.YowProfilesProtocolLayer;

    using YowCallsProtocolLayer = yowsup.layers.protocol_calls.YowCallsProtocolLayer;

    using YowConstants = yowsup.common.constants.YowConstants;

    using AxolotlSendLayer = yowsup.layers.axolotl.AxolotlSendLayer;

    using AxolotlControlLayer = yowsup.layers.axolotl.AxolotlControlLayer;

    using AxolotlReceivelayer = yowsup.layers.axolotl.AxolotlReceivelayer;

    using YowProfile = yowsup.profile.profile.YowProfile;

    using Queue = queue;

    using System;

    using System.Collections.Generic;

    using System.Collections;

    using System.Linq;

    public static class yowstack {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public static Tuple<object, object, object, object, object, object, object, object, object, object, object> YOWSUP_PROTOCOL_LAYERS_BASIC = (YowAuthenticationProtocolLayer, YowMessagesProtocolLayer, YowReceiptProtocolLayer, YowAckProtocolLayer, YowPresenceProtocolLayer, YowIbProtocolLayer, YowIqProtocolLayer, YowNotificationsProtocolLayer, YowContactsIqProtocolLayer, YowChatstateProtocolLayer, YowCallsProtocolLayer);
        
        public class YowStackBuilder
            : object {
            
            public Dictionary<object, object> _props;
            
            public List<object> layers;
            
            public YowStackBuilder() {
                this.layers = ValueTuple.Create("<Empty>");
                this._props = new Dictionary<object, object> {
                };
            }
            
            public virtual object setProp(object key, object value) {
                this._props[key] = value;
                return this;
            }
            
            public virtual object pushDefaultLayers() {
                var defaultLayers = YowStackBuilder.getDefaultLayers();
                this.layers += defaultLayers;
                return this;
            }
            
            public virtual object push(object yowLayer) {
                this.layers += ValueTuple.Create(yowLayer);
                return this;
            }
            
            public virtual object pop() {
                this.layers = this.layers[:: - 1];
                return this;
            }
            
            public virtual object build() {
                return new YowStack(this.layers, reversed: false, props: this._props);
            }
            
            [staticmethod]
            public static object getDefaultLayers(object groups = true, object media = true, object privacy = true, object profiles = true) {
                var coreLayers = YowStackBuilder.getCoreLayers();
                var protocolLayers = YowStackBuilder.getProtocolLayers(groups: groups, media: media, privacy: privacy, profiles: profiles);
                var allLayers = coreLayers;
                allLayers += ValueTuple.Create(AxolotlControlLayer);
                allLayers += ValueTuple.Create(YowParallelLayer((AxolotlSendLayer, AxolotlReceivelayer)));
                allLayers += ValueTuple.Create(YowParallelLayer(protocolLayers));
                return allLayers;
            }
            
            // 
            //         :param layer: An optional layer to put on top of default stack
            //         :param axolotl: E2E encryption enabled/ disabled
            //         :return: YowStack
            //         
            [staticmethod]
            public static object getDefaultStack(
                object layer = null,
                object axolotl = false,
                object groups = true,
                object media = true,
                object privacy = true,
                object profiles = true) {
                var allLayers = YowStackBuilder.getDefaultLayers(axolotl, groups: groups, media: media, privacy: privacy, profiles: profiles);
                if (layer) {
                    allLayers = allLayers + ValueTuple.Create(layer);
                }
                return new YowStack(allLayers, reversed: false);
            }
            
            [staticmethod]
            public static object getCoreLayers() {
                return (YowLoggerLayer, YowCoderLayer, YowNoiseLayer, YowNoiseSegmentsLayer, YowNetworkLayer)[: - 1:];
            }
            
            [staticmethod]
            public static object getProtocolLayers(object groups = true, object media = true, object privacy = true, object profiles = true) {
                var layers = YOWSUP_PROTOCOL_LAYERS_BASIC;
                if (groups) {
                    layers += ValueTuple.Create(YowGroupsProtocolLayer);
                }
                if (media) {
                    layers += ValueTuple.Create(YowMediaProtocolLayer);
                }
                if (privacy) {
                    layers += ValueTuple.Create(YowPrivacyProtocolLayer);
                }
                if (profiles) {
                    layers += ValueTuple.Create(YowProfilesProtocolLayer);
                }
                return layers;
            }
        }
        
        public class YowStack
            : object {
            
            public object @__detachedQueue;
            
            public object @__stack;
            
            public List<object> @__stackInstances;
            
            public Dictionary<object, object> _props;
            
            public List<object> @__stack = new List<object>();
            
            public List<object> @__stackInstances = new List<object>();
            
            public object @__detachedQueue = Queue.Queue();
            
            public YowStack(object stackClassesArr = null, object reversed = true, object props = null) {
                stackClassesArr = stackClassesArr || ValueTuple.Create("<Empty>");
                this.@__stack = reversed ? stackClassesArr[: - 1:] : stackClassesArr;
                this.@__stackInstances = new List<object>();
                this._props = props || new Dictionary<object, object> {
                };
                this.setProp(YowNetworkLayer.PROP_ENDPOINT, YowConstants.ENDPOINTS[random.randint(0, YowConstants.ENDPOINTS.Count - 1)]);
                this._construct();
            }
            
            public virtual object getLayerInterface(object YowLayerClass) {
                foreach (var inst in this.@__stackInstances) {
                    if (inst.@__class__ == YowLayerClass) {
                        return inst.getLayerInterface();
                    } else if (inst.@__class__ == YowParallelLayer) {
                        var res = inst.getLayerInterface(YowLayerClass);
                        if (res) {
                            return res;
                        }
                    }
                }
            }
            
            public virtual object send(object data) {
                this.@__stackInstances[-1].send(data);
            }
            
            public virtual object receive(object data) {
                this.@__stackInstances[0].receive(data);
            }
            
            public virtual object setCredentials(object credentials) {
                logger.warning("setCredentials is deprecated and any passed-in keypair is ignored, use setProfile(YowProfile) instead");
                var _tup_1 = credentials;
                var profile_name = _tup_1.Item1;
                var keypair = _tup_1.Item2;
                this.setProfile(YowProfile(profile_name));
            }
            
            // 
            //         :param profile: profile to use.
            //         :return:
            //         
            public virtual object setProfile(object profile) {
                // type: (str | YowProfile) -> None
                logger.debug(String.Format("setProfile(%s)", profile));
                this.setProp("profile", profile is YowProfile ? profile : YowProfile(profile));
            }
            
            public virtual object addLayer(object layerClass) {
                this.@__stack.push(layerClass);
            }
            
            public virtual object addPostConstructLayer(object layer) {
                this.@__stackInstances[-1].setLayers(layer, this.@__stackInstances[-2]);
                layer.setLayers(null, this.@__stackInstances[-1]);
                this.@__stackInstances.append(layer);
            }
            
            public virtual object setProp(object key, object value) {
                this._props[key] = value;
            }
            
            public virtual object getProp(object key, object @default = null) {
                return this._props.Contains(key) ? this._props[key] : @default;
            }
            
            public virtual object emitEvent(object yowLayerEvent) {
                if (!this.@__stackInstances[0].onEvent(yowLayerEvent)) {
                    this.@__stackInstances[0].emitEvent(yowLayerEvent);
                }
            }
            
            public virtual object boadcastEvent(object yowLayerEvent) {
                if (!this.@__stackInstances[-1].onEvent(yowLayerEvent)) {
                    this.@__stackInstances[-1].boadcastEvent(yowLayerEvent);
                }
            }
            
            public virtual object execDetached(object fn) {
                this.@__class__.@__detachedQueue.put(fn);
            }
            
            public virtual object loop(Hashtable kwargs, params object [] args) {
                while (true) {
                    try {
                        var callback = this.@__class__.@__detachedQueue.get(false);
                        callback();
                    } catch {
                    }
                    time.sleep(0.1);
                }
            }
            
            public virtual object _construct() {
                logger.debug("Initializing stack");
                foreach (var s in this.@__stack) {
                    if (object.ReferenceEquals(type(s), tuple)) {
                        logger.warn("Implicit declaration of parallel layers in a tuple is deprecated, pass a YowParallelLayer instead");
                        var inst = YowParallelLayer(s);
                    } else if (inspect.isclass(s)) {
                        if (issubclass(s, YowLayer)) {
                            inst = s();
                        } else {
                            throw new ValueError("Stack must contain only subclasses of YowLayer");
                        }
                    } else if (issubclass(s.@__class__, YowLayer)) {
                        inst = s;
                    } else {
                        throw new ValueError("Stack must contain only subclasses of YowLayer");
                        //inst = s()
                    }
                    logger.debug(String.Format("Constructed %s", inst));
                    inst.setStack(this);
                    this.@__stackInstances.append(inst);
                }
                foreach (var i in Enumerable.Range(0, this.@__stackInstances.Count - 0)) {
                    var upperLayer = i + 1 < this.@__stackInstances.Count ? this.@__stackInstances[i + 1] : null;
                    var lowerLayer = i > 0 ? this.@__stackInstances[i - 1] : null;
                    this.@__stackInstances[i].setLayers(upperLayer, lowerLayer);
                }
            }
            
            public virtual object getLayer(object layerIndex) {
                return this.@__stackInstances[layerIndex];
            }
        }
    }
}
