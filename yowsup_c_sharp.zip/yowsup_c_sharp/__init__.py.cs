public static class @__init__ {
    
    public static string @__version__ = "3.2.3";
    
    public static string @__author__ = "Tarek Galal";
    
    public static logger logger = logging.getLogger(@__name__);
    
    public static object ch = logging.StreamHandler();
    
    static @__init__() {
        ch.setLevel(logging.DEBUG);
        ch.setFormatter(formatter);
        logger.addHandler(ch);
    }
    
    public static object formatter = logging.Formatter("%(levelname).1s %(asctime)s %(name)s - %(message)s");
}
