namespace yowsup.config.transforms {
    
    using ConfigTransform = yowsup.config.@base.transform.ConfigTransform;
    
    using System.Collections.Generic;
    
    using System;
    
    public static class dict_keyval {
        
        public class DictKeyValTransform
            : ConfigTransform {
            
            // 
            //         :param data:
            //         :type data: dict
            //         :return:
            //         :rtype:
            //         
            public virtual object transform(object data) {
                var @out = new List<object>();
                var keys = data.keys().OrderBy(_p_1 => _p_1).ToList();
                foreach (var k in keys) {
                    @out.append(String.Format("%s=%s", k, data[k]));
                }
                return "\n".join(@out);
            }
            
            public virtual object reverse(object data) {
                var @out = new Dictionary<object, object> {
                };
                foreach (var l in data.split("\n")) {
                    var line = l.strip();
                    if (line.Count && !("#", ";").Contains(line[0])) {
                        var prep = line.split("#", 1)[0].split(";", 1)[0].split("=", 1);
                        var varname = prep[0].strip();
                        var val = prep[1].strip();
                        @out[varname.replace("-", "_")] = val;
                    }
                }
                return @out;
            }
        }
    }
}
