namespace yowsup.config.transforms {
    
    using ConfigTransform = yowsup.config.@base.transform.ConfigTransform;
    
    using System.Collections.Generic;
    
    public static class filter {
        
        public class FilterTransform
            : ConfigTransform {
            
            public object _reverse_filter;
            
            public object _transform_filter;
            
            public FilterTransform(object transform_filter = null, object reverse_filter = null) {
                this._transform_filter = transform_filter;
                this._reverse_filter = reverse_filter;
            }
            
            public virtual object transform(object data) {
                if (this._transform_filter != null) {
                    var @out = new Dictionary<object, object> {
                    };
                    foreach (var _tup_1 in data.items()) {
                        var key = _tup_1.Item1;
                        var val = _tup_1.Item2;
                        if (this._transform_filter(key, val)) {
                            @out[key] = val;
                        }
                    }
                    return @out;
                }
                return data;
            }
            
            public virtual object reverse(object data) {
                if (this._reverse_filter != null) {
                    var @out = new Dictionary<object, object> {
                    };
                    foreach (var _tup_1 in data.items()) {
                        var key = _tup_1.Item1;
                        var val = _tup_1.Item2;
                        if (this._reverse_filter(key, val)) {
                            @out[key] = val;
                        }
                    }
                    return @out;
                }
                return data;
            }
        }
    }
}
