namespace yowsup.config.transforms {
    
    using ConfigTransform = yowsup.config.@base.transform.ConfigTransform;
    
    using System.Collections.Generic;
    
    public static class map {
        
        public class MapTransform
            : ConfigTransform {
            
            public object _reverse_map;
            
            public object _transform_map;
            
            public MapTransform(object transform_map = null, object reverse_map = null) {
                this._transform_map = transform_map;
                this._reverse_map = reverse_map;
            }
            
            public virtual object transform(object data) {
                if (this._transform_map != null) {
                    var @out = new Dictionary<object, object> {
                    };
                    foreach (var _tup_1 in data.items()) {
                        var key = _tup_1.Item1;
                        var val = _tup_1.Item2;
                        var _tup_2 = this._transform_map(key, val);
                        key = _tup_2.Item1;
                        val = _tup_2.Item2;
                        @out[key] = val;
                    }
                    return @out;
                }
                return data;
            }
            
            public virtual object reverse(object data) {
                if (this._reverse_map != null) {
                    var @out = new Dictionary<object, object> {
                    };
                    foreach (var _tup_1 in data.items()) {
                        var key = _tup_1.Item1;
                        var val = _tup_1.Item2;
                        var _tup_2 = this._reverse_map(key, val);
                        key = _tup_2.Item1;
                        val = _tup_2.Item2;
                        @out[key] = val;
                    }
                    return @out;
                }
                return data;
            }
        }
    }
}
