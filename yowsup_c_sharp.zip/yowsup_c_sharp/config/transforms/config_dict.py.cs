namespace yowsup.config.transforms {
    
    using ConfigTransform = yowsup.config.@base.transform.ConfigTransform;
    
    using System.Collections.Generic;
    
    public static class config_dict {
        
        public class ConfigDictTransform
            : ConfigTransform {
            
            public object _cls;
            
            public ConfigDictTransform(object cls) {
                this._cls = cls;
            }
            
            // 
            //         :param config:
            //         :type config: dict
            //         :return:
            //         :rtype: yowsup.config.config.Config
            //         
            public virtual object transform(object config) {
                var @out = new Dictionary<object, object> {
                };
                foreach (var prop in vars(config)) {
                    @out[prop] = getattr(config, prop);
                }
                return @out;
            }
            
            // 
            //         :param data:
            //         :type data: yowsup,config.config.Config
            //         :return:
            //         :rtype: dict
            //         
            public virtual object reverse(object data) {
                return this._cls(data);
            }
        }
    }
}
