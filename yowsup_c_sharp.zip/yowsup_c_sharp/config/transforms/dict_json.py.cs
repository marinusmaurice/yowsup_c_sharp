namespace yowsup.config.transforms
{

    using ConfigTransform = yowsup.config.@base.transform.ConfigTransform;

    public static class dict_json {
        
        public class DictJsonTransform
            : ConfigTransform {
            
            public virtual object transform(object data) {
                return json.dumps(data, sort_keys: true, indent: 4, separators: (",", ": "));
            }
            
            public virtual object reverse(object data) {
                return json.loads(data);
            }
        }
    }
}
