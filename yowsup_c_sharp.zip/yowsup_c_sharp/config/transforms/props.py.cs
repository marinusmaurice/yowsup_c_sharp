using ConfigTransform = yowsup.config.@base.transform.ConfigTransform;

using System.Collections.Generic;

namespace yowsup.config.transforms
{ 
    public static class props {
        
        public class PropsTransform
            : ConfigTransform {
            
            public Dictionary<object, object> _reverse_map;
            
            public Dictionary<object, object> _transform_map;
            
            public PropsTransform(object transform_map = null, object reverse_map = null) {
                this._transform_map = transform_map || new Dictionary<object, object> {
                };
                this._reverse_map = reverse_map || new Dictionary<object, object> {
                };
            }
            
            // 
            //         :param data:
            //         :type data: dict
            //         :return:
            //         :rtype: dict
            //         
            public virtual object transform(object data) {
                var @out = new Dictionary<object, object> {
                };
                foreach (var _tup_1 in data.items()) {
                    var key = _tup_1.Item1;
                    var val = _tup_1.Item2;
                    if (this._transform_map.Contains(key)) {
                        var target = this._transform_map[key];
                        var _tup_2 = type(target) == types.FunctionType ? target(key, val) : (key, target);
                        key = _tup_2.Item1;
                        val = _tup_2.Item2;
                    }
                    @out[key] = val;
                }
                return @out;
            }
            
            public virtual object reverse(object data) {
                var transformed_dict = new Dictionary<object, object> {
                };
                foreach (var _tup_1 in data.items()) {
                    var key = _tup_1.Item1;
                    var val = _tup_1.Item2;
                    if (this._reverse_map.Contains(key)) {
                        var target = this._reverse_map[key];
                        var _tup_2 = type(target) == types.FunctionType ? target(key, val) : (key, target);
                        key = _tup_2.Item1;
                        val = _tup_2.Item2;
                    }
                    transformed_dict[key] = val;
                }
                return transformed_dict;
            }
        }
    }
}
