namespace yowsup.config.transforms {
    
    using PropsTransform = yowsup.config.transforms.props.PropsTransform;
    
    using System.Collections.Generic;
    
    public static class serialize {
        
        public class SerializeTransform
            : PropsTransform {
            
            public SerializeTransform(object serialize_map) {
                var transform_map = new Dictionary<object, object> {
                };
                var reverse_map = new Dictionary<object, object> {
                };
                foreach (var _tup_1 in serialize_map) {
                    var key = _tup_1.Item1;
                    var val = _tup_1.Item2;
                    transform_map[key] = Tuple.Create((key,val) => key, serialize_map[key].serialize(val));
                    reverse_map[key] = Tuple.Create((key,val) => key, serialize_map[key].deserialize(val));
                }
                super(SerializeTransform, this).@__init__(transform_map: transform_map, reverse_map: reverse_map);
            }
        }
    }
}
