namespace yowsup.config.transforms
{

    using ConfigTransform = yowsup.config.@base.transform.ConfigTransform;

    using System.Collections.Generic;

    public static class meta {
        
        public class MetaPropsTransform
            : ConfigTransform {
            
            public object _props_transform;
            
            public string META_FORMAT;
            
            public string META_FORMAT = "__%s__";
            
            public MetaPropsTransform(object meta_props = null, object meta_format = META_FORMAT) {
                meta_props = meta_props || ValueTuple.Create("<Empty>");
                meta_format = meta_format;
                var transform_map = new Dictionary<object, object> {
                };
                var reverse_map = new Dictionary<object, object> {
                };
                foreach (var prop in meta_props) {
                    var formatted = meta_format % prop;
                    transform_map[prop] = (key,val,formatted) => (formatted, val);
                    reverse_map[formatted] = (key,val,prop) => (prop, val);
                }
                this._props_transform = PropsTransform(transform_map: transform_map, reverse_map: reverse_map);
            }
            
            public virtual object transform(object data) {
                return this._props_transform.transform(data);
            }
            
            public virtual object reverse(object data) {
                return this._props_transform.reverse(data);
            }
        }
    }
}
