namespace yowsup.config.transforms {
    
    public static class @__init__ {
    }
}
