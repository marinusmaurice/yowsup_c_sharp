namespace yowsup.config
{

    using Config = yowsup.config.v1.config.Config;

    using DictKeyValTransform = yowsup.config.transforms.dict_keyval.DictKeyValTransform;

    using DictJsonTransform = yowsup.config.transforms.dict_json.DictJsonTransform;

    using StorageTools = yowsup.common.tools.StorageTools;

    using System.Collections.Generic;

    using System;
    using System.IO;

    public static class manager {
        
        public static logger logger = logging.getLogger(@__name__);
        
        public class ConfigManager
             {
            
            //public Dictionary<string, int> MAP_EXT;
            
            //public string NAME_FILE_CONFIG;
            
            //public int TYPE_JSON;
            
            //public int TYPE_KEYVAL;
            
            //public Dictionary<int, string> TYPE_NAMES;
            
            //public Dictionary<int, object> TYPES;
            
            public string NAME_FILE_CONFIG = "config";
            
            public static int TYPE_KEYVAL = 1;
            
            public static int TYPE_JSON = 2;
            
            public Dictionary<int, string> TYPE_NAMES = new Dictionary<int, string> {
                {
                    TYPE_KEYVAL,
                    "keyval"},
                {
                    TYPE_JSON,
                    "json"}};
            
            public Dictionary<string, int> MAP_EXT = new Dictionary<string, int> {
                {
                    "yo",
                    TYPE_KEYVAL},
                {
                    "json",
                    TYPE_JSON}};
            
            public Dictionary<int, object> TYPES = new Dictionary<object, object> {
                {
                    TYPE_KEYVAL,
                    DictKeyValTransform},
                {
                    TYPE_JSON,
                    DictJsonTransform}};
            
            // 
            //         Will first try to interpret path_or_profile_name as direct path to a config file and load from there. If
            //         this fails will interpret it as profile name and load from profile dir.
            //         :param path_or_profile_name:
            //         :param profile_only
            //         :return Config instance, or None if no config could be found
            //         
            public virtual object load(object path_or_profile_name, bool profile_only = false) {
                string fname;
                object config;
                // type: (str, bool) -> Config
                logger.debug(string.Format("load(path_or_profile_name=%s, profile_only=%s)", path_or_profile_name, profile_only));
                List<object> exhausted = new List<object>();
                if (!profile_only) {
                    config = this._load_path(path_or_profile_name);
                } else {
                    config = null;
                }
                if (config != null) {
                    return config;
                } else {
                    logger.debug("path_or_profile_name is not a path, using it as profile name");
                    if (!profile_only) {
                        exhausted.Add(path_or_profile_name);
                    }
                    var profile_name = path_or_profile_name;
                    string config_dir = StorageTools.getStorageForProfile(profile_name).ToString();
                    logger.debug(String.Format("Detecting config for profile=%s, dir=%s", profile_name, config_dir));
                    foreach (var ftype in this.MAP_EXT) {
                        if (ftype.Key.Length > 0) {
                            fname = this.NAME_FILE_CONFIG + "." + ftype;
                        } else {
                            fname = this.NAME_FILE_CONFIG;
                        }
                        var fpath = Path.Combine(config_dir, fname);
                        logger.debug(String.Format("Trying %s", fpath));

                        FileAttributes attr = File.GetAttributes(fpath);
                        if(!attr.HasFlag(FileAttributes.Directory))
                        {
                            return this._load_path(fpath);
                        }
                        exhausted.Add(fpath);
                    }
                    logger.error(String.Format("Could not find a config for profile=%s, paths checked: %s", profile_name, ":".join(exhausted)));
                }
            }
            
            // 
            //         :param type:
            //         :type type: int
            //         :return:
            //         :rtype:
            //         
            public virtual object _type_to_str(object type) {
                foreach (var _tup_1 in this.TYPE_NAMES.items()) {
                    var key = _tup_1.Item1;
                    var val = _tup_1.Item2;
                    if (key == type) {
                        return val;
                    }
                }
            }
            
            // 
            //         :param path:
            //         :type path:
            //         :return:
            //         :rtype:
            //         
            public virtual object _load_path(object path) {
                logger.debug(String.Format("_load_path(path=%s)", path));
                if (os.path.isfile(path)) {
                    var configtype = this.guess_type(path);
                    logger.debug(String.Format("Detected config type: %s", this._type_to_str(configtype)));
                    if (this.TYPES.Contains(configtype)) {
                        logger.debug("Opening config for reading");
                        using (var f = open(path, "r")) {
                            data = f.read();
                        }
                        var datadict = this.TYPES[configtype]().reverse(data);
                        return this.load_data(datadict);
                    } else {
                        throw new ValueError("Unsupported config type");
                    }
                } else {
                    logger.debug(String.Format("_load_path couldn't find the path: %s", path));
                }
            }
            
            public virtual object load_data(object datadict) {
                logger.debug("Loading config");
                return ConfigSerialize(Config).deserialize(datadict);
            }
            
            public virtual object guess_type(object config_path) {
                object config_type;
                var dissected = os.path.splitext(config_path);
                if (dissected.Count > 1) {
                    var ext = dissected[1][1].lower();
                    config_type = this.MAP_EXT.Contains(ext) ? this.MAP_EXT[ext] : null;
                } else {
                    config_type = null;
                }
                if (config_type != null) {
                    return config_type;
                } else {
                    logger.debug("Trying auto detect config type by parsing");
                    using (var f = open(config_path, "r")) {
                        data = f.read();
                    }
                    foreach (var _tup_1 in this.TYPES.items()) {
                        config_type = _tup_1.Item1;
                        var transform = _tup_1.Item2;
                        var config_type_str = this.TYPE_NAMES[config_type];
                        try {
                            logger.debug(String.Format("Trying to parse as %s", config_type_str));
                            if (transform().reverse(data)) {
                                logger.debug(String.Format("Successfully detected %s as config type for %s", config_type_str, config_path));
                                return config_type;
                            }
                        } catch (Exception) {
                            logger.debug(String.Format("%s was not parseable as %s, reason: %s", config_path, config_type_str, ex));
                        }
                    }
                }
            }
            
            public virtual object get_str_transform(object serialize_type) {
                if (this.TYPES.Contains(serialize_type)) {
                    return this.TYPES[serialize_type]();
                }
            }
            
            public virtual object config_to_str(object config, object serialize_type = TYPE_JSON) {
                var transform = this.get_str_transform(serialize_type);
                if (transform != null) {
                    return transform.transform(ConfigSerialize(config.@__class__).serialize(config));
                }
                throw new ValueError(String.Format("unrecognized serialize_type=%d", serialize_type));
            }
            
            public virtual object save(object profile_name, object config, object serialize_type = TYPE_JSON, object dest = null) {
                var outputdata = this.config_to_str(config, serialize_type);
                if (dest == null) {
                    StorageTools.writeProfileConfig(profile_name, outputdata);
                } else {
                    using (var outputfile = open(dest, "wb")) {
                        outputfile.write(outputdata);
                    }
                }
            }
        }
    }
}
