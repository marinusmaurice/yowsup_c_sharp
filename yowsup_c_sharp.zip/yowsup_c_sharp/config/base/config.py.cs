using System;
using System.Collections.Generic;
using System.Linq;

namespace yowsup.config.@base
{ 
    public static class config
    {

        public class Config
        {
            // Store items here.
            private Dictionary<object, object> Entries = new Dictionary<object, object>();
            private object DefaultValue;

            public object _version;

            public Config(object version)
            {
                this._version = version;
            }

            public object this[object key]
            {
                get
                {
                    // Return the value for this key or the default value.
                    if (Entries.ContainsKey(key)) return Entries[key];
                    return DefaultValue;
                }
                set
                {
                    // Set the property's value for the key.
                    Entries.Add(key, value);
                }
            }

            public virtual object @__contains__(object item)
            {
                return this[item] != null;
            }

            public virtual object @__getitem__(object item)
            {
                return this[String.Format("_%s", item)];
            }

            public virtual object @__setitem__(object key, object value)
            {
                Entries.Add(key, value);
                return null;
            }

            public virtual object keys()
            {
                return (from var in Entries.Keys
                        select var).ToList();
            }

            public object version
            {
                get
                {
                    return this._version;
                }
            }
        }
    }



}
