namespace yowsup.config.@base {
    
    public static class @__init__ {
    }
}
