namespace yowsup.config.@base {
    
    public static class serialize {
        
        public class ConfigSerialize
            {
            
            public object _transforms;
            
            public ConfigSerialize(object transforms) {
                this._transforms = transforms;
            }
            
            // 
            //         :param config:
            //         :type config: yowsup.config.base.config.Config
            //         :return:
            //         :rtype: bytes
            //         
            public virtual object serialize(yowsup.config.@base.config.Config config) {
                foreach (var transform in this._transforms) {
                    config = transform.transform(config);
                }
                return config;
            }
            
            // 
            //         :type cls: type
            //         :param data:
            //         :type data: bytes
            //         :return:
            //         :rtype: yowsup.config.base.config.Config
            //         
            public virtual object deserialize(object data) {
                foreach (var transform in this._transforms[: - 1:]) {
                    data = transform.reverse(data);
                }
                return data;
            }
        }
    }
}
