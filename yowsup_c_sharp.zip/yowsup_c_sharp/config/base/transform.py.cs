namespace yowsup.config.@base {
    
    public static class transform {
        
        public class ConfigTransform
            {
            
            // 
            //         :param config:
            //         :type config: yowsup.config.base.config.Config
            //         :return: dict
            //         :rtype:
            //         
            public virtual object transform(yowsup.config.@base.config.Config config) {
                return null; //TODO: added this
            }
            
            // 
            //         :param data:
            //         :type data:
            //         :return:
            //         :rtype: yowsup.config.base.config.Config
            //         
            public virtual yowsup.config.@base.config.Config reverse(object data) {
                return null; //TODO: added this
            }
        }
    }
}
