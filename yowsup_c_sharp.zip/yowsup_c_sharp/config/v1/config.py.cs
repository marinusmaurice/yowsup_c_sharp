using config = yowsup.config.@base.config;

namespace yowsup.config.v1
{
     
    public static class config {
        
        public static logger logger = logging.getLogger("@__name__");
        
        public class Config
            : yowsup.config.@base.config.Config {
            
            public object _cc;
            
            public object _chat_dns_domain;
            
            public object _client_static_keypair;
            
            public object _edge_routing_info;
            
            public object _expid;
            
            public object _fdid;
            
            public object _id;
            
            public object _login;
            
            public object _mcc;
            
            public object _mnc;
            
            public object _password;
            
            public string _phone;
            
            public object _pushname;
            
            public object _server_static_public;
            
            public object _sim_mcc;
            
            public object _sim_mnc;
            
            public Config(
                object phone = null,
                object cc = null,
                object login = null,
                object password = null,
                object pushname = null,
                object id = null,
                object mcc = null,
                object mnc = null,
                object sim_mcc = null,
                object sim_mnc = null,
                object client_static_keypair = null,
                object server_static_public = null,
                object expid = null,
                object fdid = null,
                object edge_routing_info = null,
                object chat_dns_domain = null) {
                this._phone = phone != null ? phone.ToString() : null;
                this._cc = cc;
                this._login = login != null ? login.ToString() : null;
                this._password = password;
                this._pushname = pushname;
                this._id = id;
                this._client_static_keypair = client_static_keypair;
                this._server_static_public = server_static_public;
                this._expid = expid;
                this._fdid = fdid;
                this._mcc = mcc;
                this._mnc = mnc;
                this._sim_mcc = sim_mcc;
                this._sim_mnc = sim_mnc;
                this._edge_routing_info = edge_routing_info;
                this._chat_dns_domain = chat_dns_domain;
                if (this._password != null) {
                    logger.warn("Setting a password in Config is deprecated and not used anymore. client_static_keypair is used instead");
                }
            }
            
            public override string ToString() {
                return DictJsonTransform().transform(ConfigSerialize(this.@__class__).serialize(this));
            }
            
            public object phone {
                get {
                    return this._phone;
                }
                set {
                    this._phone = value != null ? value.ToString() : null;
                }
            }
            
            public object cc {
                get {
                    return this._cc;
                }
                set {
                    this._cc = value;
                }
            }
            
            public object login {
                get {
                    return this._login;
                }
                set {
                    this._login = value;
                }
            }
            
            public object password {
                get {
                    return this._password;
                }
                set {
                    this._password = value;
                    if (value != null) {
                        logger.warn("Setting a password in Config is deprecated and not used anymore. client_static_keypair is used instead");
                    }
                }
            }
            
            public object pushname {
                get {
                    return this._pushname;
                }
                set {
                    this._pushname = value;
                }
            }
            
            public object mcc {
                get {
                    return this._mcc;
                }
                set {
                    this._mcc = value;
                }
            }
            
            public object mnc {
                get {
                    return this._mnc;
                }
                set {
                    this._mnc = value;
                }
            }
            
            public object sim_mcc {
                get {
                    return this._sim_mcc;
                }
                set {
                    this._sim_mcc = value;
                }
            }
            
            public object sim_mnc {
                get {
                    return this._sim_mnc;
                }
                set {
                    this._sim_mnc = value;
                }
            }
            
            public object id {
                get {
                    return this._id;
                }
                set {
                    this._id = value;
                }
            }
            
            public object client_static_keypair {
                get {
                    return this._client_static_keypair;
                }
                set {
                    this._client_static_keypair = value;
                }
            }
            
            public object server_static_public {
                get {
                    return this._server_static_public;
                }
                set {
                    this._server_static_public = value;
                }
            }
            
            public object expid {
                get {
                    return this._expid;
                }
                set {
                    this._expid = value;
                }
            }
            
            public object fdid {
                get {
                    return this._fdid;
                }
                set {
                    this._fdid = value;
                }
            }
            
            public object edge_routing_info {
                get {
                    return this._edge_routing_info;
                }
                set {
                    this._edge_routing_info = value;
                }
            }
            
            public object chat_dns_domain {
                get {
                    return this._chat_dns_domain;
                }
                set {
                    this._chat_dns_domain = value;
                }
            }
        }
    }
}
