namespace yowsup.config.v1
{

    using serialize = yowsup.config.@base.serialize;

    public static class serialize {
        
        public class ConfigSerialize
            : serialize.ConfigSerialize {
            
            public ConfigSerialize(object config_class) {
            }
        }
    }
}
