namespace yowsup.config.v1 {
    
    public static class @__init__ {
    }
}
