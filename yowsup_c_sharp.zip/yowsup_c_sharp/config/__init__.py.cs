namespace yowsup.config {
    
    public static class @__init__ {
    }
}
