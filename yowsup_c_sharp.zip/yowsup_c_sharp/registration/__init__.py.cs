namespace yowsup.registration
{

    public static class @__init__ {
    }
}
