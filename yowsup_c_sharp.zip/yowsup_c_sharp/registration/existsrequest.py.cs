namespace yowsup.registration
{

    using WARequest = yowsup.common.http.warequest.WARequest;

    using YowsupEnv = yowsup.env.YowsupEnv;

    using System.Collections.Generic;

    public static class existsrequest {
        
        public class WAExistsRequest
            : WARequest {
            
            public List<string> pvars;
            
            public string url;
            
            public WAExistsRequest(object config) {
                if (config.id == null) {
                    throw new ValueError("Config does not contain id");
                }
                this.url = "v.whatsapp.net/v2/exist";
                this.pvars = new List<string> {
                    "status",
                    "reason",
                    "sms_length",
                    "voice_length",
                    "result",
                    "param",
                    "login",
                    "type",
                    "chat_dns_domain",
                    "edge_routing_info"
                };
                this.setParser(JSONResponseParser());
                this.addParam("token", YowsupEnv.getCurrent().getToken(this._p_in));
            }
        }
    }
}
