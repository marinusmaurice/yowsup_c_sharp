namespace yowsup.registration
{

    using WARequest = yowsup.common.http.warequest.WARequest;

    using WATools = yowsup.common.tools.WATools;

    using YowsupEnv = yowsup.env.YowsupEnv;

    using System.Collections.Generic;

    public static class coderequest {
        
        public class WACodeRequest
            : WARequest {
            
            public List<string> pvars;
            
            public string url;
            
            public WACodeRequest(object method, object config) {
                this.addParam("mcc", config.mcc.zfill(3));
                this.addParam("mnc", config.mnc.zfill(3));
                this.addParam("sim_mcc", config.sim_mcc.zfill(3));
                this.addParam("sim_mnc", config.sim_mnc.zfill(3));
                this.addParam("method", method);
                this.addParam("reason", "");
                this.addParam("token", YowsupEnv.getCurrent().getToken(this._p_in));
                this.addParam("hasav", "1");
                this.url = "v.whatsapp.net/v2/code";
                this.pvars = new List<string> {
                    "status",
                    "reason",
                    "length",
                    "method",
                    "retry_after",
                    "code",
                    "param"
                } + new List<string> {
                    "login",
                    "type",
                    "sms_wait",
                    "voice_wait"
                };
                this.setParser(JSONResponseParser());
            }
            
            public virtual object send(object parser = null, object encrypt = true, object preview = false) {
                if (this._config.id != null) {
                    var request = WAExistsRequest(this._config);
                    var result = request.send(encrypt: encrypt, preview: preview);
                    if (result) {
                        if (result["status"] == "ok") {
                            return result;
                        } else if (result["status"] == "fail" && result.Contains("reason") && result["reason"] == "blocked") {
                            return result;
                        }
                    }
                } else {
                    this._config.id = WATools.generateIdentity();
                    this.addParam("id", this._config.id);
                }
                var res = super(WACodeRequest, this).send(parser, encrypt: encrypt, preview: preview);
                return res;
            }
        }
    }
}
